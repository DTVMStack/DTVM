
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-wt45/func-51.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
   8:	4d 8b 52 18          	mov    0x18(%r10),%r10
   c:	49 83 c2 20          	add    $0x20,%r10
  10:	4c 3b d4             	cmp    %rsp,%r10
  13:	0f 87 e5 00 00 00    	ja     0xfe
  19:	48 83 ec 10          	sub    $0x10,%rsp
  1d:	48 89 1c 24          	mov    %rbx,(%rsp)
  21:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
  26:	48 89 fe             	mov    %rdi,%rsi
  29:	c4 e1 f9 7e c7       	vmovq  %xmm0,%rdi
  2e:	48 89 f8             	mov    %rdi,%rax
  31:	48 c1 e8 34          	shr    $0x34,%rax
  35:	48 89 c1             	mov    %rax,%rcx
  38:	81 e1 ff 07 00 00    	and    $0x7ff,%ecx
  3e:	81 f9 ff 07 00 00    	cmp    $0x7ff,%ecx
  44:	0f 84 a2 00 00 00    	je     0xec
  4a:	a9 ff 07 00 00       	test   $0x7ff,%eax
  4f:	0f 85 69 00 00 00    	jne    0xbe
  55:	c5 f9 2e 05 a3 00 00 	vucomisd 0xa3(%rip),%xmm0        # 0x100
  5c:	00 
  5d:	0f 8a 28 00 00 00    	jp     0x8b
  63:	0f 85 22 00 00 00    	jne    0x8b
  69:	48 89 f7             	mov    %rsi,%rdi
  6c:	48 8b 47 38          	mov    0x38(%rdi),%rax
  70:	8b ca                	mov    %edx,%ecx
  72:	c7 04 08 00 00 00 00 	movl   $0x0,(%rax,%rcx,1)
  79:	48 8b 1c 24          	mov    (%rsp),%rbx
  7d:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  82:	48 83 c4 10          	add    $0x10,%rsp
  86:	48 89 ec             	mov    %rbp,%rsp
  89:	5d                   	pop    %rbp
  8a:	c3                   	ret
  8b:	48 89 d3             	mov    %rdx,%rbx
  8e:	c5 fb 59 05 7a 00 00 	vmulsd 0x7a(%rip),%xmm0,%xmm0        # 0x110
  95:	00 
  96:	49 89 f4             	mov    %rsi,%r12
  99:	4c 89 e7             	mov    %r12,%rdi
  9c:	e8 5f ff ff ff       	call   0x0
  a1:	49 8b 44 24 38       	mov    0x38(%r12),%rax
  a6:	8b cb                	mov    %ebx,%ecx
  a8:	83 04 08 c0          	addl   $0xffffffc0,(%rax,%rcx,1)
  ac:	48 8b 1c 24          	mov    (%rsp),%rbx
  b0:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  b5:	48 83 c4 10          	add    $0x10,%rsp
  b9:	48 89 ec             	mov    %rbp,%rsp
  bc:	5d                   	pop    %rbp
  bd:	c3                   	ret
  be:	48 89 d3             	mov    %rdx,%rbx
  c1:	49 89 f4             	mov    %rsi,%r12
  c4:	25 ff 07 00 00       	and    $0x7ff,%eax
  c9:	81 c0 02 fc ff ff    	add    $0xfffffc02,%eax
  cf:	49 8b 4c 24 38       	mov    0x38(%r12),%rcx
  d4:	8b d3                	mov    %ebx,%edx
  d6:	89 04 11             	mov    %eax,(%rcx,%rdx,1)
  d9:	48 23 3d 40 00 00 00 	and    0x40(%rip),%rdi        # 0x120
  e0:	48 0b 3d 41 00 00 00 	or     0x41(%rip),%rdi        # 0x128
  e7:	c4 e1 f9 6e c7       	vmovq  %rdi,%xmm0
  ec:	48 8b 1c 24          	mov    (%rsp),%rbx
  f0:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  f5:	48 83 c4 10          	add    $0x10,%rsp
  f9:	48 89 ec             	mov    %rbp,%rsp
  fc:	5d                   	pop    %rbp
  fd:	c3                   	ret
  fe:	0f 0b                	ud2
	...
 114:	00 00                	add    %al,(%rax)
 116:	f0 43 00 00          	lock rex.XB add %al,(%r8)
 11a:	00 00                	add    %al,(%rax)
 11c:	00 00                	add    %al,(%rax)
 11e:	00 00                	add    %al,(%rax)
 120:	ff                   	(bad)
 121:	ff                   	(bad)
 122:	ff                   	(bad)
 123:	ff                   	(bad)
 124:	ff                   	(bad)
 125:	ff 0f                	decl   (%rdi)
 127:	80 00 00             	addb   $0x0,(%rax)
 12a:	00 00                	add    %al,(%rax)
 12c:	00 00                	add    %al,(%rax)
 12e:	e0 3f                	loopne 0x16f
