
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-wt45/func-21.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
   8:	4d 8b 52 18          	mov    0x18(%r10),%r10
   c:	49 83 c2 60          	add    $0x60,%r10
  10:	4c 3b d4             	cmp    %rsp,%r10
  13:	0f 87 7b 02 00 00    	ja     0x294
  19:	48 83 ec 50          	sub    $0x50,%rsp
  1d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
  22:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
  27:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
  2c:	4c 89 74 24 38       	mov    %r14,0x38(%rsp)
  31:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
  36:	48 89 d3             	mov    %rdx,%rbx
  39:	49 89 cc             	mov    %rcx,%r12
  3c:	48 89 3c 24          	mov    %rdi,(%rsp)
  40:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  45:	4c 8b 7f 38          	mov    0x38(%rdi),%r15
  49:	41 8b f8             	mov    %r8d,%edi
  4c:	4d 8d 04 3f          	lea    (%r15,%rdi,1),%r8
  50:	41 8b 4c 3f 10       	mov    0x10(%r15,%rdi,1),%ecx
  55:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  5a:	85 c9                	test   %ecx,%ecx
  5c:	0f 84 0a 00 00 00    	je     0x6c
  62:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  67:	e9 2e 00 00 00       	jmp    0x9a
  6c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  71:	48 8b 34 24          	mov    (%rsp),%rsi
  75:	48 8b 3c 24          	mov    (%rsp),%rdi
  79:	e8 22 ff ff ff       	call   0xffffffffffffffa0
  7e:	33 c9                	xor    %ecx,%ecx
  80:	85 c0                	test   %eax,%eax
  82:	0f 84 08 00 00 00    	je     0x90
  88:	48 89 c8             	mov    %rcx,%rax
  8b:	e9 c4 01 00 00       	jmp    0x254
  90:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  95:	41 8b 4c 3f 10       	mov    0x10(%r15,%rdi,1),%ecx
  9a:	41 8b 54 3f 14       	mov    0x14(%r15,%rdi,1),%edx
  9f:	2b ca                	sub    %edx,%ecx
  a1:	4c 89 e0             	mov    %r12,%rax
  a4:	3b c8                	cmp    %eax,%ecx
  a6:	0f 83 82 00 00 00    	jae    0x12e
  ac:	41 8b 4c 3f 20       	mov    0x20(%r15,%rdi,1),%ecx
  b1:	48 33 c0             	xor    %rax,%rax
  b4:	48 8b 3c 24          	mov    (%rsp),%rdi
  b8:	48 8b b7 28 01 00 00 	mov    0x128(%rdi),%rsi
  bf:	8b d1                	mov    %ecx,%edx
  c1:	48 8d 34 d6          	lea    (%rsi,%rdx,8),%rsi
  c5:	83 f9 05             	cmp    $0x5,%ecx
  c8:	48 0f 43 f0          	cmovae %rax,%rsi
  cc:	48 8b 0e             	mov    (%rsi),%rcx
  cf:	48 89 c8             	mov    %rcx,%rax
  d2:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
  d6:	48 85 c9             	test   %rcx,%rcx
  d9:	0f 84 97 01 00 00    	je     0x276
  df:	8b 48 10             	mov    0x10(%rax),%ecx
  e2:	48 8b 3c 24          	mov    (%rsp),%rdi
  e6:	48 8b 57 28          	mov    0x28(%rdi),%rdx
  ea:	3b 0a                	cmp    (%rdx),%ecx
  ec:	0f 85 a4 01 00 00    	jne    0x296
  f2:	4c 8b 48 08          	mov    0x8(%rax),%r9
  f6:	48 8b 78 18          	mov    0x18(%rax),%rdi
  fa:	48 89 d9             	mov    %rbx,%rcx
  fd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 102:	48 8b 34 24          	mov    (%rsp),%rsi
 106:	4d 89 e0             	mov    %r12,%r8
 109:	41 ff d1             	call   *%r9
 10c:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
 111:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
 116:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
 11b:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
 120:	4c 8b 7c 24 40       	mov    0x40(%rsp),%r15
 125:	48 83 c4 50          	add    $0x50,%rsp
 129:	48 89 ec             	mov    %rbp,%rsp
 12c:	5d                   	pop    %rbp
 12d:	c3                   	ret
 12e:	4d 89 e0             	mov    %r12,%r8
 131:	41 8b 44 3f 40       	mov    0x40(%r15,%rdi,1),%eax
 136:	33 f6                	xor    %esi,%esi
 138:	85 c0                	test   %eax,%eax
 13a:	0f 8d 15 00 00 00    	jge    0x155
 140:	49 89 f6             	mov    %rsi,%r14
 143:	4d 89 c4             	mov    %r8,%r12
 146:	48 8b 34 24          	mov    (%rsp),%rsi
 14a:	48 89 d9             	mov    %rbx,%rcx
 14d:	48 89 fb             	mov    %rdi,%rbx
 150:	e9 e7 00 00 00       	jmp    0x23c
 155:	49 89 f1             	mov    %rsi,%r9
 158:	49 89 dd             	mov    %rbx,%r13
 15b:	45 3b c1             	cmp    %r9d,%r8d
 15e:	0f 85 15 00 00 00    	jne    0x179
 164:	49 89 f6             	mov    %rsi,%r14
 167:	4d 89 c4             	mov    %r8,%r12
 16a:	48 8b 34 24          	mov    (%rsp),%rsi
 16e:	48 89 d9             	mov    %rbx,%rcx
 171:	48 89 fb             	mov    %rdi,%rbx
 174:	e9 c3 00 00 00       	jmp    0x23c
 179:	43 8d 44 05 ff       	lea    -0x1(%r13,%r8,1),%eax
 17e:	4d 89 c4             	mov    %r8,%r12
 181:	49 0f b6 04 07       	movzbq (%r15,%rax,1),%rax
 186:	45 8d 71 01          	lea    0x1(%r9),%r14d
 18a:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
 18f:	41 81 c5 ff ff ff ff 	add    $0xffffffff,%r13d
 196:	83 f8 0a             	cmp    $0xa,%eax
 199:	0f 84 0b 00 00 00    	je     0x1aa
 19f:	4d 89 e0             	mov    %r12,%r8
 1a2:	4d 89 f1             	mov    %r14,%r9
 1a5:	e9 b1 ff ff ff       	jmp    0x15b
 1aa:	41 8b 4c 3f 20       	mov    0x20(%r15,%rdi,1),%ecx
 1af:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
 1b4:	48 33 c0             	xor    %rax,%rax
 1b7:	48 8b 14 24          	mov    (%rsp),%rdx
 1bb:	48 8b ba 28 01 00 00 	mov    0x128(%rdx),%rdi
 1c2:	8b d1                	mov    %ecx,%edx
 1c4:	48 8d 3c d7          	lea    (%rdi,%rdx,8),%rdi
 1c8:	83 f9 05             	cmp    $0x5,%ecx
 1cb:	48 0f 43 f8          	cmovae %rax,%rdi
 1cf:	48 8b 0f             	mov    (%rdi),%rcx
 1d2:	48 89 c8             	mov    %rcx,%rax
 1d5:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
 1d9:	48 85 c9             	test   %rcx,%rcx
 1dc:	0f 84 a4 00 00 00    	je     0x286
 1e2:	8b 48 10             	mov    0x10(%rax),%ecx
 1e5:	48 8b 34 24          	mov    (%rsp),%rsi
 1e9:	48 8b 56 28          	mov    0x28(%rsi),%rdx
 1ed:	3b 0a                	cmp    (%rdx),%ecx
 1ef:	0f 85 a3 00 00 00    	jne    0x298
 1f5:	4c 8b 48 08          	mov    0x8(%rax),%r9
 1f9:	48 8b 78 18          	mov    0x18(%rax),%rdi
 1fd:	4c 89 e0             	mov    %r12,%rax
 200:	41 2b c6             	sub    %r14d,%eax
 203:	8d 70 01             	lea    0x1(%rax),%esi
 206:	48 89 d9             	mov    %rbx,%rcx
 209:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 20e:	49 89 f6             	mov    %rsi,%r14
 211:	48 8b 34 24          	mov    (%rsp),%rsi
 215:	4d 89 f0             	mov    %r14,%r8
 218:	41 ff d1             	call   *%r9
 21b:	41 3b c6             	cmp    %r14d,%eax
 21e:	0f 82 30 00 00 00    	jb     0x254
 224:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
 229:	41 8b 54 1f 14       	mov    0x14(%r15,%rbx,1),%edx
 22e:	43 8d 4c 25 01       	lea    0x1(%r13,%r12,1),%ecx
 233:	48 8b 34 24          	mov    (%rsp),%rsi
 237:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
 23c:	48 8b 34 24          	mov    (%rsp),%rsi
 240:	4d 89 e0             	mov    %r12,%r8
 243:	48 89 f7             	mov    %rsi,%rdi
 246:	e8 b5 70 00 00       	call   0x7300
 24b:	45 01 64 1f 14       	add    %r12d,0x14(%r15,%rbx,1)
 250:	43 8d 04 26          	lea    (%r14,%r12,1),%eax
 254:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
 259:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
 25e:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
 263:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
 268:	4c 8b 7c 24 40       	mov    0x40(%rsp),%r15
 26d:	48 83 c4 50          	add    $0x50,%rsp
 271:	48 89 ec             	mov    %rbp,%rsp
 274:	5d                   	pop    %rbp
 275:	c3                   	ret
 276:	33 f6                	xor    %esi,%esi
 278:	48 8b 3c 24          	mov    (%rsp),%rdi
 27c:	e8 50 87 00 00       	call   0x89d1
 281:	e9 59 fe ff ff       	jmp    0xdf
 286:	48 8b 3c 24          	mov    (%rsp),%rdi
 28a:	e8 42 87 00 00       	call   0x89d1
 28f:	e9 4e ff ff ff       	jmp    0x1e2
 294:	0f 0b                	ud2
 296:	0f 0b                	ud2
 298:	0f 0b                	ud2
