
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-wt45/func-33.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
   8:	4d 8b 52 18          	mov    0x18(%r10),%r10
   c:	49 83 c2 70          	add    $0x70,%r10
  10:	4c 3b d4             	cmp    %rsp,%r10
  13:	0f 87 99 02 00 00    	ja     0x2b2
  19:	48 83 ec 60          	sub    $0x60,%rsp
  1d:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
  22:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  27:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
  2c:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
  31:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
  36:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  3b:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  40:	44 8b bf 40 01 00 00 	mov    0x140(%rdi),%r15d
  47:	4c 89 fe             	mov    %r15,%rsi
  4a:	81 ee d0 00 00 00    	sub    $0xd0,%esi
  50:	89 b7 40 01 00 00    	mov    %esi,0x140(%rdi)
  56:	4c 8b 67 38          	mov    0x38(%rdi),%r12
  5a:	45 89 84 34 cc 00 00 	mov    %r8d,0xcc(%r12,%rsi,1)
  61:	00 
  62:	45 8d 4f f0          	lea    -0x10(%r15),%r9d
  66:	4b c7 04 0c 00 00 00 	movq   $0x0,(%r12,%r9,1)
  6d:	00 
  6e:	45 8d 4f e8          	lea    -0x18(%r15),%r9d
  72:	4b c7 04 0c 00 00 00 	movq   $0x0,(%r12,%r9,1)
  79:	00 
  7a:	45 8d 57 e0          	lea    -0x20(%r15),%r10d
  7e:	4b c7 04 14 00 00 00 	movq   $0x0,(%r12,%r10,1)
  85:	00 
  86:	49 c7 84 34 a8 00 00 	movq   $0x0,0xa8(%r12,%rsi,1)
  8d:	00 00 00 00 00 
  92:	49 c7 84 34 a0 00 00 	movq   $0x0,0xa0(%r12,%rsi,1)
  99:	00 00 00 00 00 
  9e:	45 89 84 34 c8 00 00 	mov    %r8d,0xc8(%r12,%rsi,1)
  a5:	00 
  a6:	33 d2                	xor    %edx,%edx
  a8:	45 8d 47 f8          	lea    -0x8(%r15),%r8d
  ac:	45 8d 4f 80          	lea    -0x80(%r15),%r9d
  b0:	41 8d 47 d0          	lea    -0x30(%r15),%eax
  b4:	89 04 24             	mov    %eax,(%rsp)
  b7:	48 89 fb             	mov    %rdi,%rbx
  ba:	48 89 de             	mov    %rbx,%rsi
  bd:	e8 fe 01 00 00       	call   0x2c0
  c2:	48 83 ec 10          	sub    $0x10,%rsp
  c6:	85 c0                	test   %eax,%eax
  c8:	0f 8d 0d 00 00 00    	jge    0xdb
  ce:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  d3:	48 89 c8             	mov    %rcx,%rax
  d6:	e9 9f 01 00 00       	jmp    0x27a
  db:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  e0:	44 8b ea             	mov    %edx,%r13d
  e3:	43 8b 0c 2c          	mov    (%r12,%r13,1),%ecx
  e7:	43 8b 44 2c 3c       	mov    0x3c(%r12,%r13,1),%eax
  ec:	85 c0                	test   %eax,%eax
  ee:	0f 8e 0a 00 00 00    	jle    0xfe
  f4:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  f9:	e9 0f 00 00 00       	jmp    0x10d
  fe:	48 89 c8             	mov    %rcx,%rax
 101:	83 e0 df             	and    $0xffffffdf,%eax
 104:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
 109:	43 89 04 2c          	mov    %eax,(%r12,%r13,1)
 10d:	43 8b 44 2c 2c       	mov    0x2c(%r12,%r13,1),%eax
 112:	85 c0                	test   %eax,%eax
 114:	0f 85 32 00 00 00    	jne    0x14c
 11a:	43 c7 44 2c 2c 50 00 	movl   $0x50,0x2c(%r12,%r13,1)
 121:	00 00 
 123:	43 c7 44 2c 18 00 00 	movl   $0x0,0x18(%r12,%r13,1)
 12a:	00 00 
 12c:	4b c7 44 2c 10 00 00 	movq   $0x0,0x10(%r12,%r13,1)
 133:	00 00 
 135:	47 8b 74 2c 28       	mov    0x28(%r12,%r13,1),%r14d
 13a:	4c 89 f8             	mov    %r15,%rax
 13d:	2d d0 00 00 00       	sub    $0xd0,%eax
 142:	43 89 44 2c 28       	mov    %eax,0x28(%r12,%r13,1)
 147:	e9 13 00 00 00       	jmp    0x15f
 14c:	43 8b 44 2c 10       	mov    0x10(%r12,%r13,1),%eax
 151:	45 33 f6             	xor    %r14d,%r14d
 154:	85 c0                	test   %eax,%eax
 156:	0f 85 25 00 00 00    	jne    0x181
 15c:	45 33 f6             	xor    %r14d,%r14d
 15f:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 164:	48 89 de             	mov    %rbx,%rsi
 167:	48 89 df             	mov    %rbx,%rdi
 16a:	e8 71 eb ff ff       	call   0xffffffffffffece0
 16f:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 174:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
 179:	85 c0                	test   %eax,%eax
 17b:	0f 85 2d 00 00 00    	jne    0x1ae
 181:	45 8d 47 f8          	lea    -0x8(%r15),%r8d
 185:	45 8d 4f 80          	lea    -0x80(%r15),%r9d
 189:	41 8d 47 d0          	lea    -0x30(%r15),%eax
 18d:	89 04 24             	mov    %eax,(%rsp)
 190:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 195:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 19a:	48 89 de             	mov    %rbx,%rsi
 19d:	48 89 df             	mov    %rbx,%rdi
 1a0:	e8 1b 01 00 00       	call   0x2c0
 1a5:	48 83 ec 10          	sub    $0x10,%rsp
 1a9:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 1ae:	45 85 f6             	test   %r14d,%r14d
 1b1:	0f 85 0a 00 00 00    	jne    0x1c1
 1b7:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 1bc:	e9 97 00 00 00       	jmp    0x258
 1c1:	43 8b 44 2c 20       	mov    0x20(%r12,%r13,1),%eax
 1c6:	48 8b 8b 28 01 00 00 	mov    0x128(%rbx),%rcx
 1cd:	8b d0                	mov    %eax,%edx
 1cf:	48 8d 0c d1          	lea    (%rcx,%rdx,8),%rcx
 1d3:	48 33 f6             	xor    %rsi,%rsi
 1d6:	83 f8 05             	cmp    $0x5,%eax
 1d9:	48 0f 43 ce          	cmovae %rsi,%rcx
 1dd:	48 8b 09             	mov    (%rcx),%rcx
 1e0:	48 89 c8             	mov    %rcx,%rax
 1e3:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
 1e7:	48 85 c9             	test   %rcx,%rcx
 1ea:	0f 84 b3 00 00 00    	je     0x2a3
 1f0:	8b 48 10             	mov    0x10(%rax),%ecx
 1f3:	48 8b 53 28          	mov    0x28(%rbx),%rdx
 1f7:	3b 0a                	cmp    (%rdx),%ecx
 1f9:	0f 85 b5 00 00 00    	jne    0x2b4
 1ff:	4c 8b 48 08          	mov    0x8(%rax),%r9
 203:	48 8b 78 18          	mov    0x18(%rax),%rdi
 207:	45 33 c0             	xor    %r8d,%r8d
 20a:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 20f:	48 89 de             	mov    %rbx,%rsi
 212:	4c 89 c1             	mov    %r8,%rcx
 215:	41 ff d1             	call   *%r9
 218:	43 c7 44 2c 2c 00 00 	movl   $0x0,0x2c(%r12,%r13,1)
 21f:	00 00 
 221:	47 89 74 2c 28       	mov    %r14d,0x28(%r12,%r13,1)
 226:	43 c7 44 2c 18 00 00 	movl   $0x0,0x18(%r12,%r13,1)
 22d:	00 00 
 22f:	43 c7 44 2c 10 00 00 	movl   $0x0,0x10(%r12,%r13,1)
 236:	00 00 
 238:	43 8b 44 2c 14       	mov    0x14(%r12,%r13,1),%eax
 23d:	43 c7 44 2c 14 00 00 	movl   $0x0,0x14(%r12,%r13,1)
 244:	00 00 
 246:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 24b:	85 c0                	test   %eax,%eax
 24d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
 252:	0f 45 c8             	cmovne %eax,%ecx
 255:	48 89 c8             	mov    %rcx,%rax
 258:	43 8b 0c 2c          	mov    (%r12,%r13,1),%ecx
 25c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 261:	83 e2 20             	and    $0x20,%edx
 264:	48 89 ce             	mov    %rcx,%rsi
 267:	0b f2                	or     %edx,%esi
 269:	43 89 34 2c          	mov    %esi,(%r12,%r13,1)
 26d:	f7 c1 20 00 00 00    	test   $0x20,%ecx
 273:	0f 45 05 3e 00 00 00 	cmovne 0x3e(%rip),%eax        # 0x2b8
 27a:	44 89 bb 40 01 00 00 	mov    %r15d,0x140(%rbx)
 281:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
 286:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
 28b:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
 290:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
 295:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
 29a:	48 83 c4 60          	add    $0x60,%rsp
 29e:	48 89 ec             	mov    %rbp,%rsp
 2a1:	5d                   	pop    %rbp
 2a2:	c3                   	ret
 2a3:	33 f6                	xor    %esi,%esi
 2a5:	48 89 df             	mov    %rbx,%rdi
 2a8:	e8 64 74 00 00       	call   0x7711
 2ad:	e9 3e ff ff ff       	jmp    0x1f0
 2b2:	0f 0b                	ud2
 2b4:	0f 0b                	ud2
 2b6:	00 00                	add    %al,(%rax)
 2b8:	ff                   	(bad)
 2b9:	ff                   	(bad)
 2ba:	ff                   	(bad)
 2bb:	ff 00                	incl   (%rax)
 2bd:	00 00                	add    %al,(%rax)
	...
