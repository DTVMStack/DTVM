
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-wt45/func-27.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
   8:	4d 8b 52 18          	mov    0x18(%r10),%r10
   c:	49 83 c2 20          	add    $0x20,%r10
  10:	4c 3b d4             	cmp    %rsp,%r10
  13:	0f 87 a8 00 00 00    	ja     0xc1
  19:	48 83 ec 10          	sub    $0x10,%rsp
  1d:	48 89 1c 24          	mov    %rbx,(%rsp)
  21:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
  26:	49 89 fc             	mov    %rdi,%r12
  29:	8b 9f 40 01 00 00    	mov    0x140(%rdi),%ebx
  2f:	48 89 d8             	mov    %rbx,%rax
  32:	83 e8 10             	sub    $0x10,%eax
  35:	89 87 40 01 00 00    	mov    %eax,0x140(%rdi)
  3b:	45 85 c0             	test   %r8d,%r8d
  3e:	0f 8d 1b 00 00 00    	jge    0x5f
  44:	4c 89 e7             	mov    %r12,%rdi
  47:	48 8b 47 38          	mov    0x38(%rdi),%rax
  4b:	c7 80 d0 10 00 00 1c 	movl   $0x1c,0x10d0(%rax)
  52:	00 00 00 
  55:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  5a:	e9 4a 00 00 00       	jmp    0xa9
  5f:	4c 89 e7             	mov    %r12,%rdi
  62:	48 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%rax
  69:	48 8b bf e0 00 00 00 	mov    0xe0(%rdi),%rdi
  70:	44 8d 4b fc          	lea    -0x4(%rbx),%r9d
  74:	4c 89 e6             	mov    %r12,%rsi
  77:	ff d0                	call   *%rax
  79:	85 c0                	test   %eax,%eax
  7b:	0f 84 17 00 00 00    	je     0x98
  81:	4c 89 e7             	mov    %r12,%rdi
  84:	48 8b 4f 38          	mov    0x38(%rdi),%rcx
  88:	89 81 d0 10 00 00    	mov    %eax,0x10d0(%rcx)
  8e:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  93:	e9 11 00 00 00       	jmp    0xa9
  98:	4c 89 e7             	mov    %r12,%rdi
  9b:	48 8b 47 38          	mov    0x38(%rdi),%rax
  9f:	48 89 d9             	mov    %rbx,%rcx
  a2:	83 e9 10             	sub    $0x10,%ecx
  a5:	8b 44 08 0c          	mov    0xc(%rax,%rcx,1),%eax
  a9:	89 9f 40 01 00 00    	mov    %ebx,0x140(%rdi)
  af:	48 8b 1c 24          	mov    (%rsp),%rbx
  b3:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  b8:	48 83 c4 10          	add    $0x10,%rsp
  bc:	48 89 ec             	mov    %rbp,%rsp
  bf:	5d                   	pop    %rbp
  c0:	c3                   	ret
  c1:	0f 0b                	ud2
