
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-wt45/func-34.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	55                   	push   %rbp
       1:	48 89 e5             	mov    %rsp,%rbp
       4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
       8:	4d 8b 52 18          	mov    0x18(%r10),%r10
       c:	49 81 c2 70 01 00 00 	add    $0x170,%r10
      13:	4c 3b d4             	cmp    %rsp,%r10
      16:	0f 87 eb 54 00 00    	ja     0x5507
      1c:	48 81 ec 60 01 00 00 	sub    $0x160,%rsp
      23:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
      2a:	00 
      2b:	4c 89 a4 24 38 01 00 	mov    %r12,0x138(%rsp)
      32:	00 
      33:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
      3a:	00 
      3b:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
      42:	00 
      43:	4c 89 bc 24 50 01 00 	mov    %r15,0x150(%rsp)
      4a:	00 
      4b:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
      50:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
      57:	00 
      58:	4c 8b 75 10          	mov    0x10(%rbp),%r14
      5c:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
      61:	44 8b af 40 01 00 00 	mov    0x140(%rdi),%r13d
      68:	4c 89 e8             	mov    %r13,%rax
      6b:	2d 70 03 00 00       	sub    $0x370,%eax
      70:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
      77:	00 
      78:	89 87 40 01 00 00    	mov    %eax,0x140(%rdi)
      7e:	45 33 ed             	xor    %r13d,%r13d
      81:	4c 8b 4f 38          	mov    0x38(%rdi),%r9
      85:	48 89 3c 24          	mov    %rdi,(%rsp)
      89:	4c 89 8c 24 20 01 00 	mov    %r9,0x120(%rsp)
      90:	00 
      91:	bb 01 00 00 00       	mov    $0x1,%ebx
      96:	48 89 9c 24 18 01 00 	mov    %rbx,0x118(%rsp)
      9d:	00 
      9e:	8b c2                	mov    %edx,%eax
      a0:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
      a5:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
      ac:	00 
      ad:	45 8b f0             	mov    %r8d,%r14d
      b0:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
      b5:	4c 89 b4 24 08 01 00 	mov    %r14,0x108(%rsp)
      bc:	00 
      bd:	4c 89 e9             	mov    %r13,%rcx
      c0:	4d 89 ef             	mov    %r13,%r15
      c3:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
      c8:	2b d1                	sub    %ecx,%edx
      ca:	44 3b ea             	cmp    %edx,%r13d
      cd:	0f 8e 0d 00 00 00    	jle    0xe0
      d3:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
      da:	00 
      db:	e9 c3 53 00 00       	jmp    0x54a3
      e0:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
      e7:	00 
      e8:	8b d6                	mov    %esi,%edx
      ea:	4c 8b 8c 24 20 01 00 	mov    0x120(%rsp),%r9
      f1:	00 
      f2:	49 0f b6 14 11       	movzbq (%r9,%rdx,1),%rdx
      f7:	85 d2                	test   %edx,%edx
      f9:	0f 84 dc 50 00 00    	je     0x51db
      ff:	48 89 f3             	mov    %rsi,%rbx
     102:	48 89 d7             	mov    %rdx,%rdi
     105:	81 e7 ff 00 00 00    	and    $0xff,%edi
     10b:	f7 c2 ff 00 00 00    	test   $0xff,%edx
     111:	0f 84 64 00 00 00    	je     0x17b
     117:	83 ff 25             	cmp    $0x25,%edi
     11a:	0f 85 47 00 00 00    	jne    0x167
     120:	48 89 da             	mov    %rbx,%rdx
     123:	8d 7b 01             	lea    0x1(%rbx),%edi
     126:	49 0f b6 3c 39       	movzbq (%r9,%rdi,1),%rdi
     12b:	83 ff 25             	cmp    $0x25,%edi
     12e:	0f 84 0b 00 00 00    	je     0x13f
     134:	49 89 de             	mov    %rbx,%r14
     137:	48 89 d3             	mov    %rdx,%rbx
     13a:	e9 3f 00 00 00       	jmp    0x17e
     13f:	8b fb                	mov    %ebx,%edi
     141:	49 0f b6 7c 39 02    	movzbq 0x2(%r9,%rdi,1),%rdi
     147:	81 c3 02 00 00 00    	add    $0x2,%ebx
     14d:	81 c2 01 00 00 00    	add    $0x1,%edx
     153:	83 ff 25             	cmp    $0x25,%edi
     156:	0f 84 c7 ff ff ff    	je     0x123
     15c:	49 89 de             	mov    %rbx,%r14
     15f:	48 89 d3             	mov    %rdx,%rbx
     162:	e9 17 00 00 00       	jmp    0x17e
     167:	44 8b d3             	mov    %ebx,%r10d
     16a:	4b 0f b6 54 11 01    	movzbq 0x1(%r9,%r10,1),%rdx
     170:	81 c3 01 00 00 00    	add    $0x1,%ebx
     176:	e9 87 ff ff ff       	jmp    0x102
     17b:	49 89 de             	mov    %rbx,%r14
     17e:	2b de                	sub    %esi,%ebx
     180:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
     187:	00 
     188:	41 03 cd             	add    %r13d,%ecx
     18b:	41 bb ff ff ff 7f    	mov    $0x7fffffff,%r11d
     191:	44 2b d9             	sub    %ecx,%r11d
     194:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
     199:	41 3b db             	cmp    %r11d,%ebx
     19c:	4c 89 9c 24 00 01 00 	mov    %r11,0x100(%rsp)
     1a3:	00 
     1a4:	0f 8e 10 00 00 00    	jle    0x1ba
     1aa:	4d 89 cb             	mov    %r9,%r11
     1ad:	4c 89 8c 24 20 01 00 	mov    %r9,0x120(%rsp)
     1b4:	00 
     1b5:	e9 e9 52 00 00       	jmp    0x54a3
     1ba:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
     1bf:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
     1c4:	85 c1                	test   %eax,%ecx
     1c6:	0f 85 0d 00 00 00    	jne    0x1d9
     1cc:	4c 89 8c 24 20 01 00 	mov    %r9,0x120(%rsp)
     1d3:	00 
     1d4:	e9 3e 00 00 00       	jmp    0x217
     1d9:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
     1e0:	00 
     1e1:	49 0f b6 0c 31       	movzbq (%r9,%rsi,1),%rcx
     1e6:	4c 89 8c 24 20 01 00 	mov    %r9,0x120(%rsp)
     1ed:	00 
     1ee:	f7 c1 20 00 00 00    	test   $0x20,%ecx
     1f4:	0f 85 1d 00 00 00    	jne    0x217
     1fa:	48 89 d9             	mov    %rbx,%rcx
     1fd:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
     204:	00 
     205:	48 8b 34 24          	mov    (%rsp),%rsi
     209:	48 8b 3c 24          	mov    (%rsp),%rdi
     20d:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
     212:	e8 69 e8 ff ff       	call   0xffffffffffffea80
     217:	85 db                	test   %ebx,%ebx
     219:	0f 84 15 00 00 00    	je     0x234
     21f:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
     224:	49 89 dd             	mov    %rbx,%r13
     227:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
     22e:	00 
     22f:	e9 8f fe ff ff       	jmp    0xc3
     234:	41 8b ce             	mov    %r14d,%ecx
     237:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     23e:	00 
     23f:	4d 0f be 54 0b 01    	movsbq 0x1(%r11,%rcx,1),%r10
     245:	41 8d 7a d0          	lea    -0x30(%r10),%edi
     249:	83 ff 09             	cmp    $0x9,%edi
     24c:	0f 86 17 00 00 00    	jbe    0x269
     252:	41 8d 56 01          	lea    0x1(%r14),%edx
     256:	41 bb ff ff ff ff    	mov    $0xffffffff,%r11d
     25c:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
     263:	00 
     264:	e9 52 00 00 00       	jmp    0x2bb
     269:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     270:	00 
     271:	49 0f b6 4c 0b 02    	movzbq 0x2(%r11,%rcx,1),%rcx
     277:	83 f9 24             	cmp    $0x24,%ecx
     27a:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
     281:	00 
     282:	48 89 f0             	mov    %rsi,%rax
     285:	0f 44 05 8c 52 00 00 	cmove  0x528c(%rip),%eax        # 0x5518
     28c:	41 03 c6             	add    %r14d,%eax
     28f:	4d 0f be 14 03       	movsbq (%r11,%rax,1),%r10
     294:	45 8d 46 03          	lea    0x3(%r14),%r8d
     298:	41 8d 56 01          	lea    0x1(%r14),%edx
     29c:	83 f9 24             	cmp    $0x24,%ecx
     29f:	41 0f 44 d0          	cmove  %r8d,%edx
     2a3:	83 f9 24             	cmp    $0x24,%ecx
     2a6:	44 0f 44 3d 72 52 00 	cmove  0x5272(%rip),%r15d        # 0x5520
     2ad:	00 
     2ae:	41 bb ff ff ff ff    	mov    $0xffffffff,%r11d
     2b4:	83 f9 24             	cmp    $0x24,%ecx
     2b7:	44 0f 44 df          	cmove  %edi,%r11d
     2bb:	41 8d 4a e0          	lea    -0x20(%r10),%ecx
     2bf:	83 f9 1f             	cmp    $0x1f,%ecx
     2c2:	0f 86 10 00 00 00    	jbe    0x2d8
     2c8:	45 33 c0             	xor    %r8d,%r8d
     2cb:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
     2d2:	00 
     2d3:	e9 93 00 00 00       	jmp    0x36b
     2d8:	c4 62 71 f7 c6       	shlx   %ecx,%esi,%r8d
     2dd:	41 f7 c0 89 28 01 00 	test   $0x12889,%r8d
     2e4:	0f 85 10 00 00 00    	jne    0x2fa
     2ea:	45 33 c0             	xor    %r8d,%r8d
     2ed:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
     2f4:	00 
     2f5:	e9 71 00 00 00       	jmp    0x36b
     2fa:	33 c9                	xor    %ecx,%ecx
     2fc:	8b c2                	mov    %edx,%eax
     2fe:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
     305:	00 
     306:	4c 0f be 54 07 01    	movsbq 0x1(%rdi,%rax,1),%r10
     30c:	41 8d 7a e0          	lea    -0x20(%r10),%edi
     310:	44 8d 4a 01          	lea    0x1(%rdx),%r9d
     314:	44 0b c1             	or     %ecx,%r8d
     317:	83 ff 1f             	cmp    $0x1f,%edi
     31a:	0f 86 10 00 00 00    	jbe    0x330
     320:	4c 89 ca             	mov    %r9,%rdx
     323:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
     32a:	00 
     32b:	e9 3b 00 00 00       	jmp    0x36b
     330:	c4 e2 41 f7 ce       	shlx   %edi,%esi,%ecx
     335:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
     33c:	00 
     33d:	8d 72 01             	lea    0x1(%rdx),%esi
     340:	f7 c1 89 28 01 00    	test   $0x12889,%ecx
     346:	0f 84 19 00 00 00    	je     0x365
     34c:	48 89 f2             	mov    %rsi,%rdx
     34f:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
     356:	00 
     357:	48 89 c8             	mov    %rcx,%rax
     35a:	4c 89 c1             	mov    %r8,%rcx
     35d:	49 89 c0             	mov    %rax,%r8
     360:	e9 97 ff ff ff       	jmp    0x2fc
     365:	81 c2 01 00 00 00    	add    $0x1,%edx
     36b:	41 83 fa 2a          	cmp    $0x2a,%r10d
     36f:	0f 85 58 01 00 00    	jne    0x4cd
     375:	8b ca                	mov    %edx,%ecx
     377:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
     37e:	00 
     37f:	48 0f be 44 08 01    	movsbq 0x1(%rax,%rcx,1),%rax
     385:	8d 78 d0             	lea    -0x30(%rax),%edi
     388:	83 ff 09             	cmp    $0x9,%edi
     38b:	0f 86 0f 00 00 00    	jbe    0x3a0
     391:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
     396:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
     39b:	e9 77 00 00 00       	jmp    0x417
     3a0:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
     3a7:	00 
     3a8:	48 0f b6 44 08 02    	movzbq 0x2(%rax,%rcx,1),%rax
     3ae:	83 f8 24             	cmp    $0x24,%eax
     3b1:	0f 84 0f 00 00 00    	je     0x3c6
     3b7:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
     3bc:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
     3c1:	e9 51 00 00 00       	jmp    0x417
     3c6:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
     3cb:	8d 04 be             	lea    (%rsi,%rdi,4),%eax
     3ce:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
     3d5:	00 
     3d6:	c7 04 07 0a 00 00 00 	movl   $0xa,(%rdi,%rax,1)
     3dd:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
     3e4:	00 
     3e5:	48 0f be 44 08 01    	movsbq 0x1(%rax,%rcx,1),%rax
     3eb:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
     3f0:	41 8d 84 c1 80 fe ff 	lea    -0x180(%r9,%rax,8),%eax
     3f7:	ff 
     3f8:	44 8b 14 07          	mov    (%rdi,%rax,1),%r10d
     3fc:	81 c2 03 00 00 00    	add    $0x3,%edx
     402:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
     409:	00 
     40a:	4c 8b bc 24 18 01 00 	mov    0x118(%rsp),%r15
     411:	00 
     412:	e9 79 00 00 00       	jmp    0x490
     417:	45 85 ff             	test   %r15d,%r15d
     41a:	0f 84 0d 00 00 00    	je     0x42d
     420:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     427:	00 
     428:	e9 37 50 00 00       	jmp    0x5464
     42d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
     432:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
     437:	85 c1                	test   %eax,%ecx
     439:	0f 85 26 00 00 00    	jne    0x465
     43f:	81 c2 01 00 00 00    	add    $0x1,%edx
     445:	45 33 ff             	xor    %r15d,%r15d
     448:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
     44f:	00 
     450:	4c 89 bc 24 b0 00 00 	mov    %r15,0xb0(%rsp)
     457:	00 
     458:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
     45f:	00 
     460:	e9 1a 01 00 00       	jmp    0x57f
     465:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
     46c:	00 
     46d:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
     474:	00 
     475:	8b 0c 38             	mov    (%rax,%rdi,1),%ecx
     478:	44 8d 51 04          	lea    0x4(%rcx),%r10d
     47c:	44 89 14 38          	mov    %r10d,(%rax,%rdi,1)
     480:	44 8b d1             	mov    %ecx,%r10d
     483:	46 8b 14 10          	mov    (%rax,%r10,1),%r10d
     487:	81 c2 01 00 00 00    	add    $0x1,%edx
     48d:	45 33 ff             	xor    %r15d,%r15d
     490:	45 85 d2             	test   %r10d,%r10d
     493:	0f 8c 15 00 00 00    	jl     0x4ae
     499:	4c 89 94 24 b0 00 00 	mov    %r10,0xb0(%rsp)
     4a0:	00 
     4a1:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
     4a8:	00 
     4a9:	e9 d1 00 00 00       	jmp    0x57f
     4ae:	41 81 c8 00 20 00 00 	or     $0x2000,%r8d
     4b5:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
     4bc:	00 
     4bd:	41 f7 da             	neg    %r10d
     4c0:	4c 89 94 24 b0 00 00 	mov    %r10,0xb0(%rsp)
     4c7:	00 
     4c8:	e9 b2 00 00 00       	jmp    0x57f
     4cd:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
     4d2:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
     4d9:	00 
     4da:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
     4df:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
     4e6:	00 
     4e7:	45 8d 42 d0          	lea    -0x30(%r10),%r8d
     4eb:	41 83 f8 09          	cmp    $0x9,%r8d
     4ef:	0f 86 10 00 00 00    	jbe    0x505
     4f5:	45 33 d2             	xor    %r10d,%r10d
     4f8:	4c 89 94 24 b0 00 00 	mov    %r10,0xb0(%rsp)
     4ff:	00 
     500:	e9 7a 00 00 00       	jmp    0x57f
     505:	45 33 d2             	xor    %r10d,%r10d
     508:	41 81 fa cc cc cc 0c 	cmp    $0xccccccc,%r10d
     50f:	0f 87 23 4c 00 00    	ja     0x5138
     515:	8b c2                	mov    %edx,%eax
     517:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
     51e:	00 
     51f:	48 0f be 44 01 01    	movsbq 0x1(%rcx,%rax,1),%rax
     525:	8d 48 d0             	lea    -0x30(%rax),%ecx
     528:	45 6b d2 0a          	imul   $0xa,%r10d,%r10d
     52c:	41 bd ff ff ff 7f    	mov    $0x7fffffff,%r13d
     532:	45 2b ea             	sub    %r10d,%r13d
     535:	45 03 d0             	add    %r8d,%r10d
     538:	45 3b c5             	cmp    %r13d,%r8d
     53b:	44 0f 4f 15 e5 4f 00 	cmovg  0x4fe5(%rip),%r10d        # 0x5528
     542:	00 
     543:	44 8d 42 01          	lea    0x1(%rdx),%r8d
     547:	83 f9 0a             	cmp    $0xa,%ecx
     54a:	0f 83 0b 00 00 00    	jae    0x55b
     550:	4c 89 c2             	mov    %r8,%rdx
     553:	49 89 c8             	mov    %rcx,%r8
     556:	e9 ad ff ff ff       	jmp    0x508
     55b:	45 85 d2             	test   %r10d,%r10d
     55e:	4c 89 94 24 b0 00 00 	mov    %r10,0xb0(%rsp)
     565:	00 
     566:	0f 8d 0d 00 00 00    	jge    0x579
     56c:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     573:	00 
     574:	e9 2a 4f 00 00       	jmp    0x54a3
     579:	81 c2 01 00 00 00    	add    $0x1,%edx
     57f:	8b ca                	mov    %edx,%ecx
     581:	4c 8b 84 24 20 01 00 	mov    0x120(%rsp),%r8
     588:	00 
     589:	49 0f b6 04 08       	movzbq (%r8,%rcx,1),%rax
     58e:	83 f8 2e             	cmp    $0x2e,%eax
     591:	0f 84 25 00 00 00    	je     0x5bc
     597:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     59d:	33 db                	xor    %ebx,%ebx
     59f:	4c 89 84 24 a0 00 00 	mov    %r8,0xa0(%rsp)
     5a6:	00 
     5a7:	4c 89 bc 24 b8 00 00 	mov    %r15,0xb8(%rsp)
     5ae:	00 
     5af:	48 89 bc 24 08 01 00 	mov    %rdi,0x108(%rsp)
     5b6:	00 
     5b7:	e9 e8 01 00 00       	jmp    0x7a4
     5bc:	4c 8b 94 24 20 01 00 	mov    0x120(%rsp),%r10
     5c3:	00 
     5c4:	4d 0f be 44 0a 01    	movsbq 0x1(%r10,%rcx,1),%r8
     5ca:	41 83 f8 2a          	cmp    $0x2a,%r8d
     5ce:	0f 85 15 01 00 00    	jne    0x6e9
     5d4:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
     5db:	00 
     5dc:	48 0f be 44 08 02    	movsbq 0x2(%rax,%rcx,1),%rax
     5e2:	44 8d 40 d0          	lea    -0x30(%rax),%r8d
     5e6:	41 83 f8 09          	cmp    $0x9,%r8d
     5ea:	0f 87 68 00 00 00    	ja     0x658
     5f0:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
     5f7:	00 
     5f8:	48 0f b6 44 08 03    	movzbq 0x3(%rax,%rcx,1),%rax
     5fe:	83 f8 24             	cmp    $0x24,%eax
     601:	0f 85 51 00 00 00    	jne    0x658
     607:	42 8d 04 86          	lea    (%rsi,%r8,4),%eax
     60b:	4c 8b 84 24 20 01 00 	mov    0x120(%rsp),%r8
     612:	00 
     613:	41 c7 04 00 0a 00 00 	movl   $0xa,(%r8,%rax,1)
     61a:	00 
     61b:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
     622:	00 
     623:	48 0f be 44 08 02    	movsbq 0x2(%rax,%rcx,1),%rax
     629:	41 8d 84 c1 80 fe ff 	lea    -0x180(%r9,%rax,8),%eax
     630:	ff 
     631:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
     638:	00 
     639:	44 8b 04 01          	mov    (%rcx,%rax,1),%r8d
     63d:	81 c2 04 00 00 00    	add    $0x4,%edx
     643:	4c 89 bc 24 b8 00 00 	mov    %r15,0xb8(%rsp)
     64a:	00 
     64b:	48 89 bc 24 08 01 00 	mov    %rdi,0x108(%rsp)
     652:	00 
     653:	e9 7c 00 00 00       	jmp    0x6d4
     658:	45 85 ff             	test   %r15d,%r15d
     65b:	4c 89 bc 24 b8 00 00 	mov    %r15,0xb8(%rsp)
     662:	00 
     663:	0f 84 0d 00 00 00    	je     0x676
     669:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     670:	00 
     671:	e9 ee 4d 00 00       	jmp    0x5464
     676:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
     67b:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
     680:	85 c1                	test   %eax,%ecx
     682:	0f 85 16 00 00 00    	jne    0x69e
     688:	45 33 c0             	xor    %r8d,%r8d
     68b:	81 c2 02 00 00 00    	add    $0x2,%edx
     691:	48 89 bc 24 08 01 00 	mov    %rdi,0x108(%rsp)
     698:	00 
     699:	e9 36 00 00 00       	jmp    0x6d4
     69e:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
     6a5:	00 
     6a6:	8b 04 38             	mov    (%rax,%rdi,1),%eax
     6a9:	8d 48 04             	lea    0x4(%rax),%ecx
     6ac:	4c 8b 84 24 20 01 00 	mov    0x120(%rsp),%r8
     6b3:	00 
     6b4:	41 89 0c 38          	mov    %ecx,(%r8,%rdi,1)
     6b8:	48 89 bc 24 08 01 00 	mov    %rdi,0x108(%rsp)
     6bf:	00 
     6c0:	8b c0                	mov    %eax,%eax
     6c2:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
     6c9:	00 
     6ca:	44 8b 04 01          	mov    (%rcx,%rax,1),%r8d
     6ce:	81 c2 02 00 00 00    	add    $0x2,%edx
     6d4:	4c 89 c3             	mov    %r8,%rbx
     6d7:	f7 d3                	not    %ebx
     6d9:	c1 eb 1f             	shr    $0x1f,%ebx
     6dc:	4c 89 84 24 a0 00 00 	mov    %r8,0xa0(%rsp)
     6e3:	00 
     6e4:	e9 bb 00 00 00       	jmp    0x7a4
     6e9:	4c 89 bc 24 b8 00 00 	mov    %r15,0xb8(%rsp)
     6f0:	00 
     6f1:	48 89 bc 24 08 01 00 	mov    %rdi,0x108(%rsp)
     6f8:	00 
     6f9:	41 8d 78 d0          	lea    -0x30(%r8),%edi
     6fd:	83 ff 09             	cmp    $0x9,%edi
     700:	0f 86 1e 00 00 00    	jbe    0x724
     706:	81 c2 01 00 00 00    	add    $0x1,%edx
     70c:	45 33 c0             	xor    %r8d,%r8d
     70f:	48 8b 9c 24 18 01 00 	mov    0x118(%rsp),%rbx
     716:	00 
     717:	4c 89 84 24 a0 00 00 	mov    %r8,0xa0(%rsp)
     71e:	00 
     71f:	e9 80 00 00 00       	jmp    0x7a4
     724:	45 33 c0             	xor    %r8d,%r8d
     727:	8d 42 01             	lea    0x1(%rdx),%eax
     72a:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
     72f:	41 81 f8 cc cc cc 0c 	cmp    $0xccccccc,%r8d
     736:	0f 86 0d 00 00 00    	jbe    0x749
     73c:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
     743:	00 
     744:	e9 21 00 00 00       	jmp    0x76a
     749:	41 6b c8 0a          	imul   $0xa,%r8d,%ecx
     74d:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
     752:	2b d1                	sub    %ecx,%edx
     754:	44 8d 04 39          	lea    (%rcx,%rdi,1),%r8d
     758:	3b fa                	cmp    %edx,%edi
     75a:	44 0f 4f 05 c6 4d 00 	cmovg  0x4dc6(%rip),%r8d        # 0x5528
     761:	00 
     762:	4c 89 84 24 a0 00 00 	mov    %r8,0xa0(%rsp)
     769:	00 
     76a:	8b c8                	mov    %eax,%ecx
     76c:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
     773:	00 
     774:	48 0f be 4c 0a 01    	movsbq 0x1(%rdx,%rcx,1),%rcx
     77a:	8d 79 d0             	lea    -0x30(%rcx),%edi
     77d:	8d 48 01             	lea    0x1(%rax),%ecx
     780:	83 ff 0a             	cmp    $0xa,%edi
     783:	0f 83 10 00 00 00    	jae    0x799
     789:	48 89 c8             	mov    %rcx,%rax
     78c:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
     793:	00 
     794:	e9 91 ff ff ff       	jmp    0x72a
     799:	8d 50 01             	lea    0x1(%rax),%edx
     79c:	48 8b 9c 24 18 01 00 	mov    0x118(%rsp),%rbx
     7a3:	00 
     7a4:	45 33 ff             	xor    %r15d,%r15d
     7a7:	44 8b f2             	mov    %edx,%r14d
     7aa:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
     7b1:	00 
     7b2:	4a 0f be 04 30       	movsbq (%rax,%r14,1),%rax
     7b7:	81 c0 bf ff ff ff    	add    $0xffffffbf,%eax
     7bd:	83 f8 39             	cmp    $0x39,%eax
     7c0:	0f 86 0d 00 00 00    	jbe    0x7d3
     7c6:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     7cd:	00 
     7ce:	e9 91 4c 00 00       	jmp    0x5464
     7d3:	41 6b cf 3a          	imul   $0x3a,%r15d,%ecx
     7d7:	8d 84 01 50 0b 00 00 	lea    0xb50(%rcx,%rax,1),%eax
     7de:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
     7e5:	00 
     7e6:	48 0f b6 0c 01       	movzbq (%rcx,%rax,1),%rcx
     7eb:	8d 79 ff             	lea    -0x1(%rcx),%edi
     7ee:	8d 42 01             	lea    0x1(%rdx),%eax
     7f1:	83 ff 08             	cmp    $0x8,%edi
     7f4:	0f 83 0b 00 00 00    	jae    0x805
     7fa:	48 89 c2             	mov    %rax,%rdx
     7fd:	49 89 cf             	mov    %rcx,%r15
     800:	e9 a2 ff ff ff       	jmp    0x7a7
     805:	85 c9                	test   %ecx,%ecx
     807:	0f 85 0d 00 00 00    	jne    0x81a
     80d:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     814:	00 
     815:	e9 4a 4c 00 00       	jmp    0x5464
     81a:	83 f9 1b             	cmp    $0x1b,%ecx
     81d:	0f 85 2d 00 00 00    	jne    0x850
     823:	45 85 db             	test   %r11d,%r11d
     826:	0f 8d 17 00 00 00    	jge    0x843
     82c:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
     831:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
     836:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
     83d:	00 
     83e:	e9 55 00 00 00       	jmp    0x898
     843:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     84a:	00 
     84b:	e9 14 4c 00 00       	jmp    0x5464
     850:	45 85 db             	test   %r11d,%r11d
     853:	0f 8c 93 00 00 00    	jl     0x8ec
     859:	42 8d 04 9e          	lea    (%rsi,%r11,4),%eax
     85d:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
     862:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
     869:	00 
     86a:	89 0c 06             	mov    %ecx,(%rsi,%rax,1)
     86d:	43 8d 04 d9          	lea    (%r9,%r11,8),%eax
     871:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     878:	00 
     879:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
     87e:	49 8b 04 03          	mov    (%r11,%rax,1),%rax
     882:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
     889:	00 
     88a:	48 89 f1             	mov    %rsi,%rcx
     88d:	81 e9 70 03 00 00    	sub    $0x370,%ecx
     893:	49 89 44 0b 38       	mov    %rax,0x38(%r11,%rcx,1)
     898:	8d 42 01             	lea    0x1(%rdx),%eax
     89b:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
     8a0:	45 33 ed             	xor    %r13d,%r13d
     8a3:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
     8a8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
     8ad:	85 d1                	test   %edx,%ecx
     8af:	0f 85 22 00 00 00    	jne    0x8d7
     8b5:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
     8ba:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
     8c1:	00 
     8c2:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
     8c9:	00 
     8ca:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
     8d1:	00 
     8d2:	e9 ec f7 ff ff       	jmp    0xc3
     8d7:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     8de:	00 
     8df:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
     8e6:	00 
     8e7:	e9 68 00 00 00       	jmp    0x954
     8ec:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
     8f1:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
     8f6:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
     8fb:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
     900:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     905:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
     90c:	00 
     90d:	44 85 c7             	test   %r8d,%edi
     910:	0f 85 16 00 00 00    	jne    0x92c
     916:	33 c0                	xor    %eax,%eax
     918:	48 8b 0c 24          	mov    (%rsp),%rcx
     91c:	48 89 f2             	mov    %rsi,%rdx
     91f:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
     926:	00 
     927:	e9 93 4b 00 00       	jmp    0x54bf
     92c:	8d 96 c8 fc ff ff    	lea    -0x338(%rsi),%edx
     932:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
     939:	00 
     93a:	48 8b 34 24          	mov    (%rsp),%rsi
     93e:	48 8b 3c 24          	mov    (%rsp),%rdi
     942:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
     947:	e8 14 4d 00 00       	call   0x5660
     94c:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     953:	00 
     954:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     95b:	00 
     95c:	4f 0f be 34 33       	movsbq (%r11,%r14,1),%r14
     961:	4c 89 f2             	mov    %r14,%rdx
     964:	83 e2 0f             	and    $0xf,%edx
     967:	4c 89 f1             	mov    %r14,%rcx
     96a:	83 e1 df             	and    $0xffffffdf,%ecx
     96d:	83 fa 03             	cmp    $0x3,%edx
     970:	4c 89 f2             	mov    %r14,%rdx
     973:	0f 44 d1             	cmove  %ecx,%edx
     976:	45 85 ff             	test   %r15d,%r15d
     979:	44 0f 45 f2          	cmovne %edx,%r14d
     97d:	41 8d 4e bf          	lea    -0x41(%r14),%ecx
     981:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
     988:	00 
     989:	48 89 d6             	mov    %rdx,%rsi
     98c:	81 e6 ff ff fe ff    	and    $0xfffeffff,%esi
     992:	f7 c2 00 20 00 00    	test   $0x2000,%edx
     998:	48 89 d0             	mov    %rdx,%rax
     99b:	0f 45 c6             	cmovne %esi,%eax
     99e:	49 89 c4             	mov    %rax,%r12
     9a1:	ba 38 00 00 00       	mov    $0x38,%edx
     9a6:	3b ca                	cmp    %edx,%ecx
     9a8:	0f 42 d1             	cmovb  %ecx,%edx
     9ab:	48 8d 35 09 00 00 00 	lea    0x9(%rip),%rsi        # 0x9bb
     9b2:	48 63 0c 96          	movslq (%rsi,%rdx,4),%rcx
     9b6:	48 03 f1             	add    %rcx,%rsi
     9b9:	ff e6                	jmp    *%rsi
     9bb:	f4                   	hlt
     9bc:	00 00                	add    %al,(%rax)
     9be:	00 09                	add    %cl,(%rcx)
     9c0:	01 00                	add    %eax,(%rax)
     9c2:	00 9e 0d 00 00 19    	add    %bl,0x1900000d(%rsi)
     9c8:	01 00                	add    %eax,(%rax)
     9ca:	00 29                	add    %ch,(%rcx)
     9cc:	01 00                	add    %eax,(%rax)
     9ce:	00 3e                	add    %bh,(%rsi)
     9d0:	01 00                	add    %eax,(%rax)
     9d2:	00 53 01             	add    %dl,0x1(%rbx)
     9d5:	00 00                	add    %al,(%rax)
     9d7:	68 01 00 00 78       	push   $0x78000001
     9dc:	01 00                	add    %eax,(%rax)
     9de:	00 88 01 00 00 98    	add    %cl,-0x67ffffff(%rax)
     9e4:	01 00                	add    %eax,(%rax)
     9e6:	00 a8 01 00 00 b8    	add    %ch,-0x47ffffff(%rax)
     9ec:	01 00                	add    %eax,(%rax)
     9ee:	00 c8                	add    %cl,%al
     9f0:	01 00                	add    %eax,(%rax)
     9f2:	00 d8                	add    %bl,%al
     9f4:	01 00                	add    %eax,(%rax)
     9f6:	00 e8                	add    %ch,%al
     9f8:	01 00                	add    %eax,(%rax)
     9fa:	00 f8                	add    %bh,%al
     9fc:	01 00                	add    %eax,(%rax)
     9fe:	00 08                	add    %cl,(%rax)
     a00:	02 00                	add    (%rax),%al
     a02:	00 61 0d             	add    %ah,0xd(%rcx)
     a05:	00 00                	add    %al,(%rax)
     a07:	18 02                	sbb    %al,(%rdx)
     a09:	00 00                	add    %al,(%rax)
     a0b:	28 02                	sub    %al,(%rdx)
     a0d:	00 00                	add    %al,(%rax)
     a0f:	38 02                	cmp    %al,(%rdx)
     a11:	00 00                	add    %al,(%rax)
     a13:	48 02 00             	rex.W add (%rax),%al
     a16:	00 58 02             	add    %bl,0x2(%rax)
     a19:	00 00                	add    %al,(%rax)
     a1b:	6d                   	insl   (%dx),%es:(%rdi)
     a1c:	02 00                	add    (%rax),%al
     a1e:	00 7d 02             	add    %bh,0x2(%rbp)
     a21:	00 00                	add    %al,(%rax)
     a23:	8d 02                	lea    (%rdx),%eax
     a25:	00 00                	add    %al,(%rax)
     a27:	9d                   	popf
     a28:	02 00                	add    (%rax),%al
     a2a:	00 ad 02 00 00 bd    	add    %ch,-0x42fffffe(%rbp)
     a30:	02 00                	add    (%rax),%al
     a32:	00 cd                	add    %cl,%ch
     a34:	02 00                	add    (%rax),%al
     a36:	00 dd                	add    %bl,%ch
     a38:	02 00                	add    (%rax),%al
     a3a:	00 ed                	add    %ch,%ch
     a3c:	02 00                	add    (%rax),%al
     a3e:	00 02                	add    %al,(%rdx)
     a40:	03 00                	add    (%rax),%eax
     a42:	00 8a 0a 00 00 12    	add    %cl,0x1200000a(%rdx)
     a48:	03 00                	add    (%rax),%eax
     a4a:	00 1f                	add    %bl,(%rdi)
     a4c:	03 00                	add    (%rax),%eax
     a4e:	00 34 03             	add    %dh,(%rbx,%rax,1)
     a51:	00 00                	add    %al,(%rax)
     a53:	49 03 00             	add    (%r8),%rax
     a56:	00 5e 03             	add    %bl,0x3(%rsi)
     a59:	00 00                	add    %al,(%rax)
     a5b:	6e                   	outsb  %ds:(%rsi),(%dx)
     a5c:	03 00                	add    (%rax),%eax
     a5e:	00 7b 03             	add    %bh,0x3(%rbx)
     a61:	00 00                	add    %al,(%rax)
     a63:	8b 03                	mov    (%rbx),%eax
     a65:	00 00                	add    %al,(%rax)
     a67:	9b                   	fwait
     a68:	03 00                	add    (%rax),%eax
     a6a:	00 f5                	add    %dh,%ch
     a6c:	07                   	(bad)
     a6d:	00 00                	add    %al,(%rax)
     a6f:	96                   	xchg   %eax,%esi
     a70:	05 00 00 b1 04       	add    $0x4b10000,%eax
     a75:	00 00                	add    %al,(%rax)
     a77:	72 04                	jb     0xa7d
     a79:	00 00                	add    %al,(%rax)
     a7b:	ab                   	stos   %eax,%es:(%rdi)
     a7c:	03 00                	add    (%rax),%eax
     a7e:	00 bb 03 00 00 39    	add    %bh,0x39000003(%rbx)
     a84:	04 00                	add    $0x0,%al
     a86:	00 cb                	add    %cl,%bl
     a88:	03 00                	add    (%rax),%eax
     a8a:	00 10                	add    %dl,(%rax)
     a8c:	04 00                	add    $0x0,%al
     a8e:	00 db                	add    %bl,%bl
     a90:	03 00                	add    (%rax),%eax
     a92:	00 eb                	add    %ch,%bl
     a94:	03 00                	add    (%rax),%eax
     a96:	00 fb                	add    %bh,%bl
     a98:	03 00                	add    (%rax),%eax
     a9a:	00 e4                	add    %ah,%ah
     a9c:	00 00                	add    %al,(%rax)
     a9e:	00 48 8b             	add    %cl,-0x75(%rax)
     aa1:	84 24 28             	test   %ah,(%rax,%rbp,1)
     aa4:	01 00                	add    %eax,(%rax)
     aa6:	00 4c 89 e1          	add    %cl,-0x1f(%rcx,%rcx,4)
     aaa:	e9 f7 3e 00 00       	jmp    0x49a6
     aaf:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
     ab6:	00 
     ab7:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
     abe:	00 
     abf:	e9 dc 10 00 00       	jmp    0x1ba0
     ac4:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     acb:	00 
     acc:	4c 89 e1             	mov    %r12,%rcx
     acf:	e9 d2 3e 00 00       	jmp    0x49a6
     ad4:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     adb:	00 
     adc:	4c 89 e1             	mov    %r12,%rcx
     adf:	e9 c2 3e 00 00       	jmp    0x49a6
     ae4:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
     aeb:	00 
     aec:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
     af3:	00 
     af4:	e9 a7 10 00 00       	jmp    0x1ba0
     af9:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
     b00:	00 
     b01:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
     b08:	00 
     b09:	e9 92 10 00 00       	jmp    0x1ba0
     b0e:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
     b15:	00 
     b16:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
     b1d:	00 
     b1e:	e9 7d 10 00 00       	jmp    0x1ba0
     b23:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     b2a:	00 
     b2b:	4c 89 e1             	mov    %r12,%rcx
     b2e:	e9 73 3e 00 00       	jmp    0x49a6
     b33:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     b3a:	00 
     b3b:	4c 89 e1             	mov    %r12,%rcx
     b3e:	e9 63 3e 00 00       	jmp    0x49a6
     b43:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     b4a:	00 
     b4b:	4c 89 e1             	mov    %r12,%rcx
     b4e:	e9 53 3e 00 00       	jmp    0x49a6
     b53:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     b5a:	00 
     b5b:	4c 89 e1             	mov    %r12,%rcx
     b5e:	e9 43 3e 00 00       	jmp    0x49a6
     b63:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     b6a:	00 
     b6b:	4c 89 e1             	mov    %r12,%rcx
     b6e:	e9 33 3e 00 00       	jmp    0x49a6
     b73:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     b7a:	00 
     b7b:	4c 89 e1             	mov    %r12,%rcx
     b7e:	e9 23 3e 00 00       	jmp    0x49a6
     b83:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     b8a:	00 
     b8b:	4c 89 e1             	mov    %r12,%rcx
     b8e:	e9 13 3e 00 00       	jmp    0x49a6
     b93:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     b9a:	00 
     b9b:	4c 89 e1             	mov    %r12,%rcx
     b9e:	e9 03 3e 00 00       	jmp    0x49a6
     ba3:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     baa:	00 
     bab:	4c 89 e1             	mov    %r12,%rcx
     bae:	e9 f3 3d 00 00       	jmp    0x49a6
     bb3:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     bba:	00 
     bbb:	4c 89 e1             	mov    %r12,%rcx
     bbe:	e9 e3 3d 00 00       	jmp    0x49a6
     bc3:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     bca:	00 
     bcb:	4c 89 e1             	mov    %r12,%rcx
     bce:	e9 d3 3d 00 00       	jmp    0x49a6
     bd3:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     bda:	00 
     bdb:	4c 89 e1             	mov    %r12,%rcx
     bde:	e9 c3 3d 00 00       	jmp    0x49a6
     be3:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     bea:	00 
     beb:	4c 89 e1             	mov    %r12,%rcx
     bee:	e9 b3 3d 00 00       	jmp    0x49a6
     bf3:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     bfa:	00 
     bfb:	4c 89 e1             	mov    %r12,%rcx
     bfe:	e9 a3 3d 00 00       	jmp    0x49a6
     c03:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     c0a:	00 
     c0b:	4c 89 e1             	mov    %r12,%rcx
     c0e:	e9 93 3d 00 00       	jmp    0x49a6
     c13:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     c1a:	00 
     c1b:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
     c22:	00 
     c23:	e9 9b 08 00 00       	jmp    0x14c3
     c28:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     c2f:	00 
     c30:	4c 89 e1             	mov    %r12,%rcx
     c33:	e9 6e 3d 00 00       	jmp    0x49a6
     c38:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     c3f:	00 
     c40:	4c 89 e1             	mov    %r12,%rcx
     c43:	e9 5e 3d 00 00       	jmp    0x49a6
     c48:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     c4f:	00 
     c50:	4c 89 e1             	mov    %r12,%rcx
     c53:	e9 4e 3d 00 00       	jmp    0x49a6
     c58:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     c5f:	00 
     c60:	4c 89 e1             	mov    %r12,%rcx
     c63:	e9 3e 3d 00 00       	jmp    0x49a6
     c68:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     c6f:	00 
     c70:	4c 89 e1             	mov    %r12,%rcx
     c73:	e9 2e 3d 00 00       	jmp    0x49a6
     c78:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     c7f:	00 
     c80:	4c 89 e1             	mov    %r12,%rcx
     c83:	e9 1e 3d 00 00       	jmp    0x49a6
     c88:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     c8f:	00 
     c90:	4c 89 e1             	mov    %r12,%rcx
     c93:	e9 0e 3d 00 00       	jmp    0x49a6
     c98:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     c9f:	00 
     ca0:	4c 89 e1             	mov    %r12,%rcx
     ca3:	e9 fe 3c 00 00       	jmp    0x49a6
     ca8:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
     caf:	00 
     cb0:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
     cb7:	00 
     cb8:	e9 e3 0e 00 00       	jmp    0x1ba0
     cbd:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     cc4:	00 
     cc5:	4c 89 e1             	mov    %r12,%rcx
     cc8:	e9 d9 3c 00 00       	jmp    0x49a6
     ccd:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     cd4:	00 
     cd5:	e9 e5 05 00 00       	jmp    0x12bf
     cda:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
     ce1:	00 
     ce2:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
     ce9:	00 
     cea:	e9 b1 0e 00 00       	jmp    0x1ba0
     cef:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
     cf6:	00 
     cf7:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
     cfe:	00 
     cff:	e9 9c 0e 00 00       	jmp    0x1ba0
     d04:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
     d0b:	00 
     d0c:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
     d13:	00 
     d14:	e9 87 0e 00 00       	jmp    0x1ba0
     d19:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     d20:	00 
     d21:	4c 89 e1             	mov    %r12,%rcx
     d24:	e9 7d 3c 00 00       	jmp    0x49a6
     d29:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     d30:	00 
     d31:	e9 89 05 00 00       	jmp    0x12bf
     d36:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     d3d:	00 
     d3e:	4c 89 e1             	mov    %r12,%rcx
     d41:	e9 60 3c 00 00       	jmp    0x49a6
     d46:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     d4d:	00 
     d4e:	4c 89 e1             	mov    %r12,%rcx
     d51:	e9 50 3c 00 00       	jmp    0x49a6
     d56:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     d5d:	00 
     d5e:	4c 89 e1             	mov    %r12,%rcx
     d61:	e9 40 3c 00 00       	jmp    0x49a6
     d66:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     d6d:	00 
     d6e:	4c 89 e1             	mov    %r12,%rcx
     d71:	e9 30 3c 00 00       	jmp    0x49a6
     d76:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     d7d:	00 
     d7e:	4c 89 e1             	mov    %r12,%rcx
     d81:	e9 20 3c 00 00       	jmp    0x49a6
     d86:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     d8d:	00 
     d8e:	4c 89 e1             	mov    %r12,%rcx
     d91:	e9 10 3c 00 00       	jmp    0x49a6
     d96:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     d9d:	00 
     d9e:	4c 89 e1             	mov    %r12,%rcx
     da1:	e9 00 3c 00 00       	jmp    0x49a6
     da6:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     dad:	00 
     dae:	4c 89 e1             	mov    %r12,%rcx
     db1:	e9 f0 3b 00 00       	jmp    0x49a6
     db6:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     dbd:	00 
     dbe:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
     dc5:	00 
     dc6:	e9 f8 06 00 00       	jmp    0x14c3
     dcb:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     dd2:	00 
     dd3:	2d 70 03 00 00       	sub    $0x370,%eax
     dd8:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     ddf:	00 
     de0:	49 8b 54 03 38       	mov    0x38(%r11,%rax,1),%rdx
     de5:	33 c0                	xor    %eax,%eax
     de7:	be 3a 0b 00 00       	mov    $0xb3a,%esi
     dec:	48 89 c7             	mov    %rax,%rdi
     def:	e9 4e 05 00 00       	jmp    0x1342
     df4:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     dfb:	00 
     dfc:	2d 70 03 00 00       	sub    $0x370,%eax
     e01:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     e08:	00 
     e09:	41 8b 44 03 38       	mov    0x38(%r11,%rax,1),%eax
     e0e:	be 44 0b 00 00       	mov    $0xb44,%esi
     e13:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
     e1a:	00 
     e1b:	85 c0                	test   %eax,%eax
     e1d:	0f 45 f0             	cmovne %eax,%esi
     e20:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
     e27:	00 
     e28:	e9 a7 03 00 00       	jmp    0x11d4
     e2d:	41 be 78 00 00 00    	mov    $0x78,%r14d
     e33:	ba 08 00 00 00       	mov    $0x8,%edx
     e38:	4d 89 e5             	mov    %r12,%r13
     e3b:	41 83 cd 08          	or     $0x8,%r13d
     e3f:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
     e46:	00 
     e47:	4d 89 ec             	mov    %r13,%r12
     e4a:	3b d1                	cmp    %ecx,%edx
     e4c:	0f 43 ca             	cmovae %edx,%ecx
     e4f:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     e56:	00 
     e57:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
     e5e:	00 
     e5f:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
     e66:	00 
     e67:	e9 57 06 00 00       	jmp    0x14c3
     e6c:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     e73:	00 
     e74:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
     e7b:	00 
     e7c:	2d 70 03 00 00       	sub    $0x370,%eax
     e81:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     e88:	00 
     e89:	49 8b 44 03 38       	mov    0x38(%r11,%rax,1),%rax
     e8e:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
     e95:	00 
     e96:	44 8d 92 c8 fc ff ff 	lea    -0x338(%rdx),%r10d
     e9d:	48 85 c0             	test   %rax,%rax
     ea0:	0f 85 0d 00 00 00    	jne    0xeb3
     ea6:	4c 89 94 24 98 00 00 	mov    %r10,0x98(%rsp)
     ead:	00 
     eae:	e9 40 00 00 00       	jmp    0xef3
     eb3:	4c 89 94 24 98 00 00 	mov    %r10,0x98(%rsp)
     eba:	00 
     ebb:	48 89 c2             	mov    %rax,%rdx
     ebe:	83 e2 07             	and    $0x7,%edx
     ec1:	83 ca 30             	or     $0x30,%edx
     ec4:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
     ecb:	00 
     ecc:	81 c6 ff ff ff ff    	add    $0xffffffff,%esi
     ed2:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     ed9:	00 
     eda:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
     ee1:	00 
     ee2:	41 88 14 33          	mov    %dl,(%r11,%rsi,1)
     ee6:	48 c1 e8 03          	shr    $0x3,%rax
     eea:	48 85 c0             	test   %rax,%rax
     eed:	0f 85 c8 ff ff ff    	jne    0xebb
     ef3:	33 c0                	xor    %eax,%eax
     ef5:	be 3a 0b 00 00       	mov    $0xb3a,%esi
     efa:	4d 89 e5             	mov    %r12,%r13
     efd:	41 f7 c5 08 00 00 00 	test   $0x8,%r13d
     f04:	0f 85 18 00 00 00    	jne    0xf22
     f0a:	48 89 c7             	mov    %rax,%rdi
     f0d:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
     f14:	00 
     f15:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
     f1c:	00 
     f1d:	e9 8b 06 00 00       	jmp    0x15ad
     f22:	4c 8b 9c 24 98 00 00 	mov    0x98(%rsp),%r11
     f29:	00 
     f2a:	45 2b d3             	sub    %r11d,%r10d
     f2d:	41 8d 52 01          	lea    0x1(%r10),%edx
     f31:	41 3b ca             	cmp    %r10d,%ecx
     f34:	0f 4f d1             	cmovg  %ecx,%edx
     f37:	33 c0                	xor    %eax,%eax
     f39:	48 89 c7             	mov    %rax,%rdi
     f3c:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
     f43:	00 
     f44:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
     f4b:	00 
     f4c:	e9 5c 06 00 00       	jmp    0x15ad
     f51:	41 81 e7 ff 00 00 00 	and    $0xff,%r15d
     f58:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
     f5d:	8d 72 01             	lea    0x1(%rdx),%esi
     f60:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
     f67:	00 
     f68:	45 33 ed             	xor    %r13d,%r13d
     f6b:	b8 08 00 00 00       	mov    $0x8,%eax
     f70:	44 3b f8             	cmp    %eax,%r15d
     f73:	41 0f 42 c7          	cmovb  %r15d,%eax
     f77:	48 8d 0d 09 00 00 00 	lea    0x9(%rip),%rcx        # 0xf87
     f7e:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
     f82:	48 03 c8             	add    %rax,%rcx
     f85:	ff e1                	jmp    *%rcx
     f87:	e4 01                	in     $0x1,%al
     f89:	00 00                	add    %al,(%rax)
     f8b:	9e                   	sahf
     f8c:	01 00                	add    %eax,(%rax)
     f8e:	00 58 01             	add    %bl,0x1(%rax)
     f91:	00 00                	add    %al,(%rax)
     f93:	14 01                	adc    $0x1,%al
     f95:	00 00                	add    %al,(%rax)
     f97:	d1 00                	roll   $1,(%rax)
     f99:	00 00                	add    %al,(%rax)
     f9b:	36 00 00             	ss add %al,(%rax)
     f9e:	00 8e 00 00 00 48    	add    %cl,0x48000000(%rsi)
     fa4:	00 00                	add    %al,(%rax)
     fa6:	00 24 00             	add    %ah,(%rax,%rax,1)
     fa9:	00 00                	add    %al,(%rax)
     fab:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
     fb0:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
     fb7:	00 
     fb8:	e9 06 f1 ff ff       	jmp    0xc3
     fbd:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
     fc2:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
     fc9:	00 
     fca:	e9 f4 f0 ff ff       	jmp    0xc3
     fcf:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
     fd6:	00 
     fd7:	2d 70 03 00 00       	sub    $0x370,%eax
     fdc:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
     fe3:	00 
     fe4:	49 8d 0c 03          	lea    (%r11,%rax,1),%rcx
     fe8:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
     fed:	48 63 f0             	movslq %eax,%rsi
     ff0:	8b 49 38             	mov    0x38(%rcx),%ecx
     ff3:	49 89 34 0b          	mov    %rsi,(%r11,%rcx,1)
     ff7:	8d 72 01             	lea    0x1(%rdx),%esi
     ffa:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    1001:	00 
    1002:	45 33 ed             	xor    %r13d,%r13d
    1005:	48 89 c1             	mov    %rax,%rcx
    1008:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    100f:	00 
    1010:	e9 ae f0 ff ff       	jmp    0xc3
    1015:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    101a:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
    1021:	00 
    1022:	81 e9 70 03 00 00    	sub    $0x370,%ecx
    1028:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    102f:	00 
    1030:	49 03 cb             	add    %r11,%rcx
    1033:	8b 49 38             	mov    0x38(%rcx),%ecx
    1036:	41 89 04 0b          	mov    %eax,(%r11,%rcx,1)
    103a:	8d 72 01             	lea    0x1(%rdx),%esi
    103d:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    1044:	00 
    1045:	45 33 ed             	xor    %r13d,%r13d
    1048:	48 89 c1             	mov    %rax,%rcx
    104b:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    1052:	00 
    1053:	e9 6b f0 ff ff       	jmp    0xc3
    1058:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    105d:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
    1064:	00 
    1065:	81 e9 70 03 00 00    	sub    $0x370,%ecx
    106b:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1072:	00 
    1073:	49 03 cb             	add    %r11,%rcx
    1076:	8b 49 38             	mov    0x38(%rcx),%ecx
    1079:	41 88 04 0b          	mov    %al,(%r11,%rcx,1)
    107d:	8d 72 01             	lea    0x1(%rdx),%esi
    1080:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    1087:	00 
    1088:	45 33 ed             	xor    %r13d,%r13d
    108b:	48 89 c1             	mov    %rax,%rcx
    108e:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    1095:	00 
    1096:	e9 28 f0 ff ff       	jmp    0xc3
    109b:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    10a0:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
    10a7:	00 
    10a8:	81 e9 70 03 00 00    	sub    $0x370,%ecx
    10ae:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    10b5:	00 
    10b6:	49 03 cb             	add    %r11,%rcx
    10b9:	8b 49 38             	mov    0x38(%rcx),%ecx
    10bc:	66 41 89 04 0b       	mov    %ax,(%r11,%rcx,1)
    10c1:	8d 72 01             	lea    0x1(%rdx),%esi
    10c4:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    10cb:	00 
    10cc:	45 33 ed             	xor    %r13d,%r13d
    10cf:	48 89 c1             	mov    %rax,%rcx
    10d2:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    10d9:	00 
    10da:	e9 e4 ef ff ff       	jmp    0xc3
    10df:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    10e4:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
    10eb:	00 
    10ec:	81 e9 70 03 00 00    	sub    $0x370,%ecx
    10f2:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    10f9:	00 
    10fa:	49 03 cb             	add    %r11,%rcx
    10fd:	48 63 f0             	movslq %eax,%rsi
    1100:	8b 49 38             	mov    0x38(%rcx),%ecx
    1103:	49 89 34 0b          	mov    %rsi,(%r11,%rcx,1)
    1107:	8d 72 01             	lea    0x1(%rdx),%esi
    110a:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    1111:	00 
    1112:	45 33 ed             	xor    %r13d,%r13d
    1115:	48 89 c1             	mov    %rax,%rcx
    1118:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    111f:	00 
    1120:	e9 9e ef ff ff       	jmp    0xc3
    1125:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    112a:	4c 8b 8c 24 28 01 00 	mov    0x128(%rsp),%r9
    1131:	00 
    1132:	4c 89 c9             	mov    %r9,%rcx
    1135:	81 e9 70 03 00 00    	sub    $0x370,%ecx
    113b:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1142:	00 
    1143:	49 03 cb             	add    %r11,%rcx
    1146:	8b 49 38             	mov    0x38(%rcx),%ecx
    1149:	41 89 04 0b          	mov    %eax,(%r11,%rcx,1)
    114d:	8d 72 01             	lea    0x1(%rdx),%esi
    1150:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    1157:	00 
    1158:	45 33 ed             	xor    %r13d,%r13d
    115b:	48 89 c1             	mov    %rax,%rcx
    115e:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    1165:	00 
    1166:	e9 58 ef ff ff       	jmp    0xc3
    116b:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    1170:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
    1177:	00 
    1178:	81 e9 70 03 00 00    	sub    $0x370,%ecx
    117e:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1185:	00 
    1186:	49 03 cb             	add    %r11,%rcx
    1189:	8b 49 38             	mov    0x38(%rcx),%ecx
    118c:	41 89 04 0b          	mov    %eax,(%r11,%rcx,1)
    1190:	8d 72 01             	lea    0x1(%rdx),%esi
    1193:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    119a:	00 
    119b:	45 33 ed             	xor    %r13d,%r13d
    119e:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    11a3:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    11aa:	00 
    11ab:	e9 13 ef ff ff       	jmp    0xc3
    11b0:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    11b7:	00 
    11b8:	41 8b 93 d0 10 00 00 	mov    0x10d0(%r11),%edx
    11bf:	48 8b 34 24          	mov    (%rsp),%rsi
    11c3:	48 8b 3c 24          	mov    (%rsp),%rdi
    11c7:	e8 54 ea ff ff       	call   0xfffffffffffffc20
    11cc:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    11d3:	00 
    11d4:	33 c0                	xor    %eax,%eax
    11d6:	49 89 c6             	mov    %rax,%r14
    11d9:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    11e0:	00 
    11e1:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    11e8:	00 
    11e9:	85 c1                	test   %eax,%ecx
    11eb:	0f 4c 0d 3e 43 00 00 	cmovl  0x433e(%rip),%ecx        # 0x5530
    11f2:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
    11f9:	00 
    11fa:	48 8b 34 24          	mov    (%rsp),%rsi
    11fe:	48 8b 3c 24          	mov    (%rsp),%rdi
    1202:	e8 19 4b 00 00       	call   0x5d20
    1207:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
    120e:	00 
    120f:	44 8d 04 06          	lea    (%rsi,%rax,1),%r8d
    1213:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    121a:	00 
    121b:	49 89 c1             	mov    %rax,%r9
    121e:	81 e1 ff ff fe ff    	and    $0xfffeffff,%ecx
    1224:	be 3a 0b 00 00       	mov    $0xb3a,%esi
    1229:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    1230:	00 
    1231:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    1238:	00 
    1239:	85 d0                	test   %edx,%eax
    123b:	0f 8c 28 00 00 00    	jl     0x1269
    1241:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
    1248:	00 
    1249:	4c 89 8c 24 a0 00 00 	mov    %r9,0xa0(%rsp)
    1250:	00 
    1251:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
    1258:	00 
    1259:	4c 89 f7             	mov    %r14,%rdi
    125c:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
    1263:	00 
    1264:	e9 6b 37 00 00       	jmp    0x49d4
    1269:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1270:	00 
    1271:	4b 0f b6 0c 03       	movzbq (%r11,%r8,1),%rcx
    1276:	33 ff                	xor    %edi,%edi
    1278:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
    127f:	00 
    1280:	25 ff ff fe ff       	and    $0xfffeffff,%eax
    1285:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    128c:	00 
    128d:	85 c9                	test   %ecx,%ecx
    128f:	0f 85 1d 00 00 00    	jne    0x12b2
    1295:	4c 89 8c 24 a0 00 00 	mov    %r9,0xa0(%rsp)
    129c:	00 
    129d:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
    12a4:	00 
    12a5:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
    12ac:	00 
    12ad:	e9 22 37 00 00       	jmp    0x49d4
    12b2:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    12b9:	00 
    12ba:	e9 e4 41 00 00       	jmp    0x54a3
    12bf:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    12c6:	00 
    12c7:	2d 70 03 00 00       	sub    $0x370,%eax
    12cc:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    12d3:	00 
    12d4:	49 8b 54 03 38       	mov    0x38(%r11,%rax,1),%rdx
    12d9:	48 85 d2             	test   %rdx,%rdx
    12dc:	0f 8d 22 00 00 00    	jge    0x1304
    12e2:	48 f7 da             	neg    %rdx
    12e5:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    12ec:	00 
    12ed:	49 89 54 03 38       	mov    %rdx,0x38(%r11,%rax,1)
    12f2:	be 3a 0b 00 00       	mov    $0xb3a,%esi
    12f7:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
    12fe:	00 
    12ff:	e9 3e 00 00 00       	jmp    0x1342
    1304:	4d 89 e5             	mov    %r12,%r13
    1307:	41 f7 c5 00 08 00 00 	test   $0x800,%r13d
    130e:	0f 84 12 00 00 00    	je     0x1326
    1314:	be 3b 0b 00 00       	mov    $0xb3b,%esi
    1319:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
    1320:	00 
    1321:	e9 1c 00 00 00       	jmp    0x1342
    1326:	4d 89 e5             	mov    %r12,%r13
    1329:	4c 89 ef             	mov    %r13,%rdi
    132c:	83 e7 01             	and    $0x1,%edi
    132f:	be 3a 0b 00 00       	mov    $0xb3a,%esi
    1334:	41 f7 c5 01 00 00 00 	test   $0x1,%r13d
    133b:	0f 45 35 f6 41 00 00 	cmovne 0x41f6(%rip),%esi        # 0x5538
    1342:	48 3b 15 f7 41 00 00 	cmp    0x41f7(%rip),%rdx        # 0x5540
    1349:	0f 83 1c 00 00 00    	jae    0x136b
    134f:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1356:	00 
    1357:	44 8d 90 c8 fc ff ff 	lea    -0x338(%rax),%r10d
    135e:	4c 89 94 24 98 00 00 	mov    %r10,0x98(%rsp)
    1365:	00 
    1366:	e9 6b 00 00 00       	jmp    0x13d6
    136b:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1372:	00 
    1373:	81 c0 c8 fc ff ff    	add    $0xfffffcc8,%eax
    1379:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    1380:	00 
    1381:	c4 62 bb f6 05 be 41 	mulx   0x41be(%rip),%r8,%r8        # 0x5548
    1388:	00 00 
    138a:	49 c1 e8 03          	shr    $0x3,%r8
    138e:	4d 6b d0 0a          	imul   $0xa,%r8,%r10
    1392:	49 89 d1             	mov    %rdx,%r9
    1395:	4d 2b ca             	sub    %r10,%r9
    1398:	41 83 c9 30          	or     $0x30,%r9d
    139c:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
    13a3:	00 
    13a4:	81 c0 ff ff ff ff    	add    $0xffffffff,%eax
    13aa:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    13b1:	00 
    13b2:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    13b9:	00 
    13ba:	45 88 0c 03          	mov    %r9b,(%r11,%rax,1)
    13be:	48 3b 15 8b 41 00 00 	cmp    0x418b(%rip),%rdx        # 0x5550
    13c5:	0f 86 08 00 00 00    	jbe    0x13d3
    13cb:	4c 89 c2             	mov    %r8,%rdx
    13ce:	e9 ae ff ff ff       	jmp    0x1381
    13d3:	4c 89 c2             	mov    %r8,%rdx
    13d6:	85 d2                	test   %edx,%edx
    13d8:	0f 85 0d 00 00 00    	jne    0x13eb
    13de:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    13e5:	00 
    13e6:	e9 c2 01 00 00       	jmp    0x15ad
    13eb:	c4 e2 7b f6 05 64 41 	mulx   0x4164(%rip),%eax,%eax        # 0x5558
    13f2:	00 00 
    13f4:	c1 e8 03             	shr    $0x3,%eax
    13f7:	44 6b c0 0a          	imul   $0xa,%eax,%r8d
    13fb:	48 89 d1             	mov    %rdx,%rcx
    13fe:	41 2b c8             	sub    %r8d,%ecx
    1401:	83 c9 30             	or     $0x30,%ecx
    1404:	4c 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8
    140b:	00 
    140c:	41 81 c0 ff ff ff ff 	add    $0xffffffff,%r8d
    1413:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    141a:	00 
    141b:	4c 89 84 24 98 00 00 	mov    %r8,0x98(%rsp)
    1422:	00 
    1423:	43 88 0c 03          	mov    %cl,(%r11,%r8,1)
    1427:	83 fa 09             	cmp    $0x9,%edx
    142a:	0f 86 08 00 00 00    	jbe    0x1438
    1430:	48 89 c2             	mov    %rax,%rdx
    1433:	e9 b3 ff ff ff       	jmp    0x13eb
    1438:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    143f:	00 
    1440:	e9 68 01 00 00       	jmp    0x15ad
    1445:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    144c:	00 
    144d:	2d 70 03 00 00       	sub    $0x370,%eax
    1452:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1459:	00 
    145a:	49 8b 4c 03 38       	mov    0x38(%r11,%rax,1),%rcx
    145f:	41 88 4c 03 37       	mov    %cl,0x37(%r11,%rax,1)
    1464:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    146b:	00 
    146c:	44 8d 80 c8 fc ff ff 	lea    -0x338(%rax),%r8d
    1473:	8d b0 c7 fc ff ff    	lea    -0x339(%rax),%esi
    1479:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    1480:	00 
    1481:	33 ff                	xor    %edi,%edi
    1483:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    148a:	00 
    148b:	81 e1 ff ff fe ff    	and    $0xfffeffff,%ecx
    1491:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
    1498:	00 
    1499:	be 3a 0b 00 00       	mov    $0xb3a,%esi
    149e:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    14a5:	00 
    14a6:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    14ad:	00 
    14ae:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
    14b5:	00 
    14b6:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
    14bd:	00 
    14be:	e9 11 35 00 00       	jmp    0x49d4
    14c3:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    14ca:	00 
    14cb:	48 89 c1             	mov    %rax,%rcx
    14ce:	81 e9 70 03 00 00    	sub    $0x370,%ecx
    14d4:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    14db:	00 
    14dc:	49 8b 54 0b 38       	mov    0x38(%r11,%rcx,1),%rdx
    14e1:	48 85 d2             	test   %rdx,%rdx
    14e4:	0f 85 22 00 00 00    	jne    0x150c
    14ea:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    14f1:	00 
    14f2:	8d b0 c8 fc ff ff    	lea    -0x338(%rax),%esi
    14f8:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    14ff:	00 
    1500:	33 ff                	xor    %edi,%edi
    1502:	be 3a 0b 00 00       	mov    $0xb3a,%esi
    1507:	e9 a1 00 00 00       	jmp    0x15ad
    150c:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1513:	00 
    1514:	8d b0 c8 fc ff ff    	lea    -0x338(%rax),%esi
    151a:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    1521:	00 
    1522:	4c 89 f6             	mov    %r14,%rsi
    1525:	83 e6 20             	and    $0x20,%esi
    1528:	48 89 d7             	mov    %rdx,%rdi
    152b:	83 e7 0f             	and    $0xf,%edi
    152e:	81 c7 b0 0d 00 00    	add    $0xdb0,%edi
    1534:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    153b:	00 
    153c:	49 0f b6 3c 3b       	movzbq (%r11,%rdi,1),%rdi
    1541:	0b fe                	or     %esi,%edi
    1543:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
    154a:	00 
    154b:	44 8d 40 ff          	lea    -0x1(%rax),%r8d
    154f:	4c 89 c0             	mov    %r8,%rax
    1552:	4c 89 84 24 98 00 00 	mov    %r8,0x98(%rsp)
    1559:	00 
    155a:	41 88 3c 03          	mov    %dil,(%r11,%rax,1)
    155e:	48 c1 ea 04          	shr    $0x4,%rdx
    1562:	48 85 d2             	test   %rdx,%rdx
    1565:	0f 85 bd ff ff ff    	jne    0x1528
    156b:	33 ff                	xor    %edi,%edi
    156d:	be 3a 0b 00 00       	mov    $0xb3a,%esi
    1572:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
    1579:	00 
    157a:	a9 08 00 00 00       	test   $0x8,%eax
    157f:	0f 84 28 00 00 00    	je     0x15ad
    1585:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    158c:	00 
    158d:	49 8b 4c 0b 38       	mov    0x38(%r11,%rcx,1),%rcx
    1592:	33 ff                	xor    %edi,%edi
    1594:	48 85 c9             	test   %rcx,%rcx
    1597:	0f 84 10 00 00 00    	je     0x15ad
    159d:	bf 02 00 00 00       	mov    $0x2,%edi
    15a2:	41 c1 fe 04          	sar    $0x4,%r14d
    15a6:	41 8d b6 3a 0b 00 00 	lea    0xb3a(%r14),%esi
    15ad:	85 db                	test   %ebx,%ebx
    15af:	0f 85 0d 00 00 00    	jne    0x15c2
    15b5:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    15bc:	00 
    15bd:	e9 2d 00 00 00       	jmp    0x15ef
    15c2:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    15c9:	00 
    15ca:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    15d1:	00 
    15d2:	85 c1                	test   %eax,%ecx
    15d4:	0f 8d 0d 00 00 00    	jge    0x15e7
    15da:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    15e1:	00 
    15e2:	e9 bc 3e 00 00       	jmp    0x54a3
    15e7:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    15ee:	00 
    15ef:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    15f6:	00 
    15f7:	2d 70 03 00 00       	sub    $0x370,%eax
    15fc:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1603:	00 
    1604:	49 8b 4c 03 38       	mov    0x38(%r11,%rax,1),%rcx
    1609:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    1610:	00 
    1611:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    1618:	00 
    1619:	85 d0                	test   %edx,%eax
    161b:	0f 84 0d 00 00 00    	je     0x162e
    1621:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1628:	00 
    1629:	e9 75 00 00 00       	jmp    0x16a3
    162e:	48 85 c9             	test   %rcx,%rcx
    1631:	0f 84 0d 00 00 00    	je     0x1644
    1637:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    163e:	00 
    163f:	e9 5f 00 00 00       	jmp    0x16a3
    1644:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    164b:	00 
    164c:	44 8d 80 c8 fc ff ff 	lea    -0x338(%rax),%r8d
    1653:	48 89 c8             	mov    %rcx,%rax
    1656:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    165d:	00 
    165e:	33 c8                	xor    %eax,%ecx
    1660:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    1667:	00 
    1668:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    166f:	00 
    1670:	81 e1 ff ff fe ff    	and    $0xfffeffff,%ecx
    1676:	85 db                	test   %ebx,%ebx
    1678:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
    167f:	00 
    1680:	0f 45 c1             	cmovne %ecx,%eax
    1683:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    168a:	00 
    168b:	4c 89 84 24 98 00 00 	mov    %r8,0x98(%rsp)
    1692:	00 
    1693:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
    169a:	00 
    169b:	4c 89 c6             	mov    %r8,%rsi
    169e:	e9 31 33 00 00       	jmp    0x49d4
    16a3:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    16aa:	00 
    16ab:	44 8d 80 c8 fc ff ff 	lea    -0x338(%rax),%r8d
    16b2:	4c 8b 8c 24 98 00 00 	mov    0x98(%rsp),%r9
    16b9:	00 
    16ba:	4c 89 c2             	mov    %r8,%rdx
    16bd:	41 2b d1             	sub    %r9d,%edx
    16c0:	48 85 c9             	test   %rcx,%rcx
    16c3:	0f 94 c0             	sete   %al
    16c6:	0f b6 c0             	movzbl %al,%eax
    16c9:	8d 0c 02             	lea    (%rdx,%rax,1),%ecx
    16cc:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
    16d3:	00 
    16d4:	41 3b c9             	cmp    %r9d,%ecx
    16d7:	44 0f 4d c9          	cmovge %ecx,%r9d
    16db:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    16e2:	00 
    16e3:	4c 89 8c 24 a0 00 00 	mov    %r9,0xa0(%rsp)
    16ea:	00 
    16eb:	81 e1 ff ff fe ff    	and    $0xfffeffff,%ecx
    16f1:	85 db                	test   %ebx,%ebx
    16f3:	4c 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%r9
    16fa:	00 
    16fb:	44 0f 45 c9          	cmovne %ecx,%r9d
    16ff:	4c 89 8c 24 c0 00 00 	mov    %r9,0xc0(%rsp)
    1706:	00 
    1707:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
    170e:	00 
    170f:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
    1716:	00 
    1717:	e9 b8 32 00 00       	jmp    0x49d4
    171c:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1723:	00 
    1724:	2d 70 03 00 00       	sub    $0x370,%eax
    1729:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1730:	00 
    1731:	45 8b 6c 03 38       	mov    0x38(%r11,%rax,1),%r13d
    1736:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    173d:	00 
    173e:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    1745:	00 
    1746:	85 c1                	test   %eax,%ecx
    1748:	0f 85 50 00 00 00    	jne    0x179e
    174e:	45 33 ff             	xor    %r15d,%r15d
    1751:	4c 89 e0             	mov    %r12,%rax
    1754:	e9 d7 00 00 00       	jmp    0x1830
    1759:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1760:	00 
    1761:	48 89 c2             	mov    %rax,%rdx
    1764:	81 ea 70 03 00 00    	sub    $0x370,%edx
    176a:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1771:	00 
    1772:	41 c7 44 13 0c 00 00 	movl   $0x0,0xc(%r11,%rdx,1)
    1779:	00 00 
    177b:	49 8b 74 13 38       	mov    0x38(%r11,%rdx,1),%rsi
    1780:	41 89 74 13 08       	mov    %esi,0x8(%r11,%rdx,1)
    1785:	44 8d a8 98 fc ff ff 	lea    -0x368(%rax),%r13d
    178c:	45 89 6c 13 38       	mov    %r13d,0x38(%r11,%rdx,1)
    1791:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    1796:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    179d:	00 
    179e:	45 33 ff             	xor    %r15d,%r15d
    17a1:	4c 89 eb             	mov    %r13,%rbx
    17a4:	8b fb                	mov    %ebx,%edi
    17a6:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    17ad:	00 
    17ae:	41 8b 0c 3b          	mov    (%r11,%rdi,1),%ecx
    17b2:	85 c9                	test   %ecx,%ecx
    17b4:	0f 84 5d 00 00 00    	je     0x1817
    17ba:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    17c1:	00 
    17c2:	8d 90 94 fc ff ff    	lea    -0x36c(%rax),%edx
    17c8:	48 8b 34 24          	mov    (%rsp),%rsi
    17cc:	48 8b 3c 24          	mov    (%rsp),%rdi
    17d0:	e8 eb 4f 00 00       	call   0x67c0
    17d5:	85 c0                	test   %eax,%eax
    17d7:	0f 8c 32 00 00 00    	jl     0x180f
    17dd:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    17e4:	00 
    17e5:	41 2b cf             	sub    %r15d,%ecx
    17e8:	3b c1                	cmp    %ecx,%eax
    17ea:	0f 87 1f 00 00 00    	ja     0x180f
    17f0:	44 03 f8             	add    %eax,%r15d
    17f3:	81 c3 04 00 00 00    	add    $0x4,%ebx
    17f9:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    1800:	00 
    1801:	41 3b cf             	cmp    %r15d,%ecx
    1804:	0f 87 9a ff ff ff    	ja     0x17a4
    180a:	e9 08 00 00 00       	jmp    0x1817
    180f:	85 c0                	test   %eax,%eax
    1811:	0f 8c 97 3c 00 00    	jl     0x54ae
    1817:	45 85 ff             	test   %r15d,%r15d
    181a:	0f 8d 0d 00 00 00    	jge    0x182d
    1820:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1827:	00 
    1828:	e9 76 3c 00 00       	jmp    0x54a3
    182d:	4c 89 e0             	mov    %r12,%rax
    1830:	4c 89 e0             	mov    %r12,%rax
    1833:	a9 00 20 01 00       	test   $0x12000,%eax
    1838:	0f 85 24 01 00 00    	jne    0x1962
    183e:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    1845:	00 
    1846:	41 3b cf             	cmp    %r15d,%ecx
    1849:	0f 8e 13 01 00 00    	jle    0x1962
    184f:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1856:	00 
    1857:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    185d:	b9 20 00 00 00       	mov    $0x20,%ecx
    1862:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    1869:	00 
    186a:	41 2b c7             	sub    %r15d,%eax
    186d:	be 00 01 00 00       	mov    $0x100,%esi
    1872:	3b f0                	cmp    %eax,%esi
    1874:	49 89 c0             	mov    %rax,%r8
    1877:	44 0f 42 c6          	cmovb  %esi,%r8d
    187b:	48 89 c3             	mov    %rax,%rbx
    187e:	48 8b 34 24          	mov    (%rsp),%rsi
    1882:	48 8b 3c 24          	mov    (%rsp),%rdi
    1886:	e8 55 4b 00 00       	call   0x63e0
    188b:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1892:	00 
    1893:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    189a:	00 
    189b:	41 8b 14 03          	mov    (%r11,%rax,1),%edx
    189f:	f7 c2 20 00 00 00    	test   $0x20,%edx
    18a5:	0f 94 c0             	sete   %al
    18a8:	40 0f b6 f0          	rex movzbl %al,%esi
    18ac:	48 89 d9             	mov    %rbx,%rcx
    18af:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    18b5:	0f 83 08 00 00 00    	jae    0x18c3
    18bb:	48 89 d9             	mov    %rbx,%rcx
    18be:	e9 77 00 00 00       	jmp    0x193a
    18c3:	f7 c6 01 00 00 00    	test   $0x1,%esi
    18c9:	0f 85 08 00 00 00    	jne    0x18d7
    18cf:	48 89 d9             	mov    %rbx,%rcx
    18d2:	e9 3c 00 00 00       	jmp    0x1913
    18d7:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    18de:	00 
    18df:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    18e5:	b9 00 01 00 00       	mov    $0x100,%ecx
    18ea:	48 8b 34 24          	mov    (%rsp),%rsi
    18ee:	48 8b 3c 24          	mov    (%rsp),%rdi
    18f2:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    18f7:	e8 84 d1 ff ff       	call   0xffffffffffffea80
    18fc:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1903:	00 
    1904:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    190b:	00 
    190c:	41 8b 14 03          	mov    (%r11,%rax,1),%edx
    1910:	48 89 d9             	mov    %rbx,%rcx
    1913:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    1919:	f7 c2 20 00 00 00    	test   $0x20,%edx
    191f:	0f 94 c0             	sete   %al
    1922:	40 0f b6 f0          	rex movzbl %al,%esi
    1926:	81 f9 ff 00 00 00    	cmp    $0xff,%ecx
    192c:	0f 86 08 00 00 00    	jbe    0x193a
    1932:	48 89 cb             	mov    %rcx,%rbx
    1935:	e9 89 ff ff ff       	jmp    0x18c3
    193a:	85 f6                	test   %esi,%esi
    193c:	0f 84 20 00 00 00    	je     0x1962
    1942:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1949:	00 
    194a:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    1950:	48 8b 34 24          	mov    (%rsp),%rsi
    1954:	48 8b 3c 24          	mov    (%rsp),%rdi
    1958:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    195d:	e8 1e d1 ff ff       	call   0xffffffffffffea80
    1962:	45 85 ff             	test   %r15d,%r15d
    1965:	0f 85 08 00 00 00    	jne    0x1973
    196b:	4d 89 e5             	mov    %r12,%r13
    196e:	e9 9f 00 00 00       	jmp    0x1a12
    1973:	33 db                	xor    %ebx,%ebx
    1975:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    197c:	00 
    197d:	44 8d b0 94 fc ff ff 	lea    -0x36c(%rax),%r14d
    1984:	41 8b c5             	mov    %r13d,%eax
    1987:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    198e:	00 
    198f:	41 8b 0c 03          	mov    (%r11,%rax,1),%ecx
    1993:	85 c9                	test   %ecx,%ecx
    1995:	0f 85 08 00 00 00    	jne    0x19a3
    199b:	4d 89 e5             	mov    %r12,%r13
    199e:	e9 6f 00 00 00       	jmp    0x1a12
    19a3:	4c 89 f2             	mov    %r14,%rdx
    19a6:	48 8b 34 24          	mov    (%rsp),%rsi
    19aa:	48 8b 3c 24          	mov    (%rsp),%rdi
    19ae:	e8 0d 4e 00 00       	call   0x67c0
    19b3:	03 d8                	add    %eax,%ebx
    19b5:	48 89 c1             	mov    %rax,%rcx
    19b8:	41 3b df             	cmp    %r15d,%ebx
    19bb:	0f 86 08 00 00 00    	jbe    0x19c9
    19c1:	4d 89 e5             	mov    %r12,%r13
    19c4:	e9 49 00 00 00       	jmp    0x1a12
    19c9:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    19d0:	00 
    19d1:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    19d8:	00 
    19d9:	49 0f b6 14 03       	movzbq (%r11,%rax,1),%rdx
    19de:	f7 c2 20 00 00 00    	test   $0x20,%edx
    19e4:	0f 85 15 00 00 00    	jne    0x19ff
    19ea:	4c 89 f2             	mov    %r14,%rdx
    19ed:	48 8b 34 24          	mov    (%rsp),%rsi
    19f1:	48 8b 3c 24          	mov    (%rsp),%rdi
    19f5:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    19fa:	e8 81 d0 ff ff       	call   0xffffffffffffea80
    19ff:	41 81 c5 04 00 00 00 	add    $0x4,%r13d
    1a06:	41 3b df             	cmp    %r15d,%ebx
    1a09:	0f 82 75 ff ff ff    	jb     0x1984
    1a0f:	4d 89 e5             	mov    %r12,%r13
    1a12:	4d 89 e5             	mov    %r12,%r13
    1a15:	41 81 e5 00 20 01 00 	and    $0x12000,%r13d
    1a1c:	4d 89 ec             	mov    %r13,%r12
    1a1f:	41 81 fd 00 20 00 00 	cmp    $0x2000,%r13d
    1a26:	0f 84 0a 00 00 00    	je     0x1a36
    1a2c:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    1a31:	e9 2e 01 00 00       	jmp    0x1b64
    1a36:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    1a3d:	00 
    1a3e:	41 3b cf             	cmp    %r15d,%ecx
    1a41:	0f 8f 0a 00 00 00    	jg     0x1a51
    1a47:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    1a4c:	e9 13 01 00 00       	jmp    0x1b64
    1a51:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1a58:	00 
    1a59:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    1a5f:	49 89 d4             	mov    %rdx,%r12
    1a62:	b9 20 00 00 00       	mov    $0x20,%ecx
    1a67:	4c 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%r9
    1a6e:	00 
    1a6f:	4c 89 c8             	mov    %r9,%rax
    1a72:	41 2b c7             	sub    %r15d,%eax
    1a75:	bb 00 01 00 00       	mov    $0x100,%ebx
    1a7a:	3b d8                	cmp    %eax,%ebx
    1a7c:	49 89 c0             	mov    %rax,%r8
    1a7f:	44 0f 42 c3          	cmovb  %ebx,%r8d
    1a83:	49 89 c5             	mov    %rax,%r13
    1a86:	48 8b 34 24          	mov    (%rsp),%rsi
    1a8a:	48 8b 3c 24          	mov    (%rsp),%rdi
    1a8e:	e8 4d 49 00 00       	call   0x63e0
    1a93:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1a9a:	00 
    1a9b:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1aa2:	00 
    1aa3:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    1aa7:	f7 c6 20 00 00 00    	test   $0x20,%esi
    1aad:	0f 94 c0             	sete   %al
    1ab0:	0f b6 d0             	movzbl %al,%edx
    1ab3:	4c 89 e9             	mov    %r13,%rcx
    1ab6:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    1abc:	0f 83 08 00 00 00    	jae    0x1aca
    1ac2:	4c 89 e9             	mov    %r13,%rcx
    1ac5:	e9 6e 00 00 00       	jmp    0x1b38
    1aca:	f7 c2 01 00 00 00    	test   $0x1,%edx
    1ad0:	0f 85 08 00 00 00    	jne    0x1ade
    1ad6:	4c 89 e9             	mov    %r13,%rcx
    1ad9:	e9 2f 00 00 00       	jmp    0x1b0d
    1ade:	48 89 d9             	mov    %rbx,%rcx
    1ae1:	4c 89 e2             	mov    %r12,%rdx
    1ae4:	48 8b 34 24          	mov    (%rsp),%rsi
    1ae8:	48 8b 3c 24          	mov    (%rsp),%rdi
    1aec:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    1af1:	e8 8a cf ff ff       	call   0xffffffffffffea80
    1af6:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1afd:	00 
    1afe:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1b05:	00 
    1b06:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    1b0a:	4c 89 e9             	mov    %r13,%rcx
    1b0d:	8d 81 00 ff ff ff    	lea    -0x100(%rcx),%eax
    1b13:	f7 c6 20 00 00 00    	test   $0x20,%esi
    1b19:	0f 94 c2             	sete   %dl
    1b1c:	0f b6 d2             	movzbl %dl,%edx
    1b1f:	3d ff 00 00 00       	cmp    $0xff,%eax
    1b24:	0f 86 08 00 00 00    	jbe    0x1b32
    1b2a:	49 89 c5             	mov    %rax,%r13
    1b2d:	e9 98 ff ff ff       	jmp    0x1aca
    1b32:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    1b38:	85 d2                	test   %edx,%edx
    1b3a:	0f 85 0a 00 00 00    	jne    0x1b4a
    1b40:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    1b45:	e9 1a 00 00 00       	jmp    0x1b64
    1b4a:	4c 89 e2             	mov    %r12,%rdx
    1b4d:	48 8b 34 24          	mov    (%rsp),%rsi
    1b51:	48 8b 3c 24          	mov    (%rsp),%rdi
    1b55:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    1b5a:	e8 21 cf ff ff       	call   0xffffffffffffea80
    1b5f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    1b64:	8d 72 01             	lea    0x1(%rdx),%esi
    1b67:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    1b6e:	00 
    1b6f:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    1b76:	00 
    1b77:	44 3b f9             	cmp    %ecx,%r15d
    1b7a:	41 0f 4d cf          	cmovge %r15d,%ecx
    1b7e:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    1b85:	00 
    1b86:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    1b8b:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
    1b92:	00 
    1b93:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    1b9a:	00 
    1b9b:	e9 23 e5 ff ff       	jmp    0xc3
    1ba0:	85 c1                	test   %eax,%ecx
    1ba2:	0f 8c 0d 00 00 00    	jl     0x1bb5
    1ba8:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1baf:	00 
    1bb0:	e9 1d 00 00 00       	jmp    0x1bd2
    1bb5:	85 db                	test   %ebx,%ebx
    1bb7:	0f 84 0d 00 00 00    	je     0x1bca
    1bbd:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1bc4:	00 
    1bc5:	e9 d9 38 00 00       	jmp    0x54a3
    1bca:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1bd1:	00 
    1bd2:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1bd9:	00 
    1bda:	49 89 c5             	mov    %rax,%r13
    1bdd:	41 81 ed 70 03 00 00 	sub    $0x370,%r13d
    1be4:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1beb:	00 
    1bec:	c4 81 7b 10 44 2b 38 	vmovsd 0x38(%r11,%r13,1),%xmm0
    1bf3:	43 c7 84 2b 6c 01 00 	movl   $0x0,0x16c(%r11,%r13,1)
    1bfa:	00 00 00 00 00 
    1bff:	c4 e1 f9 7e c1       	vmovq  %xmm0,%rcx
    1c04:	48 33 d2             	xor    %rdx,%rdx
    1c07:	49 89 d7             	mov    %rdx,%r15
    1c0a:	48 85 c9             	test   %rcx,%rcx
    1c0d:	0f 8d 31 00 00 00    	jge    0x1c44
    1c13:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    1c1a:	00 00 80 
    1c1d:	c4 e1 f9 6e c9       	vmovq  %rcx,%xmm1
    1c22:	c5 f9 57 c1          	vxorpd %xmm1,%xmm0,%xmm0
    1c26:	ba c0 0d 00 00       	mov    $0xdc0,%edx
    1c2b:	33 f6                	xor    %esi,%esi
    1c2d:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
    1c34:	00 
    1c35:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
    1c3a:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    1c3f:	e9 60 00 00 00       	jmp    0x1ca4
    1c44:	4c 89 e0             	mov    %r12,%rax
    1c47:	a9 00 08 00 00       	test   $0x800,%eax
    1c4c:	0f 84 1e 00 00 00    	je     0x1c70
    1c52:	ba c3 0d 00 00       	mov    $0xdc3,%edx
    1c57:	33 f6                	xor    %esi,%esi
    1c59:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
    1c60:	00 
    1c61:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
    1c66:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    1c6b:	e9 34 00 00 00       	jmp    0x1ca4
    1c70:	4c 89 e0             	mov    %r12,%rax
    1c73:	48 89 c1             	mov    %rax,%rcx
    1c76:	83 e1 01             	and    $0x1,%ecx
    1c79:	ba c1 0d 00 00       	mov    $0xdc1,%edx
    1c7e:	a9 01 00 00 00       	test   $0x1,%eax
    1c83:	0f 45 15 d6 38 00 00 	cmovne 0x38d6(%rip),%edx        # 0x5560
    1c8a:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    1c8f:	4c 89 e2             	mov    %r12,%rdx
    1c92:	f7 c2 01 00 00 00    	test   $0x1,%edx
    1c98:	0f 94 c2             	sete   %dl
    1c9b:	40 0f b6 f2          	rex movzbl %dl,%esi
    1c9f:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
    1ca4:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    1cab:	ff ff 7f 
    1cae:	c4 e1 f9 6e ca       	vmovq  %rdx,%xmm1
    1cb3:	c5 f9 54 c9          	vandpd %xmm1,%xmm0,%xmm1
    1cb7:	f3 0f 7f 44 24 40    	movdqu %xmm0,0x40(%rsp)
    1cbd:	48 ba 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdx
    1cc4:	00 f0 7f 
    1cc7:	c4 e1 f9 6e c2       	vmovq  %rdx,%xmm0
    1ccc:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
    1cd0:	0f 87 e9 03 00 00    	ja     0x20bf
    1cd6:	4d 89 e5             	mov    %r12,%r13
    1cd9:	41 f7 c5 00 20 00 00 	test   $0x2000,%r13d
    1ce0:	0f 84 1f 00 00 00    	je     0x1d05
    1ce6:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1ced:	00 
    1cee:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1cf5:	00 
    1cf6:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    1cfb:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
    1d00:	e9 83 01 00 00       	jmp    0x1e88
    1d05:	8d 51 03             	lea    0x3(%rcx),%edx
    1d08:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
    1d0d:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    1d14:	00 
    1d15:	3b ca                	cmp    %edx,%ecx
    1d17:	0f 8f 1f 00 00 00    	jg     0x1d3c
    1d1d:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1d24:	00 
    1d25:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1d2c:	00 
    1d2d:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    1d32:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    1d37:	e9 4c 01 00 00       	jmp    0x1e88
    1d3c:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    1d43:	00 
    1d44:	8d 88 d0 fc ff ff    	lea    -0x330(%rax),%ecx
    1d4a:	49 89 cd             	mov    %rcx,%r13
    1d4d:	b9 20 00 00 00       	mov    $0x20,%ecx
    1d52:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    1d59:	00 
    1d5a:	48 89 c6             	mov    %rax,%rsi
    1d5d:	2b f2                	sub    %edx,%esi
    1d5f:	bb 00 01 00 00       	mov    $0x100,%ebx
    1d64:	3b de                	cmp    %esi,%ebx
    1d66:	49 89 f0             	mov    %rsi,%r8
    1d69:	44 0f 42 c3          	cmovb  %ebx,%r8d
    1d6d:	49 89 f7             	mov    %rsi,%r15
    1d70:	4c 89 ea             	mov    %r13,%rdx
    1d73:	48 8b 34 24          	mov    (%rsp),%rsi
    1d77:	48 8b 3c 24          	mov    (%rsp),%rdi
    1d7b:	e8 60 46 00 00       	call   0x63e0
    1d80:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1d87:	00 
    1d88:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1d8f:	00 
    1d90:	45 8b 04 03          	mov    (%r11,%rax,1),%r8d
    1d94:	41 f7 c0 20 00 00 00 	test   $0x20,%r8d
    1d9b:	40 0f 94 c6          	sete   %sil
    1d9f:	40 0f b6 ce          	movzbl %sil,%ecx
    1da3:	4c 89 fa             	mov    %r15,%rdx
    1da6:	81 fa 00 01 00 00    	cmp    $0x100,%edx
    1dac:	0f 83 0f 00 00 00    	jae    0x1dc1
    1db2:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    1db7:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    1dbc:	e9 82 00 00 00       	jmp    0x1e43
    1dc1:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    1dc6:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    1dcb:	f7 c1 01 00 00 00    	test   $0x1,%ecx
    1dd1:	0f 85 08 00 00 00    	jne    0x1ddf
    1dd7:	4c 89 f9             	mov    %r15,%rcx
    1dda:	e9 2f 00 00 00       	jmp    0x1e0e
    1ddf:	48 89 d9             	mov    %rbx,%rcx
    1de2:	4c 89 ea             	mov    %r13,%rdx
    1de5:	48 8b 34 24          	mov    (%rsp),%rsi
    1de9:	48 8b 3c 24          	mov    (%rsp),%rdi
    1ded:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    1df2:	e8 89 cc ff ff       	call   0xffffffffffffea80
    1df7:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1dfe:	00 
    1dff:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1e06:	00 
    1e07:	45 8b 04 03          	mov    (%r11,%rax,1),%r8d
    1e0b:	4c 89 f9             	mov    %r15,%rcx
    1e0e:	44 8d 99 00 ff ff ff 	lea    -0x100(%rcx),%r11d
    1e15:	41 f7 c0 20 00 00 00 	test   $0x20,%r8d
    1e1c:	0f 94 c0             	sete   %al
    1e1f:	0f b6 c8             	movzbl %al,%ecx
    1e22:	41 81 fb ff 00 00 00 	cmp    $0xff,%r11d
    1e29:	0f 86 08 00 00 00    	jbe    0x1e37
    1e2f:	4d 89 df             	mov    %r11,%r15
    1e32:	e9 94 ff ff ff       	jmp    0x1dcb
    1e37:	4c 89 f8             	mov    %r15,%rax
    1e3a:	8d 90 00 ff ff ff    	lea    -0x100(%rax),%edx
    1e40:	49 89 d7             	mov    %rdx,%r15
    1e43:	85 c9                	test   %ecx,%ecx
    1e45:	0f 85 15 00 00 00    	jne    0x1e60
    1e4b:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1e52:	00 
    1e53:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1e5a:	00 
    1e5b:	e9 28 00 00 00       	jmp    0x1e88
    1e60:	4c 89 f9             	mov    %r15,%rcx
    1e63:	4c 89 ea             	mov    %r13,%rdx
    1e66:	48 8b 34 24          	mov    (%rsp),%rsi
    1e6a:	48 8b 3c 24          	mov    (%rsp),%rdi
    1e6e:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    1e73:	e8 08 cc ff ff       	call   0xffffffffffffea80
    1e78:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1e7f:	00 
    1e80:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1e87:	00 
    1e88:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1e8f:	00 
    1e90:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1e97:	00 
    1e98:	41 8b 0c 03          	mov    (%r11,%rax,1),%ecx
    1e9c:	f7 c1 20 00 00 00    	test   $0x20,%ecx
    1ea2:	0f 85 30 00 00 00    	jne    0x1ed8
    1ea8:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    1ead:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
    1eb2:	48 8b 34 24          	mov    (%rsp),%rsi
    1eb6:	48 8b 3c 24          	mov    (%rsp),%rdi
    1eba:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    1ebf:	e8 bc cb ff ff       	call   0xffffffffffffea80
    1ec4:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1ecb:	00 
    1ecc:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1ed3:	00 
    1ed4:	41 8b 0c 03          	mov    (%r11,%rax,1),%ecx
    1ed8:	f7 c1 20 00 00 00    	test   $0x20,%ecx
    1ede:	0f 84 08 00 00 00    	je     0x1eec
    1ee4:	4d 89 e5             	mov    %r12,%r13
    1ee7:	e9 50 00 00 00       	jmp    0x1f3c
    1eec:	b9 df 0d 00 00       	mov    $0xddf,%ecx
    1ef1:	41 f7 c6 20 00 00 00 	test   $0x20,%r14d
    1ef8:	0f 45 0d 69 36 00 00 	cmovne 0x3669(%rip),%ecx        # 0x5568
    1eff:	ba d7 0d 00 00       	mov    $0xdd7,%edx
    1f04:	41 f7 c6 20 00 00 00 	test   $0x20,%r14d
    1f0b:	0f 45 15 5e 36 00 00 	cmovne 0x365e(%rip),%edx        # 0x5570
    1f12:	f3 0f 6f 44 24 40    	movdqu 0x40(%rsp),%xmm0
    1f18:	c5 f9 2e c0          	vucomisd %xmm0,%xmm0
    1f1c:	0f 4a d1             	cmovp  %ecx,%edx
    1f1f:	0f 45 d1             	cmovne %ecx,%edx
    1f22:	b9 03 00 00 00       	mov    $0x3,%ecx
    1f27:	48 8b 34 24          	mov    (%rsp),%rsi
    1f2b:	48 8b 3c 24          	mov    (%rsp),%rdi
    1f2f:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    1f34:	e8 47 cb ff ff       	call   0xffffffffffffea80
    1f39:	4d 89 e5             	mov    %r12,%r13
    1f3c:	4d 89 e5             	mov    %r12,%r13
    1f3f:	41 81 e5 00 20 01 00 	and    $0x12000,%r13d
    1f46:	4d 89 ec             	mov    %r13,%r12
    1f49:	41 81 fd 00 20 00 00 	cmp    $0x2000,%r13d
    1f50:	0f 84 0a 00 00 00    	je     0x1f60
    1f56:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    1f5b:	e9 35 01 00 00       	jmp    0x2095
    1f60:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    1f65:	8d 41 03             	lea    0x3(%rcx),%eax
    1f68:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    1f6f:	00 
    1f70:	3b c8                	cmp    %eax,%ecx
    1f72:	0f 8f 0a 00 00 00    	jg     0x1f82
    1f78:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    1f7d:	e9 13 01 00 00       	jmp    0x2095
    1f82:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
    1f89:	00 
    1f8a:	8d 91 d0 fc ff ff    	lea    -0x330(%rcx),%edx
    1f90:	49 89 d4             	mov    %rdx,%r12
    1f93:	b9 20 00 00 00       	mov    $0x20,%ecx
    1f98:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
    1f9f:	00 
    1fa0:	2b d0                	sub    %eax,%edx
    1fa2:	bb 00 01 00 00       	mov    $0x100,%ebx
    1fa7:	3b da                	cmp    %edx,%ebx
    1fa9:	49 89 d0             	mov    %rdx,%r8
    1fac:	44 0f 42 c3          	cmovb  %ebx,%r8d
    1fb0:	49 89 d5             	mov    %rdx,%r13
    1fb3:	4c 89 e2             	mov    %r12,%rdx
    1fb6:	48 8b 34 24          	mov    (%rsp),%rsi
    1fba:	48 8b 3c 24          	mov    (%rsp),%rdi
    1fbe:	e8 1d 44 00 00       	call   0x63e0
    1fc3:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    1fca:	00 
    1fcb:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    1fd2:	00 
    1fd3:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    1fd7:	f7 c6 20 00 00 00    	test   $0x20,%esi
    1fdd:	0f 94 c0             	sete   %al
    1fe0:	0f b6 d0             	movzbl %al,%edx
    1fe3:	4c 89 e9             	mov    %r13,%rcx
    1fe6:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    1fec:	0f 83 08 00 00 00    	jae    0x1ffa
    1ff2:	4c 89 e9             	mov    %r13,%rcx
    1ff5:	e9 6f 00 00 00       	jmp    0x2069
    1ffa:	f7 c2 01 00 00 00    	test   $0x1,%edx
    2000:	0f 85 08 00 00 00    	jne    0x200e
    2006:	4c 89 e9             	mov    %r13,%rcx
    2009:	e9 2f 00 00 00       	jmp    0x203d
    200e:	48 89 d9             	mov    %rbx,%rcx
    2011:	4c 89 e2             	mov    %r12,%rdx
    2014:	48 8b 34 24          	mov    (%rsp),%rsi
    2018:	48 8b 3c 24          	mov    (%rsp),%rdi
    201c:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    2021:	e8 5a ca ff ff       	call   0xffffffffffffea80
    2026:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    202d:	00 
    202e:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2035:	00 
    2036:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    203a:	4c 89 e9             	mov    %r13,%rcx
    203d:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    2043:	f7 c6 20 00 00 00    	test   $0x20,%esi
    2049:	0f 94 c0             	sete   %al
    204c:	0f b6 d0             	movzbl %al,%edx
    204f:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    2055:	0f 86 08 00 00 00    	jbe    0x2063
    205b:	49 89 fd             	mov    %rdi,%r13
    205e:	e9 97 ff ff ff       	jmp    0x1ffa
    2063:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    2069:	85 d2                	test   %edx,%edx
    206b:	0f 85 0a 00 00 00    	jne    0x207b
    2071:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    2076:	e9 1a 00 00 00       	jmp    0x2095
    207b:	4c 89 e2             	mov    %r12,%rdx
    207e:	48 8b 34 24          	mov    (%rsp),%rsi
    2082:	48 8b 3c 24          	mov    (%rsp),%rdi
    2086:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    208b:	e8 f0 c9 ff ff       	call   0xffffffffffffea80
    2090:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    2095:	8d 41 03             	lea    0x3(%rcx),%eax
    2098:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    209f:	00 
    20a0:	3b c1                	cmp    %ecx,%eax
    20a2:	0f 4d c8             	cmovge %eax,%ecx
    20a5:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    20ac:	00 
    20ad:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    20b2:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
    20b9:	00 
    20ba:	e9 af 28 00 00       	jmp    0x496e
    20bf:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    20c6:	00 
    20c7:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
    20cc:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
    20d1:	f3 0f 6f 44 24 40    	movdqu 0x40(%rsp),%xmm0
    20d7:	8d 90 fc fd ff ff    	lea    -0x204(%rax),%edx
    20dd:	48 8b 34 24          	mov    (%rsp),%rsi
    20e1:	48 8b 3c 24          	mov    (%rsp),%rdi
    20e5:	e8 b6 48 00 00       	call   0x69a0
    20ea:	c5 fb 58 c0          	vaddsd %xmm0,%xmm0,%xmm0
    20ee:	c5 f9 2e 05 8a 34 00 	vucomisd 0x348a(%rip),%xmm0        # 0x5580
    20f5:	00 
    20f6:	0f 8a 06 00 00 00    	jp     0x2102
    20fc:	0f 84 99 00 00 00    	je     0x219b
    2102:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2109:	00 
    210a:	43 8b 94 2b 6c 01 00 	mov    0x16c(%r11,%r13,1),%edx
    2111:	00 
    2112:	8d 42 ff             	lea    -0x1(%rdx),%eax
    2115:	43 89 84 2b 6c 01 00 	mov    %eax,0x16c(%r11,%r13,1)
    211c:	00 
    211d:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    2122:	48 89 c1             	mov    %rax,%rcx
    2125:	83 c9 20             	or     $0x20,%ecx
    2128:	83 f9 61             	cmp    $0x61,%ecx
    212b:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
    2130:	0f 85 15 00 00 00    	jne    0x214b
    2136:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    213b:	4c 89 e1             	mov    %r12,%rcx
    213e:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    2145:	00 
    2146:	e9 f2 1c 00 00       	jmp    0x3e3d
    214b:	8d 4a e3             	lea    -0x1d(%rdx),%ecx
    214e:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2155:	00 
    2156:	43 89 8c 2b 6c 01 00 	mov    %ecx,0x16c(%r11,%r13,1)
    215d:	00 
    215e:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    2163:	c5 fb 59 05 25 34 00 	vmulsd 0x3425(%rip),%xmm0,%xmm0        # 0x5590
    216a:	00 
    216b:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    2172:	00 
    2173:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    217a:	00 
    217b:	85 d1                	test   %edx,%ecx
    217d:	0f 4c 0d 1c 34 00 00 	cmovl  0x341c(%rip),%ecx        # 0x55a0
    2184:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    218b:	00 
    218c:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    2191:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    2196:	e9 67 00 00 00       	jmp    0x2202
    219b:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    21a0:	48 89 c1             	mov    %rax,%rcx
    21a3:	83 c9 20             	or     $0x20,%ecx
    21a6:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
    21ab:	48 89 c8             	mov    %rcx,%rax
    21ae:	83 f8 61             	cmp    $0x61,%eax
    21b1:	0f 85 10 00 00 00    	jne    0x21c7
    21b7:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    21be:	00 
    21bf:	4c 89 e1             	mov    %r12,%rcx
    21c2:	e9 76 1c 00 00       	jmp    0x3e3d
    21c7:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    21ce:	00 
    21cf:	43 8b 84 2b 6c 01 00 	mov    0x16c(%r11,%r13,1),%eax
    21d6:	00 
    21d7:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    21dc:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    21e3:	00 
    21e4:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    21eb:	00 
    21ec:	85 c1                	test   %eax,%ecx
    21ee:	0f 4c 0d ab 33 00 00 	cmovl  0x33ab(%rip),%ecx        # 0x55a0
    21f5:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    21fc:	00 
    21fd:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    2202:	48 89 c1             	mov    %rax,%rcx
    2205:	c1 e9 1f             	shr    $0x1f,%ecx
    2208:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    220f:	00 
    2210:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
    2217:	00 
    2218:	44 8d 98 00 fe ff ff 	lea    -0x200(%rax),%r11d
    221f:	8d 88 20 ff ff ff    	lea    -0xe0(%rax),%ecx
    2225:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    222c:	00 
    222d:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    2232:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    2237:	85 c8                	test   %ecx,%eax
    2239:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
    2240:	00 
    2241:	41 0f 4c cb          	cmovl  %r11d,%ecx
    2245:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    224c:	00 
    224d:	4c 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%r14
    2254:	00 
    2255:	48 b9 00 00 00 00 00 	movabs $0x41f0000000000000,%rcx
    225c:	00 f0 41 
    225f:	c4 e1 f9 6e c9       	vmovq  %rcx,%xmm1
    2264:	c5 f9 2e c8          	vucomisd %xmm0,%xmm1
    2268:	0f 97 c1             	seta   %cl
    226b:	c5 f9 2e 05 3d 33 00 	vucomisd 0x333d(%rip),%xmm0        # 0x55b0
    2272:	00 
    2273:	0f 93 c2             	setae  %dl
    2276:	23 ca                	and    %edx,%ecx
    2278:	0f b6 c9             	movzbl %cl,%ecx
    227b:	85 c9                	test   %ecx,%ecx
    227d:	0f 84 4d 00 00 00    	je     0x22d0
    2283:	48 b9 00 00 00 00 00 	movabs $0x41e0000000000000,%rcx
    228a:	00 e0 41 
    228d:	66 48 0f 6e d1       	movq   %rcx,%xmm2
    2292:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    2296:	0f 83 15 00 00 00    	jae    0x22b1
    229c:	0f 8a 67 32 00 00    	jp     0x5509
    22a2:	f2 0f 2c d0          	cvttsd2si %xmm0,%edx
    22a6:	83 fa 00             	cmp    $0x0,%edx
    22a9:	0f 8d 23 00 00 00    	jge    0x22d2
    22af:	0f 0b                	ud2
    22b1:	0f 28 c8             	movaps %xmm0,%xmm1
    22b4:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
    22b8:	f2 0f 2c d1          	cvttsd2si %xmm1,%edx
    22bc:	83 fa 00             	cmp    $0x0,%edx
    22bf:	0f 8c 46 32 00 00    	jl     0x550b
    22c5:	81 c2 00 00 00 80    	add    $0x80000000,%edx
    22cb:	e9 02 00 00 00       	jmp    0x22d2
    22d0:	33 d2                	xor    %edx,%edx
    22d2:	41 8b ce             	mov    %r14d,%ecx
    22d5:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    22dc:	00 
    22dd:	41 89 14 0b          	mov    %edx,(%r11,%rcx,1)
    22e1:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
    22e5:	8b ca                	mov    %edx,%ecx
    22e7:	c4 e1 f3 2a c9       	vcvtsi2sd %rcx,%xmm1,%xmm1
    22ec:	c5 fb 5c c1          	vsubsd %xmm1,%xmm0,%xmm0
    22f0:	c5 fb 59 05 c8 32 00 	vmulsd 0x32c8(%rip),%xmm0,%xmm0        # 0x55c0
    22f7:	00 
    22f8:	41 81 c6 04 00 00 00 	add    $0x4,%r14d
    22ff:	c5 f9 2e 05 c9 32 00 	vucomisd 0x32c9(%rip),%xmm0        # 0x55d0
    2306:	00 
    2307:	0f 8a 48 ff ff ff    	jp     0x2255
    230d:	0f 85 42 ff ff ff    	jne    0x2255
    2313:	85 c0                	test   %eax,%eax
    2315:	0f 8f 0d 00 00 00    	jg     0x2328
    231b:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
    2322:	00 
    2323:	e9 1c 01 00 00       	jmp    0x2444
    2328:	41 bb 1d 00 00 00    	mov    $0x1d,%r11d
    232e:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
    2335:	00 
    2336:	41 8d 76 fc          	lea    -0x4(%r14),%esi
    233a:	3b f3                	cmp    %ebx,%esi
    233c:	0f 82 89 00 00 00    	jb     0x23cb
    2342:	b9 1d 00 00 00       	mov    $0x1d,%ecx
    2347:	3b c8                	cmp    %eax,%ecx
    2349:	49 89 c0             	mov    %rax,%r8
    234c:	44 0f 4c c1          	cmovl  %ecx,%r8d
    2350:	4d 89 f9             	mov    %r15,%r9
    2353:	44 8b d6             	mov    %esi,%r10d
    2356:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
    235d:	00 
    235e:	42 8b 0c 11          	mov    (%rcx,%r10,1),%ecx
    2362:	c4 e2 b9 f7 c9       	shlx   %r8,%rcx,%rcx
    2367:	4c 23 0d ba 31 00 00 	and    0x31ba(%rip),%r9        # 0x5528
    236e:	4a 8d 14 09          	lea    (%rcx,%r9,1),%rdx
    2372:	c4 e2 f3 f6 0d 65 32 	mulx   0x3265(%rip),%rcx,%rcx        # 0x55e0
    2379:	00 00 
    237b:	48 89 d7             	mov    %rdx,%rdi
    237e:	48 2b f9             	sub    %rcx,%rdi
    2381:	48 d1 ef             	shr    $1,%rdi
    2384:	4c 8d 0c 39          	lea    (%rcx,%rdi,1),%r9
    2388:	49 c1 e9 1d          	shr    $0x1d,%r9
    238c:	49 69 c9 00 ca 9a 3b 	imul   $0x3b9aca00,%r9,%rcx
    2393:	48 2b d1             	sub    %rcx,%rdx
    2396:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
    239d:	00 
    239e:	42 89 14 17          	mov    %edx,(%rdi,%r10,1)
    23a2:	81 c6 fc ff ff ff    	add    $0xfffffffc,%esi
    23a8:	3b f3                	cmp    %ebx,%esi
    23aa:	0f 83 a3 ff ff ff    	jae    0x2353
    23b0:	45 85 c9             	test   %r9d,%r9d
    23b3:	0f 84 12 00 00 00    	je     0x23cb
    23b9:	81 c3 fc ff ff ff    	add    $0xfffffffc,%ebx
    23bf:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
    23c6:	00 
    23c7:	44 89 0c 19          	mov    %r9d,(%rcx,%rbx,1)
    23cb:	44 3b f3             	cmp    %ebx,%r14d
    23ce:	0f 87 0d 00 00 00    	ja     0x23e1
    23d4:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
    23db:	00 
    23dc:	e9 27 00 00 00       	jmp    0x2408
    23e1:	41 8d 56 fc          	lea    -0x4(%r14),%edx
    23e5:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
    23ec:	00 
    23ed:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    23f0:	85 c9                	test   %ecx,%ecx
    23f2:	0f 85 08 00 00 00    	jne    0x2400
    23f8:	49 89 d6             	mov    %rdx,%r14
    23fb:	e9 cb ff ff ff       	jmp    0x23cb
    2400:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
    2407:	00 
    2408:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
    240f:	00 
    2410:	42 8b b4 29 6c 01 00 	mov    0x16c(%rcx,%r13,1),%esi
    2417:	00 
    2418:	44 3b d8             	cmp    %eax,%r11d
    241b:	41 0f 4c c3          	cmovl  %r11d,%eax
    241f:	2b f0                	sub    %eax,%esi
    2421:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
    2428:	00 
    2429:	42 89 b4 28 6c 01 00 	mov    %esi,0x16c(%rax,%r13,1)
    2430:	00 
    2431:	85 f6                	test   %esi,%esi
    2433:	0f 8e 08 00 00 00    	jle    0x2441
    2439:	48 89 f0             	mov    %rsi,%rax
    243c:	e9 f5 fe ff ff       	jmp    0x2336
    2441:	48 89 f0             	mov    %rsi,%rax
    2444:	85 c0                	test   %eax,%eax
    2446:	0f 8d 6d 01 00 00    	jge    0x25b9
    244c:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    2453:	00 
    2454:	8d 51 19             	lea    0x19(%rcx),%edx
    2457:	c4 e2 6b f6 15 88 31 	mulx   0x3188(%rip),%edx,%edx        # 0x55e8
    245e:	00 00 
    2460:	d1 ea                	shr    $1,%edx
    2462:	8d 4a 01             	lea    0x1(%rdx),%ecx
    2465:	48 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%rsp)
    246c:	00 
    246d:	41 3b de             	cmp    %r14d,%ebx
    2470:	0f 82 1e 00 00 00    	jb     0x2494
    2476:	8b cb                	mov    %ebx,%ecx
    2478:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    247f:	00 
    2480:	41 8b 3c 0b          	mov    (%r11,%rcx,1),%edi
    2484:	8d 4b 04             	lea    0x4(%rbx),%ecx
    2487:	85 ff                	test   %edi,%edi
    2489:	0f 45 cb             	cmovne %ebx,%ecx
    248c:	48 89 cb             	mov    %rcx,%rbx
    248f:	e9 b2 00 00 00       	jmp    0x2546
    2494:	45 33 c0             	xor    %r8d,%r8d
    2497:	49 89 c1             	mov    %rax,%r9
    249a:	41 f7 d9             	neg    %r9d
    249d:	83 f8 f7             	cmp    $0xfffffff7,%eax
    24a0:	44 0f 4c 0d 48 31 00 	cmovl  0x3148(%rip),%r9d        # 0x55f0
    24a7:	00 
    24a8:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    24ad:	c4 62 31 f7 d7       	shlx   %r9d,%edi,%r10d
    24b2:	bf 00 ca 9a 3b       	mov    $0x3b9aca00,%edi
    24b7:	c4 62 33 f7 ff       	shrx   %r9d,%edi,%r15d
    24bc:	49 89 db             	mov    %rbx,%r11
    24bf:	41 8b fb             	mov    %r11d,%edi
    24c2:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
    24c9:	00 
    24ca:	8b 0c 3e             	mov    (%rsi,%rdi,1),%ecx
    24cd:	c4 e2 33 f7 f1       	shrx   %r9d,%ecx,%esi
    24d2:	41 03 f0             	add    %r8d,%esi
    24d5:	4c 8b 84 24 20 01 00 	mov    0x120(%rsp),%r8
    24dc:	00 
    24dd:	41 89 34 38          	mov    %esi,(%r8,%rdi,1)
    24e1:	41 81 c3 04 00 00 00 	add    $0x4,%r11d
    24e8:	c4 62 28 f2 c1       	andn   %ecx,%r10d,%r8d
    24ed:	45 0f af c7          	imul   %r15d,%r8d
    24f1:	45 3b de             	cmp    %r14d,%r11d
    24f4:	0f 82 c5 ff ff ff    	jb     0x24bf
    24fa:	44 8b cb             	mov    %ebx,%r9d
    24fd:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2504:	00 
    2505:	47 8b 14 0b          	mov    (%r11,%r9,1),%r10d
    2509:	44 8d 4b 04          	lea    0x4(%rbx),%r9d
    250d:	45 85 d2             	test   %r10d,%r10d
    2510:	44 0f 45 cb          	cmovne %ebx,%r9d
    2514:	45 85 c0             	test   %r8d,%r8d
    2517:	0f 85 10 00 00 00    	jne    0x252d
    251d:	4c 89 cb             	mov    %r9,%rbx
    2520:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2527:	00 
    2528:	e9 19 00 00 00       	jmp    0x2546
    252d:	41 8b ce             	mov    %r14d,%ecx
    2530:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2537:	00 
    2538:	45 89 04 0b          	mov    %r8d,(%r11,%rcx,1)
    253c:	41 81 c6 04 00 00 00 	add    $0x4,%r14d
    2543:	4c 89 cb             	mov    %r9,%rbx
    2546:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    254d:	00 
    254e:	43 8b 8c 2b 6c 01 00 	mov    0x16c(%r11,%r13,1),%ecx
    2555:	00 
    2556:	48 89 c7             	mov    %rax,%rdi
    2559:	f7 df                	neg    %edi
    255b:	83 f8 f7             	cmp    $0xfffffff7,%eax
    255e:	0f 4c 3d 8b 30 00 00 	cmovl  0x308b(%rip),%edi        # 0x55f0
    2565:	8d 04 39             	lea    (%rcx,%rdi,1),%eax
    2568:	43 89 84 2b 6c 01 00 	mov    %eax,0x16c(%r11,%r13,1)
    256f:	00 
    2570:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
    2575:	83 f9 66             	cmp    $0x66,%ecx
    2578:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
    257f:	00 
    2580:	48 89 d9             	mov    %rbx,%rcx
    2583:	0f 44 cf             	cmove  %edi,%ecx
    2586:	4c 89 f7             	mov    %r14,%rdi
    2589:	2b f9                	sub    %ecx,%edi
    258b:	c1 ff 02             	sar    $0x2,%edi
    258e:	44 8d 42 01          	lea    0x1(%rdx),%r8d
    2592:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
    2599:	00 
    259a:	8d 0c b1             	lea    (%rcx,%rsi,4),%ecx
    259d:	41 3b f8             	cmp    %r8d,%edi
    25a0:	44 0f 4f f1          	cmovg  %ecx,%r14d
    25a4:	85 c0                	test   %eax,%eax
    25a6:	0f 8d 0d 00 00 00    	jge    0x25b9
    25ac:	48 89 b4 24 e8 00 00 	mov    %rsi,0xe8(%rsp)
    25b3:	00 
    25b4:	e9 b4 fe ff ff       	jmp    0x246d
    25b9:	45 33 d2             	xor    %r10d,%r10d
    25bc:	41 3b de             	cmp    %r14d,%ebx
    25bf:	0f 82 0a 00 00 00    	jb     0x25cf
    25c5:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    25ca:	e9 5a 00 00 00       	jmp    0x2629
    25cf:	8b c3                	mov    %ebx,%eax
    25d1:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    25d8:	00 
    25d9:	41 8b 04 03          	mov    (%r11,%rax,1),%eax
    25dd:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
    25e4:	00 
    25e5:	2b cb                	sub    %ebx,%ecx
    25e7:	c1 f9 02             	sar    $0x2,%ecx
    25ea:	44 6b d1 09          	imul   $0x9,%ecx,%r10d
    25ee:	83 f8 0a             	cmp    $0xa,%eax
    25f1:	0f 83 0a 00 00 00    	jae    0x2601
    25f7:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    25fc:	e9 28 00 00 00       	jmp    0x2629
    2601:	ba 0a 00 00 00       	mov    $0xa,%edx
    2606:	6b d2 0a             	imul   $0xa,%edx,%edx
    2609:	41 8d 4a 01          	lea    0x1(%r10),%ecx
    260d:	3b c2                	cmp    %edx,%eax
    260f:	0f 82 08 00 00 00    	jb     0x261d
    2615:	49 89 ca             	mov    %rcx,%r10
    2618:	e9 e9 ff ff ff       	jmp    0x2606
    261d:	41 81 c2 01 00 00 00 	add    $0x1,%r10d
    2624:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    2629:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    262e:	41 83 fd 66          	cmp    $0x66,%r13d
    2632:	4c 89 d1             	mov    %r10,%rcx
    2635:	0f 44 0d bc 2f 00 00 	cmove  0x2fbc(%rip),%ecx        # 0x55f8
    263c:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    2643:	00 
    2644:	2b c1                	sub    %ecx,%eax
    2646:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    264d:	00 
    264e:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    2655:	00 
    2656:	85 d1                	test   %edx,%ecx
    2658:	0f 95 c1             	setne  %cl
    265b:	41 83 fd 67          	cmp    $0x67,%r13d
    265f:	0f 94 c2             	sete   %dl
    2662:	23 ca                	and    %edx,%ecx
    2664:	0f b6 c9             	movzbl %cl,%ecx
    2667:	2b c1                	sub    %ecx,%eax
    2669:	48 8b 94 24 f0 00 00 	mov    0xf0(%rsp),%rdx
    2670:	00 
    2671:	4c 89 f1             	mov    %r14,%rcx
    2674:	2b ca                	sub    %edx,%ecx
    2676:	c1 f9 02             	sar    $0x2,%ecx
    2679:	6b c9 09             	imul   $0x9,%ecx,%ecx
    267c:	81 c1 f7 ff ff ff    	add    $0xfffffff7,%ecx
    2682:	48 8b 94 24 f8 00 00 	mov    0xf8(%rsp),%rdx
    2689:	00 
    268a:	40 0f b6 f2          	rex movzbl %dl,%esi
    268e:	3b c1                	cmp    %ecx,%eax
    2690:	0f 8d 42 03 00 00    	jge    0x29d8
    2696:	8d 88 00 24 00 00    	lea    0x2400(%rax),%ecx
    269c:	48 89 c8             	mov    %rcx,%rax
    269f:	f7 2d 43 2f 00 00    	imull  0x2f43(%rip)        # 0x55e8
    26a5:	d1 fa                	sar    $1,%edx
    26a7:	48 89 d0             	mov    %rdx,%rax
    26aa:	c1 e8 1f             	shr    $0x1f,%eax
    26ad:	44 8d 04 02          	lea    (%rdx,%rax,1),%r8d
    26b1:	41 6b c0 09          	imul   $0x9,%r8d,%eax
    26b5:	2b c8                	sub    %eax,%ecx
    26b7:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
    26bd:	83 f9 07             	cmp    $0x7,%ecx
    26c0:	0f 8e 0d 00 00 00    	jle    0x26d3
    26c6:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    26cd:	00 
    26ce:	e9 2b 00 00 00       	jmp    0x26fe
    26d3:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
    26d9:	81 c1 f8 ff ff ff    	add    $0xfffffff8,%ecx
    26df:	8d 41 01             	lea    0x1(%rcx),%eax
    26e2:	45 6b c9 0a          	imul   $0xa,%r9d,%r9d
    26e6:	3b c1                	cmp    %ecx,%eax
    26e8:	0f 82 08 00 00 00    	jb     0x26f6
    26ee:	48 89 c1             	mov    %rax,%rcx
    26f1:	e9 e9 ff ff ff       	jmp    0x26df
    26f6:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    26fd:	00 
    26fe:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    2705:	00 
    2706:	81 c0 00 fe ff ff    	add    $0xfffffe00,%eax
    270c:	83 c8 04             	or     $0x4,%eax
    270f:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
    2716:	00 
    2717:	44 8d 99 24 ff ff ff 	lea    -0xdc(%rcx),%r11d
    271e:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    2723:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
    2728:	41 85 cd             	test   %ecx,%r13d
    272b:	44 0f 4c d8          	cmovl  %eax,%r11d
    272f:	43 8d 34 83          	lea    (%r11,%r8,4),%esi
    2733:	43 8d bc 83 00 f0 ff 	lea    -0x1000(%r11,%r8,4),%edi
    273a:	ff 
    273b:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
    2742:	00 
    2743:	44 8b 2c 38          	mov    (%rax,%rdi,1),%r13d
    2747:	48 33 d2             	xor    %rdx,%rdx
    274a:	4c 89 e8             	mov    %r13,%rax
    274d:	41 f7 f1             	div    %r9d
    2750:	43 8d 8c 83 04 f0 ff 	lea    -0xffc(%r11,%r8,4),%ecx
    2757:	ff 
    2758:	41 3b ce             	cmp    %r14d,%ecx
    275b:	0f 84 08 00 00 00    	je     0x2769
    2761:	49 89 c7             	mov    %rax,%r15
    2764:	e9 1f 00 00 00       	jmp    0x2788
    2769:	48 89 c1             	mov    %rax,%rcx
    276c:	41 0f af c9          	imul   %r9d,%ecx
    2770:	49 89 c7             	mov    %rax,%r15
    2773:	4c 89 ea             	mov    %r13,%rdx
    2776:	2b d1                	sub    %ecx,%edx
    2778:	43 8d 84 83 00 f0 ff 	lea    -0x1000(%r11,%r8,4),%eax
    277f:	ff 
    2780:	85 d2                	test   %edx,%edx
    2782:	0f 84 43 02 00 00    	je     0x29cb
    2788:	41 f7 c7 01 00 00 00 	test   $0x1,%r15d
    278f:	0f 85 6b 00 00 00    	jne    0x2800
    2795:	43 8d 84 83 00 f0 ff 	lea    -0x1000(%r11,%r8,4),%eax
    279c:	ff 
    279d:	48 b9 00 00 00 00 00 	movabs $0x4340000000000000,%rcx
    27a4:	00 40 43 
    27a7:	c4 e1 f9 6e c1       	vmovq  %rcx,%xmm0
    27ac:	3b c3                	cmp    %ebx,%eax
    27ae:	0f 86 5b 00 00 00    	jbe    0x280f
    27b4:	48 b8 00 00 00 00 00 	movabs $0x4340000000000000,%rax
    27bb:	00 40 43 
    27be:	c4 e1 f9 6e c0       	vmovq  %rax,%xmm0
    27c3:	41 81 f9 00 ca 9a 3b 	cmp    $0x3b9aca00,%r9d
    27ca:	0f 85 3f 00 00 00    	jne    0x280f
    27d0:	43 8d 94 83 fc ef ff 	lea    -0x1004(%r11,%r8,4),%edx
    27d7:	ff 
    27d8:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
    27df:	00 
    27e0:	48 0f b6 14 10       	movzbq (%rax,%rdx,1),%rdx
    27e5:	48 b9 00 00 00 00 00 	movabs $0x4340000000000000,%rcx
    27ec:	00 40 43 
    27ef:	c4 e1 f9 6e c1       	vmovq  %rcx,%xmm0
    27f4:	f7 c2 01 00 00 00    	test   $0x1,%edx
    27fa:	0f 84 0f 00 00 00    	je     0x280f
    2800:	48 b8 01 00 00 00 00 	movabs $0x4340000000000001,%rax
    2807:	00 40 43 
    280a:	c4 e1 f9 6e c0       	vmovq  %rax,%xmm0
    280f:	45 0f af f9          	imul   %r9d,%r15d
    2813:	4c 89 e8             	mov    %r13,%rax
    2816:	41 2b c7             	sub    %r15d,%eax
    2819:	4c 89 ca             	mov    %r9,%rdx
    281c:	d1 ea                	shr    $1,%edx
    281e:	48 b9 00 00 00 00 00 	movabs $0x3fe0000000000000,%rcx
    2825:	00 e0 3f 
    2828:	c4 e1 f9 6e c9       	vmovq  %rcx,%xmm1
    282d:	47 8d bc 83 04 f0 ff 	lea    -0xffc(%r11,%r8,4),%r15d
    2834:	ff 
    2835:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    283c:	00 f0 3f 
    283f:	c4 e1 f9 6e d9       	vmovq  %rcx,%xmm3
    2844:	48 b9 00 00 00 00 00 	movabs $0x3ff8000000000000,%rcx
    284b:	00 f8 3f 
    284e:	c4 e1 f9 6e d1       	vmovq  %rcx,%xmm2
    2853:	3b c2                	cmp    %edx,%eax
    2855:	66 0f 6f e2          	movdqa %xmm2,%xmm4
    2859:	0f 85 03 00 00 00    	jne    0x2862
    285f:	0f 28 e3             	movaps %xmm3,%xmm4
    2862:	45 3b fe             	cmp    %r14d,%r15d
    2865:	0f 85 03 00 00 00    	jne    0x286e
    286b:	0f 28 d4             	movaps %xmm4,%xmm2
    286e:	3b c2                	cmp    %edx,%eax
    2870:	0f 83 03 00 00 00    	jae    0x2879
    2876:	0f 28 d1             	movaps %xmm1,%xmm2
    2879:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
    287e:	85 c9                	test   %ecx,%ecx
    2880:	0f 85 43 00 00 00    	jne    0x28c9
    2886:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
    288b:	8b ca                	mov    %edx,%ecx
    288d:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
    2894:	00 
    2895:	48 0f b6 0c 0a       	movzbq (%rdx,%rcx,1),%rcx
    289a:	83 f9 2d             	cmp    $0x2d,%ecx
    289d:	0f 85 26 00 00 00    	jne    0x28c9
    28a3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    28aa:	00 00 80 
    28ad:	c4 e1 f9 6e c9       	vmovq  %rcx,%xmm1
    28b2:	c5 f9 57 c1          	vxorpd %xmm1,%xmm0,%xmm0
    28b6:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    28bd:	00 00 80 
    28c0:	c4 e1 f9 6e c9       	vmovq  %rcx,%xmm1
    28c5:	c5 e9 57 d1          	vxorpd %xmm1,%xmm2,%xmm2
    28c9:	44 2b e8             	sub    %eax,%r13d
    28cc:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
    28d3:	00 
    28d4:	44 89 2c 38          	mov    %r13d,(%rax,%rdi,1)
    28d8:	c5 fb 58 ca          	vaddsd %xmm2,%xmm0,%xmm1
    28dc:	43 8d 84 83 00 f0 ff 	lea    -0x1000(%r11,%r8,4),%eax
    28e3:	ff 
    28e4:	c5 f9 2e c8          	vucomisd %xmm0,%xmm1
    28e8:	0f 8a 06 00 00 00    	jp     0x28f4
    28ee:	0f 84 d7 00 00 00    	je     0x29cb
    28f4:	43 8d 4c 0d 00       	lea    0x0(%r13,%r9,1),%ecx
    28f9:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
    2900:	00 
    2901:	89 0c 38             	mov    %ecx,(%rax,%rdi,1)
    2904:	43 8d 84 83 00 f0 ff 	lea    -0x1000(%r11,%r8,4),%eax
    290b:	ff 
    290c:	81 f9 00 ca 9a 3b    	cmp    $0x3b9aca00,%ecx
    2912:	0f 82 68 00 00 00    	jb     0x2980
    2918:	43 8d 84 83 fc ef ff 	lea    -0x1004(%r11,%r8,4),%eax
    291f:	ff 
    2920:	8d 48 04             	lea    0x4(%rax),%ecx
    2923:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    292a:	00 
    292b:	41 c7 04 0b 00 00 00 	movl   $0x0,(%r11,%rcx,1)
    2932:	00 
    2933:	3b c3                	cmp    %ebx,%eax
    2935:	0f 83 16 00 00 00    	jae    0x2951
    293b:	81 c3 fc ff ff ff    	add    $0xfffffffc,%ebx
    2941:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2948:	00 
    2949:	41 c7 04 1b 00 00 00 	movl   $0x0,(%r11,%rbx,1)
    2950:	00 
    2951:	8b c8                	mov    %eax,%ecx
    2953:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    295a:	00 
    295b:	41 8b 14 0b          	mov    (%r11,%rcx,1),%edx
    295f:	81 c2 01 00 00 00    	add    $0x1,%edx
    2965:	41 89 14 0b          	mov    %edx,(%r11,%rcx,1)
    2969:	8d 48 fc             	lea    -0x4(%rax),%ecx
    296c:	81 fa ff c9 9a 3b    	cmp    $0x3b9ac9ff,%edx
    2972:	0f 86 08 00 00 00    	jbe    0x2980
    2978:	48 89 c8             	mov    %rcx,%rax
    297b:	e9 a0 ff ff ff       	jmp    0x2920
    2980:	8b cb                	mov    %ebx,%ecx
    2982:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2989:	00 
    298a:	41 8b 14 0b          	mov    (%r11,%rcx,1),%edx
    298e:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
    2995:	00 
    2996:	2b cb                	sub    %ebx,%ecx
    2998:	c1 f9 02             	sar    $0x2,%ecx
    299b:	44 6b d1 09          	imul   $0x9,%ecx,%r10d
    299f:	83 fa 0a             	cmp    $0xa,%edx
    29a2:	0f 82 23 00 00 00    	jb     0x29cb
    29a8:	bf 0a 00 00 00       	mov    $0xa,%edi
    29ad:	6b ff 0a             	imul   $0xa,%edi,%edi
    29b0:	41 8d 4a 01          	lea    0x1(%r10),%ecx
    29b4:	3b d7                	cmp    %edi,%edx
    29b6:	0f 82 08 00 00 00    	jb     0x29c4
    29bc:	49 89 ca             	mov    %rcx,%r10
    29bf:	e9 e9 ff ff ff       	jmp    0x29ad
    29c4:	41 81 c2 01 00 00 00 	add    $0x1,%r10d
    29cb:	81 c0 04 00 00 00    	add    $0x4,%eax
    29d1:	41 3b c6             	cmp    %r14d,%eax
    29d4:	44 0f 42 f0          	cmovb  %eax,%r14d
    29d8:	44 3b f3             	cmp    %ebx,%r14d
    29db:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
    29e2:	00 
    29e3:	0f 87 0c 00 00 00    	ja     0x29f5
    29e9:	33 c0                	xor    %eax,%eax
    29eb:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    29f0:	e9 35 00 00 00       	jmp    0x2a2a
    29f5:	41 8d 46 fc          	lea    -0x4(%r14),%eax
    29f9:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2a00:	00 
    2a01:	41 8b 0c 03          	mov    (%r11,%rax,1),%ecx
    2a05:	85 c9                	test   %ecx,%ecx
    2a07:	0f 85 10 00 00 00    	jne    0x2a1d
    2a0d:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
    2a14:	00 
    2a15:	49 89 c6             	mov    %rax,%r14
    2a18:	e9 bb ff ff ff       	jmp    0x29d8
    2a1d:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    2a24:	00 
    2a25:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    2a2a:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    2a2f:	41 83 fd 67          	cmp    $0x67,%r13d
    2a33:	0f 84 1f 00 00 00    	je     0x2a58
    2a39:	4c 89 e1             	mov    %r12,%rcx
    2a3c:	49 89 c8             	mov    %rcx,%r8
    2a3f:	41 83 e0 08          	and    $0x8,%r8d
    2a43:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    2a4a:	00 
    2a4b:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    2a52:	00 
    2a53:	e9 d1 01 00 00       	jmp    0x2c29
    2a58:	4c 89 e1             	mov    %r12,%rcx
    2a5b:	49 89 c8             	mov    %rcx,%r8
    2a5e:	41 83 e0 08          	and    $0x8,%r8d
    2a62:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    2a69:	00 
    2a6a:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
    2a71:	00 
    2a72:	85 fa                	test   %edi,%edx
    2a74:	4c 8b 9c 24 18 01 00 	mov    0x118(%rsp),%r11
    2a7b:	00 
    2a7c:	4c 89 da             	mov    %r11,%rdx
    2a7f:	0f 45 d7             	cmovne %edi,%edx
    2a82:	41 3b d2             	cmp    %r10d,%edx
    2a85:	40 0f 9f c7          	setg   %dil
    2a89:	41 83 fa fb          	cmp    $0xfffffffb,%r10d
    2a8d:	41 0f 9f c1          	setg   %r9b
    2a91:	4d 89 d3             	mov    %r10,%r11
    2a94:	41 f7 d3             	not    %r11d
    2a97:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    2a9c:	41 84 f9             	test   %dil,%r9b
    2a9f:	41 0f 45 db          	cmovne %r11d,%ebx
    2aa3:	03 d3                	add    %ebx,%edx
    2aa5:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
    2aac:	00 
    2aad:	ba fe ff ff ff       	mov    $0xfffffffe,%edx
    2ab2:	41 84 f9             	test   %dil,%r9b
    2ab5:	0f 45 15 6c 2a 00 00 	cmovne 0x2a6c(%rip),%edx        # 0x5528
    2abc:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
    2ac1:	03 d7                	add    %edi,%edx
    2ac3:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
    2ac8:	f7 c1 08 00 00 00    	test   $0x8,%ecx
    2ace:	0f 84 15 00 00 00    	je     0x2ae9
    2ad4:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    2adb:	00 
    2adc:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    2ae3:	00 
    2ae4:	e9 40 01 00 00       	jmp    0x2c29
    2ae9:	bf 09 00 00 00       	mov    $0x9,%edi
    2aee:	85 c0                	test   %eax,%eax
    2af0:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    2af7:	00 
    2af8:	0f 85 0a 00 00 00    	jne    0x2b08
    2afe:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    2b03:	e9 87 00 00 00       	jmp    0x2b8f
    2b08:	45 8d 4e fc          	lea    -0x4(%r14),%r9d
    2b0c:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2b13:	00 
    2b14:	43 8b 14 0b          	mov    (%r11,%r9,1),%edx
    2b18:	bf 09 00 00 00       	mov    $0x9,%edi
    2b1d:	85 d2                	test   %edx,%edx
    2b1f:	0f 85 0a 00 00 00    	jne    0x2b2f
    2b25:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    2b2a:	e9 60 00 00 00       	jmp    0x2b8f
    2b2f:	c4 62 23 f6 1d 20 2a 	mulx   0x2a20(%rip),%r11d,%r11d        # 0x5558
    2b36:	00 00 
    2b38:	41 c1 eb 03          	shr    $0x3,%r11d
    2b3c:	41 6b fb 0a          	imul   $0xa,%r11d,%edi
    2b40:	48 89 d0             	mov    %rdx,%rax
    2b43:	2b c7                	sub    %edi,%eax
    2b45:	49 89 d1             	mov    %rdx,%r9
    2b48:	33 ff                	xor    %edi,%edi
    2b4a:	85 c0                	test   %eax,%eax
    2b4c:	0f 84 0a 00 00 00    	je     0x2b5c
    2b52:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    2b57:	e9 33 00 00 00       	jmp    0x2b8f
    2b5c:	33 ff                	xor    %edi,%edi
    2b5e:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
    2b64:	45 6b c0 0a          	imul   $0xa,%r8d,%r8d
    2b68:	48 33 d2             	xor    %rdx,%rdx
    2b6b:	4c 89 c8             	mov    %r9,%rax
    2b6e:	41 f7 f0             	div    %r8d
    2b71:	8d 47 01             	lea    0x1(%rdi),%eax
    2b74:	85 d2                	test   %edx,%edx
    2b76:	0f 85 08 00 00 00    	jne    0x2b84
    2b7c:	48 89 c7             	mov    %rax,%rdi
    2b7f:	e9 e0 ff ff ff       	jmp    0x2b64
    2b84:	81 c7 01 00 00 00    	add    $0x1,%edi
    2b8a:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    2b8f:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    2b94:	83 e0 df             	and    $0xffffffdf,%eax
    2b97:	83 f8 46             	cmp    $0x46,%eax
    2b9a:	0f 85 48 00 00 00    	jne    0x2be8
    2ba0:	4c 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%r9
    2ba7:	00 
    2ba8:	4c 89 f0             	mov    %r14,%rax
    2bab:	41 2b c1             	sub    %r9d,%eax
    2bae:	c1 f8 02             	sar    $0x2,%eax
    2bb1:	6b c0 09             	imul   $0x9,%eax,%eax
    2bb4:	81 c0 f7 ff ff ff    	add    $0xfffffff7,%eax
    2bba:	2b c7                	sub    %edi,%eax
    2bbc:	45 33 c0             	xor    %r8d,%r8d
    2bbf:	44 3b c0             	cmp    %eax,%r8d
    2bc2:	41 0f 4d c0          	cmovge %r8d,%eax
    2bc6:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
    2bcd:	00 
    2bce:	3b c7                	cmp    %edi,%eax
    2bd0:	0f 4c f8             	cmovl  %eax,%edi
    2bd3:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
    2bda:	00 
    2bdb:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    2be2:	00 
    2be3:	e9 41 00 00 00       	jmp    0x2c29
    2be8:	48 8b 94 24 f0 00 00 	mov    0xf0(%rsp),%rdx
    2bef:	00 
    2bf0:	4c 89 f0             	mov    %r14,%rax
    2bf3:	2b c2                	sub    %edx,%eax
    2bf5:	c1 f8 02             	sar    $0x2,%eax
    2bf8:	6b c0 09             	imul   $0x9,%eax,%eax
    2bfb:	42 8d 44 10 f7       	lea    -0x9(%rax,%r10,1),%eax
    2c00:	2b c7                	sub    %edi,%eax
    2c02:	45 33 c0             	xor    %r8d,%r8d
    2c05:	44 3b c0             	cmp    %eax,%r8d
    2c08:	41 0f 4d c0          	cmovge %r8d,%eax
    2c0c:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    2c13:	00 
    2c14:	3b c2                	cmp    %edx,%eax
    2c16:	0f 4c d0             	cmovl  %eax,%edx
    2c19:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
    2c20:	00 
    2c21:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    2c28:	00 
    2c29:	48 89 c7             	mov    %rax,%rdi
    2c2c:	41 0b f8             	or     %r8d,%edi
    2c2f:	4c 89 44 24 58       	mov    %r8,0x58(%rsp)
    2c34:	b8 fe ff ff 7f       	mov    $0x7ffffffe,%eax
    2c39:	85 ff                	test   %edi,%edi
    2c3b:	0f 45 05 be 29 00 00 	cmovne 0x29be(%rip),%eax        # 0x5600
    2c42:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
    2c48:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    2c4f:	00 
    2c50:	3b d0                	cmp    %eax,%edx
    2c52:	0f 8e 0a 00 00 00    	jle    0x2c62
    2c58:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    2c5d:	e9 0c 1d 00 00       	jmp    0x496e
    2c62:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    2c67:	83 e0 df             	and    $0xffffffdf,%eax
    2c6a:	83 f8 46             	cmp    $0x46,%eax
    2c6d:	49 89 c4             	mov    %rax,%r12
    2c70:	0f 85 4a 00 00 00    	jne    0x2cc0
    2c76:	85 ff                	test   %edi,%edi
    2c78:	0f 95 c0             	setne  %al
    2c7b:	0f b6 c0             	movzbl %al,%eax
    2c7e:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    2c85:	00 
    2c86:	8d 44 02 01          	lea    0x1(%rdx,%rax,1),%eax
    2c8a:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    2c8f:	2b d0                	sub    %eax,%edx
    2c91:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
    2c97:	44 3b d2             	cmp    %edx,%r10d
    2c9a:	0f 8e 0a 00 00 00    	jle    0x2caa
    2ca0:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    2ca5:	e9 c4 1c 00 00       	jmp    0x496e
    2caa:	33 c0                	xor    %eax,%eax
    2cac:	41 3b c2             	cmp    %r10d,%eax
    2caf:	44 0f 4d d0          	cmovge %eax,%r10d
    2cb3:	48 89 b4 24 a8 00 00 	mov    %rsi,0xa8(%rsp)
    2cba:	00 
    2cbb:	e9 5a 01 00 00       	jmp    0x2e1a
    2cc0:	4c 89 d0             	mov    %r10,%rax
    2cc3:	c1 f8 1f             	sar    $0x1f,%eax
    2cc6:	41 8d 14 02          	lea    (%r10,%rax,1),%edx
    2cca:	33 d0                	xor    %eax,%edx
    2ccc:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    2cd3:	00 
    2cd4:	8d b0 e0 fd ff ff    	lea    -0x220(%rax),%esi
    2cda:	85 d2                	test   %edx,%edx
    2cdc:	0f 85 0d 00 00 00    	jne    0x2cef
    2ce2:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    2ce9:	00 
    2cea:	e9 53 00 00 00       	jmp    0x2d42
    2cef:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    2cf6:	00 
    2cf7:	8d b0 e0 fd ff ff    	lea    -0x220(%rax),%esi
    2cfd:	c4 e2 7b f6 05 52 28 	mulx   0x2852(%rip),%eax,%eax        # 0x5558
    2d04:	00 00 
    2d06:	c1 e8 03             	shr    $0x3,%eax
    2d09:	44 6b c8 0a          	imul   $0xa,%eax,%r9d
    2d0d:	49 89 d0             	mov    %rdx,%r8
    2d10:	45 2b c1             	sub    %r9d,%r8d
    2d13:	41 83 c8 30          	or     $0x30,%r8d
    2d17:	81 c6 ff ff ff ff    	add    $0xffffffff,%esi
    2d1d:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2d24:	00 
    2d25:	45 88 04 33          	mov    %r8b,(%r11,%rsi,1)
    2d29:	83 fa 09             	cmp    $0x9,%edx
    2d2c:	0f 86 08 00 00 00    	jbe    0x2d3a
    2d32:	48 89 c2             	mov    %rax,%rdx
    2d35:	e9 c3 ff ff ff       	jmp    0x2cfd
    2d3a:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    2d41:	00 
    2d42:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    2d49:	00 
    2d4a:	81 c0 e0 fd ff ff    	add    $0xfffffde0,%eax
    2d50:	2b c6                	sub    %esi,%eax
    2d52:	83 f8 01             	cmp    $0x1,%eax
    2d55:	0f 8f 40 00 00 00    	jg     0x2d9b
    2d5b:	81 c6 ff ff ff ff    	add    $0xffffffff,%esi
    2d61:	b8 30 00 00 00       	mov    $0x30,%eax
    2d66:	8b d6                	mov    %esi,%edx
    2d68:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2d6f:	00 
    2d70:	41 88 04 13          	mov    %al,(%r11,%rdx,1)
    2d74:	4c 8b 84 24 28 01 00 	mov    0x128(%rsp),%r8
    2d7b:	00 
    2d7c:	41 81 c0 e0 fd ff ff 	add    $0xfffffde0,%r8d
    2d83:	44 2b c6             	sub    %esi,%r8d
    2d86:	8d 56 ff             	lea    -0x1(%rsi),%edx
    2d89:	41 83 f8 02          	cmp    $0x2,%r8d
    2d8d:	0f 8d 08 00 00 00    	jge    0x2d9b
    2d93:	48 89 d6             	mov    %rdx,%rsi
    2d96:	e9 cb ff ff ff       	jmp    0x2d66
    2d9b:	8d 46 fe             	lea    -0x2(%rsi),%eax
    2d9e:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
    2da3:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2daa:	00 
    2dab:	41 88 14 03          	mov    %dl,(%r11,%rax,1)
    2daf:	ba 2b 00 00 00       	mov    $0x2b,%edx
    2db4:	45 85 d2             	test   %r10d,%r10d
    2db7:	0f 4c 15 4a 28 00 00 	cmovl  0x284a(%rip),%edx        # 0x5608
    2dbe:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
    2dc4:	44 8d 46 ff          	lea    -0x1(%rsi),%r8d
    2dc8:	43 88 14 03          	mov    %dl,(%r11,%r8,1)
    2dcc:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
    2dd3:	00 
    2dd4:	44 8d 92 e0 fd ff ff 	lea    -0x220(%rdx),%r10d
    2ddb:	44 2b d0             	sub    %eax,%r10d
    2dde:	85 ff                	test   %edi,%edi
    2de0:	0f 95 c2             	setne  %dl
    2de3:	0f b6 d2             	movzbl %dl,%edx
    2de6:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    2ded:	00 
    2dee:	8d 54 10 01          	lea    0x1(%rax,%rdx,1),%edx
    2df2:	b8 ff ff ff 7f       	mov    $0x7fffffff,%eax
    2df7:	2b c2                	sub    %edx,%eax
    2df9:	44 3b d0             	cmp    %eax,%r10d
    2dfc:	0f 8e 0a 00 00 00    	jle    0x2e0c
    2e02:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    2e07:	e9 62 1b 00 00       	jmp    0x496e
    2e0c:	81 c6 fe ff ff ff    	add    $0xfffffffe,%esi
    2e12:	48 89 b4 24 a8 00 00 	mov    %rsi,0xa8(%rsp)
    2e19:	00 
    2e1a:	85 ff                	test   %edi,%edi
    2e1c:	48 89 bc 24 e8 00 00 	mov    %rdi,0xe8(%rsp)
    2e23:	00 
    2e24:	40 0f 95 c6          	setne  %sil
    2e28:	40 0f b6 f6          	movzbl %sil,%esi
    2e2c:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    2e33:	00 
    2e34:	03 f0                	add    %eax,%esi
    2e36:	41 8d 74 32 01       	lea    0x1(%r10,%rsi,1),%esi
    2e3b:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    2e40:	48 89 c7             	mov    %rax,%rdi
    2e43:	81 f7 ff ff ff 7f    	xor    $0x7fffffff,%edi
    2e49:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
    2e4f:	3b f7                	cmp    %edi,%esi
    2e51:	0f 8e 0a 00 00 00    	jle    0x2e61
    2e57:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    2e5c:	e9 0d 1b 00 00       	jmp    0x496e
    2e61:	49 89 c9             	mov    %rcx,%r9
    2e64:	41 81 e1 00 20 01 00 	and    $0x12000,%r9d
    2e6b:	4c 89 8c 24 d8 00 00 	mov    %r9,0xd8(%rsp)
    2e72:	00 
    2e73:	f7 c1 00 20 01 00    	test   $0x12000,%ecx
    2e79:	0f 84 27 00 00 00    	je     0x2ea6
    2e7f:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    2e86:	00 
    2e87:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2e8e:	00 
    2e8f:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    2e94:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    2e99:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
    2ea0:	00 
    2ea1:	e9 7e 01 00 00       	jmp    0x3024
    2ea6:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    2eab:	8d 04 0e             	lea    (%rsi,%rcx,1),%eax
    2eae:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    2eb5:	00 
    2eb6:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
    2ebd:	00 
    2ebe:	3b c8                	cmp    %eax,%ecx
    2ec0:	0f 8f 1f 00 00 00    	jg     0x2ee5
    2ec6:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    2ecd:	00 
    2ece:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2ed5:	00 
    2ed6:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    2edb:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    2ee0:	e9 3f 01 00 00       	jmp    0x3024
    2ee5:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
    2eec:	00 
    2eed:	8d 91 d0 fc ff ff    	lea    -0x330(%rcx),%edx
    2ef3:	49 89 d5             	mov    %rdx,%r13
    2ef6:	b9 20 00 00 00       	mov    $0x20,%ecx
    2efb:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
    2f02:	00 
    2f03:	2b d0                	sub    %eax,%edx
    2f05:	41 bf 00 01 00 00    	mov    $0x100,%r15d
    2f0b:	44 3b fa             	cmp    %edx,%r15d
    2f0e:	49 89 d0             	mov    %rdx,%r8
    2f11:	45 0f 42 c7          	cmovb  %r15d,%r8d
    2f15:	48 89 d3             	mov    %rdx,%rbx
    2f18:	4c 89 ea             	mov    %r13,%rdx
    2f1b:	48 8b 34 24          	mov    (%rsp),%rsi
    2f1f:	48 8b 3c 24          	mov    (%rsp),%rdi
    2f23:	e8 b8 34 00 00       	call   0x63e0
    2f28:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    2f2f:	00 
    2f30:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2f37:	00 
    2f38:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    2f3c:	f7 c6 20 00 00 00    	test   $0x20,%esi
    2f42:	0f 94 c0             	sete   %al
    2f45:	0f b6 d0             	movzbl %al,%edx
    2f48:	48 89 d9             	mov    %rbx,%rcx
    2f4b:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    2f51:	0f 83 12 00 00 00    	jae    0x2f69
    2f57:	48 89 d9             	mov    %rbx,%rcx
    2f5a:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    2f5f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    2f64:	e9 79 00 00 00       	jmp    0x2fe2
    2f69:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    2f6e:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    2f73:	f7 c2 01 00 00 00    	test   $0x1,%edx
    2f79:	0f 85 08 00 00 00    	jne    0x2f87
    2f7f:	48 89 d9             	mov    %rbx,%rcx
    2f82:	e9 2f 00 00 00       	jmp    0x2fb6
    2f87:	4c 89 f9             	mov    %r15,%rcx
    2f8a:	4c 89 ea             	mov    %r13,%rdx
    2f8d:	48 8b 34 24          	mov    (%rsp),%rsi
    2f91:	48 8b 3c 24          	mov    (%rsp),%rdi
    2f95:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    2f9a:	e8 e1 ba ff ff       	call   0xffffffffffffea80
    2f9f:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    2fa6:	00 
    2fa7:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2fae:	00 
    2faf:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    2fb3:	48 89 d9             	mov    %rbx,%rcx
    2fb6:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    2fbc:	f7 c6 20 00 00 00    	test   $0x20,%esi
    2fc2:	0f 94 c0             	sete   %al
    2fc5:	0f b6 d0             	movzbl %al,%edx
    2fc8:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    2fce:	0f 86 08 00 00 00    	jbe    0x2fdc
    2fd4:	48 89 fb             	mov    %rdi,%rbx
    2fd7:	e9 97 ff ff ff       	jmp    0x2f73
    2fdc:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    2fe2:	85 d2                	test   %edx,%edx
    2fe4:	0f 85 15 00 00 00    	jne    0x2fff
    2fea:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    2ff1:	00 
    2ff2:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    2ff9:	00 
    2ffa:	e9 25 00 00 00       	jmp    0x3024
    2fff:	4c 89 ea             	mov    %r13,%rdx
    3002:	48 8b 34 24          	mov    (%rsp),%rsi
    3006:	48 8b 3c 24          	mov    (%rsp),%rdi
    300a:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    300f:	e8 6c ba ff ff       	call   0xffffffffffffea80
    3014:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    301b:	00 
    301c:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3023:	00 
    3024:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    302b:	00 
    302c:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3033:	00 
    3034:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    3039:	a9 20 00 00 00       	test   $0x20,%eax
    303e:	0f 84 0d 00 00 00    	je     0x3051
    3044:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
    304b:	00 
    304c:	e9 24 00 00 00       	jmp    0x3075
    3051:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    3056:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
    305b:	48 8b 34 24          	mov    (%rsp),%rsi
    305f:	48 8b 3c 24          	mov    (%rsp),%rdi
    3063:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3068:	e8 13 ba ff ff       	call   0xffffffffffffea80
    306d:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
    3074:	00 
    3075:	41 81 f9 00 00 01 00 	cmp    $0x10000,%r9d
    307c:	4c 89 8c 24 d8 00 00 	mov    %r9,0xd8(%rsp)
    3083:	00 
    3084:	0f 84 08 00 00 00    	je     0x3092
    308a:	4c 89 e7             	mov    %r12,%rdi
    308d:	e9 37 01 00 00       	jmp    0x31c9
    3092:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    3097:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
    309e:	00 
    309f:	8d 04 0e             	lea    (%rsi,%rcx,1),%eax
    30a2:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    30a9:	00 
    30aa:	3b c8                	cmp    %eax,%ecx
    30ac:	0f 8f 08 00 00 00    	jg     0x30ba
    30b2:	4c 89 e7             	mov    %r12,%rdi
    30b5:	e9 0f 01 00 00       	jmp    0x31c9
    30ba:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
    30c1:	00 
    30c2:	8d 91 d0 fc ff ff    	lea    -0x330(%rcx),%edx
    30c8:	49 89 d5             	mov    %rdx,%r13
    30cb:	b9 30 00 00 00       	mov    $0x30,%ecx
    30d0:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
    30d7:	00 
    30d8:	2b d0                	sub    %eax,%edx
    30da:	bb 00 01 00 00       	mov    $0x100,%ebx
    30df:	3b da                	cmp    %edx,%ebx
    30e1:	49 89 d0             	mov    %rdx,%r8
    30e4:	44 0f 42 c3          	cmovb  %ebx,%r8d
    30e8:	49 89 d7             	mov    %rdx,%r15
    30eb:	4c 89 ea             	mov    %r13,%rdx
    30ee:	48 8b 34 24          	mov    (%rsp),%rsi
    30f2:	48 8b 3c 24          	mov    (%rsp),%rdi
    30f6:	e8 e5 32 00 00       	call   0x63e0
    30fb:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3102:	00 
    3103:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    310a:	00 
    310b:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    310f:	f7 c6 20 00 00 00    	test   $0x20,%esi
    3115:	0f 94 c0             	sete   %al
    3118:	0f b6 d0             	movzbl %al,%edx
    311b:	4c 89 f9             	mov    %r15,%rcx
    311e:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    3124:	0f 83 08 00 00 00    	jae    0x3132
    312a:	4c 89 f9             	mov    %r15,%rcx
    312d:	e9 6f 00 00 00       	jmp    0x31a1
    3132:	f7 c2 01 00 00 00    	test   $0x1,%edx
    3138:	0f 85 08 00 00 00    	jne    0x3146
    313e:	4c 89 f9             	mov    %r15,%rcx
    3141:	e9 2f 00 00 00       	jmp    0x3175
    3146:	48 89 d9             	mov    %rbx,%rcx
    3149:	4c 89 ea             	mov    %r13,%rdx
    314c:	48 8b 34 24          	mov    (%rsp),%rsi
    3150:	48 8b 3c 24          	mov    (%rsp),%rdi
    3154:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3159:	e8 22 b9 ff ff       	call   0xffffffffffffea80
    315e:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3165:	00 
    3166:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    316d:	00 
    316e:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    3172:	4c 89 f9             	mov    %r15,%rcx
    3175:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    317b:	f7 c6 20 00 00 00    	test   $0x20,%esi
    3181:	0f 94 c0             	sete   %al
    3184:	0f b6 d0             	movzbl %al,%edx
    3187:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    318d:	0f 86 08 00 00 00    	jbe    0x319b
    3193:	49 89 ff             	mov    %rdi,%r15
    3196:	e9 97 ff ff ff       	jmp    0x3132
    319b:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    31a1:	85 d2                	test   %edx,%edx
    31a3:	0f 85 08 00 00 00    	jne    0x31b1
    31a9:	4c 89 e7             	mov    %r12,%rdi
    31ac:	e9 18 00 00 00       	jmp    0x31c9
    31b1:	4c 89 ea             	mov    %r13,%rdx
    31b4:	48 8b 34 24          	mov    (%rsp),%rsi
    31b8:	48 8b 3c 24          	mov    (%rsp),%rdi
    31bc:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    31c1:	e8 ba b8 ff ff       	call   0xffffffffffffea80
    31c6:	4c 89 e7             	mov    %r12,%rdi
    31c9:	83 ff 46             	cmp    $0x46,%edi
    31cc:	0f 85 9b 05 00 00    	jne    0x376d
    31d2:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    31d9:	00 
    31da:	4c 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%r15
    31e1:	00 
    31e2:	44 3b f8             	cmp    %eax,%r15d
    31e5:	49 89 c4             	mov    %rax,%r12
    31e8:	4c 89 e1             	mov    %r12,%rcx
    31eb:	41 0f 42 cf          	cmovb  %r15d,%ecx
    31ef:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    31f6:	00 
    31f7:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
    31fe:	00 
    31ff:	8d 98 e0 fd ff ff    	lea    -0x220(%rax),%ebx
    3205:	48 89 de             	mov    %rbx,%rsi
    3208:	83 ce 09             	or     $0x9,%esi
    320b:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
    3210:	b9 30 00 00 00       	mov    $0x30,%ecx
    3215:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    321a:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    3221:	00 
    3222:	41 8b f5             	mov    %r13d,%esi
    3225:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    322c:	00 
    322d:	41 8b 14 33          	mov    (%r11,%rsi,1),%edx
    3231:	85 d2                	test   %edx,%edx
    3233:	0f 84 c0 00 00 00    	je     0x32f9
    3239:	33 c9                	xor    %ecx,%ecx
    323b:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    3242:	00 
    3243:	44 8d 80 e0 fd ff ff 	lea    -0x220(%rax),%r8d
    324a:	c4 62 33 f6 0d 05 23 	mulx   0x2305(%rip),%r9d,%r9d        # 0x5558
    3251:	00 00 
    3253:	41 c1 e9 03          	shr    $0x3,%r9d
    3257:	45 6b d9 0a          	imul   $0xa,%r9d,%r11d
    325b:	49 89 d2             	mov    %rdx,%r10
    325e:	45 2b d3             	sub    %r11d,%r10d
    3261:	41 83 ca 30          	or     $0x30,%r10d
    3265:	45 8d 5c 08 08       	lea    0x8(%r8,%rcx,1),%r11d
    326a:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
    3271:	00 
    3272:	46 88 14 18          	mov    %r10b,(%rax,%r11,1)
    3276:	44 8d 59 ff          	lea    -0x1(%rcx),%r11d
    327a:	83 fa 09             	cmp    $0x9,%edx
    327d:	0f 86 0b 00 00 00    	jbe    0x328e
    3283:	4c 89 d9             	mov    %r11,%rcx
    3286:	4c 89 ca             	mov    %r9,%rdx
    3289:	e9 bc ff ff ff       	jmp    0x324a
    328e:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
    3295:	00 
    3296:	45 3b ec             	cmp    %r12d,%r13d
    3299:	0f 84 2d 00 00 00    	je     0x32cc
    329f:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    32a6:	00 
    32a7:	8d 94 08 e8 fd ff ff 	lea    -0x218(%rax,%rcx,1),%edx
    32ae:	41 3b d0             	cmp    %r8d,%edx
    32b1:	0f 87 7f 00 00 00    	ja     0x3336
    32b7:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    32be:	00 
    32bf:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    32c6:	00 
    32c7:	e9 96 00 00 00       	jmp    0x3362
    32cc:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    32d3:	00 
    32d4:	8d 94 08 e8 fd ff ff 	lea    -0x218(%rax,%rcx,1),%edx
    32db:	45 85 db             	test   %r11d,%r11d
    32de:	0f 84 2e 00 00 00    	je     0x3312
    32e4:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    32eb:	00 
    32ec:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    32f3:	00 
    32f4:	e9 69 00 00 00       	jmp    0x3362
    32f9:	45 33 db             	xor    %r11d,%r11d
    32fc:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
    3303:	00 
    3304:	45 3b ec             	cmp    %r12d,%r13d
    3307:	0f 85 29 00 00 00    	jne    0x3336
    330d:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    3312:	81 c2 ff ff ff ff    	add    $0xffffffff,%edx
    3318:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    331d:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3324:	00 
    3325:	41 88 0c 13          	mov    %cl,(%r11,%rdx,1)
    3329:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3330:	00 
    3331:	e9 2c 00 00 00       	jmp    0x3362
    3336:	45 8d 43 09          	lea    0x9(%r11),%r8d
    333a:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    333f:	48 89 da             	mov    %rbx,%rdx
    3342:	48 8b 34 24          	mov    (%rsp),%rsi
    3346:	48 8b 3c 24          	mov    (%rsp),%rdi
    334a:	e8 91 30 00 00       	call   0x63e0
    334f:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3356:	00 
    3357:	48 89 da             	mov    %rbx,%rdx
    335a:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3361:	00 
    3362:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3369:	00 
    336a:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3371:	00 
    3372:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    3377:	a9 20 00 00 00       	test   $0x20,%eax
    337c:	0f 85 1c 00 00 00    	jne    0x339e
    3382:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
    3387:	48 89 f1             	mov    %rsi,%rcx
    338a:	2b ca                	sub    %edx,%ecx
    338c:	48 8b 34 24          	mov    (%rsp),%rsi
    3390:	48 8b 3c 24          	mov    (%rsp),%rdi
    3394:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3399:	e8 e2 b6 ff ff       	call   0xffffffffffffea80
    339e:	41 81 c5 04 00 00 00 	add    $0x4,%r13d
    33a5:	45 3b ef             	cmp    %r15d,%r13d
    33a8:	0f 86 74 fe ff ff    	jbe    0x3222
    33ae:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
    33b5:	00 
    33b6:	85 ff                	test   %edi,%edi
    33b8:	0f 85 15 00 00 00    	jne    0x33d3
    33be:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    33c5:	00 
    33c6:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    33cd:	00 
    33ce:	e9 64 00 00 00       	jmp    0x3437
    33d3:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    33da:	00 
    33db:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    33e2:	00 
    33e3:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    33e8:	a9 20 00 00 00       	test   $0x20,%eax
    33ed:	0f 84 15 00 00 00    	je     0x3408
    33f3:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    33fa:	00 
    33fb:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    3402:	00 
    3403:	e9 2f 00 00 00       	jmp    0x3437
    3408:	ba e3 0d 00 00       	mov    $0xde3,%edx
    340d:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
    3414:	00 
    3415:	48 8b 34 24          	mov    (%rsp),%rsi
    3419:	48 8b 3c 24          	mov    (%rsp),%rdi
    341d:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3422:	e8 59 b6 ff ff       	call   0xffffffffffffea80
    3427:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    342e:	00 
    342f:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    3436:	00 
    3437:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    343e:	00 
    343f:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    3446:	00 
    3447:	85 c1                	test   %eax,%ecx
    3449:	0f 8f 15 00 00 00    	jg     0x3464
    344f:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3456:	00 
    3457:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    345e:	00 
    345f:	e9 b2 01 00 00       	jmp    0x3616
    3464:	45 3b ee             	cmp    %r14d,%r13d
    3467:	0f 82 15 00 00 00    	jb     0x3482
    346d:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3474:	00 
    3475:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    347c:	00 
    347d:	e9 94 01 00 00       	jmp    0x3616
    3482:	41 8b c5             	mov    %r13d,%eax
    3485:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    348c:	00 
    348d:	41 8b 14 03          	mov    (%r11,%rax,1),%edx
    3491:	85 d2                	test   %edx,%edx
    3493:	0f 85 0a 00 00 00    	jne    0x34a3
    3499:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
    349e:	e9 61 00 00 00       	jmp    0x3504
    34a3:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
    34a8:	c4 e2 4b f6 35 a7 20 	mulx   0x20a7(%rip),%esi,%esi        # 0x5558
    34af:	00 00 
    34b1:	c1 ee 03             	shr    $0x3,%esi
    34b4:	44 6b c6 0a          	imul   $0xa,%esi,%r8d
    34b8:	48 89 d7             	mov    %rdx,%rdi
    34bb:	41 2b f8             	sub    %r8d,%edi
    34be:	83 cf 30             	or     $0x30,%edi
    34c1:	81 c1 ff ff ff ff    	add    $0xffffffff,%ecx
    34c7:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    34ce:	00 
    34cf:	41 88 3c 0b          	mov    %dil,(%r11,%rcx,1)
    34d3:	83 fa 09             	cmp    $0x9,%edx
    34d6:	0f 86 08 00 00 00    	jbe    0x34e4
    34dc:	48 89 f2             	mov    %rsi,%rdx
    34df:	e9 c4 ff ff ff       	jmp    0x34a8
    34e4:	3b cb                	cmp    %ebx,%ecx
    34e6:	0f 87 18 00 00 00    	ja     0x3504
    34ec:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    34f3:	00 
    34f4:	48 89 ca             	mov    %rcx,%rdx
    34f7:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    34fe:	00 
    34ff:	e9 3f 00 00 00       	jmp    0x3543
    3504:	49 89 c8             	mov    %rcx,%r8
    3507:	44 2b c3             	sub    %ebx,%r8d
    350a:	49 89 cc             	mov    %rcx,%r12
    350d:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    3512:	48 89 da             	mov    %rbx,%rdx
    3515:	48 8b 34 24          	mov    (%rsp),%rsi
    3519:	48 8b 3c 24          	mov    (%rsp),%rdi
    351d:	e8 be 2e 00 00       	call   0x63e0
    3522:	4c 89 e2             	mov    %r12,%rdx
    3525:	81 c2 ff ff ff ff    	add    $0xffffffff,%edx
    352b:	3b d3                	cmp    %ebx,%edx
    352d:	0f 87 f2 ff ff ff    	ja     0x3525
    3533:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    353a:	00 
    353b:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3542:	00 
    3543:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    354a:	00 
    354b:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3552:	00 
    3553:	4d 0f b6 0c 03       	movzbq (%r11,%rax,1),%r9
    3558:	41 f7 c1 20 00 00 00 	test   $0x20,%r9d
    355f:	0f 84 0d 00 00 00    	je     0x3572
    3565:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    356c:	00 
    356d:	e9 2c 00 00 00       	jmp    0x359e
    3572:	b8 09 00 00 00       	mov    $0x9,%eax
    3577:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    357e:	00 
    357f:	3b c1                	cmp    %ecx,%eax
    3581:	0f 4c c8             	cmovl  %eax,%ecx
    3584:	48 8b 34 24          	mov    (%rsp),%rsi
    3588:	48 8b 3c 24          	mov    (%rsp),%rdi
    358c:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3591:	e8 ea b4 ff ff       	call   0xffffffffffffea80
    3596:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    359d:	00 
    359e:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    35a5:	00 
    35a6:	81 c1 f7 ff ff ff    	add    $0xfffffff7,%ecx
    35ac:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    35b3:	00 
    35b4:	83 f8 0a             	cmp    $0xa,%eax
    35b7:	0f 8d 10 00 00 00    	jge    0x35cd
    35bd:	48 89 c8             	mov    %rcx,%rax
    35c0:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    35c7:	00 
    35c8:	e9 49 00 00 00       	jmp    0x3616
    35cd:	41 81 c5 04 00 00 00 	add    $0x4,%r13d
    35d4:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    35db:	00 
    35dc:	81 c1 f7 ff ff ff    	add    $0xfffffff7,%ecx
    35e2:	45 3b ee             	cmp    %r14d,%r13d
    35e5:	0f 83 0d 00 00 00    	jae    0x35f8
    35eb:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    35f2:	00 
    35f3:	e9 8a fe ff ff       	jmp    0x3482
    35f8:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    35ff:	00 
    3600:	81 c1 f7 ff ff ff    	add    $0xfffffff7,%ecx
    3606:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    360d:	00 
    360e:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3615:	00 
    3616:	85 c1                	test   %eax,%ecx
    3618:	0f 8f 0d 00 00 00    	jg     0x362b
    361e:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
    3625:	00 
    3626:	e9 80 06 00 00       	jmp    0x3cab
    362b:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    3632:	00 
    3633:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    3639:	49 89 d4             	mov    %rdx,%r12
    363c:	bb 00 01 00 00       	mov    $0x100,%ebx
    3641:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    3648:	00 
    3649:	3b d9                	cmp    %ecx,%ebx
    364b:	49 89 c8             	mov    %rcx,%r8
    364e:	44 0f 42 c3          	cmovb  %ebx,%r8d
    3652:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    3657:	48 8b 34 24          	mov    (%rsp),%rsi
    365b:	48 8b 3c 24          	mov    (%rsp),%rdi
    365f:	e8 7c 2d 00 00       	call   0x63e0
    3664:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    366b:	00 
    366c:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3673:	00 
    3674:	41 8b 0c 03          	mov    (%r11,%rax,1),%ecx
    3678:	f7 c1 20 00 00 00    	test   $0x20,%ecx
    367e:	0f 94 c0             	sete   %al
    3681:	0f b6 d0             	movzbl %al,%edx
    3684:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    368b:	00 
    368c:	3d 00 01 00 00       	cmp    $0x100,%eax
    3691:	0f 82 97 00 00 00    	jb     0x372e
    3697:	f7 c2 01 00 00 00    	test   $0x1,%edx
    369d:	0f 85 0d 00 00 00    	jne    0x36b0
    36a3:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
    36aa:	00 
    36ab:	e9 34 00 00 00       	jmp    0x36e4
    36b0:	48 89 d9             	mov    %rbx,%rcx
    36b3:	4c 89 e2             	mov    %r12,%rdx
    36b6:	48 8b 34 24          	mov    (%rsp),%rsi
    36ba:	48 8b 3c 24          	mov    (%rsp),%rdi
    36be:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    36c3:	e8 b8 b3 ff ff       	call   0xffffffffffffea80
    36c8:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    36cf:	00 
    36d0:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    36d7:	00 
    36d8:	41 8b 0c 03          	mov    (%r11,%rax,1),%ecx
    36dc:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
    36e3:	00 
    36e4:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
    36eb:	00 
    36ec:	41 8d b1 00 ff ff ff 	lea    -0x100(%r9),%esi
    36f3:	f7 c1 20 00 00 00    	test   $0x20,%ecx
    36f9:	0f 94 c0             	sete   %al
    36fc:	0f b6 d0             	movzbl %al,%edx
    36ff:	81 fe ff 00 00 00    	cmp    $0xff,%esi
    3705:	0f 86 0d 00 00 00    	jbe    0x3718
    370b:	48 89 b4 24 a0 00 00 	mov    %rsi,0xa0(%rsp)
    3712:	00 
    3713:	e9 7f ff ff ff       	jmp    0x3697
    3718:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    371f:	00 
    3720:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    3726:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    372d:	00 
    372e:	85 d2                	test   %edx,%edx
    3730:	0f 85 0d 00 00 00    	jne    0x3743
    3736:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
    373d:	00 
    373e:	e9 68 05 00 00       	jmp    0x3cab
    3743:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    374a:	00 
    374b:	4c 89 e2             	mov    %r12,%rdx
    374e:	48 8b 34 24          	mov    (%rsp),%rsi
    3752:	48 8b 3c 24          	mov    (%rsp),%rdi
    3756:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    375b:	e8 20 b3 ff ff       	call   0xffffffffffffea80
    3760:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
    3767:	00 
    3768:	e9 3e 05 00 00       	jmp    0x3cab
    376d:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3774:	00 
    3775:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    377c:	00 
    377d:	85 c1                	test   %eax,%ecx
    377f:	0f 8d 15 00 00 00    	jge    0x379a
    3785:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    378c:	00 
    378d:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3794:	00 
    3795:	e9 b2 04 00 00       	jmp    0x3c4c
    379a:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    37a1:	00 
    37a2:	44 8d a0 e0 fd ff ff 	lea    -0x220(%rax),%r12d
    37a9:	4c 89 e3             	mov    %r12,%rbx
    37ac:	83 cb 09             	or     $0x9,%ebx
    37af:	b9 30 00 00 00       	mov    $0x30,%ecx
    37b4:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    37b9:	41 bf e3 0d 00 00    	mov    $0xde3,%r15d
    37bf:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    37c6:	00 
    37c7:	4c 89 bc 24 d0 00 00 	mov    %r15,0xd0(%rsp)
    37ce:	00 
    37cf:	44 8d 78 04          	lea    0x4(%rax),%r15d
    37d3:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
    37da:	00 
    37db:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
    37e0:	85 f6                	test   %esi,%esi
    37e2:	45 0f 45 fe          	cmovne %r14d,%r15d
    37e6:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
    37eb:	4c 8b b4 24 80 00 00 	mov    0x80(%rsp),%r14
    37f2:	00 
    37f3:	41 8b ce             	mov    %r14d,%ecx
    37f6:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    37fd:	00 
    37fe:	41 8b 14 0b          	mov    (%r11,%rcx,1),%edx
    3802:	85 d2                	test   %edx,%edx
    3804:	0f 85 08 00 00 00    	jne    0x3812
    380a:	48 89 d9             	mov    %rbx,%rcx
    380d:	e9 77 00 00 00       	jmp    0x3889
    3812:	33 c9                	xor    %ecx,%ecx
    3814:	c4 e2 4b f6 35 3b 1d 	mulx   0x1d3b(%rip),%esi,%esi        # 0x5558
    381b:	00 00 
    381d:	c1 ee 03             	shr    $0x3,%esi
    3820:	44 6b c6 0a          	imul   $0xa,%esi,%r8d
    3824:	48 89 d7             	mov    %rdx,%rdi
    3827:	41 2b f8             	sub    %r8d,%edi
    382a:	83 cf 30             	or     $0x30,%edi
    382d:	45 8d 44 0c 08       	lea    0x8(%r12,%rcx,1),%r8d
    3832:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3839:	00 
    383a:	43 88 3c 03          	mov    %dil,(%r11,%r8,1)
    383e:	8d 79 ff             	lea    -0x1(%rcx),%edi
    3841:	83 fa 09             	cmp    $0x9,%edx
    3844:	0f 86 0b 00 00 00    	jbe    0x3855
    384a:	48 89 f9             	mov    %rdi,%rcx
    384d:	48 89 f2             	mov    %rsi,%rdx
    3850:	e9 bf ff ff ff       	jmp    0x3814
    3855:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    385c:	00 
    385d:	44 8d bc 08 e8 fd ff 	lea    -0x218(%rax,%rcx,1),%r15d
    3864:	ff 
    3865:	85 ff                	test   %edi,%edi
    3867:	0f 84 0d 00 00 00    	je     0x387a
    386d:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    3874:	00 
    3875:	e9 2c 00 00 00       	jmp    0x38a6
    387a:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    3881:	00 
    3882:	8d 8c 08 e8 fd ff ff 	lea    -0x218(%rax,%rcx,1),%ecx
    3889:	44 8d 79 ff          	lea    -0x1(%rcx),%r15d
    388d:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    3892:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3899:	00 
    389a:	43 88 0c 3b          	mov    %cl,(%r11,%r15,1)
    389e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    38a5:	00 
    38a6:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    38ad:	00 
    38ae:	44 3b f0             	cmp    %eax,%r14d
    38b1:	0f 84 68 00 00 00    	je     0x391f
    38b7:	45 3b fc             	cmp    %r12d,%r15d
    38ba:	0f 87 1a 00 00 00    	ja     0x38da
    38c0:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    38c7:	00 
    38c8:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    38cf:	00 
    38d0:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    38d5:	e9 62 01 00 00       	jmp    0x3a3c
    38da:	4d 89 f8             	mov    %r15,%r8
    38dd:	45 2b c4             	sub    %r12d,%r8d
    38e0:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    38e5:	4c 89 e2             	mov    %r12,%rdx
    38e8:	48 8b 34 24          	mov    (%rsp),%rsi
    38ec:	48 8b 3c 24          	mov    (%rsp),%rdi
    38f0:	e8 eb 2a 00 00       	call   0x63e0
    38f5:	41 81 c7 ff ff ff ff 	add    $0xffffffff,%r15d
    38fc:	45 3b fc             	cmp    %r12d,%r15d
    38ff:	0f 87 f0 ff ff ff    	ja     0x38f5
    3905:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    390c:	00 
    390d:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3914:	00 
    3915:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    391a:	e9 1d 01 00 00       	jmp    0x3a3c
    391f:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3926:	00 
    3927:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    392e:	00 
    392f:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    3934:	a9 20 00 00 00       	test   $0x20,%eax
    3939:	0f 84 0a 00 00 00    	je     0x3949
    393f:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    3944:	e9 22 00 00 00       	jmp    0x396b
    3949:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
    3950:	00 
    3951:	4c 89 fa             	mov    %r15,%rdx
    3954:	48 8b 34 24          	mov    (%rsp),%rsi
    3958:	48 8b 3c 24          	mov    (%rsp),%rdi
    395c:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3961:	e8 1a b1 ff ff       	call   0xffffffffffffea80
    3966:	4c 8b 6c 24 58       	mov    0x58(%rsp),%r13
    396b:	45 85 ed             	test   %r13d,%r13d
    396e:	0f 84 15 00 00 00    	je     0x3989
    3974:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    397b:	00 
    397c:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3983:	00 
    3984:	e9 44 00 00 00       	jmp    0x39cd
    3989:	41 8d 4f 01          	lea    0x1(%r15),%ecx
    398d:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3994:	00 
    3995:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    399c:	00 
    399d:	85 d0                	test   %edx,%eax
    399f:	0f 8f 18 00 00 00    	jg     0x39bd
    39a5:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    39ac:	00 
    39ad:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    39b4:	00 
    39b5:	49 89 cf             	mov    %rcx,%r15
    39b8:	e9 7f 00 00 00       	jmp    0x3a3c
    39bd:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    39c4:	00 
    39c5:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    39cc:	00 
    39cd:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    39d4:	00 
    39d5:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    39dc:	00 
    39dd:	49 0f b6 0c 03       	movzbq (%r11,%rax,1),%rcx
    39e2:	41 81 c7 01 00 00 00 	add    $0x1,%r15d
    39e9:	f7 c1 20 00 00 00    	test   $0x20,%ecx
    39ef:	0f 84 15 00 00 00    	je     0x3a0a
    39f5:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    39fc:	00 
    39fd:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3a04:	00 
    3a05:	e9 32 00 00 00       	jmp    0x3a3c
    3a0a:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
    3a11:	00 
    3a12:	48 8b 94 24 d0 00 00 	mov    0xd0(%rsp),%rdx
    3a19:	00 
    3a1a:	48 8b 34 24          	mov    (%rsp),%rsi
    3a1e:	48 8b 3c 24          	mov    (%rsp),%rdi
    3a22:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3a27:	e8 54 b0 ff ff       	call   0xffffffffffffea80
    3a2c:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3a33:	00 
    3a34:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3a3b:	00 
    3a3c:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3a43:	00 
    3a44:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3a4b:	00 
    3a4c:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    3a51:	a9 20 00 00 00       	test   $0x20,%eax
    3a56:	0f 85 28 00 00 00    	jne    0x3a84
    3a5c:	48 89 d8             	mov    %rbx,%rax
    3a5f:	41 2b c7             	sub    %r15d,%eax
    3a62:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    3a69:	00 
    3a6a:	3b c1                	cmp    %ecx,%eax
    3a6c:	0f 4c c8             	cmovl  %eax,%ecx
    3a6f:	4c 89 fa             	mov    %r15,%rdx
    3a72:	48 8b 34 24          	mov    (%rsp),%rsi
    3a76:	48 8b 3c 24          	mov    (%rsp),%rdi
    3a7a:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3a7f:	e8 fc af ff ff       	call   0xffffffffffffea80
    3a84:	41 81 c6 04 00 00 00 	add    $0x4,%r14d
    3a8b:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
    3a90:	44 3b f1             	cmp    %ecx,%r14d
    3a93:	0f 83 32 00 00 00    	jae    0x3acb
    3a99:	48 89 de             	mov    %rbx,%rsi
    3a9c:	41 2b f7             	sub    %r15d,%esi
    3a9f:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3aa6:	00 
    3aa7:	48 89 c2             	mov    %rax,%rdx
    3aaa:	2b d6                	sub    %esi,%edx
    3aac:	85 d2                	test   %edx,%edx
    3aae:	0f 8c 17 00 00 00    	jl     0x3acb
    3ab4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    3ab9:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
    3abe:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
    3ac5:	00 
    3ac6:	e9 28 fd ff ff       	jmp    0x37f3
    3acb:	41 2b df             	sub    %r15d,%ebx
    3ace:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    3ad5:	00 
    3ad6:	2b cb                	sub    %ebx,%ecx
    3ad8:	48 89 cf             	mov    %rcx,%rdi
    3adb:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    3ae2:	00 
    3ae3:	85 f9                	test   %edi,%ecx
    3ae5:	0f 8f 15 00 00 00    	jg     0x3b00
    3aeb:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3af2:	00 
    3af3:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3afa:	00 
    3afb:	e9 4c 01 00 00       	jmp    0x3c4c
    3b00:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    3b07:	00 
    3b08:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    3b0e:	49 89 d4             	mov    %rdx,%r12
    3b11:	bb 00 01 00 00       	mov    $0x100,%ebx
    3b16:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    3b1d:	00 
    3b1e:	3b d9                	cmp    %ecx,%ebx
    3b20:	49 89 c8             	mov    %rcx,%r8
    3b23:	44 0f 42 c3          	cmovb  %ebx,%r8d
    3b27:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    3b2c:	48 8b 34 24          	mov    (%rsp),%rsi
    3b30:	48 8b 3c 24          	mov    (%rsp),%rdi
    3b34:	e8 a7 28 00 00       	call   0x63e0
    3b39:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3b40:	00 
    3b41:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3b48:	00 
    3b49:	41 8b 0c 03          	mov    (%r11,%rax,1),%ecx
    3b4d:	f7 c1 20 00 00 00    	test   $0x20,%ecx
    3b53:	0f 94 c0             	sete   %al
    3b56:	0f b6 d0             	movzbl %al,%edx
    3b59:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3b60:	00 
    3b61:	3d 00 01 00 00       	cmp    $0x100,%eax
    3b66:	0f 82 96 00 00 00    	jb     0x3c02
    3b6c:	f7 c2 01 00 00 00    	test   $0x1,%edx
    3b72:	0f 85 0d 00 00 00    	jne    0x3b85
    3b78:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3b7f:	00 
    3b80:	e9 34 00 00 00       	jmp    0x3bb9
    3b85:	48 89 d9             	mov    %rbx,%rcx
    3b88:	4c 89 e2             	mov    %r12,%rdx
    3b8b:	48 8b 34 24          	mov    (%rsp),%rsi
    3b8f:	48 8b 3c 24          	mov    (%rsp),%rdi
    3b93:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3b98:	e8 e3 ae ff ff       	call   0xffffffffffffea80
    3b9d:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3ba4:	00 
    3ba5:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3bac:	00 
    3bad:	41 8b 0c 03          	mov    (%r11,%rax,1),%ecx
    3bb1:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3bb8:	00 
    3bb9:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3bc0:	00 
    3bc1:	8d b0 00 ff ff ff    	lea    -0x100(%rax),%esi
    3bc7:	f7 c1 20 00 00 00    	test   $0x20,%ecx
    3bcd:	0f 94 c0             	sete   %al
    3bd0:	0f b6 d0             	movzbl %al,%edx
    3bd3:	81 fe ff 00 00 00    	cmp    $0xff,%esi
    3bd9:	0f 86 0d 00 00 00    	jbe    0x3bec
    3bdf:	48 89 b4 24 a0 00 00 	mov    %rsi,0xa0(%rsp)
    3be6:	00 
    3be7:	e9 80 ff ff ff       	jmp    0x3b6c
    3bec:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    3bf3:	00 
    3bf4:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    3bfa:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
    3c01:	00 
    3c02:	85 d2                	test   %edx,%edx
    3c04:	0f 85 15 00 00 00    	jne    0x3c1f
    3c0a:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3c11:	00 
    3c12:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3c19:	00 
    3c1a:	e9 2d 00 00 00       	jmp    0x3c4c
    3c1f:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    3c26:	00 
    3c27:	4c 89 e2             	mov    %r12,%rdx
    3c2a:	48 8b 34 24          	mov    (%rsp),%rsi
    3c2e:	48 8b 3c 24          	mov    (%rsp),%rdi
    3c32:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3c37:	e8 44 ae ff ff       	call   0xffffffffffffea80
    3c3c:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3c43:	00 
    3c44:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3c4b:	00 
    3c4c:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3c53:	00 
    3c54:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3c5b:	00 
    3c5c:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    3c61:	a9 20 00 00 00       	test   $0x20,%eax
    3c66:	0f 84 0d 00 00 00    	je     0x3c79
    3c6c:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
    3c73:	00 
    3c74:	e9 32 00 00 00       	jmp    0x3cab
    3c79:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    3c80:	00 
    3c81:	8d 88 e0 fd ff ff    	lea    -0x220(%rax),%ecx
    3c87:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
    3c8e:	00 
    3c8f:	2b ca                	sub    %edx,%ecx
    3c91:	48 8b 34 24          	mov    (%rsp),%rsi
    3c95:	48 8b 3c 24          	mov    (%rsp),%rdi
    3c99:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3c9e:	e8 dd ad ff ff       	call   0xffffffffffffea80
    3ca3:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
    3caa:	00 
    3cab:	41 81 f9 00 20 00 00 	cmp    $0x2000,%r9d
    3cb2:	0f 84 12 00 00 00    	je     0x3cca
    3cb8:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    3cbd:	48 8b 9c 24 e0 00 00 	mov    0xe0(%rsp),%rbx
    3cc4:	00 
    3cc5:	e9 44 01 00 00       	jmp    0x3e0e
    3cca:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    3ccf:	48 8b 9c 24 e0 00 00 	mov    0xe0(%rsp),%rbx
    3cd6:	00 
    3cd7:	8d 3c 0b             	lea    (%rbx,%rcx,1),%edi
    3cda:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    3ce1:	00 
    3ce2:	3b cf                	cmp    %edi,%ecx
    3ce4:	0f 8f 0a 00 00 00    	jg     0x3cf4
    3cea:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    3cef:	e9 1a 01 00 00       	jmp    0x3e0e
    3cf4:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    3cfb:	00 
    3cfc:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    3d02:	49 89 d6             	mov    %rdx,%r14
    3d05:	b9 20 00 00 00       	mov    $0x20,%ecx
    3d0a:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    3d11:	00 
    3d12:	48 89 c2             	mov    %rax,%rdx
    3d15:	2b d7                	sub    %edi,%edx
    3d17:	41 bd 00 01 00 00    	mov    $0x100,%r13d
    3d1d:	44 3b ea             	cmp    %edx,%r13d
    3d20:	49 89 d0             	mov    %rdx,%r8
    3d23:	45 0f 42 c5          	cmovb  %r13d,%r8d
    3d27:	49 89 d4             	mov    %rdx,%r12
    3d2a:	4c 89 f2             	mov    %r14,%rdx
    3d2d:	48 8b 34 24          	mov    (%rsp),%rsi
    3d31:	48 8b 3c 24          	mov    (%rsp),%rdi
    3d35:	e8 a6 26 00 00       	call   0x63e0
    3d3a:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3d41:	00 
    3d42:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3d49:	00 
    3d4a:	41 8b 14 03          	mov    (%r11,%rax,1),%edx
    3d4e:	f7 c2 20 00 00 00    	test   $0x20,%edx
    3d54:	0f 94 c0             	sete   %al
    3d57:	40 0f b6 f0          	rex movzbl %al,%esi
    3d5b:	4c 89 e1             	mov    %r12,%rcx
    3d5e:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    3d64:	0f 83 08 00 00 00    	jae    0x3d72
    3d6a:	4c 89 e1             	mov    %r12,%rcx
    3d6d:	e9 70 00 00 00       	jmp    0x3de2
    3d72:	f7 c6 01 00 00 00    	test   $0x1,%esi
    3d78:	0f 85 08 00 00 00    	jne    0x3d86
    3d7e:	4c 89 e1             	mov    %r12,%rcx
    3d81:	e9 2f 00 00 00       	jmp    0x3db5
    3d86:	4c 89 e9             	mov    %r13,%rcx
    3d89:	4c 89 f2             	mov    %r14,%rdx
    3d8c:	48 8b 34 24          	mov    (%rsp),%rsi
    3d90:	48 8b 3c 24          	mov    (%rsp),%rdi
    3d94:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3d99:	e8 e2 ac ff ff       	call   0xffffffffffffea80
    3d9e:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    3da5:	00 
    3da6:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3dad:	00 
    3dae:	41 8b 14 03          	mov    (%r11,%rax,1),%edx
    3db2:	4c 89 e1             	mov    %r12,%rcx
    3db5:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    3dbb:	f7 c2 20 00 00 00    	test   $0x20,%edx
    3dc1:	0f 94 c0             	sete   %al
    3dc4:	40 0f b6 f0          	rex movzbl %al,%esi
    3dc8:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    3dce:	0f 86 08 00 00 00    	jbe    0x3ddc
    3dd4:	49 89 fc             	mov    %rdi,%r12
    3dd7:	e9 96 ff ff ff       	jmp    0x3d72
    3ddc:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    3de2:	85 f6                	test   %esi,%esi
    3de4:	0f 85 0a 00 00 00    	jne    0x3df4
    3dea:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    3def:	e9 1a 00 00 00       	jmp    0x3e0e
    3df4:	4c 89 f2             	mov    %r14,%rdx
    3df7:	48 8b 34 24          	mov    (%rsp),%rsi
    3dfb:	48 8b 3c 24          	mov    (%rsp),%rdi
    3dff:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3e04:	e8 77 ac ff ff       	call   0xffffffffffffea80
    3e09:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    3e0e:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    3e13:	8d 04 0b             	lea    (%rbx,%rcx,1),%eax
    3e16:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    3e1d:	00 
    3e1e:	3b c1                	cmp    %ecx,%eax
    3e20:	0f 4d c8             	cmovge %eax,%ecx
    3e23:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    3e2a:	00 
    3e2b:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    3e30:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
    3e37:	00 
    3e38:	e9 31 0b 00 00       	jmp    0x496e
    3e3d:	83 f8 0b             	cmp    $0xb,%eax
    3e40:	0f 86 0d 00 00 00    	jbe    0x3e53
    3e46:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3e4d:	00 
    3e4e:	e9 d2 00 00 00       	jmp    0x3f25
    3e53:	b8 0c 00 00 00       	mov    $0xc,%eax
    3e58:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    3e5f:	00 
    3e60:	2b c2                	sub    %edx,%eax
    3e62:	85 c0                	test   %eax,%eax
    3e64:	0f 85 0d 00 00 00    	jne    0x3e77
    3e6a:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3e71:	00 
    3e72:	e9 ae 00 00 00       	jmp    0x3f25
    3e77:	48 b8 00 00 00 00 00 	movabs $0x4030000000000000,%rax
    3e7e:	00 30 40 
    3e81:	c4 e1 f9 6e c8       	vmovq  %rax,%xmm1
    3e86:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    3e8d:	00 
    3e8e:	8d 50 f4             	lea    -0xc(%rax),%edx
    3e91:	8d 42 01             	lea    0x1(%rdx),%eax
    3e94:	c5 f3 59 0d 74 17 00 	vmulsd 0x1774(%rip),%xmm1,%xmm1        # 0x5610
    3e9b:	00 
    3e9c:	3b c2                	cmp    %edx,%eax
    3e9e:	0f 82 08 00 00 00    	jb     0x3eac
    3ea4:	48 89 c2             	mov    %rax,%rdx
    3ea7:	e9 e5 ff ff ff       	jmp    0x3e91
    3eac:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
    3eb1:	8d 42 09             	lea    0x9(%rdx),%eax
    3eb4:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
    3eb9:	f7 c6 20 00 00 00    	test   $0x20,%esi
    3ebf:	0f 45 d0             	cmovne %eax,%edx
    3ec2:	8b c2                	mov    %edx,%eax
    3ec4:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3ecb:	00 
    3ecc:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    3ed1:	83 f8 2d             	cmp    $0x2d,%eax
    3ed4:	0f 85 3b 00 00 00    	jne    0x3f15
    3eda:	48 b8 00 00 00 00 00 	movabs $0x8000000000000000,%rax
    3ee1:	00 00 80 
    3ee4:	c4 e1 f9 6e d0       	vmovq  %rax,%xmm2
    3ee9:	c5 f9 57 c2          	vxorpd %xmm2,%xmm0,%xmm0
    3eed:	c5 fb 5c c1          	vsubsd %xmm1,%xmm0,%xmm0
    3ef1:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
    3ef5:	48 b8 00 00 00 00 00 	movabs $0x8000000000000000,%rax
    3efc:	00 00 80 
    3eff:	c4 e1 f9 6e c8       	vmovq  %rax,%xmm1
    3f04:	c5 f9 57 c1          	vxorpd %xmm1,%xmm0,%xmm0
    3f08:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3f0f:	00 
    3f10:	e9 10 00 00 00       	jmp    0x3f25
    3f15:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
    3f19:	c5 fb 5c c1          	vsubsd %xmm1,%xmm0,%xmm0
    3f1d:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3f24:	00 
    3f25:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3f2c:	00 
    3f2d:	43 8b 84 2b 6c 01 00 	mov    0x16c(%r11,%r13,1),%eax
    3f34:	00 
    3f35:	48 89 c6             	mov    %rax,%rsi
    3f38:	c1 fe 1f             	sar    $0x1f,%esi
    3f3b:	8d 14 30             	lea    (%rax,%rsi,1),%edx
    3f3e:	33 d6                	xor    %esi,%edx
    3f40:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
    3f47:	00 
    3f48:	8d 9e e0 fd ff ff    	lea    -0x220(%rsi),%ebx
    3f4e:	85 d2                	test   %edx,%edx
    3f50:	0f 85 08 00 00 00    	jne    0x3f5e
    3f56:	48 89 da             	mov    %rbx,%rdx
    3f59:	e9 86 00 00 00       	jmp    0x3fe4
    3f5e:	33 f6                	xor    %esi,%esi
    3f60:	c4 e2 43 f6 3d ef 15 	mulx   0x15ef(%rip),%edi,%edi        # 0x5558
    3f67:	00 00 
    3f69:	c1 ef 03             	shr    $0x3,%edi
    3f6c:	44 6b cf 0a          	imul   $0xa,%edi,%r9d
    3f70:	49 89 d0             	mov    %rdx,%r8
    3f73:	45 2b c1             	sub    %r9d,%r8d
    3f76:	41 83 c8 30          	or     $0x30,%r8d
    3f7a:	4c 8b 8c 24 28 01 00 	mov    0x128(%rsp),%r9
    3f81:	00 
    3f82:	41 81 c1 d4 fd ff ff 	add    $0xfffffdd4,%r9d
    3f89:	45 8d 4c 31 0b       	lea    0xb(%r9,%rsi,1),%r9d
    3f8e:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3f95:	00 
    3f96:	47 88 04 0b          	mov    %r8b,(%r11,%r9,1)
    3f9a:	44 8d 46 ff          	lea    -0x1(%rsi),%r8d
    3f9e:	83 fa 09             	cmp    $0x9,%edx
    3fa1:	0f 86 0b 00 00 00    	jbe    0x3fb2
    3fa7:	48 89 fa             	mov    %rdi,%rdx
    3faa:	4c 89 c6             	mov    %r8,%rsi
    3fad:	e9 ae ff ff ff       	jmp    0x3f60
    3fb2:	48 8b bc 24 28 01 00 	mov    0x128(%rsp),%rdi
    3fb9:	00 
    3fba:	8d 94 37 df fd ff ff 	lea    -0x221(%rdi,%rsi,1),%edx
    3fc1:	45 85 c0             	test   %r8d,%r8d
    3fc4:	0f 84 0a 00 00 00    	je     0x3fd4
    3fca:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
    3fcf:	e9 2c 00 00 00       	jmp    0x4000
    3fd4:	4c 8b 8c 24 28 01 00 	mov    0x128(%rsp),%r9
    3fdb:	00 
    3fdc:	41 8d 94 31 df fd ff 	lea    -0x221(%r9,%rsi,1),%edx
    3fe3:	ff 
    3fe4:	be 30 00 00 00       	mov    $0x30,%esi
    3fe9:	81 c2 ff ff ff ff    	add    $0xffffffff,%edx
    3fef:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    3ff6:	00 
    3ff7:	41 88 34 13          	mov    %sil,(%r11,%rdx,1)
    3ffb:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
    4000:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
    4005:	81 c6 0f 00 00 00    	add    $0xf,%esi
    400b:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
    4011:	8d 7a fe             	lea    -0x2(%rdx),%edi
    4014:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    401b:	00 
    401c:	41 88 34 3b          	mov    %sil,(%r11,%rdi,1)
    4020:	be 2b 00 00 00       	mov    $0x2b,%esi
    4025:	85 c0                	test   %eax,%eax
    4027:	0f 4c 35 da 15 00 00 	cmovl  0x15da(%rip),%esi        # 0x5608
    402e:	8d 7a ff             	lea    -0x1(%rdx),%edi
    4031:	41 88 34 3b          	mov    %sil,(%r11,%rdi,1)
    4035:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
    403a:	83 e6 20             	and    $0x20,%esi
    403d:	49 89 dc             	mov    %rbx,%r12
    4040:	48 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdi
    4047:	ff ff 7f 
    404a:	c4 e1 f9 6e e7       	vmovq  %rdi,%xmm4
    404f:	c5 f9 54 f4          	vandpd %xmm4,%xmm0,%xmm6
    4053:	48 bf 00 00 00 00 00 	movabs $0x41e0000000000000,%rdi
    405a:	00 e0 41 
    405d:	c4 e1 f9 6e ef       	vmovq  %rdi,%xmm5
    4062:	c5 f9 2e ee          	vucomisd %xmm6,%xmm5
    4066:	40 0f 97 c7          	seta   %dil
    406a:	40 0f b6 ff          	movzbl %dil,%edi
    406e:	85 ff                	test   %edi,%edi
    4070:	0f 84 43 00 00 00    	je     0x40b9
    4076:	f2 0f 2c f8          	cvttsd2si %xmm0,%edi
    407a:	83 ff 01             	cmp    $0x1,%edi
    407d:	0f 81 3b 00 00 00    	jno    0x40be
    4083:	66 0f 2e c0          	ucomisd %xmm0,%xmm0
    4087:	0f 8a 80 14 00 00    	jp     0x550d
    408d:	49 b8 00 00 20 00 00 	movabs $0xc1e0000000200000,%r8
    4094:	00 e0 c1 
    4097:	66 49 0f 6e f0       	movq   %r8,%xmm6
    409c:	66 0f 2e c6          	ucomisd %xmm6,%xmm0
    40a0:	0f 86 69 14 00 00    	jbe    0x550f
    40a6:	66 0f 57 f6          	xorpd  %xmm6,%xmm6
    40aa:	66 0f 2e f0          	ucomisd %xmm0,%xmm6
    40ae:	0f 82 5d 14 00 00    	jb     0x5511
    40b4:	e9 05 00 00 00       	jmp    0x40be
    40b9:	bf 00 00 00 80       	mov    $0x80000000,%edi
    40be:	44 8d 87 b0 0d 00 00 	lea    0xdb0(%rdi),%r8d
    40c5:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    40cc:	00 
    40cd:	4f 0f b6 0c 03       	movzbq (%r11,%r8,1),%r9
    40d2:	44 0b ce             	or     %esi,%r9d
    40d5:	45 8b c4             	mov    %r12d,%r8d
    40d8:	47 88 0c 03          	mov    %r9b,(%r11,%r8,1)
    40dc:	45 8d 4c 24 01       	lea    0x1(%r12),%r9d
    40e1:	4d 89 ca             	mov    %r9,%r10
    40e4:	44 2b d3             	sub    %ebx,%r10d
    40e7:	41 83 fa 01          	cmp    $0x1,%r10d
    40eb:	0f 84 08 00 00 00    	je     0x40f9
    40f1:	4d 89 cc             	mov    %r9,%r12
    40f4:	e9 74 00 00 00       	jmp    0x416d
    40f9:	f7 c1 08 00 00 00    	test   $0x8,%ecx
    40ff:	0f 85 4e 00 00 00    	jne    0x4153
    4105:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    410c:	00 
    410d:	4c 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%r9
    4114:	00 
    4115:	44 85 c8             	test   %r9d,%eax
    4118:	0f 8f 35 00 00 00    	jg     0x4153
    411e:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
    4122:	c5 f3 2a cf          	vcvtsi2sd %edi,%xmm1,%xmm1
    4126:	c5 fb 5c c9          	vsubsd %xmm1,%xmm0,%xmm1
    412a:	c5 f3 59 0d ee 14 00 	vmulsd 0x14ee(%rip),%xmm1,%xmm1        # 0x5620
    4131:	00 
    4132:	45 8d 4c 24 01       	lea    0x1(%r12),%r9d
    4137:	c5 f9 2e 0d f1 14 00 	vucomisd 0x14f1(%rip),%xmm1        # 0x5630
    413e:	00 
    413f:	0f 8a 0e 00 00 00    	jp     0x4153
    4145:	0f 85 08 00 00 00    	jne    0x4153
    414b:	4d 89 cc             	mov    %r9,%r12
    414e:	e9 1a 00 00 00       	jmp    0x416d
    4153:	41 b9 2e 00 00 00    	mov    $0x2e,%r9d
    4159:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4160:	00 
    4161:	47 88 4c 03 01       	mov    %r9b,0x1(%r11,%r8,1)
    4166:	41 81 c4 02 00 00 00 	add    $0x2,%r12d
    416d:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
    4171:	c5 f3 2a cf          	vcvtsi2sd %edi,%xmm1,%xmm1
    4175:	c5 fb 5c c1          	vsubsd %xmm1,%xmm0,%xmm0
    4179:	c5 fb 59 05 bf 14 00 	vmulsd 0x14bf(%rip),%xmm0,%xmm0        # 0x5640
    4180:	00 
    4181:	c5 f9 2e 05 c7 14 00 	vucomisd 0x14c7(%rip),%xmm0        # 0x5650
    4188:	00 
    4189:	0f 8a b1 fe ff ff    	jp     0x4040
    418f:	0f 85 ab fe ff ff    	jne    0x4040
    4195:	be fd ff ff 7f       	mov    $0x7ffffffd,%esi
    419a:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    419f:	48 89 c7             	mov    %rax,%rdi
    41a2:	83 cf 02             	or     $0x2,%edi
    41a5:	48 89 7c 24 68       	mov    %rdi,0x68(%rsp)
    41aa:	8d 7a fe             	lea    -0x2(%rdx),%edi
    41ad:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
    41b4:	00 
    41b5:	49 89 d8             	mov    %rbx,%r8
    41b8:	44 2b c7             	sub    %edi,%r8d
    41bb:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    41c0:	42 8d 14 00          	lea    (%rax,%r8,1),%edx
    41c4:	4c 89 44 24 60       	mov    %r8,0x60(%rsp)
    41c9:	2b f2                	sub    %edx,%esi
    41cb:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
    41d1:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
    41d8:	00 
    41d9:	3b f7                	cmp    %edi,%esi
    41db:	0f 8d 0a 00 00 00    	jge    0x41eb
    41e1:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    41e6:	e9 83 07 00 00       	jmp    0x496e
    41eb:	48 89 ce             	mov    %rcx,%rsi
    41ee:	81 e6 00 20 01 00    	and    $0x12000,%esi
    41f4:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
    41f9:	f7 c1 00 20 01 00    	test   $0x12000,%ecx
    41ff:	0f 84 18 00 00 00    	je     0x421d
    4205:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    420c:	00 
    420d:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4214:	00 
    4215:	49 89 d7             	mov    %rdx,%r15
    4218:	e9 b1 01 00 00       	jmp    0x43ce
    421d:	4c 89 f1             	mov    %r14,%rcx
    4220:	2b cb                	sub    %ebx,%ecx
    4222:	42 8d 3c 21          	lea    (%rcx,%r12,1),%edi
    4226:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    422d:	00 
    422e:	8d 71 02             	lea    0x2(%rcx),%esi
    4231:	4c 89 e1             	mov    %r12,%rcx
    4234:	2b cb                	sub    %ebx,%ecx
    4236:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    423d:	00 
    423e:	3b f8                	cmp    %eax,%edi
    4240:	48 89 cf             	mov    %rcx,%rdi
    4243:	0f 4c fe             	cmovl  %esi,%edi
    4246:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
    424d:	00 
    424e:	85 f0                	test   %esi,%eax
    4250:	0f 45 cf             	cmovne %edi,%ecx
    4253:	03 ca                	add    %edx,%ecx
    4255:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    425c:	00 
    425d:	49 89 d7             	mov    %rdx,%r15
    4260:	3b c1                	cmp    %ecx,%eax
    4262:	0f 8f 15 00 00 00    	jg     0x427d
    4268:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    426f:	00 
    4270:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4277:	00 
    4278:	e9 51 01 00 00       	jmp    0x43ce
    427d:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    4284:	00 
    4285:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    428b:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
    4292:	00 
    4293:	ba 20 00 00 00       	mov    $0x20,%edx
    4298:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    429f:	00 
    42a0:	48 89 c6             	mov    %rax,%rsi
    42a3:	2b f1                	sub    %ecx,%esi
    42a5:	41 bd 00 01 00 00    	mov    $0x100,%r13d
    42ab:	44 3b ee             	cmp    %esi,%r13d
    42ae:	49 89 f0             	mov    %rsi,%r8
    42b1:	45 0f 42 c5          	cmovb  %r13d,%r8d
    42b5:	48 89 d1             	mov    %rdx,%rcx
    42b8:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
    42bd:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
    42c4:	00 
    42c5:	48 8b 34 24          	mov    (%rsp),%rsi
    42c9:	48 8b 3c 24          	mov    (%rsp),%rdi
    42cd:	e8 0e 21 00 00       	call   0x63e0
    42d2:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    42d9:	00 
    42da:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    42e1:	00 
    42e2:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    42e6:	f7 c6 20 00 00 00    	test   $0x20,%esi
    42ec:	0f 94 c0             	sete   %al
    42ef:	0f b6 d0             	movzbl %al,%edx
    42f2:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    42f7:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    42fd:	0f 83 0a 00 00 00    	jae    0x430d
    4303:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    4308:	e9 7a 00 00 00       	jmp    0x4387
    430d:	f7 c2 01 00 00 00    	test   $0x1,%edx
    4313:	0f 85 0a 00 00 00    	jne    0x4323
    4319:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    431e:	e9 36 00 00 00       	jmp    0x4359
    4323:	4c 89 e9             	mov    %r13,%rcx
    4326:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
    432d:	00 
    432e:	48 8b 34 24          	mov    (%rsp),%rsi
    4332:	48 8b 3c 24          	mov    (%rsp),%rdi
    4336:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    433b:	e8 40 a7 ff ff       	call   0xffffffffffffea80
    4340:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4347:	00 
    4348:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    434f:	00 
    4350:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    4354:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    4359:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    435f:	f7 c6 20 00 00 00    	test   $0x20,%esi
    4365:	0f 94 c0             	sete   %al
    4368:	0f b6 d0             	movzbl %al,%edx
    436b:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    4371:	0f 86 0a 00 00 00    	jbe    0x4381
    4377:	48 89 7c 24 50       	mov    %rdi,0x50(%rsp)
    437c:	e9 8c ff ff ff       	jmp    0x430d
    4381:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    4387:	85 d2                	test   %edx,%edx
    4389:	0f 85 15 00 00 00    	jne    0x43a4
    438f:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4396:	00 
    4397:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    439e:	00 
    439f:	e9 2a 00 00 00       	jmp    0x43ce
    43a4:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
    43ab:	00 
    43ac:	48 8b 34 24          	mov    (%rsp),%rsi
    43b0:	48 8b 3c 24          	mov    (%rsp),%rdi
    43b4:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    43b9:	e8 c2 a6 ff ff       	call   0xffffffffffffea80
    43be:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    43c5:	00 
    43c6:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    43cd:	00 
    43ce:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    43d5:	00 
    43d6:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    43dd:	00 
    43de:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    43e3:	a9 20 00 00 00       	test   $0x20,%eax
    43e8:	0f 84 0a 00 00 00    	je     0x43f8
    43ee:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    43f3:	e9 37 00 00 00       	jmp    0x442f
    43f8:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
    43fd:	8d 4a 09             	lea    0x9(%rdx),%ecx
    4400:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
    4405:	f7 c6 20 00 00 00    	test   $0x20,%esi
    440b:	0f 45 d1             	cmovne %ecx,%edx
    440e:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
    4413:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
    4418:	48 8b 34 24          	mov    (%rsp),%rsi
    441c:	48 8b 3c 24          	mov    (%rsp),%rdi
    4420:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4425:	e8 56 a6 ff ff       	call   0xffffffffffffea80
    442a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    442f:	81 fa 00 00 01 00    	cmp    $0x10000,%edx
    4435:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
    443a:	0f 84 18 00 00 00    	je     0x4458
    4440:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4447:	00 
    4448:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    444f:	00 
    4450:	4d 89 fd             	mov    %r15,%r13
    4453:	e9 b3 01 00 00       	jmp    0x460b
    4458:	4c 89 f6             	mov    %r14,%rsi
    445b:	2b f3                	sub    %ebx,%esi
    445d:	42 8d 3c 26          	lea    (%rsi,%r12,1),%edi
    4461:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    4468:	00 
    4469:	8d 71 02             	lea    0x2(%rcx),%esi
    446c:	4c 89 e1             	mov    %r12,%rcx
    446f:	2b cb                	sub    %ebx,%ecx
    4471:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    4478:	00 
    4479:	3b f8                	cmp    %eax,%edi
    447b:	48 89 cf             	mov    %rcx,%rdi
    447e:	0f 4c fe             	cmovl  %esi,%edi
    4481:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
    4488:	00 
    4489:	85 d0                	test   %edx,%eax
    448b:	0f 45 cf             	cmovne %edi,%ecx
    448e:	4d 89 fd             	mov    %r15,%r13
    4491:	41 8d 74 0d 00       	lea    0x0(%r13,%rcx,1),%esi
    4496:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    449d:	00 
    449e:	3b ce                	cmp    %esi,%ecx
    44a0:	0f 8f 15 00 00 00    	jg     0x44bb
    44a6:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    44ad:	00 
    44ae:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    44b5:	00 
    44b6:	e9 50 01 00 00       	jmp    0x460b
    44bb:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    44c2:	00 
    44c3:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    44c9:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
    44d0:	00 
    44d1:	b9 30 00 00 00       	mov    $0x30,%ecx
    44d6:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    44dd:	00 
    44de:	48 89 c2             	mov    %rax,%rdx
    44e1:	2b d6                	sub    %esi,%edx
    44e3:	41 bf 00 01 00 00    	mov    $0x100,%r15d
    44e9:	44 3b fa             	cmp    %edx,%r15d
    44ec:	49 89 d0             	mov    %rdx,%r8
    44ef:	45 0f 42 c7          	cmovb  %r15d,%r8d
    44f3:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
    44f8:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
    44ff:	00 
    4500:	48 8b 34 24          	mov    (%rsp),%rsi
    4504:	48 8b 3c 24          	mov    (%rsp),%rdi
    4508:	e8 d3 1e 00 00       	call   0x63e0
    450d:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4514:	00 
    4515:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    451c:	00 
    451d:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    4521:	f7 c6 20 00 00 00    	test   $0x20,%esi
    4527:	41 0f 94 c2          	sete   %r10b
    452b:	41 0f b6 d2          	movzbl %r10b,%edx
    452f:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    4534:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    453a:	0f 83 0a 00 00 00    	jae    0x454a
    4540:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    4545:	e9 7a 00 00 00       	jmp    0x45c4
    454a:	f7 c2 01 00 00 00    	test   $0x1,%edx
    4550:	0f 85 0a 00 00 00    	jne    0x4560
    4556:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    455b:	e9 36 00 00 00       	jmp    0x4596
    4560:	4c 89 f9             	mov    %r15,%rcx
    4563:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
    456a:	00 
    456b:	48 8b 34 24          	mov    (%rsp),%rsi
    456f:	48 8b 3c 24          	mov    (%rsp),%rdi
    4573:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4578:	e8 03 a5 ff ff       	call   0xffffffffffffea80
    457d:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4584:	00 
    4585:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    458c:	00 
    458d:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    4591:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    4596:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    459c:	f7 c6 20 00 00 00    	test   $0x20,%esi
    45a2:	0f 94 c0             	sete   %al
    45a5:	0f b6 d0             	movzbl %al,%edx
    45a8:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    45ae:	0f 86 0a 00 00 00    	jbe    0x45be
    45b4:	48 89 7c 24 50       	mov    %rdi,0x50(%rsp)
    45b9:	e9 8c ff ff ff       	jmp    0x454a
    45be:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    45c4:	85 d2                	test   %edx,%edx
    45c6:	0f 85 15 00 00 00    	jne    0x45e1
    45cc:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    45d3:	00 
    45d4:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    45db:	00 
    45dc:	e9 2a 00 00 00       	jmp    0x460b
    45e1:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
    45e8:	00 
    45e9:	48 8b 34 24          	mov    (%rsp),%rsi
    45ed:	48 8b 3c 24          	mov    (%rsp),%rdi
    45f1:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    45f6:	e8 85 a4 ff ff       	call   0xffffffffffffea80
    45fb:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4602:	00 
    4603:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    460a:	00 
    460b:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4612:	00 
    4613:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    461a:	00 
    461b:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    4620:	a9 20 00 00 00       	test   $0x20,%eax
    4625:	0f 85 1a 00 00 00    	jne    0x4645
    462b:	4c 89 e1             	mov    %r12,%rcx
    462e:	2b cb                	sub    %ebx,%ecx
    4630:	48 89 da             	mov    %rbx,%rdx
    4633:	48 8b 34 24          	mov    (%rsp),%rsi
    4637:	48 8b 3c 24          	mov    (%rsp),%rdi
    463b:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4640:	e8 3b a4 ff ff       	call   0xffffffffffffea80
    4645:	44 2b f3             	sub    %ebx,%r14d
    4648:	43 8d 14 26          	lea    (%r14,%r12,1),%edx
    464c:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    4653:	00 
    4654:	81 c1 02 00 00 00    	add    $0x2,%ecx
    465a:	44 2b e3             	sub    %ebx,%r12d
    465d:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    4664:	00 
    4665:	3b d0                	cmp    %eax,%edx
    4667:	4c 89 e2             	mov    %r12,%rdx
    466a:	0f 4c d1             	cmovl  %ecx,%edx
    466d:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    4674:	00 
    4675:	85 c1                	test   %eax,%ecx
    4677:	4c 89 e3             	mov    %r12,%rbx
    467a:	0f 45 da             	cmovne %edx,%ebx
    467d:	48 89 d9             	mov    %rbx,%rcx
    4680:	41 2b cc             	sub    %r12d,%ecx
    4683:	85 c9                	test   %ecx,%ecx
    4685:	0f 8f 15 00 00 00    	jg     0x46a0
    468b:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4692:	00 
    4693:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    469a:	00 
    469b:	e9 24 01 00 00       	jmp    0x47c4
    46a0:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    46a7:	00 
    46a8:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    46ae:	49 89 d7             	mov    %rdx,%r15
    46b1:	ba 30 00 00 00       	mov    $0x30,%edx
    46b6:	41 bc 00 01 00 00    	mov    $0x100,%r12d
    46bc:	44 3b e1             	cmp    %ecx,%r12d
    46bf:	49 89 c8             	mov    %rcx,%r8
    46c2:	45 0f 42 c4          	cmovb  %r12d,%r8d
    46c6:	49 89 ce             	mov    %rcx,%r14
    46c9:	48 89 d1             	mov    %rdx,%rcx
    46cc:	4c 89 fa             	mov    %r15,%rdx
    46cf:	48 8b 34 24          	mov    (%rsp),%rsi
    46d3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46d7:	e8 04 1d 00 00       	call   0x63e0
    46dc:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    46e3:	00 
    46e4:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    46eb:	00 
    46ec:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    46f0:	f7 c6 20 00 00 00    	test   $0x20,%esi
    46f6:	0f 94 c0             	sete   %al
    46f9:	0f b6 d0             	movzbl %al,%edx
    46fc:	4c 89 f1             	mov    %r14,%rcx
    46ff:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    4705:	0f 83 08 00 00 00    	jae    0x4713
    470b:	4c 89 f1             	mov    %r14,%rcx
    470e:	e9 6f 00 00 00       	jmp    0x4782
    4713:	f7 c2 01 00 00 00    	test   $0x1,%edx
    4719:	0f 85 08 00 00 00    	jne    0x4727
    471f:	4c 89 f1             	mov    %r14,%rcx
    4722:	e9 2f 00 00 00       	jmp    0x4756
    4727:	4c 89 e1             	mov    %r12,%rcx
    472a:	4c 89 fa             	mov    %r15,%rdx
    472d:	48 8b 34 24          	mov    (%rsp),%rsi
    4731:	48 8b 3c 24          	mov    (%rsp),%rdi
    4735:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    473a:	e8 41 a3 ff ff       	call   0xffffffffffffea80
    473f:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4746:	00 
    4747:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    474e:	00 
    474f:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    4753:	4c 89 f1             	mov    %r14,%rcx
    4756:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    475c:	f7 c6 20 00 00 00    	test   $0x20,%esi
    4762:	0f 94 c0             	sete   %al
    4765:	0f b6 d0             	movzbl %al,%edx
    4768:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    476e:	0f 86 08 00 00 00    	jbe    0x477c
    4774:	49 89 fe             	mov    %rdi,%r14
    4777:	e9 97 ff ff ff       	jmp    0x4713
    477c:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    4782:	85 d2                	test   %edx,%edx
    4784:	0f 85 15 00 00 00    	jne    0x479f
    478a:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4791:	00 
    4792:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4799:	00 
    479a:	e9 25 00 00 00       	jmp    0x47c4
    479f:	4c 89 fa             	mov    %r15,%rdx
    47a2:	48 8b 34 24          	mov    (%rsp),%rsi
    47a6:	48 8b 3c 24          	mov    (%rsp),%rdi
    47aa:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    47af:	e8 cc a2 ff ff       	call   0xffffffffffffea80
    47b4:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    47bb:	00 
    47bc:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    47c3:	00 
    47c4:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    47cb:	00 
    47cc:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    47d3:	00 
    47d4:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    47d9:	a9 20 00 00 00       	test   $0x20,%eax
    47de:	0f 84 0a 00 00 00    	je     0x47ee
    47e4:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    47e9:	e9 2a 00 00 00       	jmp    0x4818
    47ee:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
    47f5:	00 
    47f6:	81 c2 fe ff ff ff    	add    $0xfffffffe,%edx
    47fc:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
    4801:	48 8b 34 24          	mov    (%rsp),%rsi
    4805:	48 8b 3c 24          	mov    (%rsp),%rdi
    4809:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    480e:	e8 6d a2 ff ff       	call   0xffffffffffffea80
    4813:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    4818:	81 fa 00 20 00 00    	cmp    $0x2000,%edx
    481e:	0f 85 23 01 00 00    	jne    0x4947
    4824:	41 8d 4c 1d 00       	lea    0x0(%r13,%rbx,1),%ecx
    4829:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    4830:	00 
    4831:	3b c1                	cmp    %ecx,%eax
    4833:	0f 8e 0e 01 00 00    	jle    0x4947
    4839:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    4840:	00 
    4841:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    4847:	49 89 d6             	mov    %rdx,%r14
    484a:	be 20 00 00 00       	mov    $0x20,%esi
    484f:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    4856:	00 
    4857:	48 89 c2             	mov    %rax,%rdx
    485a:	2b d1                	sub    %ecx,%edx
    485c:	41 bc 00 01 00 00    	mov    $0x100,%r12d
    4862:	44 3b e2             	cmp    %edx,%r12d
    4865:	49 89 d0             	mov    %rdx,%r8
    4868:	45 0f 42 c4          	cmovb  %r12d,%r8d
    486c:	48 89 f1             	mov    %rsi,%rcx
    486f:	49 89 d7             	mov    %rdx,%r15
    4872:	4c 89 f2             	mov    %r14,%rdx
    4875:	48 8b 34 24          	mov    (%rsp),%rsi
    4879:	48 8b 3c 24          	mov    (%rsp),%rdi
    487d:	e8 5e 1b 00 00       	call   0x63e0
    4882:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4889:	00 
    488a:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4891:	00 
    4892:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    4896:	f7 c6 20 00 00 00    	test   $0x20,%esi
    489c:	40 0f 94 c7          	sete   %dil
    48a0:	40 0f b6 d7          	movzbl %dil,%edx
    48a4:	4c 89 f9             	mov    %r15,%rcx
    48a7:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    48ad:	0f 83 08 00 00 00    	jae    0x48bb
    48b3:	4c 89 f9             	mov    %r15,%rcx
    48b6:	e9 6f 00 00 00       	jmp    0x492a
    48bb:	f7 c2 01 00 00 00    	test   $0x1,%edx
    48c1:	0f 85 08 00 00 00    	jne    0x48cf
    48c7:	4c 89 f9             	mov    %r15,%rcx
    48ca:	e9 2f 00 00 00       	jmp    0x48fe
    48cf:	4c 89 e1             	mov    %r12,%rcx
    48d2:	4c 89 f2             	mov    %r14,%rdx
    48d5:	48 8b 34 24          	mov    (%rsp),%rsi
    48d9:	48 8b 3c 24          	mov    (%rsp),%rdi
    48dd:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    48e2:	e8 99 a1 ff ff       	call   0xffffffffffffea80
    48e7:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    48ee:	00 
    48ef:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    48f6:	00 
    48f7:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    48fb:	4c 89 f9             	mov    %r15,%rcx
    48fe:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    4904:	f7 c6 20 00 00 00    	test   $0x20,%esi
    490a:	0f 94 c0             	sete   %al
    490d:	0f b6 d0             	movzbl %al,%edx
    4910:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    4916:	0f 86 08 00 00 00    	jbe    0x4924
    491c:	49 89 ff             	mov    %rdi,%r15
    491f:	e9 97 ff ff ff       	jmp    0x48bb
    4924:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    492a:	85 d2                	test   %edx,%edx
    492c:	0f 84 15 00 00 00    	je     0x4947
    4932:	4c 89 f2             	mov    %r14,%rdx
    4935:	48 8b 34 24          	mov    (%rsp),%rsi
    4939:	48 8b 3c 24          	mov    (%rsp),%rdi
    493d:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4942:	e8 39 a1 ff ff       	call   0xffffffffffffea80
    4947:	41 8d 44 1d 00       	lea    0x0(%r13,%rbx,1),%eax
    494c:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    4953:	00 
    4954:	3b c1                	cmp    %ecx,%eax
    4956:	0f 4d c8             	cmovge %eax,%ecx
    4959:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    4960:	00 
    4961:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    4966:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
    496d:	00 
    496e:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    4973:	8d 72 01             	lea    0x1(%rdx),%esi
    4976:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    497d:	00 
    497e:	45 85 ed             	test   %r13d,%r13d
    4981:	0f 8c 12 00 00 00    	jl     0x4999
    4987:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    498c:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    4993:	00 
    4994:	e9 2a b7 ff ff       	jmp    0xc3
    4999:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    49a0:	00 
    49a1:	e9 fd 0a 00 00       	jmp    0x54a3
    49a6:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    49ad:	00 
    49ae:	44 8d 80 c8 fc ff ff 	lea    -0x338(%rax),%r8d
    49b5:	33 ff                	xor    %edi,%edi
    49b7:	be 3a 0b 00 00       	mov    $0xb3a,%esi
    49bc:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
    49c3:	00 
    49c4:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
    49cb:	00 
    49cc:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
    49d3:	00 
    49d4:	44 2b c6             	sub    %esi,%r8d
    49d7:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    49de:	00 
    49df:	44 3b c1             	cmp    %ecx,%r8d
    49e2:	41 0f 4d c8          	cmovge %r8d,%ecx
    49e6:	4d 89 c7             	mov    %r8,%r15
    49e9:	b8 ff ff ff 7f       	mov    $0x7fffffff,%eax
    49ee:	2b c7                	sub    %edi,%eax
    49f0:	3b c8                	cmp    %eax,%ecx
    49f2:	0f 8e 0d 00 00 00    	jle    0x4a05
    49f8:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    49ff:	00 
    4a00:	e9 9e 0a 00 00       	jmp    0x54a3
    4a05:	44 8d 24 0f          	lea    (%rdi,%rcx,1),%r12d
    4a09:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    4a0e:	49 89 fe             	mov    %rdi,%r14
    4a11:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    4a18:	00 
    4a19:	44 3b e1             	cmp    %ecx,%r12d
    4a1c:	49 89 cd             	mov    %rcx,%r13
    4a1f:	45 0f 4d ec          	cmovge %r12d,%r13d
    4a23:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
    4a2a:	00 
    4a2b:	44 3b e9             	cmp    %ecx,%r13d
    4a2e:	0f 8e 0d 00 00 00    	jle    0x4a41
    4a34:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4a3b:	00 
    4a3c:	e9 62 0a 00 00       	jmp    0x54a3
    4a41:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    4a48:	00 
    4a49:	f7 c1 00 20 01 00    	test   $0x12000,%ecx
    4a4f:	0f 84 15 00 00 00    	je     0x4a6a
    4a55:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4a5c:	00 
    4a5d:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4a64:	00 
    4a65:	e9 6b 01 00 00       	jmp    0x4bd5
    4a6a:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    4a71:	00 
    4a72:	44 3b e1             	cmp    %ecx,%r12d
    4a75:	0f 8c 15 00 00 00    	jl     0x4a90
    4a7b:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4a82:	00 
    4a83:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4a8a:	00 
    4a8b:	e9 45 01 00 00       	jmp    0x4bd5
    4a90:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    4a97:	00 
    4a98:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    4a9e:	48 89 94 24 c8 00 00 	mov    %rdx,0xc8(%rsp)
    4aa5:	00 
    4aa6:	b9 20 00 00 00       	mov    $0x20,%ecx
    4aab:	4c 89 ea             	mov    %r13,%rdx
    4aae:	41 2b d4             	sub    %r12d,%edx
    4ab1:	bb 00 01 00 00       	mov    $0x100,%ebx
    4ab6:	3b da                	cmp    %edx,%ebx
    4ab8:	49 89 d0             	mov    %rdx,%r8
    4abb:	44 0f 42 c3          	cmovb  %ebx,%r8d
    4abf:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
    4ac4:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
    4acb:	00 
    4acc:	48 8b 34 24          	mov    (%rsp),%rsi
    4ad0:	48 8b 3c 24          	mov    (%rsp),%rdi
    4ad4:	e8 07 19 00 00       	call   0x63e0
    4ad9:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4ae0:	00 
    4ae1:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4ae8:	00 
    4ae9:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    4aed:	f7 c6 20 00 00 00    	test   $0x20,%esi
    4af3:	0f 94 c0             	sete   %al
    4af6:	0f b6 d0             	movzbl %al,%edx
    4af9:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
    4afe:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    4b04:	0f 83 0a 00 00 00    	jae    0x4b14
    4b0a:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
    4b0f:	e9 7a 00 00 00       	jmp    0x4b8e
    4b14:	f7 c2 01 00 00 00    	test   $0x1,%edx
    4b1a:	0f 85 0a 00 00 00    	jne    0x4b2a
    4b20:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
    4b25:	e9 36 00 00 00       	jmp    0x4b60
    4b2a:	48 89 d9             	mov    %rbx,%rcx
    4b2d:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
    4b34:	00 
    4b35:	48 8b 34 24          	mov    (%rsp),%rsi
    4b39:	48 8b 3c 24          	mov    (%rsp),%rdi
    4b3d:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4b42:	e8 39 9f ff ff       	call   0xffffffffffffea80
    4b47:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4b4e:	00 
    4b4f:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4b56:	00 
    4b57:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    4b5b:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
    4b60:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    4b66:	f7 c6 20 00 00 00    	test   $0x20,%esi
    4b6c:	0f 94 c0             	sete   %al
    4b6f:	0f b6 d0             	movzbl %al,%edx
    4b72:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    4b78:	0f 86 0a 00 00 00    	jbe    0x4b88
    4b7e:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
    4b83:	e9 8c ff ff ff       	jmp    0x4b14
    4b88:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    4b8e:	85 d2                	test   %edx,%edx
    4b90:	0f 85 15 00 00 00    	jne    0x4bab
    4b96:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4b9d:	00 
    4b9e:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4ba5:	00 
    4ba6:	e9 2a 00 00 00       	jmp    0x4bd5
    4bab:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
    4bb2:	00 
    4bb3:	48 8b 34 24          	mov    (%rsp),%rsi
    4bb7:	48 8b 3c 24          	mov    (%rsp),%rdi
    4bbb:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4bc0:	e8 bb 9e ff ff       	call   0xffffffffffffea80
    4bc5:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4bcc:	00 
    4bcd:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4bd4:	00 
    4bd5:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4bdc:	00 
    4bdd:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4be4:	00 
    4be5:	49 0f b6 34 03       	movzbq (%r11,%rax,1),%rsi
    4bea:	f7 c6 20 00 00 00    	test   $0x20,%esi
    4bf0:	0f 84 0d 00 00 00    	je     0x4c03
    4bf6:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    4bfd:	00 
    4bfe:	e9 25 00 00 00       	jmp    0x4c28
    4c03:	4c 89 f1             	mov    %r14,%rcx
    4c06:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
    4c0d:	00 
    4c0e:	48 8b 34 24          	mov    (%rsp),%rsi
    4c12:	48 8b 3c 24          	mov    (%rsp),%rdi
    4c16:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4c1b:	e8 60 9e ff ff       	call   0xffffffffffffea80
    4c20:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    4c27:	00 
    4c28:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    4c2f:	00 
    4c30:	48 89 cf             	mov    %rcx,%rdi
    4c33:	81 e7 00 20 01 00    	and    $0x12000,%edi
    4c39:	81 ff 00 00 01 00    	cmp    $0x10000,%edi
    4c3f:	0f 84 10 00 00 00    	je     0x4c55
    4c45:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    4c4c:	00 
    4c4d:	4c 89 fa             	mov    %r15,%rdx
    4c50:	e9 5c 01 00 00       	jmp    0x4db1
    4c55:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    4c5c:	00 
    4c5d:	44 3b e1             	cmp    %ecx,%r12d
    4c60:	0f 8c 10 00 00 00    	jl     0x4c76
    4c66:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    4c6d:	00 
    4c6e:	4c 89 fa             	mov    %r15,%rdx
    4c71:	e9 3b 01 00 00       	jmp    0x4db1
    4c76:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    4c7d:	00 
    4c7e:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    4c84:	48 89 d3             	mov    %rdx,%rbx
    4c87:	b9 30 00 00 00       	mov    $0x30,%ecx
    4c8c:	4c 89 ea             	mov    %r13,%rdx
    4c8f:	41 2b d4             	sub    %r12d,%edx
    4c92:	41 be 00 01 00 00    	mov    $0x100,%r14d
    4c98:	44 3b f2             	cmp    %edx,%r14d
    4c9b:	49 89 d0             	mov    %rdx,%r8
    4c9e:	45 0f 42 c6          	cmovb  %r14d,%r8d
    4ca2:	48 89 94 24 90 00 00 	mov    %rdx,0x90(%rsp)
    4ca9:	00 
    4caa:	48 89 da             	mov    %rbx,%rdx
    4cad:	48 8b 34 24          	mov    (%rsp),%rsi
    4cb1:	48 8b 3c 24          	mov    (%rsp),%rdi
    4cb5:	e8 26 17 00 00       	call   0x63e0
    4cba:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4cc1:	00 
    4cc2:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4cc9:	00 
    4cca:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    4cce:	f7 c6 20 00 00 00    	test   $0x20,%esi
    4cd4:	0f 94 c0             	sete   %al
    4cd7:	0f b6 d0             	movzbl %al,%edx
    4cda:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
    4ce1:	00 
    4ce2:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    4ce8:	0f 83 0d 00 00 00    	jae    0x4cfb
    4cee:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
    4cf5:	00 
    4cf6:	e9 7e 00 00 00       	jmp    0x4d79
    4cfb:	f7 c2 01 00 00 00    	test   $0x1,%edx
    4d01:	0f 85 0d 00 00 00    	jne    0x4d14
    4d07:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
    4d0e:	00 
    4d0f:	e9 34 00 00 00       	jmp    0x4d48
    4d14:	4c 89 f1             	mov    %r14,%rcx
    4d17:	48 89 da             	mov    %rbx,%rdx
    4d1a:	48 8b 34 24          	mov    (%rsp),%rsi
    4d1e:	48 8b 3c 24          	mov    (%rsp),%rdi
    4d22:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4d27:	e8 54 9d ff ff       	call   0xffffffffffffea80
    4d2c:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4d33:	00 
    4d34:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4d3b:	00 
    4d3c:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    4d40:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
    4d47:	00 
    4d48:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    4d4e:	f7 c6 20 00 00 00    	test   $0x20,%esi
    4d54:	0f 94 c0             	sete   %al
    4d57:	0f b6 d0             	movzbl %al,%edx
    4d5a:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    4d60:	0f 86 0d 00 00 00    	jbe    0x4d73
    4d66:	48 89 bc 24 90 00 00 	mov    %rdi,0x90(%rsp)
    4d6d:	00 
    4d6e:	e9 88 ff ff ff       	jmp    0x4cfb
    4d73:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    4d79:	85 d2                	test   %edx,%edx
    4d7b:	0f 85 10 00 00 00    	jne    0x4d91
    4d81:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    4d88:	00 
    4d89:	4c 89 fa             	mov    %r15,%rdx
    4d8c:	e9 20 00 00 00       	jmp    0x4db1
    4d91:	48 89 da             	mov    %rbx,%rdx
    4d94:	48 8b 34 24          	mov    (%rsp),%rsi
    4d98:	48 8b 3c 24          	mov    (%rsp),%rdi
    4d9c:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4da1:	e8 da 9c ff ff       	call   0xffffffffffffea80
    4da6:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
    4dad:	00 
    4dae:	4c 89 fa             	mov    %r15,%rdx
    4db1:	3b d1                	cmp    %ecx,%edx
    4db3:	0f 8c 20 00 00 00    	jl     0x4dd9
    4db9:	49 89 d7             	mov    %rdx,%r15
    4dbc:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4dc3:	00 
    4dc4:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
    4dcb:	00 
    4dcc:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4dd3:	00 
    4dd4:	e9 4e 01 00 00       	jmp    0x4f27
    4dd9:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    4de0:	00 
    4de1:	81 c0 d0 fc ff ff    	add    $0xfffffcd0,%eax
    4de7:	49 89 c6             	mov    %rax,%r14
    4dea:	b9 30 00 00 00       	mov    $0x30,%ecx
    4def:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
    4df4:	2b f2                	sub    %edx,%esi
    4df6:	49 89 d7             	mov    %rdx,%r15
    4df9:	bb 00 01 00 00       	mov    $0x100,%ebx
    4dfe:	3b de                	cmp    %esi,%ebx
    4e00:	49 89 f0             	mov    %rsi,%r8
    4e03:	44 0f 42 c3          	cmovb  %ebx,%r8d
    4e07:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
    4e0c:	4c 89 f2             	mov    %r14,%rdx
    4e0f:	48 8b 34 24          	mov    (%rsp),%rsi
    4e13:	48 8b 3c 24          	mov    (%rsp),%rdi
    4e17:	e8 c4 15 00 00       	call   0x63e0
    4e1c:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4e23:	00 
    4e24:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4e2b:	00 
    4e2c:	41 8b 0c 03          	mov    (%r11,%rax,1),%ecx
    4e30:	f7 c1 20 00 00 00    	test   $0x20,%ecx
    4e36:	0f 94 c0             	sete   %al
    4e39:	0f b6 d0             	movzbl %al,%edx
    4e3c:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    4e41:	3d 00 01 00 00       	cmp    $0x100,%eax
    4e46:	0f 82 84 00 00 00    	jb     0x4ed0
    4e4c:	f7 c2 01 00 00 00    	test   $0x1,%edx
    4e52:	0f 85 0a 00 00 00    	jne    0x4e62
    4e58:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    4e5d:	e9 31 00 00 00       	jmp    0x4e93
    4e62:	48 89 d9             	mov    %rbx,%rcx
    4e65:	4c 89 f2             	mov    %r14,%rdx
    4e68:	48 8b 34 24          	mov    (%rsp),%rsi
    4e6c:	48 8b 3c 24          	mov    (%rsp),%rdi
    4e70:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4e75:	e8 06 9c ff ff       	call   0xffffffffffffea80
    4e7a:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4e81:	00 
    4e82:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4e89:	00 
    4e8a:	41 8b 0c 03          	mov    (%r11,%rax,1),%ecx
    4e8e:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    4e93:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    4e98:	8d b0 00 ff ff ff    	lea    -0x100(%rax),%esi
    4e9e:	f7 c1 20 00 00 00    	test   $0x20,%ecx
    4ea4:	0f 94 c0             	sete   %al
    4ea7:	0f b6 d0             	movzbl %al,%edx
    4eaa:	81 fe ff 00 00 00    	cmp    $0xff,%esi
    4eb0:	0f 86 0a 00 00 00    	jbe    0x4ec0
    4eb6:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
    4ebb:	e9 8c ff ff ff       	jmp    0x4e4c
    4ec0:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    4ec5:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    4ecb:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    4ed0:	85 d2                	test   %edx,%edx
    4ed2:	0f 85 1d 00 00 00    	jne    0x4ef5
    4ed8:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4edf:	00 
    4ee0:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
    4ee7:	00 
    4ee8:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4eef:	00 
    4ef0:	e9 32 00 00 00       	jmp    0x4f27
    4ef5:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    4efa:	4c 89 f2             	mov    %r14,%rdx
    4efd:	48 8b 34 24          	mov    (%rsp),%rsi
    4f01:	48 8b 3c 24          	mov    (%rsp),%rdi
    4f05:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4f0a:	e8 71 9b ff ff       	call   0xffffffffffffea80
    4f0f:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4f16:	00 
    4f17:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
    4f1e:	00 
    4f1f:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4f26:	00 
    4f27:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    4f2e:	00 
    4f2f:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    4f36:	00 
    4f37:	49 0f b6 04 03       	movzbq (%r11,%rax,1),%rax
    4f3c:	a9 20 00 00 00       	test   $0x20,%eax
    4f41:	0f 84 0d 00 00 00    	je     0x4f54
    4f47:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    4f4e:	00 
    4f4f:	e9 1d 00 00 00       	jmp    0x4f71
    4f54:	4c 89 f9             	mov    %r15,%rcx
    4f57:	48 8b 34 24          	mov    (%rsp),%rsi
    4f5b:	48 8b 3c 24          	mov    (%rsp),%rdi
    4f5f:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    4f64:	e8 17 9b ff ff       	call   0xffffffffffffea80
    4f69:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    4f70:	00 
    4f71:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    4f78:	00 
    4f79:	81 e1 00 20 01 00    	and    $0x12000,%ecx
    4f7f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    4f84:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
    4f8b:	00 
    4f8c:	8d 72 01             	lea    0x1(%rdx),%esi
    4f8f:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    4f96:	00 
    4f97:	81 f9 00 20 00 00    	cmp    $0x2000,%ecx
    4f9d:	0f 84 12 00 00 00    	je     0x4fb5
    4fa3:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    4fa8:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    4faf:	00 
    4fb0:	e9 0e b1 ff ff       	jmp    0xc3
    4fb5:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    4fba:	8d 72 01             	lea    0x1(%rdx),%esi
    4fbd:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    4fc4:	00 
    4fc5:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    4fcc:	00 
    4fcd:	44 3b e1             	cmp    %ecx,%r12d
    4fd0:	0f 8c 12 00 00 00    	jl     0x4fe8
    4fd6:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    4fdb:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    4fe2:	00 
    4fe3:	e9 db b0 ff ff       	jmp    0xc3
    4fe8:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
    4fef:	00 
    4ff0:	8d 90 d0 fc ff ff    	lea    -0x330(%rax),%edx
    4ff6:	49 89 d6             	mov    %rdx,%r14
    4ff9:	b9 20 00 00 00       	mov    $0x20,%ecx
    4ffe:	4c 89 ea             	mov    %r13,%rdx
    5001:	41 2b d4             	sub    %r12d,%edx
    5004:	bb 00 01 00 00       	mov    $0x100,%ebx
    5009:	3b da                	cmp    %edx,%ebx
    500b:	49 89 d0             	mov    %rdx,%r8
    500e:	44 0f 42 c3          	cmovb  %ebx,%r8d
    5012:	49 89 d4             	mov    %rdx,%r12
    5015:	4c 89 f2             	mov    %r14,%rdx
    5018:	48 8b 34 24          	mov    (%rsp),%rsi
    501c:	48 8b 3c 24          	mov    (%rsp),%rdi
    5020:	e8 bb 13 00 00       	call   0x63e0
    5025:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    502c:	00 
    502d:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    5034:	00 
    5035:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    5039:	f7 c6 20 00 00 00    	test   $0x20,%esi
    503f:	40 0f 94 c7          	sete   %dil
    5043:	40 0f b6 d7          	movzbl %dil,%edx
    5047:	4c 89 e1             	mov    %r12,%rcx
    504a:	81 f9 00 01 00 00    	cmp    $0x100,%ecx
    5050:	0f 83 0d 00 00 00    	jae    0x5063
    5056:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    505b:	4c 89 e1             	mov    %r12,%rcx
    505e:	e9 74 00 00 00       	jmp    0x50d7
    5063:	f7 c2 01 00 00 00    	test   $0x1,%edx
    5069:	0f 85 08 00 00 00    	jne    0x5077
    506f:	4c 89 e1             	mov    %r12,%rcx
    5072:	e9 2f 00 00 00       	jmp    0x50a6
    5077:	48 89 d9             	mov    %rbx,%rcx
    507a:	4c 89 f2             	mov    %r14,%rdx
    507d:	48 8b 34 24          	mov    (%rsp),%rsi
    5081:	48 8b 3c 24          	mov    (%rsp),%rdi
    5085:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    508a:	e8 f1 99 ff ff       	call   0xffffffffffffea80
    508f:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
    5096:	00 
    5097:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    509e:	00 
    509f:	41 8b 34 03          	mov    (%r11,%rax,1),%esi
    50a3:	4c 89 e1             	mov    %r12,%rcx
    50a6:	8d b9 00 ff ff ff    	lea    -0x100(%rcx),%edi
    50ac:	f7 c6 20 00 00 00    	test   $0x20,%esi
    50b2:	0f 94 c0             	sete   %al
    50b5:	0f b6 d0             	movzbl %al,%edx
    50b8:	81 ff ff 00 00 00    	cmp    $0xff,%edi
    50be:	0f 86 08 00 00 00    	jbe    0x50cc
    50c4:	49 89 fc             	mov    %rdi,%r12
    50c7:	e9 97 ff ff ff       	jmp    0x5063
    50cc:	81 c1 00 ff ff ff    	add    $0xffffff00,%ecx
    50d2:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    50d7:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    50dc:	8d 70 01             	lea    0x1(%rax),%esi
    50df:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    50e6:	00 
    50e7:	85 d2                	test   %edx,%edx
    50e9:	0f 85 12 00 00 00    	jne    0x5101
    50ef:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    50f4:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    50fb:	00 
    50fc:	e9 c2 af ff ff       	jmp    0xc3
    5101:	4c 89 f2             	mov    %r14,%rdx
    5104:	48 8b 34 24          	mov    (%rsp),%rsi
    5108:	48 8b 3c 24          	mov    (%rsp),%rdi
    510c:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5111:	e8 6a 99 ff ff       	call   0xffffffffffffea80
    5116:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    511b:	8d 72 01             	lea    0x1(%rdx),%esi
    511e:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
    5125:	00 
    5126:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    512b:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    5132:	00 
    5133:	e9 8b af ff ff       	jmp    0xc3
    5138:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
    513f:	00 
    5140:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
    5145:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
    514a:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    514f:	4c 89 bc 24 b8 00 00 	mov    %r15,0xb8(%rsp)
    5156:	00 
    5157:	48 89 bc 24 08 01 00 	mov    %rdi,0x108(%rsp)
    515e:	00 
    515f:	8b c2                	mov    %edx,%eax
    5161:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
    5168:	00 
    5169:	48 0f be 44 02 01    	movsbq 0x1(%rdx,%rax,1),%rax
    516f:	44 8d 40 d0          	lea    -0x30(%rax),%r8d
    5173:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5178:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    517d:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    5184:	00 
    5185:	81 c2 01 00 00 00    	add    $0x1,%edx
    518b:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    5190:	41 83 f8 0a          	cmp    $0xa,%r8d
    5194:	0f 83 34 00 00 00    	jae    0x51ce
    519a:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    519f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    51a4:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
    51ab:	00 
    51ac:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
    51b1:	4c 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%r10
    51b8:	00 
    51b9:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    51c0:	00 
    51c1:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
    51c8:	00 
    51c9:	e9 3a b3 ff ff       	jmp    0x508
    51ce:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    51d5:	00 
    51d6:	e9 c8 02 00 00       	jmp    0x54a3
    51db:	48 89 c8             	mov    %rcx,%rax
    51de:	4c 89 bc 24 b8 00 00 	mov    %r15,0xb8(%rsp)
    51e5:	00 
    51e6:	4c 89 8c 24 20 01 00 	mov    %r9,0x120(%rsp)
    51ed:	00 
    51ee:	41 03 c5             	add    %r13d,%eax
    51f1:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    51f6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    51fb:	85 d1                	test   %edx,%ecx
    51fd:	0f 84 11 00 00 00    	je     0x5214
    5203:	48 8b 0c 24          	mov    (%rsp),%rcx
    5207:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
    520e:	00 
    520f:	e9 ab 02 00 00       	jmp    0x54bf
    5214:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
    521b:	00 
    521c:	85 c0                	test   %eax,%eax
    521e:	0f 85 13 00 00 00    	jne    0x5237
    5224:	33 c0                	xor    %eax,%eax
    5226:	48 8b 0c 24          	mov    (%rsp),%rcx
    522a:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
    5231:	00 
    5232:	e9 88 02 00 00       	jmp    0x54bf
    5237:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
    523c:	44 8b f3             	mov    %ebx,%r14d
    523f:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    5246:	00 
    5247:	43 8b 4c 33 04       	mov    0x4(%r11,%r14,1),%ecx
    524c:	85 c9                	test   %ecx,%ecx
    524e:	0f 85 0d 00 00 00    	jne    0x5261
    5254:	4c 8b ac 24 18 01 00 	mov    0x118(%rsp),%r13
    525b:	00 
    525c:	e9 ab 01 00 00       	jmp    0x540c
    5261:	41 bd 08 00 00 00    	mov    $0x8,%r13d
    5267:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
    526c:	41 8d 57 08          	lea    0x8(%r15),%edx
    5270:	48 8b 34 24          	mov    (%rsp),%rsi
    5274:	48 8b 3c 24          	mov    (%rsp),%rdi
    5278:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    527d:	e8 de 03 00 00       	call   0x5660
    5282:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    5289:	00 
    528a:	43 8b 4c 33 08       	mov    0x8(%r11,%r14,1),%ecx
    528f:	85 c9                	test   %ecx,%ecx
    5291:	0f 85 0b 00 00 00    	jne    0x52a2
    5297:	41 bd 02 00 00 00    	mov    $0x2,%r13d
    529d:	e9 6a 01 00 00       	jmp    0x540c
    52a2:	41 8d 57 10          	lea    0x10(%r15),%edx
    52a6:	48 8b 34 24          	mov    (%rsp),%rsi
    52aa:	48 8b 3c 24          	mov    (%rsp),%rdi
    52ae:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    52b3:	e8 a8 03 00 00       	call   0x5660
    52b8:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    52bf:	00 
    52c0:	43 8b 4c 33 0c       	mov    0xc(%r11,%r14,1),%ecx
    52c5:	85 c9                	test   %ecx,%ecx
    52c7:	0f 85 0b 00 00 00    	jne    0x52d8
    52cd:	41 bd 03 00 00 00    	mov    $0x3,%r13d
    52d3:	e9 34 01 00 00       	jmp    0x540c
    52d8:	41 8d 57 18          	lea    0x18(%r15),%edx
    52dc:	48 8b 34 24          	mov    (%rsp),%rsi
    52e0:	48 8b 3c 24          	mov    (%rsp),%rdi
    52e4:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    52e9:	e8 72 03 00 00       	call   0x5660
    52ee:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    52f5:	00 
    52f6:	43 8b 4c 33 10       	mov    0x10(%r11,%r14,1),%ecx
    52fb:	85 c9                	test   %ecx,%ecx
    52fd:	0f 85 0b 00 00 00    	jne    0x530e
    5303:	41 bd 04 00 00 00    	mov    $0x4,%r13d
    5309:	e9 fe 00 00 00       	jmp    0x540c
    530e:	41 8d 57 20          	lea    0x20(%r15),%edx
    5312:	48 8b 34 24          	mov    (%rsp),%rsi
    5316:	48 8b 3c 24          	mov    (%rsp),%rdi
    531a:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    531f:	e8 3c 03 00 00       	call   0x5660
    5324:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    532b:	00 
    532c:	43 8b 4c 33 14       	mov    0x14(%r11,%r14,1),%ecx
    5331:	85 c9                	test   %ecx,%ecx
    5333:	0f 85 0b 00 00 00    	jne    0x5344
    5339:	41 bd 05 00 00 00    	mov    $0x5,%r13d
    533f:	e9 c8 00 00 00       	jmp    0x540c
    5344:	41 8d 57 28          	lea    0x28(%r15),%edx
    5348:	48 8b 34 24          	mov    (%rsp),%rsi
    534c:	48 8b 3c 24          	mov    (%rsp),%rdi
    5350:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    5355:	e8 06 03 00 00       	call   0x5660
    535a:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    5361:	00 
    5362:	43 8b 4c 33 18       	mov    0x18(%r11,%r14,1),%ecx
    5367:	85 c9                	test   %ecx,%ecx
    5369:	0f 85 0b 00 00 00    	jne    0x537a
    536f:	41 bd 06 00 00 00    	mov    $0x6,%r13d
    5375:	e9 92 00 00 00       	jmp    0x540c
    537a:	41 8d 57 30          	lea    0x30(%r15),%edx
    537e:	48 8b 34 24          	mov    (%rsp),%rsi
    5382:	48 8b 3c 24          	mov    (%rsp),%rdi
    5386:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    538b:	e8 d0 02 00 00       	call   0x5660
    5390:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    5397:	00 
    5398:	43 8b 4c 33 1c       	mov    0x1c(%r11,%r14,1),%ecx
    539d:	85 c9                	test   %ecx,%ecx
    539f:	0f 85 0b 00 00 00    	jne    0x53b0
    53a5:	41 bd 07 00 00 00    	mov    $0x7,%r13d
    53ab:	e9 5c 00 00 00       	jmp    0x540c
    53b0:	41 8d 57 38          	lea    0x38(%r15),%edx
    53b4:	48 8b 34 24          	mov    (%rsp),%rsi
    53b8:	48 8b 3c 24          	mov    (%rsp),%rdi
    53bc:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    53c1:	e8 9a 02 00 00       	call   0x5660
    53c6:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    53cd:	00 
    53ce:	43 8b 4c 33 20       	mov    0x20(%r11,%r14,1),%ecx
    53d3:	85 c9                	test   %ecx,%ecx
    53d5:	0f 84 31 00 00 00    	je     0x540c
    53db:	41 8d 57 40          	lea    0x40(%r15),%edx
    53df:	48 8b 34 24          	mov    (%rsp),%rsi
    53e3:	48 8b 3c 24          	mov    (%rsp),%rdi
    53e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    53ec:	e8 6f 02 00 00       	call   0x5660
    53f1:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    53f8:	00 
    53f9:	43 8b 4c 33 24       	mov    0x24(%r11,%r14,1),%ecx
    53fe:	85 c9                	test   %ecx,%ecx
    5400:	0f 85 6e 00 00 00    	jne    0x5474
    5406:	41 bd 09 00 00 00    	mov    $0x9,%r13d
    540c:	41 c1 e5 02          	shl    $0x2,%r13d
    5410:	42 8d 34 2b          	lea    (%rbx,%r13,1),%esi
    5414:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    541b:	00 
    541c:	41 8b 34 33          	mov    (%r11,%rsi,1),%esi
    5420:	85 f6                	test   %esi,%esi
    5422:	0f 84 0d 00 00 00    	je     0x5435
    5428:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
    542f:	00 
    5430:	e9 2f 00 00 00       	jmp    0x5464
    5435:	45 8d 4d 04          	lea    0x4(%r13),%r9d
    5439:	41 83 fd 24          	cmp    $0x24,%r13d
    543d:	0f 84 08 00 00 00    	je     0x544b
    5443:	4d 89 cd             	mov    %r9,%r13
    5446:	e9 c5 ff ff ff       	jmp    0x5410
    544b:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    5452:	00 
    5453:	48 8b 0c 24          	mov    (%rsp),%rcx
    5457:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
    545e:	00 
    545f:	e9 5b 00 00 00       	jmp    0x54bf
    5464:	41 c7 83 d0 10 00 00 	movl   $0x1c,0x10d0(%r11)
    546b:	1c 00 00 00 
    546f:	e9 3a 00 00 00       	jmp    0x54ae
    5474:	41 8d 57 48          	lea    0x48(%r15),%edx
    5478:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    547d:	48 8b 34 24          	mov    (%rsp),%rsi
    5481:	48 8b 3c 24          	mov    (%rsp),%rdi
    5485:	e8 d6 01 00 00       	call   0x5660
    548a:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    5491:	00 
    5492:	48 8b 0c 24          	mov    (%rsp),%rcx
    5496:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
    549d:	00 
    549e:	e9 1c 00 00 00       	jmp    0x54bf
    54a3:	41 c7 83 d0 10 00 00 	movl   $0x3d,0x10d0(%r11)
    54aa:	3d 00 00 00 
    54ae:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    54b3:	48 8b 0c 24          	mov    (%rsp),%rcx
    54b7:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
    54be:	00 
    54bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    54c3:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
    54ca:	00 
    54cb:	89 91 40 01 00 00    	mov    %edx,0x140(%rcx)
    54d1:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
    54d8:	00 
    54d9:	4c 8b a4 24 38 01 00 	mov    0x138(%rsp),%r12
    54e0:	00 
    54e1:	4c 8b ac 24 40 01 00 	mov    0x140(%rsp),%r13
    54e8:	00 
    54e9:	4c 8b b4 24 48 01 00 	mov    0x148(%rsp),%r14
    54f0:	00 
    54f1:	4c 8b bc 24 50 01 00 	mov    0x150(%rsp),%r15
    54f8:	00 
    54f9:	48 81 c4 60 01 00 00 	add    $0x160,%rsp
    5500:	48 89 ec             	mov    %rbp,%rsp
    5503:	5d                   	pop    %rbp
    5504:	c2 10 00             	ret    $0x10
    5507:	0f 0b                	ud2
    5509:	0f 0b                	ud2
    550b:	0f 0b                	ud2
    550d:	0f 0b                	ud2
    550f:	0f 0b                	ud2
    5511:	0f 0b                	ud2
    5513:	00 00                	add    %al,(%rax)
    5515:	00 00                	add    %al,(%rax)
    5517:	00 03                	add    %al,(%rbx)
    5519:	00 00                	add    %al,(%rax)
    551b:	00 00                	add    %al,(%rax)
    551d:	00 00                	add    %al,(%rax)
    551f:	00 01                	add    %al,(%rcx)
    5521:	00 00                	add    %al,(%rax)
    5523:	00 00                	add    %al,(%rax)
    5525:	00 00                	add    %al,(%rax)
    5527:	00 ff                	add    %bh,%bh
    5529:	ff                   	(bad)
    552a:	ff                   	(bad)
    552b:	ff 00                	incl   (%rax)
    552d:	00 00                	add    %al,(%rax)
    552f:	00 ff                	add    %bh,%bh
    5531:	ff                   	(bad)
    5532:	ff                   	(bad)
    5533:	7f 00                	jg     0x5535
    5535:	00 00                	add    %al,(%rax)
    5537:	00 3c 0b             	add    %bh,(%rbx,%rcx,1)
	...
    5542:	00 00                	add    %al,(%rax)
    5544:	01 00                	add    %eax,(%rax)
    5546:	00 00                	add    %al,(%rax)
    5548:	cd cc                	int    $0xcc
    554a:	cc                   	int3
    554b:	cc                   	int3
    554c:	cc                   	int3
    554d:	cc                   	int3
    554e:	cc                   	int3
    554f:	cc                   	int3
    5550:	ff                   	(bad)
    5551:	ff                   	(bad)
    5552:	ff                   	(bad)
    5553:	ff 09                	decl   (%rcx)
    5555:	00 00                	add    %al,(%rax)
    5557:	00 cd                	add    %cl,%ch
    5559:	cc                   	int3
    555a:	cc                   	int3
    555b:	cc                   	int3
    555c:	00 00                	add    %al,(%rax)
    555e:	00 00                	add    %al,(%rax)
    5560:	c6                   	(bad)
    5561:	0d 00 00 00 00       	or     $0x0,%eax
    5566:	00 00                	add    %al,(%rax)
    5568:	db 0d 00 00 00 00    	fisttpl 0x0(%rip)        # 0x556e
    556e:	00 00                	add    %al,(%rax)
    5570:	d3 0d 00 00 00 00    	rorl   %cl,0x0(%rip)        # 0x5576
	...
    5596:	b0 41                	mov    $0x41,%al
	...
    55a0:	06                   	(bad)
	...
    55c1:	00 00                	add    %al,(%rax)
    55c3:	00 65 cd             	add    %ah,-0x33(%rbp)
    55c6:	cd 41                	int    $0x41
	...
    55e0:	2f                   	(bad)
    55e1:	4b 69 6d 82 be e0 12 	rex.WXB imul $0x3912e0be,-0x7e(%r13),%rbp
    55e8:	39 
    55e9:	8e e3                	mov    %ebx,%fs
    55eb:	38 00                	cmp    %al,(%rax)
    55ed:	00 00                	add    %al,(%rax)
    55ef:	00 09                	add    %cl,(%rcx)
	...
    55fd:	00 00                	add    %al,(%rax)
    55ff:	00 fd                	add    %bh,%ch
    5601:	ff                   	(bad)
    5602:	ff                   	(bad)
    5603:	7f 00                	jg     0x5605
    5605:	00 00                	add    %al,(%rax)
    5607:	00 2d 00 00 00 00    	add    %ch,0x0(%rip)        # 0x560d
	...
    5615:	00 30                	add    %dh,(%rax)
    5617:	40 00 00             	rex add %al,(%rax)
	...
    5626:	30 40 00             	xor    %al,0x0(%rax)
	...
    5645:	00 30                	add    %dh,(%rax)
    5647:	40 00 00             	rex add %al,(%rax)
	...
