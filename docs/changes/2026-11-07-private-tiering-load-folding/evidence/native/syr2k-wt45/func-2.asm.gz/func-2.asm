
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-wt45/func-2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
   8:	4d 8b 52 18          	mov    0x18(%r10),%r10
   c:	49 81 c2 90 00 00 00 	add    $0x90,%r10
  13:	4c 3b d4             	cmp    %rsp,%r10
  16:	0f 87 60 05 00 00    	ja     0x57c
  1c:	48 81 ec 80 00 00 00 	sub    $0x80,%rsp
  23:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
  28:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  2d:	4c 89 6c 24 60       	mov    %r13,0x60(%rsp)
  32:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
  37:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  3c:	8b 8f 40 01 00 00    	mov    0x140(%rdi),%ecx
  42:	48 89 c8             	mov    %rcx,%rax
  45:	83 e8 30             	sub    $0x30,%eax
  48:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  4d:	89 87 40 01 00 00    	mov    %eax,0x140(%rdi)
  53:	48 89 3c 24          	mov    %rdi,(%rsp)
  57:	ba 00 f9 15 00       	mov    $0x15f900,%edx
  5c:	bb 08 00 00 00       	mov    $0x8,%ebx
  61:	48 89 d9             	mov    %rbx,%rcx
  64:	48 8b 34 24          	mov    (%rsp),%rsi
  68:	e8 73 05 00 00       	call   0x5e0
  6d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  72:	41 bc 80 4f 12 00    	mov    $0x124f80,%r12d
  78:	48 89 d9             	mov    %rbx,%rcx
  7b:	4c 89 e2             	mov    %r12,%rdx
  7e:	48 8b 34 24          	mov    (%rsp),%rsi
  82:	48 8b 3c 24          	mov    (%rsp),%rdi
  86:	e8 55 05 00 00       	call   0x5e0
  8b:	48 89 d9             	mov    %rbx,%rcx
  8e:	4c 89 e2             	mov    %r12,%rdx
  91:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  96:	48 8b 34 24          	mov    (%rsp),%rsi
  9a:	48 8b 3c 24          	mov    (%rsp),%rdi
  9e:	e8 3d 05 00 00       	call   0x5e0
  a3:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  a8:	45 33 db             	xor    %r11d,%r11d
  ab:	48 8b 0c 24          	mov    (%rsp),%rcx
  af:	4c 8b 69 38          	mov    0x38(%rcx),%r13
  b3:	4c 89 d9             	mov    %r11,%rcx
  b6:	33 f6                	xor    %esi,%esi
  b8:	ba 01 00 00 00       	mov    $0x1,%edx
  bd:	49 89 d4             	mov    %rdx,%r12
  c0:	ba 02 00 00 00       	mov    $0x2,%edx
  c5:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  ca:	49 89 d6             	mov    %rdx,%r14
  cd:	42 8d 3c 18          	lea    (%rax,%r11,1),%edi
  d1:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  d6:	46 8d 04 18          	lea    (%rax,%r11,1),%r8d
  da:	4c 89 e2             	mov    %r12,%rdx
  dd:	c4 62 33 f6 0d 9a 04 	mulx   0x49a(%rip),%r9d,%r9d        # 0x580
  e4:	00 00 
  e6:	41 c1 e9 07          	shr    $0x7,%r9d
  ea:	45 69 d1 b0 04 00 00 	imul   $0x4b0,%r9d,%r10d
  f1:	49 89 d1             	mov    %rdx,%r9
  f4:	45 2b ca             	sub    %r10d,%r9d
  f7:	49 89 d4             	mov    %rdx,%r12
  fa:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  fe:	c4 c1 7b 2a c1       	vcvtsi2sd %r9d,%xmm0,%xmm0
 103:	c5 fb 5e 05 85 04 00 	vdivsd 0x485(%rip),%xmm0,%xmm0        # 0x590
 10a:	00 
 10b:	8d 04 37             	lea    (%rdi,%rsi,1),%eax
 10e:	c4 c1 7b 11 44 05 00 	vmovsd %xmm0,0x0(%r13,%rax,1)
 115:	4c 89 f2             	mov    %r14,%rdx
 118:	c4 62 33 f6 0d 7f 04 	mulx   0x47f(%rip),%r9d,%r9d        # 0x5a0
 11f:	00 00 
 121:	41 c1 e9 06          	shr    $0x6,%r9d
 125:	45 69 d1 e8 03 00 00 	imul   $0x3e8,%r9d,%r10d
 12c:	49 89 d1             	mov    %rdx,%r9
 12f:	45 2b ca             	sub    %r10d,%r9d
 132:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 136:	c4 c1 7b 2a c1       	vcvtsi2sd %r9d,%xmm0,%xmm0
 13b:	c5 fb 5e 05 6d 04 00 	vdivsd 0x46d(%rip),%xmm0,%xmm0        # 0x5b0
 142:	00 
 143:	41 8d 04 30          	lea    (%r8,%rsi,1),%eax
 147:	c4 c1 7b 11 44 05 00 	vmovsd %xmm0,0x0(%r13,%rax,1)
 14e:	44 8d 4e 08          	lea    0x8(%rsi),%r9d
 152:	4d 89 e2             	mov    %r12,%r10
 155:	44 03 d1             	add    %ecx,%r10d
 158:	03 d1                	add    %ecx,%edx
 15a:	81 fe 38 1f 00 00    	cmp    $0x1f38,%esi
 160:	0f 84 0e 00 00 00    	je     0x174
 166:	49 89 d6             	mov    %rdx,%r14
 169:	4c 89 ce             	mov    %r9,%rsi
 16c:	4c 89 d2             	mov    %r10,%rdx
 16f:	e9 69 ff ff ff       	jmp    0xdd
 174:	41 81 c3 40 1f 00 00 	add    $0x1f40,%r11d
 17b:	8d 51 01             	lea    0x1(%rcx),%edx
 17e:	81 f9 af 04 00 00    	cmp    $0x4af,%ecx
 184:	0f 84 08 00 00 00    	je     0x192
 18a:	48 89 d1             	mov    %rdx,%rcx
 18d:	e9 24 ff ff ff       	jmp    0xb6
 192:	33 c9                	xor    %ecx,%ecx
 194:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
 199:	33 ff                	xor    %edi,%edi
 19b:	ba 03 00 00 00       	mov    $0x3,%edx
 1a0:	c4 62 3b f6 05 d7 03 	mulx   0x3d7(%rip),%r8d,%r8d        # 0x580
 1a7:	00 00 
 1a9:	41 c1 e8 07          	shr    $0x7,%r8d
 1ad:	45 69 c8 b0 04 00 00 	imul   $0x4b0,%r8d,%r9d
 1b4:	49 89 d0             	mov    %rdx,%r8
 1b7:	45 2b c1             	sub    %r9d,%r8d
 1ba:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 1be:	c4 c1 7b 2a c0       	vcvtsi2sd %r8d,%xmm0,%xmm0
 1c3:	c5 fb 5e 05 f5 03 00 	vdivsd 0x3f5(%rip),%xmm0,%xmm0        # 0x5c0
 1ca:	00 
 1cb:	8d 04 3e             	lea    (%rsi,%rdi,1),%eax
 1ce:	c4 c1 7b 11 44 05 00 	vmovsd %xmm0,0x0(%r13,%rax,1)
 1d5:	44 8d 47 08          	lea    0x8(%rdi),%r8d
 1d9:	03 d1                	add    %ecx,%edx
 1db:	81 ff 78 25 00 00    	cmp    $0x2578,%edi
 1e1:	0f 84 08 00 00 00    	je     0x1ef
 1e7:	4c 89 c7             	mov    %r8,%rdi
 1ea:	e9 b1 ff ff ff       	jmp    0x1a0
 1ef:	81 c6 80 25 00 00    	add    $0x2580,%esi
 1f5:	8d 51 01             	lea    0x1(%rcx),%edx
 1f8:	81 f9 af 04 00 00    	cmp    $0x4af,%ecx
 1fe:	0f 84 08 00 00 00    	je     0x20c
 204:	48 89 d1             	mov    %rdx,%rcx
 207:	e9 8d ff ff ff       	jmp    0x199
 20c:	be 01 00 00 00       	mov    $0x1,%esi
 211:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
 216:	33 d2                	xor    %edx,%edx
 218:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
 21d:	ba 08 00 00 00       	mov    $0x8,%edx
 222:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 227:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
 22c:	49 89 f9             	mov    %rdi,%r9
 22f:	45 8b d1             	mov    %r9d,%r10d
 232:	49 bb 33 33 33 33 33 	movabs $0x3ff3333333333333,%r11
 239:	33 f3 3f 
 23c:	c4 c1 f9 6e fb       	vmovq  %r11,%xmm7
 241:	c4 81 43 59 74 15 00 	vmulsd 0x0(%r13,%r10,1),%xmm7,%xmm6
 248:	c4 81 7b 11 74 15 00 	vmovsd %xmm6,0x0(%r13,%r10,1)
 24f:	41 81 c0 ff ff ff ff 	add    $0xffffffff,%r8d
 256:	41 81 c1 08 00 00 00 	add    $0x8,%r9d
 25d:	45 85 c0             	test   %r8d,%r8d
 260:	0f 85 c9 ff ff ff    	jne    0x22f
 266:	45 33 c0             	xor    %r8d,%r8d
 269:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 26e:	44 69 de e8 03 00 00 	imul   $0x3e8,%esi,%r11d
 275:	4d 89 c1             	mov    %r8,%r9
 278:	45 33 d2             	xor    %r10d,%r10d
 27b:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 280:	42 8d 04 c0          	lea    (%rax,%r8,8),%eax
 284:	46 8d 24 d8          	lea    (%rax,%r11,8),%r12d
 288:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 28d:	42 8d 04 c0          	lea    (%rax,%r8,8),%eax
 291:	46 8d 34 d8          	lea    (%rax,%r11,8),%r14d
 295:	4d 89 cf             	mov    %r9,%r15
 298:	42 8d 1c 17          	lea    (%rdi,%r10,1),%ebx
 29c:	c4 c1 7b 10 44 1d 00 	vmovsd 0x0(%r13,%rbx,1),%xmm0
 2a3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
 2a8:	42 8d 0c 38          	lea    (%rax,%r15,1),%ecx
 2ac:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 2b1:	41 03 c7             	add    %r15d,%eax
 2b4:	48 be 00 00 00 00 00 	movabs $0x3ff8000000000000,%rsi
 2bb:	00 f8 3f 
 2be:	c4 e1 f9 6e ce       	vmovq  %rsi,%xmm1
 2c3:	c4 c1 73 59 54 0d 00 	vmulsd 0x0(%r13,%rcx,1),%xmm1,%xmm2
 2ca:	c4 81 6b 59 54 25 00 	vmulsd 0x0(%r13,%r12,1),%xmm2,%xmm2
 2d1:	c4 c1 73 59 4c 05 00 	vmulsd 0x0(%r13,%rax,1),%xmm1,%xmm1
 2d8:	c4 81 73 59 4c 35 00 	vmulsd 0x0(%r13,%r14,1),%xmm1,%xmm1
 2df:	c5 eb 58 c9          	vaddsd %xmm1,%xmm2,%xmm1
 2e3:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 2e7:	c4 c1 7b 11 44 1d 00 	vmovsd %xmm0,0x0(%r13,%rbx,1)
 2ee:	41 81 c2 08 00 00 00 	add    $0x8,%r10d
 2f5:	41 81 c7 40 1f 00 00 	add    $0x1f40,%r15d
 2fc:	41 3b d2             	cmp    %r10d,%edx
 2ff:	0f 85 93 ff ff ff    	jne    0x298
 305:	41 8d 40 01          	lea    0x1(%r8),%eax
 309:	41 81 c1 08 00 00 00 	add    $0x8,%r9d
 310:	41 81 f8 e7 03 00 00 	cmp    $0x3e7,%r8d
 317:	0f 84 08 00 00 00    	je     0x325
 31d:	49 89 c0             	mov    %rax,%r8
 320:	e9 53 ff ff ff       	jmp    0x278
 325:	81 c7 80 25 00 00    	add    $0x2580,%edi
 32b:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
 330:	81 c1 01 00 00 00    	add    $0x1,%ecx
 336:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
 33b:	41 8d 43 01          	lea    0x1(%r11),%eax
 33f:	81 c2 08 00 00 00    	add    $0x8,%edx
 345:	41 81 fb af 04 00 00 	cmp    $0x4af,%r11d
 34c:	0f 84 0f 00 00 00    	je     0x361
 352:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
 357:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 35c:	e9 c6 fe ff ff       	jmp    0x227
 361:	41 8b 9d 8c 04 00 00 	mov    0x48c(%r13),%ebx
 368:	ba 00 04 00 00       	mov    $0x400,%edx
 36d:	b9 16 00 00 00       	mov    $0x16,%ecx
 372:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 378:	48 8b 34 24          	mov    (%rsp),%rsi
 37c:	48 8b 3c 24          	mov    (%rsp),%rdi
 380:	49 89 d9             	mov    %rbx,%r9
 383:	e8 38 3d 00 00       	call   0x40c0
 388:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
 38d:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
 392:	48 89 d0             	mov    %rdx,%rax
 395:	83 e8 30             	sub    $0x30,%eax
 398:	41 c7 44 05 20 26 04 	movl   $0x426,0x20(%r13,%rax,1)
 39f:	00 00 
 3a1:	49 89 c4             	mov    %rax,%r12
 3a4:	b9 17 04 00 00       	mov    $0x417,%ecx
 3a9:	44 8d 42 f0          	lea    -0x10(%rdx),%r8d
 3ad:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 3b2:	48 8b 34 24          	mov    (%rsp),%rsi
 3b6:	48 8b 3c 24          	mov    (%rsp),%rdi
 3ba:	e8 e1 a9 00 00       	call   0xada0
 3bf:	33 d2                	xor    %edx,%edx
 3c1:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
 3c6:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
 3cb:	4c 8b 7c 24 40       	mov    0x40(%rsp),%r15
 3d0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 3d5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
 3da:	45 33 f6             	xor    %r14d,%r14d
 3dd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 3e2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 3e7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 3ec:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
 3f1:	c4 e2 7b f6 05 d6 01 	mulx   0x1d6(%rip),%eax,%eax        # 0x5d0
 3f8:	00 00 
 3fa:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
 3ff:	c1 e8 04             	shr    $0x4,%eax
 402:	6b c0 14             	imul   $0x14,%eax,%eax
 405:	03 c3                	add    %ebx,%eax
 407:	85 c0                	test   %eax,%eax
 409:	0f 85 17 00 00 00    	jne    0x426
 40f:	ba 0a 00 00 00       	mov    $0xa,%edx
 414:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 419:	48 8b 34 24          	mov    (%rsp),%rsi
 41d:	48 8b 3c 24          	mov    (%rsp),%rdi
 421:	e8 fa 4a 00 00       	call   0x4f20
 426:	43 8d 04 37          	lea    (%r15,%r14,1),%eax
 42a:	c4 c1 7b 10 44 05 00 	vmovsd 0x0(%r13,%rax,1),%xmm0
 431:	c4 81 7b 11 44 25 10 	vmovsd %xmm0,0x10(%r13,%r12,1)
 438:	b9 28 04 00 00       	mov    $0x428,%ecx
 43d:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
 442:	44 8d 42 e0          	lea    -0x20(%rdx),%r8d
 446:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 44b:	48 8b 34 24          	mov    (%rsp),%rsi
 44f:	48 8b 3c 24          	mov    (%rsp),%rdi
 453:	e8 48 a9 00 00       	call   0xada0
 458:	81 c3 ff ff ff ff    	add    $0xffffffff,%ebx
 45e:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 463:	81 c2 01 00 00 00    	add    $0x1,%edx
 469:	41 8d 4e 08          	lea    0x8(%r14),%ecx
 46d:	41 81 fe 78 25 00 00 	cmp    $0x2578,%r14d
 474:	0f 84 08 00 00 00    	je     0x482
 47a:	49 89 ce             	mov    %rcx,%r14
 47d:	e9 6f ff ff ff       	jmp    0x3f1
 482:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
 487:	8d 91 b0 04 00 00    	lea    0x4b0(%rcx),%edx
 48d:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
 492:	8d 99 50 fb ff ff    	lea    -0x4b0(%rcx),%ebx
 498:	41 81 c7 80 25 00 00 	add    $0x2580,%r15d
 49f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
 4a4:	8d 4e 01             	lea    0x1(%rsi),%ecx
 4a7:	81 fe af 04 00 00    	cmp    $0x4af,%esi
 4ad:	0f 84 0f 00 00 00    	je     0x4c2
 4b3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
 4b8:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
 4bd:	e9 18 ff ff ff       	jmp    0x3da
 4c2:	43 c7 44 25 00 26 04 	movl   $0x426,0x0(%r13,%r12,1)
 4c9:	00 00 
 4cb:	b9 30 04 00 00       	mov    $0x430,%ecx
 4d0:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
 4d5:	49 89 d0             	mov    %rdx,%r8
 4d8:	41 83 e8 30          	sub    $0x30,%r8d
 4dc:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 4e1:	48 8b 34 24          	mov    (%rsp),%rsi
 4e5:	48 8b 3c 24          	mov    (%rsp),%rdi
 4e9:	e8 b2 a8 00 00       	call   0xada0
 4ee:	ba 41 04 00 00       	mov    $0x441,%edx
 4f3:	b9 16 00 00 00       	mov    $0x16,%ecx
 4f8:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 4fe:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
 503:	48 8b 34 24          	mov    (%rsp),%rsi
 507:	48 8b 3c 24          	mov    (%rsp),%rdi
 50b:	e8 b0 3b 00 00       	call   0x40c0
 510:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
 515:	48 8b 34 24          	mov    (%rsp),%rsi
 519:	48 8b 3c 24          	mov    (%rsp),%rdi
 51d:	e8 de 1f 00 00       	call   0x2500
 522:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
 527:	48 8b 34 24          	mov    (%rsp),%rsi
 52b:	48 8b 3c 24          	mov    (%rsp),%rdi
 52f:	e8 cc 1f 00 00       	call   0x2500
 534:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 539:	48 8b 34 24          	mov    (%rsp),%rsi
 53d:	48 8b 3c 24          	mov    (%rsp),%rdi
 541:	e8 ba 1f 00 00       	call   0x2500
 546:	48 8b 0c 24          	mov    (%rsp),%rcx
 54a:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
 54f:	89 91 40 01 00 00    	mov    %edx,0x140(%rcx)
 555:	33 c0                	xor    %eax,%eax
 557:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
 55c:	4c 8b 64 24 58       	mov    0x58(%rsp),%r12
 561:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
 566:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
 56b:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
 570:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
 577:	48 89 ec             	mov    %rbp,%rsp
 57a:	5d                   	pop    %rbp
 57b:	c3                   	ret
 57c:	0f 0b                	ud2
 57e:	00 00                	add    %al,(%rax)
 580:	b5 81                	mov    $0x81,%ch
 582:	4e 1b 00             	rex.WRX sbb (%rax),%r8
	...
 595:	c0 92 40 00 00 00 00 	rclb   $0x0,0x40(%rdx)
 59c:	00 00                	add    %al,(%rax)
 59e:	00 00                	add    %al,(%rax)
 5a0:	d3 4d 62             	rorl   %cl,0x62(%rbp)
 5a3:	10 00                	adc    %al,(%rax)
	...
 5b5:	40 8f 40 00          	rex pop 0x0(%rax)
	...
 5c5:	40 8f 40 00          	rex pop 0x0(%rax)
 5c9:	00 00                	add    %al,(%rax)
 5cb:	00 00                	add    %al,(%rax)
 5cd:	00 00                	add    %al,(%rax)
 5cf:	00 cd                	add    %cl,%ch
 5d1:	cc                   	int3
 5d2:	cc                   	int3
 5d3:	cc                   	int3
 5d4:	00 00                	add    %al,(%rax)
	...
