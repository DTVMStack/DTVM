
/workspace/DTVM/work/post645-research/profiles/bicg-repeat30-wt45/func-2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
   8:	4d 8b 52 18          	mov    0x18(%r10),%r10
   c:	49 81 c2 80 00 00 00 	add    $0x80,%r10
  13:	4c 3b d4             	cmp    %rsp,%r10
  16:	0f 87 80 05 00 00    	ja     0x59c
  1c:	48 83 ec 70          	sub    $0x70,%rsp
  20:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
  25:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  2a:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
  2f:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
  34:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
  39:	48 89 fe             	mov    %rdi,%rsi
  3c:	ba 10 00 00 00       	mov    $0x10,%edx
  41:	48 89 f3             	mov    %rsi,%rbx
  44:	48 89 df             	mov    %rbx,%rdi
  47:	e8 54 be 00 00       	call   0xbea0
  4c:	8b 83 60 01 00 00    	mov    0x160(%rbx),%eax
  52:	48 89 c1             	mov    %rax,%rcx
  55:	83 e9 60             	sub    $0x60,%ecx
  58:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  5d:	89 8b 60 01 00 00    	mov    %ecx,0x160(%rbx)
  63:	ba f0 e1 3c 00       	mov    $0x3ce1f0,%edx
  68:	41 be 08 00 00 00    	mov    $0x8,%r14d
  6e:	4c 89 f1             	mov    %r14,%rcx
  71:	48 89 de             	mov    %rbx,%rsi
  74:	48 89 df             	mov    %rbx,%rdi
  77:	e8 84 05 00 00       	call   0x600
  7c:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  81:	41 bc 6c 07 00 00    	mov    $0x76c,%r12d
  87:	4c 89 f1             	mov    %r14,%rcx
  8a:	4c 89 e2             	mov    %r12,%rdx
  8d:	48 89 de             	mov    %rbx,%rsi
  90:	48 89 df             	mov    %rbx,%rdi
  93:	e8 68 05 00 00       	call   0x600
  98:	49 89 c7             	mov    %rax,%r15
  9b:	41 bd 34 08 00 00    	mov    $0x834,%r13d
  a1:	4c 89 f1             	mov    %r14,%rcx
  a4:	4c 89 ea             	mov    %r13,%rdx
  a7:	48 89 de             	mov    %rbx,%rsi
  aa:	48 89 df             	mov    %rbx,%rdi
  ad:	e8 4e 05 00 00       	call   0x600
  b2:	4c 89 e2             	mov    %r12,%rdx
  b5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  ba:	4c 89 f1             	mov    %r14,%rcx
  bd:	48 89 de             	mov    %rbx,%rsi
  c0:	48 89 df             	mov    %rbx,%rdi
  c3:	e8 38 05 00 00       	call   0x600
  c8:	4c 89 f1             	mov    %r14,%rcx
  cb:	4c 89 ea             	mov    %r13,%rdx
  ce:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  d3:	48 89 de             	mov    %rbx,%rsi
  d6:	48 89 df             	mov    %rbx,%rdi
  d9:	e8 22 05 00 00       	call   0x600
  de:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  e3:	ba 18 00 00 00       	mov    $0x18,%edx
  e8:	48 89 de             	mov    %rbx,%rsi
  eb:	48 89 df             	mov    %rbx,%rdi
  ee:	e8 ad bd 00 00       	call   0xbea0
  f3:	33 c0                	xor    %eax,%eax
  f5:	4c 8b 6b 38          	mov    0x38(%rbx),%r13
  f9:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  fe:	48 89 c2             	mov    %rax,%rdx
 101:	81 e2 ff ff 00 00    	and    $0xffff,%edx
 107:	c4 e2 4b f6 35 90 04 	mulx   0x490(%rip),%esi,%esi        # 0x5a0
 10e:	00 00 
 110:	c1 ee 09             	shr    $0x9,%esi
 113:	69 f6 6c 07 00 00    	imul   $0x76c,%esi,%esi
 119:	2b d6                	sub    %esi,%edx
 11b:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 11f:	c4 e1 fb 2a c2       	vcvtsi2sd %rdx,%xmm0,%xmm0
 124:	c5 fb 5e 05 84 04 00 	vdivsd 0x484(%rip),%xmm0,%xmm0        # 0x5b0
 12b:	00 
 12c:	8b d1                	mov    %ecx,%edx
 12e:	c4 c1 7b 11 44 15 00 	vmovsd %xmm0,0x0(%r13,%rdx,1)
 135:	81 c1 08 00 00 00    	add    $0x8,%ecx
 13b:	8d 50 01             	lea    0x1(%rax),%edx
 13e:	3d 6b 07 00 00       	cmp    $0x76b,%eax
 143:	0f 84 08 00 00 00    	je     0x151
 149:	48 89 d0             	mov    %rdx,%rax
 14c:	e9 ad ff ff ff       	jmp    0xfe
 151:	ba 20 00 00 00       	mov    $0x20,%edx
 156:	48 89 de             	mov    %rbx,%rsi
 159:	48 89 df             	mov    %rbx,%rdi
 15c:	e8 3f bd 00 00       	call   0xbea0
 161:	33 c9                	xor    %ecx,%ecx
 163:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 168:	48 89 ca             	mov    %rcx,%rdx
 16b:	81 e2 ff ff 00 00    	and    $0xffff,%edx
 171:	c4 e2 4b f6 35 46 04 	mulx   0x446(%rip),%esi,%esi        # 0x5c0
 178:	00 00 
 17a:	c1 ee 0b             	shr    $0xb,%esi
 17d:	69 f6 34 08 00 00    	imul   $0x834,%esi,%esi
 183:	2b d6                	sub    %esi,%edx
 185:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 189:	c4 e1 fb 2a c2       	vcvtsi2sd %rdx,%xmm0,%xmm0
 18e:	c5 fb 5e 05 3a 04 00 	vdivsd 0x43a(%rip),%xmm0,%xmm0        # 0x5d0
 195:	00 
 196:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 19b:	8d 14 ca             	lea    (%rdx,%rcx,8),%edx
 19e:	c4 c1 7b 11 44 15 00 	vmovsd %xmm0,0x0(%r13,%rdx,1)
 1a5:	33 f6                	xor    %esi,%esi
 1a7:	48 89 ca             	mov    %rcx,%rdx
 1aa:	c4 e2 43 f6 3d 0d 04 	mulx   0x40d(%rip),%edi,%edi        # 0x5c0
 1b1:	00 00 
 1b3:	c1 ef 0b             	shr    $0xb,%edi
 1b6:	44 69 c7 34 08 00 00 	imul   $0x834,%edi,%r8d
 1bd:	48 89 d7             	mov    %rdx,%rdi
 1c0:	41 2b f8             	sub    %r8d,%edi
 1c3:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 1c7:	c5 fb 2a c7          	vcvtsi2sd %edi,%xmm0,%xmm0
 1cb:	c5 fb 5e 05 0d 04 00 	vdivsd 0x40d(%rip),%xmm0,%xmm0        # 0x5e0
 1d2:	00 
 1d3:	8d 3c 30             	lea    (%rax,%rsi,1),%edi
 1d6:	c4 c1 7b 11 44 3d 00 	vmovsd %xmm0,0x0(%r13,%rdi,1)
 1dd:	8d 7e 08             	lea    0x8(%rsi),%edi
 1e0:	03 d1                	add    %ecx,%edx
 1e2:	81 fe 58 3b 00 00    	cmp    $0x3b58,%esi
 1e8:	0f 84 08 00 00 00    	je     0x1f6
 1ee:	48 89 fe             	mov    %rdi,%rsi
 1f1:	e9 b4 ff ff ff       	jmp    0x1aa
 1f6:	8d 51 01             	lea    0x1(%rcx),%edx
 1f9:	81 c0 60 3b 00 00    	add    $0x3b60,%eax
 1ff:	81 f9 33 08 00 00    	cmp    $0x833,%ecx
 205:	0f 84 08 00 00 00    	je     0x213
 20b:	48 89 d1             	mov    %rdx,%rcx
 20e:	e9 55 ff ff ff       	jmp    0x168
 213:	ba 28 00 00 00       	mov    $0x28,%edx
 218:	48 89 de             	mov    %rbx,%rsi
 21b:	48 89 df             	mov    %rbx,%rdi
 21e:	e8 7d bc 00 00       	call   0xbea0
 223:	45 33 e4             	xor    %r12d,%r12d
 226:	41 b8 60 3b 00 00    	mov    $0x3b60,%r8d
 22c:	4c 89 fa             	mov    %r15,%rdx
 22f:	4c 89 e1             	mov    %r12,%rcx
 232:	48 89 de             	mov    %rbx,%rsi
 235:	48 89 df             	mov    %rbx,%rdi
 238:	e8 63 b5 00 00       	call   0xb7a0
 23d:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 242:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 247:	42 8d 14 e2          	lea    (%rdx,%r12,8),%edx
 24b:	49 c7 44 15 00 00 00 	movq   $0x0,0x0(%r13,%rdx,1)
 252:	00 00 
 254:	33 ff                	xor    %edi,%edi
 256:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 25b:	42 8d 34 e6          	lea    (%rsi,%r12,8),%esi
 25f:	44 8d 04 38          	lea    (%rax,%rdi,1),%r8d
 263:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 268:	c4 81 7b 10 44 05 00 	vmovsd 0x0(%r13,%r8,1),%xmm0
 26f:	c4 c1 7b 10 4c 35 00 	vmovsd 0x0(%r13,%rsi,1),%xmm1
 276:	8d 04 39             	lea    (%rcx,%rdi,1),%eax
 279:	c4 c1 73 59 4c 05 00 	vmulsd 0x0(%r13,%rax,1),%xmm1,%xmm1
 280:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 284:	c4 81 7b 11 44 05 00 	vmovsd %xmm0,0x0(%r13,%r8,1)
 28b:	c4 c1 7b 10 44 15 00 	vmovsd 0x0(%r13,%rdx,1),%xmm0
 292:	c4 c1 7b 10 4c 05 00 	vmovsd 0x0(%r13,%rax,1),%xmm1
 299:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
 29e:	41 8d 04 39          	lea    (%r9,%rdi,1),%eax
 2a2:	c4 c1 73 59 4c 05 00 	vmulsd 0x0(%r13,%rax,1),%xmm1,%xmm1
 2a9:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 2ad:	c4 c1 7b 11 44 15 00 	vmovsd %xmm0,0x0(%r13,%rdx,1)
 2b4:	8d 47 08             	lea    0x8(%rdi),%eax
 2b7:	81 ff 58 3b 00 00    	cmp    $0x3b58,%edi
 2bd:	0f 84 0d 00 00 00    	je     0x2d0
 2c3:	48 89 c7             	mov    %rax,%rdi
 2c6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 2cb:	e9 8f ff ff ff       	jmp    0x25f
 2d0:	41 8d 44 24 01       	lea    0x1(%r12),%eax
 2d5:	81 c1 60 3b 00 00    	add    $0x3b60,%ecx
 2db:	41 81 fc 33 08 00 00 	cmp    $0x833,%r12d
 2e2:	0f 84 12 00 00 00    	je     0x2fa
 2e8:	49 89 c4             	mov    %rax,%r12
 2eb:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 2f0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 2f5:	e9 4d ff ff ff       	jmp    0x247
 2fa:	ba 30 00 00 00       	mov    $0x30,%edx
 2ff:	48 89 de             	mov    %rbx,%rsi
 302:	48 89 df             	mov    %rbx,%rdi
 305:	e8 96 bb 00 00       	call   0xbea0
 30a:	41 8b b5 90 04 00 00 	mov    0x490(%r13),%esi
 311:	48 89 34 24          	mov    %rsi,(%rsp)
 315:	ba 00 04 00 00       	mov    $0x400,%edx
 31a:	b9 16 00 00 00       	mov    $0x16,%ecx
 31f:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 325:	48 89 de             	mov    %rbx,%rsi
 328:	48 89 df             	mov    %rbx,%rdi
 32b:	4c 8b 0c 24          	mov    (%rsp),%r9
 32f:	e8 ac 3d 00 00       	call   0x40e0
 334:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
 339:	48 89 f2             	mov    %rsi,%rdx
 33c:	83 ea 60             	sub    $0x60,%edx
 33f:	41 c7 44 15 50 26 04 	movl   $0x426,0x50(%r13,%rdx,1)
 346:	00 00 
 348:	49 89 d6             	mov    %rdx,%r14
 34b:	b9 17 04 00 00       	mov    $0x417,%ecx
 350:	44 8d 46 f0          	lea    -0x10(%rsi),%r8d
 354:	48 8b 14 24          	mov    (%rsp),%rdx
 358:	48 89 de             	mov    %rbx,%rsi
 35b:	48 89 df             	mov    %rbx,%rdi
 35e:	e8 5d aa 00 00       	call   0xadc0
 363:	45 33 ff             	xor    %r15d,%r15d
 366:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
 36b:	4c 89 fa             	mov    %r15,%rdx
 36e:	81 e2 ff ff 00 00    	and    $0xffff,%edx
 374:	c4 e2 73 f6 0d 73 02 	mulx   0x273(%rip),%ecx,%ecx        # 0x5f0
 37b:	00 00 
 37d:	c1 e9 04             	shr    $0x4,%ecx
 380:	6b c9 14             	imul   $0x14,%ecx,%ecx
 383:	2b d1                	sub    %ecx,%edx
 385:	85 d2                	test   %edx,%edx
 387:	0f 85 14 00 00 00    	jne    0x3a1
 38d:	ba 0a 00 00 00       	mov    $0xa,%edx
 392:	48 8b 0c 24          	mov    (%rsp),%rcx
 396:	48 89 de             	mov    %rbx,%rsi
 399:	48 89 df             	mov    %rbx,%rdi
 39c:	e8 9f 4b 00 00       	call   0x4f40
 3a1:	41 8b f4             	mov    %r12d,%esi
 3a4:	c4 c1 7b 10 64 35 00 	vmovsd 0x0(%r13,%rsi,1),%xmm4
 3ab:	c4 81 7b 11 64 35 40 	vmovsd %xmm4,0x40(%r13,%r14,1)
 3b2:	b9 28 04 00 00       	mov    $0x428,%ecx
 3b7:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 3bc:	44 8d 40 e0          	lea    -0x20(%rax),%r8d
 3c0:	48 8b 14 24          	mov    (%rsp),%rdx
 3c4:	48 89 de             	mov    %rbx,%rsi
 3c7:	48 89 df             	mov    %rbx,%rdi
 3ca:	e8 f1 a9 00 00       	call   0xadc0
 3cf:	41 8d 77 01          	lea    0x1(%r15),%esi
 3d3:	41 81 c4 08 00 00 00 	add    $0x8,%r12d
 3da:	41 81 ff 6b 07 00 00 	cmp    $0x76b,%r15d
 3e1:	0f 84 08 00 00 00    	je     0x3ef
 3e7:	49 89 f7             	mov    %rsi,%r15
 3ea:	e9 7c ff ff ff       	jmp    0x36b
 3ef:	43 c7 44 35 30 26 04 	movl   $0x426,0x30(%r13,%r14,1)
 3f6:	00 00 
 3f8:	b9 30 04 00 00       	mov    $0x430,%ecx
 3fd:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 402:	44 8d 40 d0          	lea    -0x30(%rax),%r8d
 406:	48 8b 14 24          	mov    (%rsp),%rdx
 40a:	48 89 de             	mov    %rbx,%rsi
 40d:	48 89 df             	mov    %rbx,%rdi
 410:	e8 ab a9 00 00       	call   0xadc0
 415:	43 c7 44 35 20 41 04 	movl   $0x441,0x20(%r13,%r14,1)
 41c:	00 00 
 41e:	b9 17 04 00 00       	mov    $0x417,%ecx
 423:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 428:	44 8d 40 c0          	lea    -0x40(%rax),%r8d
 42c:	48 8b 14 24          	mov    (%rsp),%rdx
 430:	48 89 de             	mov    %rbx,%rsi
 433:	48 89 df             	mov    %rbx,%rdi
 436:	e8 85 a9 00 00       	call   0xadc0
 43b:	45 33 e4             	xor    %r12d,%r12d
 43e:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
 443:	4c 89 e2             	mov    %r12,%rdx
 446:	81 e2 ff ff 00 00    	and    $0xffff,%edx
 44c:	c4 62 23 f6 1d 9b 01 	mulx   0x19b(%rip),%r11d,%r11d        # 0x5f0
 453:	00 00 
 455:	41 c1 eb 04          	shr    $0x4,%r11d
 459:	41 6b cb 14          	imul   $0x14,%r11d,%ecx
 45d:	2b d1                	sub    %ecx,%edx
 45f:	85 d2                	test   %edx,%edx
 461:	0f 85 14 00 00 00    	jne    0x47b
 467:	ba 0a 00 00 00       	mov    $0xa,%edx
 46c:	48 8b 0c 24          	mov    (%rsp),%rcx
 470:	48 89 de             	mov    %rbx,%rsi
 473:	48 89 df             	mov    %rbx,%rdi
 476:	e8 c5 4a 00 00       	call   0x4f40
 47b:	41 8b c7             	mov    %r15d,%eax
 47e:	c4 c1 7b 10 44 05 00 	vmovsd 0x0(%r13,%rax,1),%xmm0
 485:	c4 81 7b 11 44 35 10 	vmovsd %xmm0,0x10(%r13,%r14,1)
 48c:	b9 28 04 00 00       	mov    $0x428,%ecx
 491:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 496:	44 8d 40 b0          	lea    -0x50(%rax),%r8d
 49a:	48 8b 14 24          	mov    (%rsp),%rdx
 49e:	48 89 de             	mov    %rbx,%rsi
 4a1:	48 89 df             	mov    %rbx,%rdi
 4a4:	e8 17 a9 00 00       	call   0xadc0
 4a9:	41 8d 4c 24 01       	lea    0x1(%r12),%ecx
 4ae:	41 81 c7 08 00 00 00 	add    $0x8,%r15d
 4b5:	41 81 fc 33 08 00 00 	cmp    $0x833,%r12d
 4bc:	0f 84 08 00 00 00    	je     0x4ca
 4c2:	49 89 cc             	mov    %rcx,%r12
 4c5:	e9 79 ff ff ff       	jmp    0x443
 4ca:	43 c7 44 35 00 41 04 	movl   $0x441,0x0(%r13,%r14,1)
 4d1:	00 00 
 4d3:	b9 30 04 00 00       	mov    $0x430,%ecx
 4d8:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 4dd:	49 89 c0             	mov    %rax,%r8
 4e0:	41 83 e8 60          	sub    $0x60,%r8d
 4e4:	48 8b 14 24          	mov    (%rsp),%rdx
 4e8:	48 89 de             	mov    %rbx,%rsi
 4eb:	48 89 df             	mov    %rbx,%rdi
 4ee:	e8 cd a8 00 00       	call   0xadc0
 4f3:	ba 43 04 00 00       	mov    $0x443,%edx
 4f8:	b9 16 00 00 00       	mov    $0x16,%ecx
 4fd:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 503:	4c 8b 0c 24          	mov    (%rsp),%r9
 507:	48 89 de             	mov    %rbx,%rsi
 50a:	48 89 df             	mov    %rbx,%rdi
 50d:	e8 ce 3b 00 00       	call   0x40e0
 512:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 517:	48 89 de             	mov    %rbx,%rsi
 51a:	48 89 df             	mov    %rbx,%rdi
 51d:	e8 fe 1f 00 00       	call   0x2520
 522:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 527:	48 89 de             	mov    %rbx,%rsi
 52a:	48 89 df             	mov    %rbx,%rdi
 52d:	e8 ee 1f 00 00       	call   0x2520
 532:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 537:	48 89 de             	mov    %rbx,%rsi
 53a:	48 89 df             	mov    %rbx,%rdi
 53d:	e8 de 1f 00 00       	call   0x2520
 542:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 547:	48 89 de             	mov    %rbx,%rsi
 54a:	48 89 df             	mov    %rbx,%rdi
 54d:	e8 ce 1f 00 00       	call   0x2520
 552:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 557:	48 89 de             	mov    %rbx,%rsi
 55a:	48 89 df             	mov    %rbx,%rdi
 55d:	e8 be 1f 00 00       	call   0x2520
 562:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 567:	89 83 60 01 00 00    	mov    %eax,0x160(%rbx)
 56d:	48 89 de             	mov    %rbx,%rsi
 570:	48 89 f7             	mov    %rsi,%rdi
 573:	e8 88 b9 00 00       	call   0xbf00
 578:	33 c0                	xor    %eax,%eax
 57a:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
 57f:	4c 8b 64 24 48       	mov    0x48(%rsp),%r12
 584:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
 589:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
 58e:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
 593:	48 83 c4 70          	add    $0x70,%rsp
 597:	48 89 ec             	mov    %rbp,%rsp
 59a:	5d                   	pop    %rbp
 59b:	c3                   	ret
 59c:	0f 0b                	ud2
 59e:	00 00                	add    %al,(%rax)
 5a0:	35 3a fc 44 00       	xor    $0x44fc3a,%eax
	...
 5b5:	b0 9d                	mov    $0x9d,%al
 5b7:	40 00 00             	rex add %al,(%rax)
 5ba:	00 00                	add    %al,(%rax)
 5bc:	00 00                	add    %al,(%rax)
 5be:	00 00                	add    %al,(%rax)
 5c0:	2d 34 a9 f9 00       	sub    $0xf9a934,%eax
	...
 5d5:	68 a0 40 00 00       	push   $0x40a0
	...
 5e2:	00 00                	add    %al,(%rax)
 5e4:	00 68 a0             	add    %ch,-0x60(%rax)
 5e7:	40 00 00             	rex add %al,(%rax)
 5ea:	00 00                	add    %al,(%rax)
 5ec:	00 00                	add    %al,(%rax)
 5ee:	00 00                	add    %al,(%rax)
 5f0:	cd cc                	int    $0xcc
 5f2:	cc                   	int3
 5f3:	cc                   	int3
 5f4:	00 00                	add    %al,(%rax)
	...
