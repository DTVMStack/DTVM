
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-main/func-9-1-7fcea560e000.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	41 57                	push   %r15
   6:	41 56                	push   %r14
   8:	41 55                	push   %r13
   a:	41 54                	push   %r12
   c:	53                   	push   %rbx
   d:	48 83 ec 68          	sub    $0x68,%rsp
  11:	49 89 fe             	mov    %rdi,%r14
  14:	48 b8 00 00 00 00 00 	movabs $0x4092c00000000000,%rax
  1b:	c0 92 40 
  1e:	66 48 0f 6e c0       	movq   %rax,%xmm0
  23:	f2 0f 11 85 78 ff ff 	movsd  %xmm0,-0x88(%rbp)
  2a:	ff 
  2b:	48 b8 00 00 00 00 00 	movabs $0x408f400000000000,%rax
  32:	40 8f 40 
  35:	66 48 0f 6e c0       	movq   %rax,%xmm0
  3a:	f2 0f 11 85 70 ff ff 	movsd  %xmm0,-0x90(%rbp)
  41:	ff 
  42:	48 b8 33 33 33 33 33 	movabs $0x3ff3333333333333,%rax
  49:	33 f3 3f 
  4c:	66 48 0f 6e c0       	movq   %rax,%xmm0
  51:	f2 0f 11 45 a8       	movsd  %xmm0,-0x58(%rbp)
  56:	48 b8 00 00 00 00 00 	movabs $0x3ff8000000000000,%rax
  5d:	00 f8 3f 
  60:	66 48 0f 6e c0       	movq   %rax,%xmm0
  65:	f2 0f 11 45 a0       	movsd  %xmm0,-0x60(%rbp)
  6a:	31 c0                	xor    %eax,%eax
  6c:	31 c0                	xor    %eax,%eax
  6e:	31 c0                	xor    %eax,%eax
  70:	31 c0                	xor    %eax,%eax
  72:	31 c0                	xor    %eax,%eax
  74:	31 c0                	xor    %eax,%eax
  76:	31 c0                	xor    %eax,%eax
  78:	31 c0                	xor    %eax,%eax
  7a:	31 c0                	xor    %eax,%eax
  7c:	31 c0                	xor    %eax,%eax
  7e:	31 c0                	xor    %eax,%eax
  80:	31 c0                	xor    %eax,%eax
  82:	31 c0                	xor    %eax,%eax
  84:	31 c0                	xor    %eax,%eax
  86:	31 c0                	xor    %eax,%eax
  88:	31 c0                	xor    %eax,%eax
  8a:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
  91:	ff 
  92:	49 8b 86 b8 11 00 00 	mov    0x11b8(%r14),%rax
  99:	41 8b 86 78 11 00 00 	mov    0x1178(%r14),%eax
  a0:	8d 48 d0             	lea    -0x30(%rax),%ecx
  a3:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
  a7:	8d 40 d0             	lea    -0x30(%rax),%eax
  aa:	41 89 86 78 11 00 00 	mov    %eax,0x1178(%r14)
  b1:	31 db                	xor    %ebx,%ebx
  b3:	be 00 f9 15 00       	mov    $0x15f900,%esi
  b8:	ba 08 00 00 00       	mov    $0x8,%edx
  bd:	4c 89 f7             	mov    %r14,%rdi
  c0:	e8 59 1f ff ff       	call   0xffffffffffff201e
  c5:	41 89 c4             	mov    %eax,%r12d
  c8:	49 8b 86 b8 11 00 00 	mov    0x11b8(%r14),%rax
  cf:	be 80 4f 12 00       	mov    $0x124f80,%esi
  d4:	ba 08 00 00 00       	mov    $0x8,%edx
  d9:	4c 89 f7             	mov    %r14,%rdi
  dc:	e8 3d 1f ff ff       	call   0xffffffffffff201e
  e1:	41 89 c7             	mov    %eax,%r15d
  e4:	49 8b 86 b8 11 00 00 	mov    0x11b8(%r14),%rax
  eb:	be 80 4f 12 00       	mov    $0x124f80,%esi
  f0:	ba 08 00 00 00       	mov    $0x8,%edx
  f5:	4c 89 f7             	mov    %r14,%rdi
  f8:	e8 21 1f ff ff       	call   0xffffffffffff201e
  fd:	f2 0f 10 95 78 ff ff 	movsd  -0x88(%rbp),%xmm2
 104:	ff 
 105:	f2 0f 10 8d 70 ff ff 	movsd  -0x90(%rbp),%xmm1
 10c:	ff 
 10d:	41 89 c2             	mov    %eax,%r10d
 110:	4c 89 f0             	mov    %r14,%rax
 113:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
 117:	49 8b 86 b8 11 00 00 	mov    0x11b8(%r14),%rax
 11e:	31 ff                	xor    %edi,%edi
 120:	44 89 f9             	mov    %r15d,%ecx
 123:	89 4d c0             	mov    %ecx,-0x40(%rbp)
 126:	45 89 f9             	mov    %r15d,%r9d
 129:	41 01 d9             	add    %ebx,%r9d
 12c:	45 89 d0             	mov    %r10d,%r8d
 12f:	41 01 d8             	add    %ebx,%r8d
 132:	41 be 02 00 00 00    	mov    $0x2,%r14d
 138:	45 31 ed             	xor    %r13d,%r13d
 13b:	41 bf 01 00 00 00    	mov    $0x1,%r15d
 141:	44 89 f9             	mov    %r15d,%ecx
 144:	48 69 c9 b5 81 4e 1b 	imul   $0x1b4e81b5,%rcx,%rcx
 14b:	48 c1 e9 27          	shr    $0x27,%rcx
 14f:	89 c9                	mov    %ecx,%ecx
 151:	44 89 ca             	mov    %r9d,%edx
 154:	44 01 ea             	add    %r13d,%edx
 157:	69 c9 b0 04 00 00    	imul   $0x4b0,%ecx,%ecx
 15d:	44 89 fe             	mov    %r15d,%esi
 160:	29 ce                	sub    %ecx,%esi
 162:	0f 57 c0             	xorps  %xmm0,%xmm0
 165:	f2 0f 2a c6          	cvtsi2sd %esi,%xmm0
 169:	f2 0f 5e c2          	divsd  %xmm2,%xmm0
 16d:	f2 0f 11 04 10       	movsd  %xmm0,(%rax,%rdx,1)
 172:	44 89 f1             	mov    %r14d,%ecx
 175:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
 17c:	48 c1 e9 26          	shr    $0x26,%rcx
 180:	89 c9                	mov    %ecx,%ecx
 182:	44 89 c2             	mov    %r8d,%edx
 185:	44 01 ea             	add    %r13d,%edx
 188:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
 18e:	44 89 f6             	mov    %r14d,%esi
 191:	29 ce                	sub    %ecx,%esi
 193:	0f 57 c0             	xorps  %xmm0,%xmm0
 196:	f2 0f 2a c6          	cvtsi2sd %esi,%xmm0
 19a:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 19e:	f2 0f 11 04 10       	movsd  %xmm0,(%rax,%rdx,1)
 1a3:	41 01 ff             	add    %edi,%r15d
 1a6:	41 01 fe             	add    %edi,%r14d
 1a9:	45 8d 6d 08          	lea    0x8(%r13),%r13d
 1ad:	41 81 fd 40 1f 00 00 	cmp    $0x1f40,%r13d
 1b4:	75 8b                	jne    0x141
 1b6:	8d 9b 40 1f 00 00    	lea    0x1f40(%rbx),%ebx
 1bc:	8d 7f 01             	lea    0x1(%rdi),%edi
 1bf:	81 ff b0 04 00 00    	cmp    $0x4b0,%edi
 1c5:	44 8b 7d c0          	mov    -0x40(%rbp),%r15d
 1c9:	0f 85 51 ff ff ff    	jne    0x120
 1cf:	45 31 ff             	xor    %r15d,%r15d
 1d2:	44 89 e7             	mov    %r12d,%edi
 1d5:	f2 0f 10 6d a8       	movsd  -0x58(%rbp),%xmm5
 1da:	f2 0f 10 75 a0       	movsd  -0x60(%rbp),%xmm6
 1df:	41 be 03 00 00 00    	mov    $0x3,%r14d
 1e5:	45 31 ed             	xor    %r13d,%r13d
 1e8:	44 89 f1             	mov    %r14d,%ecx
 1eb:	48 69 c9 b5 81 4e 1b 	imul   $0x1b4e81b5,%rcx,%rcx
 1f2:	48 c1 e9 27          	shr    $0x27,%rcx
 1f6:	89 c9                	mov    %ecx,%ecx
 1f8:	89 fa                	mov    %edi,%edx
 1fa:	44 01 ea             	add    %r13d,%edx
 1fd:	69 c9 b0 04 00 00    	imul   $0x4b0,%ecx,%ecx
 203:	44 89 f6             	mov    %r14d,%esi
 206:	29 ce                	sub    %ecx,%esi
 208:	0f 57 c0             	xorps  %xmm0,%xmm0
 20b:	f2 0f 2a c6          	cvtsi2sd %esi,%xmm0
 20f:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 213:	f2 0f 11 04 10       	movsd  %xmm0,(%rax,%rdx,1)
 218:	45 01 fe             	add    %r15d,%r14d
 21b:	45 8d 6d 08          	lea    0x8(%r13),%r13d
 21f:	41 81 fd 80 25 00 00 	cmp    $0x2580,%r13d
 226:	75 c0                	jne    0x1e8
 228:	8d bf 80 25 00 00    	lea    0x2580(%rdi),%edi
 22e:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 232:	41 81 ff b0 04 00 00 	cmp    $0x4b0,%r15d
 239:	8b 75 c0             	mov    -0x40(%rbp),%esi
 23c:	75 a1                	jne    0x1df
 23e:	44 89 55 bc          	mov    %r10d,-0x44(%rbp)
 242:	31 c9                	xor    %ecx,%ecx
 244:	41 b9 08 00 00 00    	mov    $0x8,%r9d
 24a:	44 89 e3             	mov    %r12d,%ebx
 24d:	41 bb 01 00 00 00    	mov    $0x1,%r11d
 253:	41 89 de             	mov    %ebx,%r14d
 256:	45 89 dd             	mov    %r11d,%r13d
 259:	f2 42 0f 10 04 30    	movsd  (%rax,%r14,1),%xmm0
 25f:	f2 0f 59 c5          	mulsd  %xmm5,%xmm0
 263:	f2 42 0f 11 04 30    	movsd  %xmm0,(%rax,%r14,1)
 269:	45 8d 76 08          	lea    0x8(%r14),%r14d
 26d:	45 8d 6d ff          	lea    -0x1(%r13),%r13d
 271:	45 85 ed             	test   %r13d,%r13d
 274:	75 e3                	jne    0x259
 276:	44 89 65 c4          	mov    %r12d,-0x3c(%rbp)
 27a:	69 d1 e8 03 00 00    	imul   $0x3e8,%ecx,%edx
 280:	89 55 84             	mov    %edx,-0x7c(%rbp)
 283:	31 d2                	xor    %edx,%edx
 285:	45 31 f6             	xor    %r14d,%r14d
 288:	4c 89 f7             	mov    %r14,%rdi
 28b:	48 89 7d 88          	mov    %rdi,-0x78(%rbp)
 28f:	41 c1 e6 03          	shl    $0x3,%r14d
 293:	8b 7d 84             	mov    -0x7c(%rbp),%edi
 296:	41 89 fd             	mov    %edi,%r13d
 299:	41 c1 e5 03          	shl    $0x3,%r13d
 29d:	41 89 f4             	mov    %esi,%r12d
 2a0:	45 01 f4             	add    %r14d,%r12d
 2a3:	45 01 ec             	add    %r13d,%r12d
 2a6:	44 8b 55 bc          	mov    -0x44(%rbp),%r10d
 2aa:	44 89 d7             	mov    %r10d,%edi
 2ad:	44 01 f7             	add    %r14d,%edi
 2b0:	44 01 ef             	add    %r13d,%edi
 2b3:	41 89 d6             	mov    %edx,%r14d
 2b6:	45 31 ed             	xor    %r13d,%r13d
 2b9:	4d 89 c8             	mov    %r9,%r8
 2bc:	41 89 df             	mov    %ebx,%r15d
 2bf:	45 01 ef             	add    %r13d,%r15d
 2c2:	f2 42 0f 10 04 38    	movsd  (%rax,%r15,1),%xmm0
 2c8:	8b 75 c0             	mov    -0x40(%rbp),%esi
 2cb:	44 01 f6             	add    %r14d,%esi
 2ce:	f2 0f 10 0c 30       	movsd  (%rax,%rsi,1),%xmm1
 2d3:	f2 0f 10 14 38       	movsd  (%rax,%rdi,1),%xmm2
 2d8:	44 89 d6             	mov    %r10d,%esi
 2db:	44 01 f6             	add    %r14d,%esi
 2de:	f2 0f 10 1c 30       	movsd  (%rax,%rsi,1),%xmm3
 2e3:	8b 75 c0             	mov    -0x40(%rbp),%esi
 2e6:	f2 42 0f 10 24 20    	movsd  (%rax,%r12,1),%xmm4
 2ec:	f2 0f 59 ce          	mulsd  %xmm6,%xmm1
 2f0:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
 2f4:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
 2f8:	f2 0f 59 dc          	mulsd  %xmm4,%xmm3
 2fc:	f2 0f 58 cb          	addsd  %xmm3,%xmm1
 300:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 304:	f2 42 0f 11 04 38    	movsd  %xmm0,(%rax,%r15,1)
 30a:	45 8d b6 40 1f 00 00 	lea    0x1f40(%r14),%r14d
 311:	45 8d 6d 08          	lea    0x8(%r13),%r13d
 315:	45 39 e8             	cmp    %r13d,%r8d
 318:	75 a2                	jne    0x2bc
 31a:	8d 52 08             	lea    0x8(%rdx),%edx
 31d:	4c 8b 75 88          	mov    -0x78(%rbp),%r14
 321:	45 8d 76 01          	lea    0x1(%r14),%r14d
 325:	41 81 fe e8 03 00 00 	cmp    $0x3e8,%r14d
 32c:	0f 85 56 ff ff ff    	jne    0x288
 332:	45 8d 49 08          	lea    0x8(%r9),%r9d
 336:	8d 9b 80 25 00 00    	lea    0x2580(%rbx),%ebx
 33c:	45 8d 5b 01          	lea    0x1(%r11),%r11d
 340:	8d 49 01             	lea    0x1(%rcx),%ecx
 343:	81 f9 b0 04 00 00    	cmp    $0x4b0,%ecx
 349:	44 8b 65 c4          	mov    -0x3c(%rbp),%r12d
 34d:	0f 85 00 ff ff ff    	jne    0x253
 353:	45 31 ed             	xor    %r13d,%r13d
 356:	44 8b b0 8c 04 00 00 	mov    0x48c(%rax),%r14d
 35d:	be 00 04 00 00       	mov    $0x400,%esi
 362:	ba 16 00 00 00       	mov    $0x16,%edx
 367:	b9 01 00 00 00       	mov    $0x1,%ecx
 36c:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 370:	48 89 df             	mov    %rbx,%rdi
 373:	45 89 f0             	mov    %r14d,%r8d
 376:	e8 61 1d ff ff       	call   0xffffffffffff20dc
 37b:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 382:	b9 26 04 00 00       	mov    $0x426,%ecx
 387:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 38b:	48 89 d6             	mov    %rdx,%rsi
 38e:	89 4c 30 20          	mov    %ecx,0x20(%rax,%rsi,1)
 392:	ba 17 04 00 00       	mov    $0x417,%edx
 397:	8d 4e 20             	lea    0x20(%rsi),%ecx
 39a:	48 89 df             	mov    %rbx,%rdi
 39d:	4c 89 f0             	mov    %r14,%rax
 3a0:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 3a4:	44 89 f6             	mov    %r14d,%esi
 3a7:	e8 c6 1d ff ff       	call   0xffffffffffff2172
 3ac:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 3b3:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
 3b6:	89 ce                	mov    %ecx,%esi
 3b8:	45 31 ff             	xor    %r15d,%r15d
 3bb:	45 31 e4             	xor    %r12d,%r12d
 3be:	45 31 f6             	xor    %r14d,%r14d
 3c1:	4c 89 e9             	mov    %r13,%rcx
 3c4:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
 3c8:	4c 89 f9             	mov    %r15,%rcx
 3cb:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 3cf:	48 89 f1             	mov    %rsi,%rcx
 3d2:	48 89 4d 98          	mov    %rcx,-0x68(%rbp)
 3d6:	44 89 e9             	mov    %r13d,%ecx
 3d9:	48 ba cd cc cc cc 00 	movabs $0xcccccccd,%rdx
 3e0:	00 00 00 
 3e3:	48 0f af ca          	imul   %rdx,%rcx
 3e7:	48 c1 e9 24          	shr    $0x24,%rcx
 3eb:	89 c9                	mov    %ecx,%ecx
 3ed:	6b c9 14             	imul   $0x14,%ecx,%ecx
 3f0:	44 89 fa             	mov    %r15d,%edx
 3f3:	01 ca                	add    %ecx,%edx
 3f5:	85 d2                	test   %edx,%edx
 3f7:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 3fb:	75 20                	jne    0x41d
 3fd:	be 0a 00 00 00       	mov    $0xa,%esi
 402:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 406:	48 89 df             	mov    %rbx,%rdi
 409:	e8 1e 1d ff ff       	call   0xffffffffffff212c
 40e:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 412:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 416:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 41d:	89 f1                	mov    %esi,%ecx
 41f:	44 01 f1             	add    %r14d,%ecx
 422:	f2 0f 10 04 08       	movsd  (%rax,%rcx,1),%xmm0
 427:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 42b:	f2 0f 11 44 08 10    	movsd  %xmm0,0x10(%rax,%rcx,1)
 431:	41 b8 28 04 00 00    	mov    $0x428,%r8d
 437:	8d 49 10             	lea    0x10(%rcx),%ecx
 43a:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 43e:	48 89 df             	mov    %rbx,%rdi
 441:	89 d6                	mov    %edx,%esi
 443:	44 89 c2             	mov    %r8d,%edx
 446:	e8 27 1d ff ff       	call   0xffffffffffff2172
 44b:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 44f:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 456:	45 8d 6d 01          	lea    0x1(%r13),%r13d
 45a:	45 8d 7f ff          	lea    -0x1(%r15),%r15d
 45e:	45 8d 76 08          	lea    0x8(%r14),%r14d
 462:	41 81 fe 80 25 00 00 	cmp    $0x2580,%r14d
 469:	0f 85 67 ff ff ff    	jne    0x3d6
 46f:	8d b6 80 25 00 00    	lea    0x2580(%rsi),%esi
 475:	4c 8b 6d 88          	mov    -0x78(%rbp),%r13
 479:	45 8d ad b0 04 00 00 	lea    0x4b0(%r13),%r13d
 480:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 484:	45 8d bf 50 fb ff ff 	lea    -0x4b0(%r15),%r15d
 48b:	45 8d 64 24 01       	lea    0x1(%r12),%r12d
 490:	41 81 fc b0 04 00 00 	cmp    $0x4b0,%r12d
 497:	0f 85 21 ff ff ff    	jne    0x3be
 49d:	b9 26 04 00 00       	mov    $0x426,%ecx
 4a2:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 4a6:	42 89 0c 30          	mov    %ecx,(%rax,%r14,1)
 4aa:	ba 30 04 00 00       	mov    $0x430,%edx
 4af:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 4b3:	48 89 df             	mov    %rbx,%rdi
 4b6:	4c 8b 7d b0          	mov    -0x50(%rbp),%r15
 4ba:	44 89 fe             	mov    %r15d,%esi
 4bd:	44 89 f1             	mov    %r14d,%ecx
 4c0:	e8 ad 1c ff ff       	call   0xffffffffffff2172
 4c5:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 4cc:	be 41 04 00 00       	mov    $0x441,%esi
 4d1:	ba 16 00 00 00       	mov    $0x16,%edx
 4d6:	b9 01 00 00 00       	mov    $0x1,%ecx
 4db:	48 89 df             	mov    %rbx,%rdi
 4de:	45 89 f8             	mov    %r15d,%r8d
 4e1:	e8 f6 1b ff ff       	call   0xffffffffffff20dc
 4e6:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 4ed:	48 89 df             	mov    %rbx,%rdi
 4f0:	8b 75 c4             	mov    -0x3c(%rbp),%esi
 4f3:	e8 44 1b ff ff       	call   0xffffffffffff203c
 4f8:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 4ff:	48 89 df             	mov    %rbx,%rdi
 502:	8b 75 c0             	mov    -0x40(%rbp),%esi
 505:	e8 32 1b ff ff       	call   0xffffffffffff203c
 50a:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 511:	48 89 df             	mov    %rbx,%rdi
 514:	8b 75 bc             	mov    -0x44(%rbp),%esi
 517:	e8 20 1b ff ff       	call   0xffffffffffff203c
 51c:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 523:	41 8d 46 30          	lea    0x30(%r14),%eax
 527:	89 83 78 11 00 00    	mov    %eax,0x1178(%rbx)
 52d:	31 c0                	xor    %eax,%eax
 52f:	48 83 c4 68          	add    $0x68,%rsp
 533:	5b                   	pop    %rbx
 534:	41 5c                	pop    %r12
 536:	41 5d                	pop    %r13
 538:	41 5e                	pop    %r14
 53a:	41 5f                	pop    %r15
 53c:	5d                   	pop    %rbp
 53d:	c3                   	ret
