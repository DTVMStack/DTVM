
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-main/func-58-0-7fcea5625000.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	48 83 ec 40          	sub    $0x40,%rsp
   8:	48 89 7d c8          	mov    %rdi,-0x38(%rbp)
   c:	f2 0f 11 45 d0       	movsd  %xmm0,-0x30(%rbp)
  11:	89 75 dc             	mov    %esi,-0x24(%rbp)
  14:	48 b8 00 00 00 00 00 	movabs $0x43f0000000000000,%rax
  1b:	00 f0 43 
  1e:	66 48 0f 6e c8       	movq   %rax,%xmm1
  23:	f2 0f 11 4d e0       	movsd  %xmm1,-0x20(%rbp)
  28:	31 c0                	xor    %eax,%eax
  2a:	31 c0                	xor    %eax,%eax
  2c:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
  33:	ff 
  34:	48 8b 87 b8 11 00 00 	mov    0x11b8(%rdi),%rax
  3b:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
  3f:	66 48 0f 7e c0       	movq   %xmm0,%rax
  44:	48 89 c1             	mov    %rax,%rcx
  47:	48 89 4d f0          	mov    %rcx,-0x10(%rbp)
  4b:	48 c1 e8 34          	shr    $0x34,%rax
  4f:	89 c0                	mov    %eax,%eax
  51:	25 ff 07 00 00       	and    $0x7ff,%eax
  56:	89 c1                	mov    %eax,%ecx
  58:	89 4d fc             	mov    %ecx,-0x4(%rbp)
  5b:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  60:	0f 84 ad 00 00 00    	je     0x113
  66:	8b 45 fc             	mov    -0x4(%rbp),%eax
  69:	85 c0                	test   %eax,%eax
  6b:	75 6b                	jne    0xd8
  6d:	f2 0f 10 45 d0       	movsd  -0x30(%rbp),%xmm0
  72:	0f 57 c9             	xorps  %xmm1,%xmm1
  75:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
  79:	0f 95 c0             	setne  %al
  7c:	0f 9a c1             	setp   %cl
  7f:	08 c8                	or     %cl,%al
  81:	0f b6 c0             	movzbl %al,%eax
  84:	85 c0                	test   %eax,%eax
  86:	75 17                	jne    0x9f
  88:	f2 0f 10 45 d0       	movsd  -0x30(%rbp),%xmm0
  8d:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
  91:	8b 4d dc             	mov    -0x24(%rbp),%ecx
  94:	31 d2                	xor    %edx,%edx
  96:	89 14 08             	mov    %edx,(%rax,%rcx,1)
  99:	48 83 c4 40          	add    $0x40,%rsp
  9d:	5d                   	pop    %rbp
  9e:	c3                   	ret
  9f:	f2 0f 10 45 d0       	movsd  -0x30(%rbp),%xmm0
  a4:	8b 75 dc             	mov    -0x24(%rbp),%esi
  a7:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
  ab:	f2 0f 10 4d e0       	movsd  -0x20(%rbp),%xmm1
  b0:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
  b4:	e8 47 ff ff ff       	call   0x0
  b9:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
  bd:	8b 55 dc             	mov    -0x24(%rbp),%edx
  c0:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
  c7:	89 d1                	mov    %edx,%ecx
  c9:	8b 14 10             	mov    (%rax,%rdx,1),%edx
  cc:	8d 52 c0             	lea    -0x40(%rdx),%edx
  cf:	89 14 08             	mov    %edx,(%rax,%rcx,1)
  d2:	48 83 c4 40          	add    $0x40,%rsp
  d6:	5d                   	pop    %rbp
  d7:	c3                   	ret
  d8:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  dc:	48 8b 4d e8          	mov    -0x18(%rbp),%rcx
  e0:	8b 75 fc             	mov    -0x4(%rbp),%esi
  e3:	8b 55 dc             	mov    -0x24(%rbp),%edx
  e6:	8d b6 02 fc ff ff    	lea    -0x3fe(%rsi),%esi
  ec:	89 34 11             	mov    %esi,(%rcx,%rdx,1)
  ef:	48 b9 ff ff ff ff ff 	movabs $0x800fffffffffffff,%rcx
  f6:	ff 0f 80 
  f9:	48 21 c8             	and    %rcx,%rax
  fc:	48 b9 00 00 00 00 00 	movabs $0x3fe0000000000000,%rcx
 103:	00 e0 3f 
 106:	48 09 c8             	or     %rcx,%rax
 109:	66 48 0f 6e c0       	movq   %rax,%xmm0
 10e:	f2 0f 11 45 d0       	movsd  %xmm0,-0x30(%rbp)
 113:	f2 0f 10 45 d0       	movsd  -0x30(%rbp),%xmm0
 118:	f2 0f 11 45 c0       	movsd  %xmm0,-0x40(%rbp)
 11d:	f2 0f 10 45 c0       	movsd  -0x40(%rbp),%xmm0
 122:	48 83 c4 40          	add    $0x40,%rsp
 126:	5d                   	pop    %rbp
 127:	c3                   	ret
