
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-combined/func-41-0-7fd818a19000.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	55                   	push   %rbp
       1:	48 89 e5             	mov    %rsp,%rbp
       4:	48 81 ec a0 01 00 00 	sub    $0x1a0,%rsp
       b:	48 89 bd d8 fe ff ff 	mov    %rdi,-0x128(%rbp)
      12:	89 b5 e4 fe ff ff    	mov    %esi,-0x11c(%rbp)
      18:	89 d0                	mov    %edx,%eax
      1a:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
      20:	89 8d ec fe ff ff    	mov    %ecx,-0x114(%rbp)
      26:	44 89 85 f0 fe ff ff 	mov    %r8d,-0x110(%rbp)
      2d:	44 89 8d f4 fe ff ff 	mov    %r9d,-0x10c(%rbp)
      34:	48 b8 00 00 00 00 00 	movabs $0x7ff0000000000000,%rax
      3b:	00 f0 7f 
      3e:	66 48 0f 6e c0       	movq   %rax,%xmm0
      43:	f2 0f 11 85 f8 fe ff 	movsd  %xmm0,-0x108(%rbp)
      4a:	ff 
      4b:	48 b8 00 00 00 00 00 	movabs $0x41b0000000000000,%rax
      52:	00 b0 41 
      55:	66 48 0f 6e c0       	movq   %rax,%xmm0
      5a:	f2 0f 11 85 00 ff ff 	movsd  %xmm0,-0x100(%rbp)
      61:	ff 
      62:	48 b8 00 00 00 00 00 	movabs $0x41f0000000000000,%rax
      69:	00 f0 41 
      6c:	66 48 0f 6e c0       	movq   %rax,%xmm0
      71:	f2 0f 11 85 08 ff ff 	movsd  %xmm0,-0xf8(%rbp)
      78:	ff 
      79:	48 b8 00 00 00 00 65 	movabs $0x41cdcd6500000000,%rax
      80:	cd cd 41 
      83:	66 48 0f 6e c0       	movq   %rax,%xmm0
      88:	f2 0f 11 85 10 ff ff 	movsd  %xmm0,-0xf0(%rbp)
      8f:	ff 
      90:	48 b8 00 00 00 00 00 	movabs $0x4340000000000000,%rax
      97:	00 40 43 
      9a:	66 48 0f 6e c0       	movq   %rax,%xmm0
      9f:	f2 0f 11 85 18 ff ff 	movsd  %xmm0,-0xe8(%rbp)
      a6:	ff 
      a7:	48 b8 01 00 00 00 00 	movabs $0x4340000000000001,%rax
      ae:	00 40 43 
      b1:	66 48 0f 6e c0       	movq   %rax,%xmm0
      b6:	f2 0f 11 85 20 ff ff 	movsd  %xmm0,-0xe0(%rbp)
      bd:	ff 
      be:	48 b8 00 00 00 00 00 	movabs $0x3fe0000000000000,%rax
      c5:	00 e0 3f 
      c8:	66 48 0f 6e c0       	movq   %rax,%xmm0
      cd:	f2 0f 11 85 28 ff ff 	movsd  %xmm0,-0xd8(%rbp)
      d4:	ff 
      d5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
      dc:	00 f0 3f 
      df:	66 48 0f 6e c0       	movq   %rax,%xmm0
      e4:	f2 0f 11 85 30 ff ff 	movsd  %xmm0,-0xd0(%rbp)
      eb:	ff 
      ec:	48 b8 00 00 00 00 00 	movabs $0x3ff8000000000000,%rax
      f3:	00 f8 3f 
      f6:	66 48 0f 6e c0       	movq   %rax,%xmm0
      fb:	f2 0f 11 85 38 ff ff 	movsd  %xmm0,-0xc8(%rbp)
     102:	ff 
     103:	48 b8 00 00 00 00 00 	movabs $0x4030000000000000,%rax
     10a:	00 30 40 
     10d:	66 48 0f 6e c0       	movq   %rax,%xmm0
     112:	f2 0f 11 85 40 ff ff 	movsd  %xmm0,-0xc0(%rbp)
     119:	ff 
     11a:	48 b8 00 00 00 00 00 	movabs $0x41e0000000000000,%rax
     121:	00 e0 41 
     124:	66 48 0f 6e c0       	movq   %rax,%xmm0
     129:	f2 0f 11 85 48 ff ff 	movsd  %xmm0,-0xb8(%rbp)
     130:	ff 
     131:	31 c0                	xor    %eax,%eax
     133:	31 c0                	xor    %eax,%eax
     135:	31 c0                	xor    %eax,%eax
     137:	31 c0                	xor    %eax,%eax
     139:	31 c0                	xor    %eax,%eax
     13b:	31 c0                	xor    %eax,%eax
     13d:	31 c0                	xor    %eax,%eax
     13f:	31 c0                	xor    %eax,%eax
     141:	31 c0                	xor    %eax,%eax
     143:	31 c0                	xor    %eax,%eax
     145:	31 c0                	xor    %eax,%eax
     147:	31 c0                	xor    %eax,%eax
     149:	31 c0                	xor    %eax,%eax
     14b:	31 c0                	xor    %eax,%eax
     14d:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
     153:	31 c0                	xor    %eax,%eax
     155:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
     15b:	31 c0                	xor    %eax,%eax
     15d:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
     163:	31 c0                	xor    %eax,%eax
     165:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
     16b:	31 c0                	xor    %eax,%eax
     16d:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
     173:	31 c0                	xor    %eax,%eax
     175:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
     17b:	31 c0                	xor    %eax,%eax
     17d:	89 85 68 ff ff ff    	mov    %eax,-0x98(%rbp)
     183:	31 c0                	xor    %eax,%eax
     185:	89 85 6c ff ff ff    	mov    %eax,-0x94(%rbp)
     18b:	31 c0                	xor    %eax,%eax
     18d:	89 85 70 ff ff ff    	mov    %eax,-0x90(%rbp)
     193:	31 c0                	xor    %eax,%eax
     195:	89 85 74 ff ff ff    	mov    %eax,-0x8c(%rbp)
     19b:	31 c0                	xor    %eax,%eax
     19d:	89 85 78 ff ff ff    	mov    %eax,-0x88(%rbp)
     1a3:	31 c0                	xor    %eax,%eax
     1a5:	89 85 7c ff ff ff    	mov    %eax,-0x84(%rbp)
     1ab:	31 c0                	xor    %eax,%eax
     1ad:	89 45 80             	mov    %eax,-0x80(%rbp)
     1b0:	31 c0                	xor    %eax,%eax
     1b2:	89 45 84             	mov    %eax,-0x7c(%rbp)
     1b5:	31 c0                	xor    %eax,%eax
     1b7:	48 89 45 88          	mov    %rax,-0x78(%rbp)
     1bb:	31 c0                	xor    %eax,%eax
     1bd:	48 89 45 90          	mov    %rax,-0x70(%rbp)
     1c1:	0f 57 c0             	xorps  %xmm0,%xmm0
     1c4:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
     1c9:	31 c0                	xor    %eax,%eax
     1cb:	89 45 a0             	mov    %eax,-0x60(%rbp)
     1ce:	31 c0                	xor    %eax,%eax
     1d0:	89 45 a4             	mov    %eax,-0x5c(%rbp)
     1d3:	31 c0                	xor    %eax,%eax
     1d5:	89 45 a8             	mov    %eax,-0x58(%rbp)
     1d8:	31 c0                	xor    %eax,%eax
     1da:	89 45 ac             	mov    %eax,-0x54(%rbp)
     1dd:	0f 57 c0             	xorps  %xmm0,%xmm0
     1e0:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
     1e5:	31 c0                	xor    %eax,%eax
     1e7:	89 45 bc             	mov    %eax,-0x44(%rbp)
     1ea:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
     1f1:	ff 
     1f2:	48 8b 87 b8 11 00 00 	mov    0x11b8(%rdi),%rax
     1f9:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     1fd:	8b 8f 78 11 00 00    	mov    0x1178(%rdi),%ecx
     203:	89 c8                	mov    %ecx,%eax
     205:	8d 80 90 fc ff ff    	lea    -0x370(%rax),%eax
     20b:	89 45 cc             	mov    %eax,-0x34(%rbp)
     20e:	8d 89 90 fc ff ff    	lea    -0x370(%rcx),%ecx
     214:	89 8f 78 11 00 00    	mov    %ecx,0x1178(%rdi)
     21a:	89 c1                	mov    %eax,%ecx
     21c:	8d 49 37             	lea    0x37(%rcx),%ecx
     21f:	89 4d d0             	mov    %ecx,-0x30(%rbp)
     222:	89 c2                	mov    %eax,%edx
     224:	b9 fe ff ff ff       	mov    $0xfffffffe,%ecx
     229:	8d 92 50 01 00 00    	lea    0x150(%rdx),%edx
     22f:	29 d1                	sub    %edx,%ecx
     231:	89 4d d4             	mov    %ecx,-0x2c(%rbp)
     234:	89 c1                	mov    %eax,%ecx
     236:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
     23c:	83 c9 09             	or     $0x9,%ecx
     23f:	89 4d d8             	mov    %ecx,-0x28(%rbp)
     242:	89 c1                	mov    %eax,%ecx
     244:	8d 89 94 02 00 00    	lea    0x294(%rcx),%ecx
     24a:	89 4d dc             	mov    %ecx,-0x24(%rbp)
     24d:	89 c1                	mov    %eax,%ecx
     24f:	8d 89 70 01 00 00    	lea    0x170(%rcx),%ecx
     255:	83 c9 04             	or     $0x4,%ecx
     258:	89 4d e0             	mov    %ecx,-0x20(%rbp)
     25b:	89 c1                	mov    %eax,%ecx
     25d:	8d 89 90 02 00 00    	lea    0x290(%rcx),%ecx
     263:	89 4d e4             	mov    %ecx,-0x1c(%rbp)
     266:	89 c1                	mov    %eax,%ecx
     268:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
     26e:	89 4d e8             	mov    %ecx,-0x18(%rbp)
     271:	89 c2                	mov    %eax,%edx
     273:	31 c9                	xor    %ecx,%ecx
     275:	8d 92 50 01 00 00    	lea    0x150(%rdx),%edx
     27b:	29 d1                	sub    %edx,%ecx
     27d:	89 4d ec             	mov    %ecx,-0x14(%rbp)
     280:	8d 40 38             	lea    0x38(%rax),%eax
     283:	89 45 f0             	mov    %eax,-0x10(%rbp)
     286:	31 c0                	xor    %eax,%eax
     288:	89 45 f4             	mov    %eax,-0xc(%rbp)
     28b:	31 c0                	xor    %eax,%eax
     28d:	89 45 f8             	mov    %eax,-0x8(%rbp)
     290:	31 c0                	xor    %eax,%eax
     292:	89 45 fc             	mov    %eax,-0x4(%rbp)
     295:	8b 55 f8             	mov    -0x8(%rbp),%edx
     298:	8b 45 fc             	mov    -0x4(%rbp),%eax
     29b:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     2a1:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
     2a7:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
     2ac:	29 d1                	sub    %edx,%ecx
     2ae:	39 c8                	cmp    %ecx,%eax
     2b0:	0f 8f ad 4b 00 00    	jg     0x4e63
     2b6:	8b 55 fc             	mov    -0x4(%rbp),%edx
     2b9:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     2bd:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
     2c3:	8b 75 f8             	mov    -0x8(%rbp),%esi
     2c6:	01 f2                	add    %esi,%edx
     2c8:	89 55 f8             	mov    %edx,-0x8(%rbp)
     2cb:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
     2cf:	89 c1                	mov    %eax,%ecx
     2d1:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     2d4:	85 c0                	test   %eax,%eax
     2d6:	0f 84 e4 04 00 00    	je     0x7c0
     2dc:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
     2e2:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     2e8:	8b 45 fc             	mov    -0x4(%rbp),%eax
     2eb:	25 ff 00 00 00       	and    $0xff,%eax
     2f0:	89 c1                	mov    %eax,%ecx
     2f2:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     2f5:	85 c0                	test   %eax,%eax
     2f7:	74 73                	je     0x36c
     2f9:	8b 45 fc             	mov    -0x4(%rbp),%eax
     2fc:	83 f8 25             	cmp    $0x25,%eax
     2ff:	0f 85 99 04 00 00    	jne    0x79e
     305:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     30b:	89 c1                	mov    %eax,%ecx
     30d:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
     313:	89 45 fc             	mov    %eax,-0x4(%rbp)
     316:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     31a:	8b 4d fc             	mov    -0x4(%rbp),%ecx
     31d:	8d 49 01             	lea    0x1(%rcx),%ecx
     320:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
     324:	83 f8 25             	cmp    $0x25,%eax
     327:	74 0b                	je     0x334
     329:	8b 45 fc             	mov    -0x4(%rbp),%eax
     32c:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     332:	eb 44                	jmp    0x378
     334:	8b 4d fc             	mov    -0x4(%rbp),%ecx
     337:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     33b:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
     341:	8d 52 01             	lea    0x1(%rdx),%edx
     344:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
     34a:	89 ca                	mov    %ecx,%edx
     34c:	0f b6 44 10 02       	movzbl 0x2(%rax,%rdx,1),%eax
     351:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
     357:	8d 49 02             	lea    0x2(%rcx),%ecx
     35a:	89 ca                	mov    %ecx,%edx
     35c:	89 95 e8 fe ff ff    	mov    %edx,-0x118(%rbp)
     362:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     365:	83 f8 25             	cmp    $0x25,%eax
     368:	74 ac                	je     0x316
     36a:	eb 0c                	jmp    0x378
     36c:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     372:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
     378:	8b 55 f8             	mov    -0x8(%rbp),%edx
     37b:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
     381:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
     387:	29 c8                	sub    %ecx,%eax
     389:	89 c1                	mov    %eax,%ecx
     38b:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     38e:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
     393:	29 d1                	sub    %edx,%ecx
     395:	89 ca                	mov    %ecx,%edx
     397:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
     39d:	39 c8                	cmp    %ecx,%eax
     39f:	0f 8f be 4a 00 00    	jg     0x4e63
     3a5:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     3ab:	85 c0                	test   %eax,%eax
     3ad:	74 44                	je     0x3f3
     3af:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     3b3:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
     3b9:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
     3bd:	83 e0 20             	and    $0x20,%eax
     3c0:	85 c0                	test   %eax,%eax
     3c2:	75 2f                	jne    0x3f3
     3c4:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     3cb:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
     3d1:	8b 55 fc             	mov    -0x4(%rbp),%edx
     3d4:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
     3da:	e8 f3 6c fe ff       	call   0xfffffffffffe70d2
     3df:	89 c1                	mov    %eax,%ecx
     3e1:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     3e8:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     3ef:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     3f3:	8b 45 fc             	mov    -0x4(%rbp),%eax
     3f6:	85 c0                	test   %eax,%eax
     3f8:	0f 85 97 fe ff ff    	jne    0x295
     3fe:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     402:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     408:	89 ca                	mov    %ecx,%edx
     40a:	8d 52 01             	lea    0x1(%rdx),%edx
     40d:	89 55 fc             	mov    %edx,-0x4(%rbp)
     410:	0f be 44 08 01       	movsbl 0x1(%rax,%rcx,1),%eax
     415:	89 c1                	mov    %eax,%ecx
     417:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
     41d:	8d 40 d0             	lea    -0x30(%rax),%eax
     420:	89 c1                	mov    %eax,%ecx
     422:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
     428:	83 f8 09             	cmp    $0x9,%eax
     42b:	76 10                	jbe    0x43d
     42d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     432:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
     438:	e9 84 00 00 00       	jmp    0x4c1
     43d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     441:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     447:	8b 55 f4             	mov    -0xc(%rbp),%edx
     44a:	44 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%r8d
     451:	8b 75 fc             	mov    -0x4(%rbp),%esi
     454:	41 89 c9             	mov    %ecx,%r9d
     457:	89 cf                	mov    %ecx,%edi
     459:	44 0f b6 54 38 02    	movzbl 0x2(%rax,%rdi,1),%r10d
     45f:	41 83 fa 24          	cmp    $0x24,%r10d
     463:	40 0f 94 c7          	sete   %dil
     467:	40 0f b6 ff          	movzbl %dil,%edi
     46b:	89 bd 54 ff ff ff    	mov    %edi,-0xac(%rbp)
     471:	45 8d 49 03          	lea    0x3(%r9),%r9d
     475:	41 83 fa 24          	cmp    $0x24,%r10d
     479:	41 0f 44 f1          	cmove  %r9d,%esi
     47d:	89 75 fc             	mov    %esi,-0x4(%rbp)
     480:	41 89 f9             	mov    %edi,%r9d
     483:	be ff ff ff ff       	mov    $0xffffffff,%esi
     488:	45 85 c9             	test   %r9d,%r9d
     48b:	41 0f 45 f0          	cmovne %r8d,%esi
     48f:	89 b5 64 ff ff ff    	mov    %esi,-0x9c(%rbp)
     495:	41 89 f8             	mov    %edi,%r8d
     498:	be 01 00 00 00       	mov    $0x1,%esi
     49d:	45 85 c0             	test   %r8d,%r8d
     4a0:	0f 45 d6             	cmovne %esi,%edx
     4a3:	89 55 f4             	mov    %edx,-0xc(%rbp)
     4a6:	be 03 00 00 00       	mov    $0x3,%esi
     4ab:	ba 01 00 00 00       	mov    $0x1,%edx
     4b0:	85 ff                	test   %edi,%edi
     4b2:	0f 45 d6             	cmovne %esi,%edx
     4b5:	01 d1                	add    %edx,%ecx
     4b7:	0f be 04 08          	movsbl (%rax,%rcx,1),%eax
     4bb:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
     4c1:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
     4c7:	31 c9                	xor    %ecx,%ecx
     4c9:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
     4cf:	8d 40 e0             	lea    -0x20(%rax),%eax
     4d2:	89 c1                	mov    %eax,%ecx
     4d4:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     4da:	83 f8 1f             	cmp    $0x1f,%eax
     4dd:	76 0e                	jbe    0x4ed
     4df:	8b 45 fc             	mov    -0x4(%rbp),%eax
     4e2:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     4e8:	e9 9b 00 00 00       	jmp    0x588
     4ed:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     4f3:	b8 01 00 00 00       	mov    $0x1,%eax
     4f8:	d3 e0                	shl    %cl,%eax
     4fa:	89 c1                	mov    %eax,%ecx
     4fc:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
     502:	25 89 28 01 00       	and    $0x12889,%eax
     507:	85 c0                	test   %eax,%eax
     509:	75 0b                	jne    0x516
     50b:	8b 45 fc             	mov    -0x4(%rbp),%eax
     50e:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     514:	eb 72                	jmp    0x588
     516:	31 c0                	xor    %eax,%eax
     518:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
     51e:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
     524:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     528:	8b 4d fc             	mov    -0x4(%rbp),%ecx
     52b:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
     531:	89 cf                	mov    %ecx,%edi
     533:	8d 7f 01             	lea    0x1(%rdi),%edi
     536:	89 bd e8 fe ff ff    	mov    %edi,-0x118(%rbp)
     53c:	09 f2                	or     %esi,%edx
     53e:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
     544:	0f be 44 08 01       	movsbl 0x1(%rax,%rcx,1),%eax
     549:	89 c1                	mov    %eax,%ecx
     54b:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
     551:	8d 40 e0             	lea    -0x20(%rax),%eax
     554:	89 c1                	mov    %eax,%ecx
     556:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
     55c:	83 f8 1f             	cmp    $0x1f,%eax
     55f:	77 27                	ja     0x588
     561:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
     567:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     56d:	89 45 fc             	mov    %eax,-0x4(%rbp)
     570:	b8 01 00 00 00       	mov    $0x1,%eax
     575:	d3 e0                	shl    %cl,%eax
     577:	89 c1                	mov    %eax,%ecx
     579:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
     57f:	25 89 28 01 00       	and    $0x12889,%eax
     584:	85 c0                	test   %eax,%eax
     586:	75 96                	jne    0x51e
     588:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
     58e:	83 f8 2a             	cmp    $0x2a,%eax
     591:	0f 85 1a 01 00 00    	jne    0x6b1
     597:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     59b:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     5a1:	0f be 44 08 01       	movsbl 0x1(%rax,%rcx,1),%eax
     5a6:	8d 40 d0             	lea    -0x30(%rax),%eax
     5a9:	89 c1                	mov    %eax,%ecx
     5ab:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     5ae:	83 f8 09             	cmp    $0x9,%eax
     5b1:	77 68                	ja     0x61b
     5b3:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     5b7:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     5bd:	0f b6 44 08 02       	movzbl 0x2(%rax,%rcx,1),%eax
     5c2:	83 f8 24             	cmp    $0x24,%eax
     5c5:	75 54                	jne    0x61b
     5c7:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     5cb:	8b 95 f0 fe ff ff    	mov    -0x110(%rbp),%edx
     5d1:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     5d7:	8b 7d fc             	mov    -0x4(%rbp),%edi
     5da:	8b b5 f4 fe ff ff    	mov    -0x10c(%rbp),%esi
     5e0:	c1 e7 02             	shl    $0x2,%edi
     5e3:	01 fe                	add    %edi,%esi
     5e5:	bf 0a 00 00 00       	mov    $0xa,%edi
     5ea:	89 3c 30             	mov    %edi,(%rax,%rsi,1)
     5ed:	89 ce                	mov    %ecx,%esi
     5ef:	8d 76 03             	lea    0x3(%rsi),%esi
     5f2:	89 b5 60 ff ff ff    	mov    %esi,-0xa0(%rbp)
     5f8:	0f be 4c 08 01       	movsbl 0x1(%rax,%rcx,1),%ecx
     5fd:	c1 e1 03             	shl    $0x3,%ecx
     600:	01 d1                	add    %edx,%ecx
     602:	8d 89 80 fe ff ff    	lea    -0x180(%rcx),%ecx
     608:	8b 04 08             	mov    (%rax,%rcx,1),%eax
     60b:	89 85 68 ff ff ff    	mov    %eax,-0x98(%rbp)
     611:	b8 01 00 00 00       	mov    $0x1,%eax
     616:	89 45 f4             	mov    %eax,-0xc(%rbp)
     619:	eb 61                	jmp    0x67c
     61b:	8b 45 f4             	mov    -0xc(%rbp),%eax
     61e:	85 c0                	test   %eax,%eax
     620:	0f 85 e0 07 00 00    	jne    0xe06
     626:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     62c:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     632:	8d 49 01             	lea    0x1(%rcx),%ecx
     635:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
     63b:	85 c0                	test   %eax,%eax
     63d:	75 12                	jne    0x651
     63f:	31 c0                	xor    %eax,%eax
     641:	89 45 f4             	mov    %eax,-0xc(%rbp)
     644:	31 c0                	xor    %eax,%eax
     646:	89 85 68 ff ff ff    	mov    %eax,-0x98(%rbp)
     64c:	e9 0c 05 00 00       	jmp    0xb5d
     651:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     655:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     65b:	89 ca                	mov    %ecx,%edx
     65d:	8b 34 08             	mov    (%rax,%rcx,1),%esi
     660:	89 f1                	mov    %esi,%ecx
     662:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     668:	8d 76 04             	lea    0x4(%rsi),%esi
     66b:	89 34 10             	mov    %esi,(%rax,%rdx,1)
     66e:	8b 04 08             	mov    (%rax,%rcx,1),%eax
     671:	89 85 68 ff ff ff    	mov    %eax,-0x98(%rbp)
     677:	31 c0                	xor    %eax,%eax
     679:	89 45 f4             	mov    %eax,-0xc(%rbp)
     67c:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
     682:	83 f8 ff             	cmp    $0xffffffff,%eax
     685:	0f 8f d2 04 00 00    	jg     0xb5d
     68b:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
     691:	8b 95 68 ff ff ff    	mov    -0x98(%rbp),%edx
     697:	31 c9                	xor    %ecx,%ecx
     699:	29 d1                	sub    %edx,%ecx
     69b:	89 8d 68 ff ff ff    	mov    %ecx,-0x98(%rbp)
     6a1:	0d 00 20 00 00       	or     $0x2000,%eax
     6a6:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
     6ac:	e9 ac 04 00 00       	jmp    0xb5d
     6b1:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
     6b7:	31 c9                	xor    %ecx,%ecx
     6b9:	89 8d 68 ff ff ff    	mov    %ecx,-0x98(%rbp)
     6bf:	8d 40 d0             	lea    -0x30(%rax),%eax
     6c2:	89 c1                	mov    %eax,%ecx
     6c4:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     6c7:	83 f8 09             	cmp    $0x9,%eax
     6ca:	76 11                	jbe    0x6dd
     6cc:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     6d2:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
     6d8:	e9 80 04 00 00       	jmp    0xb5d
     6dd:	31 c0                	xor    %eax,%eax
     6df:	89 85 68 ff ff ff    	mov    %eax,-0x98(%rbp)
     6e5:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
     6eb:	3d cc cc cc 0c       	cmp    $0xccccccc,%eax
     6f0:	77 71                	ja     0x763
     6f2:	8b 7d fc             	mov    -0x4(%rbp),%edi
     6f5:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     6fb:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     6ff:	8b 95 68 ff ff ff    	mov    -0x98(%rbp),%edx
     705:	6b d2 0a             	imul   $0xa,%edx,%edx
     708:	41 89 d1             	mov    %edx,%r9d
     70b:	41 89 f8             	mov    %edi,%r8d
     70e:	be ff ff ff ff       	mov    $0xffffffff,%esi
     713:	44 01 c2             	add    %r8d,%edx
     716:	41 b8 ff ff ff 7f    	mov    $0x7fffffff,%r8d
     71c:	45 29 c8             	sub    %r9d,%r8d
     71f:	44 39 c7             	cmp    %r8d,%edi
     722:	0f 4f d6             	cmovg  %esi,%edx
     725:	89 95 68 ff ff ff    	mov    %edx,-0x98(%rbp)
     72b:	89 ca                	mov    %ecx,%edx
     72d:	0f be 44 10 01       	movsbl 0x1(%rax,%rdx,1),%eax
     732:	8d 49 01             	lea    0x1(%rcx),%ecx
     735:	89 ca                	mov    %ecx,%edx
     737:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
     73d:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     743:	8d 40 d0             	lea    -0x30(%rax),%eax
     746:	89 c1                	mov    %eax,%ecx
     748:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     74b:	83 f8 0a             	cmp    $0xa,%eax
     74e:	72 95                	jb     0x6e5
     750:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
     756:	85 c0                	test   %eax,%eax
     758:	0f 8c 05 47 00 00    	jl     0x4e63
     75e:	e9 fa 03 00 00       	jmp    0xb5d
     763:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     769:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     76d:	89 ca                	mov    %ecx,%edx
     76f:	0f be 44 10 01       	movsbl 0x1(%rax,%rdx,1),%eax
     774:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     779:	89 95 68 ff ff ff    	mov    %edx,-0x98(%rbp)
     77f:	8d 49 01             	lea    0x1(%rcx),%ecx
     782:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     788:	8d 40 d0             	lea    -0x30(%rax),%eax
     78b:	89 c1                	mov    %eax,%ecx
     78d:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     790:	83 f8 0a             	cmp    $0xa,%eax
     793:	0f 82 4c ff ff ff    	jb     0x6e5
     799:	e9 c5 46 00 00       	jmp    0x4e63
     79e:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     7a4:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
     7a8:	89 c2                	mov    %eax,%edx
     7aa:	0f b6 4c 11 01       	movzbl 0x1(%rcx,%rdx,1),%ecx
     7af:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     7b2:	8d 40 01             	lea    0x1(%rax),%eax
     7b5:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     7bb:	e9 28 fb ff ff       	jmp    0x2e8
     7c0:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     7c6:	85 c0                	test   %eax,%eax
     7c8:	0f 85 ac 46 00 00    	jne    0x4e7a
     7ce:	8b 45 f4             	mov    -0xc(%rbp),%eax
     7d1:	85 c0                	test   %eax,%eax
     7d3:	75 0a                	jne    0x7df
     7d5:	31 c0                	xor    %eax,%eax
     7d7:	89 45 f8             	mov    %eax,-0x8(%rbp)
     7da:	e9 9b 46 00 00       	jmp    0x4e7a
     7df:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     7e3:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     7e9:	8b 44 08 04          	mov    0x4(%rax,%rcx,1),%eax
     7ed:	89 c1                	mov    %eax,%ecx
     7ef:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     7f5:	85 c0                	test   %eax,%eax
     7f7:	75 10                	jne    0x809
     7f9:	b8 01 00 00 00       	mov    $0x1,%eax
     7fe:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     804:	e9 05 03 00 00       	jmp    0xb0e
     809:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     80f:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     816:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     81c:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     822:	8d 70 08             	lea    0x8(%rax),%esi
     825:	e8 34 69 fe ff       	call   0xfffffffffffe715e
     82a:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     831:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     837:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     83e:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     842:	8b 44 08 08          	mov    0x8(%rax,%rcx,1),%eax
     846:	89 c1                	mov    %eax,%ecx
     848:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     84e:	85 c0                	test   %eax,%eax
     850:	75 10                	jne    0x862
     852:	b8 02 00 00 00       	mov    $0x2,%eax
     857:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     85d:	e9 ac 02 00 00       	jmp    0xb0e
     862:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     868:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     86f:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     875:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     87b:	8d 70 10             	lea    0x10(%rax),%esi
     87e:	e8 db 68 fe ff       	call   0xfffffffffffe715e
     883:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     88a:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     890:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     897:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     89b:	8b 44 08 0c          	mov    0xc(%rax,%rcx,1),%eax
     89f:	89 c1                	mov    %eax,%ecx
     8a1:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     8a7:	85 c0                	test   %eax,%eax
     8a9:	75 10                	jne    0x8bb
     8ab:	b8 03 00 00 00       	mov    $0x3,%eax
     8b0:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     8b6:	e9 53 02 00 00       	jmp    0xb0e
     8bb:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     8c1:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     8c8:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     8ce:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     8d4:	8d 70 18             	lea    0x18(%rax),%esi
     8d7:	e8 82 68 fe ff       	call   0xfffffffffffe715e
     8dc:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     8e3:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     8e9:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     8f0:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     8f4:	8b 44 08 10          	mov    0x10(%rax,%rcx,1),%eax
     8f8:	89 c1                	mov    %eax,%ecx
     8fa:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     900:	85 c0                	test   %eax,%eax
     902:	75 10                	jne    0x914
     904:	b8 04 00 00 00       	mov    $0x4,%eax
     909:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     90f:	e9 fa 01 00 00       	jmp    0xb0e
     914:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     91a:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     921:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     927:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     92d:	8d 70 20             	lea    0x20(%rax),%esi
     930:	e8 29 68 fe ff       	call   0xfffffffffffe715e
     935:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     93c:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     942:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     949:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     94d:	8b 44 08 14          	mov    0x14(%rax,%rcx,1),%eax
     951:	89 c1                	mov    %eax,%ecx
     953:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     959:	85 c0                	test   %eax,%eax
     95b:	75 10                	jne    0x96d
     95d:	b8 05 00 00 00       	mov    $0x5,%eax
     962:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     968:	e9 a1 01 00 00       	jmp    0xb0e
     96d:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     973:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     97a:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     980:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     986:	8d 70 28             	lea    0x28(%rax),%esi
     989:	e8 d0 67 fe ff       	call   0xfffffffffffe715e
     98e:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     995:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     99b:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     9a2:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     9a6:	8b 44 08 18          	mov    0x18(%rax,%rcx,1),%eax
     9aa:	89 c1                	mov    %eax,%ecx
     9ac:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     9b2:	85 c0                	test   %eax,%eax
     9b4:	75 10                	jne    0x9c6
     9b6:	b8 06 00 00 00       	mov    $0x6,%eax
     9bb:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     9c1:	e9 48 01 00 00       	jmp    0xb0e
     9c6:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     9cc:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     9d3:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     9d9:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     9df:	8d 70 30             	lea    0x30(%rax),%esi
     9e2:	e8 77 67 fe ff       	call   0xfffffffffffe715e
     9e7:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     9ee:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     9f4:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     9fb:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     9ff:	8b 44 08 1c          	mov    0x1c(%rax,%rcx,1),%eax
     a03:	89 c1                	mov    %eax,%ecx
     a05:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     a0b:	85 c0                	test   %eax,%eax
     a0d:	75 10                	jne    0xa1f
     a0f:	b8 07 00 00 00       	mov    $0x7,%eax
     a14:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     a1a:	e9 ef 00 00 00       	jmp    0xb0e
     a1f:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     a25:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     a2c:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     a32:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     a38:	8d 70 38             	lea    0x38(%rax),%esi
     a3b:	e8 1e 67 fe ff       	call   0xfffffffffffe715e
     a40:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     a47:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     a4d:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     a54:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     a58:	8b 44 08 20          	mov    0x20(%rax,%rcx,1),%eax
     a5c:	89 c1                	mov    %eax,%ecx
     a5e:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     a64:	85 c0                	test   %eax,%eax
     a66:	75 10                	jne    0xa78
     a68:	b8 08 00 00 00       	mov    $0x8,%eax
     a6d:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     a73:	e9 96 00 00 00       	jmp    0xb0e
     a78:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     a7e:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     a85:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     a8b:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     a91:	8d 70 40             	lea    0x40(%rax),%esi
     a94:	e8 c5 66 fe ff       	call   0xfffffffffffe715e
     a99:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     aa0:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     aa6:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     aad:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     ab1:	8b 44 08 24          	mov    0x24(%rax,%rcx,1),%eax
     ab5:	89 c1                	mov    %eax,%ecx
     ab7:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     abd:	85 c0                	test   %eax,%eax
     abf:	75 0d                	jne    0xace
     ac1:	b8 09 00 00 00       	mov    $0x9,%eax
     ac6:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     acc:	eb 40                	jmp    0xb0e
     ace:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     ad5:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     adb:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     ae1:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     ae7:	8d 70 48             	lea    0x48(%rax),%esi
     aea:	e8 6f 66 fe ff       	call   0xfffffffffffe715e
     aef:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     af6:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     afd:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     b01:	b8 01 00 00 00       	mov    $0x1,%eax
     b06:	89 45 f8             	mov    %eax,-0x8(%rbp)
     b09:	e9 6c 43 00 00       	jmp    0x4e7a
     b0e:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     b14:	c1 e0 02             	shl    $0x2,%eax
     b17:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     b1d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     b21:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     b27:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     b2d:	01 d1                	add    %edx,%ecx
     b2f:	8b 04 08             	mov    (%rax,%rcx,1),%eax
     b32:	85 c0                	test   %eax,%eax
     b34:	0f 85 cc 02 00 00    	jne    0xe06
     b3a:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     b40:	8d 40 04             	lea    0x4(%rax),%eax
     b43:	89 c1                	mov    %eax,%ecx
     b45:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     b4b:	83 f8 28             	cmp    $0x28,%eax
     b4e:	75 cd                	jne    0xb1d
     b50:	b8 01 00 00 00       	mov    $0x1,%eax
     b55:	89 45 f8             	mov    %eax,-0x8(%rbp)
     b58:	e9 1d 43 00 00       	jmp    0x4e7a
     b5d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     b61:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
     b67:	31 d2                	xor    %edx,%edx
     b69:	89 55 fc             	mov    %edx,-0x4(%rbp)
     b6c:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     b71:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
     b77:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
     b7b:	83 f8 2e             	cmp    $0x2e,%eax
     b7e:	74 19                	je     0xb99
     b80:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
     b86:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     b8c:	31 c0                	xor    %eax,%eax
     b8e:	89 85 6c ff ff ff    	mov    %eax,-0x94(%rbp)
     b94:	e9 f7 01 00 00       	jmp    0xd90
     b99:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     b9d:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
     ba3:	0f be 44 08 01       	movsbl 0x1(%rax,%rcx,1),%eax
     ba8:	89 c1                	mov    %eax,%ecx
     baa:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
     bb0:	83 f8 2a             	cmp    $0x2a,%eax
     bb3:	0f 85 ef 00 00 00    	jne    0xca8
     bb9:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     bbd:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
     bc3:	0f be 44 08 02       	movsbl 0x2(%rax,%rcx,1),%eax
     bc8:	8d 40 d0             	lea    -0x30(%rax),%eax
     bcb:	89 c1                	mov    %eax,%ecx
     bcd:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     bd3:	83 f8 09             	cmp    $0x9,%eax
     bd6:	77 63                	ja     0xc3b
     bd8:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     bdc:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
     be2:	0f b6 44 08 03       	movzbl 0x3(%rax,%rcx,1),%eax
     be7:	83 f8 24             	cmp    $0x24,%eax
     bea:	75 4f                	jne    0xc3b
     bec:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     bf0:	8b 95 f0 fe ff ff    	mov    -0x110(%rbp),%edx
     bf6:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
     bfc:	8b bd e8 fe ff ff    	mov    -0x118(%rbp),%edi
     c02:	8b b5 f4 fe ff ff    	mov    -0x10c(%rbp),%esi
     c08:	c1 e7 02             	shl    $0x2,%edi
     c0b:	01 fe                	add    %edi,%esi
     c0d:	bf 0a 00 00 00       	mov    $0xa,%edi
     c12:	89 3c 30             	mov    %edi,(%rax,%rsi,1)
     c15:	89 ce                	mov    %ecx,%esi
     c17:	8d 76 04             	lea    0x4(%rsi),%esi
     c1a:	89 b5 e8 fe ff ff    	mov    %esi,-0x118(%rbp)
     c20:	0f be 4c 08 02       	movsbl 0x2(%rax,%rcx,1),%ecx
     c25:	c1 e1 03             	shl    $0x3,%ecx
     c28:	01 d1                	add    %edx,%ecx
     c2a:	8d 89 80 fe ff ff    	lea    -0x180(%rcx),%ecx
     c30:	8b 04 08             	mov    (%rax,%rcx,1),%eax
     c33:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
     c39:	eb 54                	jmp    0xc8f
     c3b:	8b 45 f4             	mov    -0xc(%rbp),%eax
     c3e:	85 c0                	test   %eax,%eax
     c40:	0f 85 c0 01 00 00    	jne    0xe06
     c46:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     c4c:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
     c52:	8d 49 02             	lea    0x2(%rcx),%ecx
     c55:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     c5b:	85 c0                	test   %eax,%eax
     c5d:	75 0a                	jne    0xc69
     c5f:	31 c0                	xor    %eax,%eax
     c61:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
     c67:	eb 26                	jmp    0xc8f
     c69:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     c6d:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     c73:	89 ca                	mov    %ecx,%edx
     c75:	8b 34 08             	mov    (%rax,%rcx,1),%esi
     c78:	89 f1                	mov    %esi,%ecx
     c7a:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
     c80:	8d 76 04             	lea    0x4(%rsi),%esi
     c83:	89 34 10             	mov    %esi,(%rax,%rdx,1)
     c86:	8b 04 08             	mov    (%rax,%rcx,1),%eax
     c89:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
     c8f:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
     c95:	35 ff ff ff ff       	xor    $0xffffffff,%eax
     c9a:	c1 e8 1f             	shr    $0x1f,%eax
     c9d:	89 85 6c ff ff ff    	mov    %eax,-0x94(%rbp)
     ca3:	e9 e8 00 00 00       	jmp    0xd90
     ca8:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
     cae:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
     cb4:	8d 49 01             	lea    0x1(%rcx),%ecx
     cb7:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     cbd:	8d 40 d0             	lea    -0x30(%rax),%eax
     cc0:	89 c1                	mov    %eax,%ecx
     cc2:	89 8d 70 ff ff ff    	mov    %ecx,-0x90(%rbp)
     cc8:	83 f8 09             	cmp    $0x9,%eax
     ccb:	76 18                	jbe    0xce5
     ccd:	b8 01 00 00 00       	mov    $0x1,%eax
     cd2:	89 85 6c ff ff ff    	mov    %eax,-0x94(%rbp)
     cd8:	31 c0                	xor    %eax,%eax
     cda:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
     ce0:	e9 ab 00 00 00       	jmp    0xd90
     ce5:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     ceb:	31 c9                	xor    %ecx,%ecx
     ced:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
     cf3:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
     cf9:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
     cff:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
     d04:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
     d0a:	3d cc cc cc 0c       	cmp    $0xccccccc,%eax
     d0f:	77 32                	ja     0xd43
     d11:	8b 95 70 ff ff ff    	mov    -0x90(%rbp),%edx
     d17:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
     d1d:	6b c0 0a             	imul   $0xa,%eax,%eax
     d20:	89 c7                	mov    %eax,%edi
     d22:	89 bd e8 fe ff ff    	mov    %edi,-0x118(%rbp)
     d28:	89 d6                	mov    %edx,%esi
     d2a:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
     d2f:	01 f0                	add    %esi,%eax
     d31:	be ff ff ff 7f       	mov    $0x7fffffff,%esi
     d36:	29 fe                	sub    %edi,%esi
     d38:	39 f2                	cmp    %esi,%edx
     d3a:	0f 4f c1             	cmovg  %ecx,%eax
     d3d:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
     d43:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
     d49:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
     d4f:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     d53:	be 01 00 00 00       	mov    $0x1,%esi
     d58:	89 b5 6c ff ff ff    	mov    %esi,-0x94(%rbp)
     d5e:	89 d6                	mov    %edx,%esi
     d60:	0f be 44 30 01       	movsbl 0x1(%rax,%rsi,1),%eax
     d65:	8d 52 01             	lea    0x1(%rdx),%edx
     d68:	89 d6                	mov    %edx,%esi
     d6a:	89 b5 e8 fe ff ff    	mov    %esi,-0x118(%rbp)
     d70:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
     d76:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
     d7c:	8d 40 d0             	lea    -0x30(%rax),%eax
     d7f:	89 c1                	mov    %eax,%ecx
     d81:	89 8d 70 ff ff ff    	mov    %ecx,-0x90(%rbp)
     d87:	83 f8 0a             	cmp    $0xa,%eax
     d8a:	0f 82 69 ff ff ff    	jb     0xcf9
     d90:	8b 55 fc             	mov    -0x4(%rbp),%edx
     d93:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     d97:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     d9d:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
     da3:	0f be 04 08          	movsbl (%rax,%rcx,1),%eax
     da7:	8d 40 bf             	lea    -0x41(%rax),%eax
     daa:	89 c1                	mov    %eax,%ecx
     dac:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     daf:	83 f8 39             	cmp    $0x39,%eax
     db2:	77 52                	ja     0xe06
     db4:	8b 55 fc             	mov    -0x4(%rbp),%edx
     db7:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     dbb:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
     dc1:	8b b5 e8 fe ff ff    	mov    -0x118(%rbp),%esi
     dc7:	8d 76 01             	lea    0x1(%rsi),%esi
     dca:	89 b5 e8 fe ff ff    	mov    %esi,-0x118(%rbp)
     dd0:	6b c9 3a             	imul   $0x3a,%ecx,%ecx
     dd3:	01 d1                	add    %edx,%ecx
     dd5:	8d 89 50 0b 00 00    	lea    0xb50(%rcx),%ecx
     ddb:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
     ddf:	89 c1                	mov    %eax,%ecx
     de1:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     de4:	8d 40 ff             	lea    -0x1(%rax),%eax
     de7:	83 f8 08             	cmp    $0x8,%eax
     dea:	72 a4                	jb     0xd90
     dec:	8b 45 fc             	mov    -0x4(%rbp),%eax
     def:	85 c0                	test   %eax,%eax
     df1:	74 13                	je     0xe06
     df3:	8b 45 fc             	mov    -0x4(%rbp),%eax
     df6:	83 f8 1b             	cmp    $0x1b,%eax
     df9:	75 1f                	jne    0xe1a
     dfb:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
     e01:	83 f8 ff             	cmp    $0xffffffff,%eax
     e04:	7e 57                	jle    0xe5d
     e06:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     e0a:	b9 1c 00 00 00       	mov    $0x1c,%ecx
     e0f:	89 88 d0 10 00 00    	mov    %ecx,0x10d0(%rax)
     e15:	e9 58 40 00 00       	jmp    0x4e72
     e1a:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
     e20:	85 c0                	test   %eax,%eax
     e22:	7c 4e                	jl     0xe72
     e24:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     e28:	8b b5 64 ff ff ff    	mov    -0x9c(%rbp),%esi
     e2e:	8b 95 f0 fe ff ff    	mov    -0x110(%rbp),%edx
     e34:	8b 4d cc             	mov    -0x34(%rbp),%ecx
     e37:	44 8b 45 fc          	mov    -0x4(%rbp),%r8d
     e3b:	8b bd f4 fe ff ff    	mov    -0x10c(%rbp),%edi
     e41:	41 89 f1             	mov    %esi,%r9d
     e44:	41 c1 e1 02          	shl    $0x2,%r9d
     e48:	44 01 cf             	add    %r9d,%edi
     e4b:	44 89 04 38          	mov    %r8d,(%rax,%rdi,1)
     e4f:	c1 e6 03             	shl    $0x3,%esi
     e52:	01 f2                	add    %esi,%edx
     e54:	48 8b 14 10          	mov    (%rax,%rdx,1),%rdx
     e58:	48 89 54 08 38       	mov    %rdx,0x38(%rax,%rcx,1)
     e5d:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     e63:	31 c9                	xor    %ecx,%ecx
     e65:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     e68:	85 c0                	test   %eax,%eax
     e6a:	0f 84 25 f4 ff ff    	je     0x295
     e70:	eb 41                	jmp    0xeb3
     e72:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     e78:	85 c0                	test   %eax,%eax
     e7a:	75 0a                	jne    0xe86
     e7c:	31 c0                	xor    %eax,%eax
     e7e:	89 45 f8             	mov    %eax,-0x8(%rbp)
     e81:	e9 f4 3f 00 00       	jmp    0x4e7a
     e86:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     e8d:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     e93:	8b 55 fc             	mov    -0x4(%rbp),%edx
     e96:	8b 45 cc             	mov    -0x34(%rbp),%eax
     e99:	8d 70 38             	lea    0x38(%rax),%esi
     e9c:	e8 bd 62 fe ff       	call   0xfffffffffffe715e
     ea1:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     ea8:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
     eaf:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     eb3:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
     eb9:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     ebd:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     ec3:	44 8b 85 54 ff ff ff 	mov    -0xac(%rbp),%r8d
     eca:	44 89 c7             	mov    %r8d,%edi
     ecd:	81 e7 ff ff fe ff    	and    $0xfffeffff,%edi
     ed3:	89 fe                	mov    %edi,%esi
     ed5:	89 b5 78 ff ff ff    	mov    %esi,-0x88(%rbp)
     edb:	44 89 c6             	mov    %r8d,%esi
     ede:	41 81 e0 00 20 00 00 	and    $0x2000,%r8d
     ee5:	45 85 c0             	test   %r8d,%r8d
     ee8:	0f 45 f7             	cmovne %edi,%esi
     eeb:	89 b5 64 ff ff ff    	mov    %esi,-0x9c(%rbp)
     ef1:	8d 49 ff             	lea    -0x1(%rcx),%ecx
     ef4:	0f be 34 08          	movsbl (%rax,%rcx,1),%esi
     ef8:	89 f0                	mov    %esi,%eax
     efa:	89 45 fc             	mov    %eax,-0x4(%rbp)
     efd:	89 c1                	mov    %eax,%ecx
     eff:	89 c7                	mov    %eax,%edi
     f01:	81 e6 df ff ff ff    	and    $0xffffffdf,%esi
     f07:	83 e7 0f             	and    $0xf,%edi
     f0a:	83 ff 03             	cmp    $0x3,%edi
     f0d:	0f 44 ce             	cmove  %esi,%ecx
     f10:	85 d2                	test   %edx,%edx
     f12:	0f 45 c1             	cmovne %ecx,%eax
     f15:	89 c1                	mov    %eax,%ecx
     f17:	89 8d 7c ff ff ff    	mov    %ecx,-0x84(%rbp)
     f1d:	8d 40 bf             	lea    -0x41(%rax),%eax
     f20:	89 85 d4 fe ff ff    	mov    %eax,-0x12c(%rbp)
     f26:	3d 37 00 00 00       	cmp    $0x37,%eax
     f2b:	77 47                	ja     0xf74
     f2d:	8b 85 d4 fe ff ff    	mov    -0x12c(%rbp),%eax
     f33:	48 8d 0d be 3f 00 00 	lea    0x3fbe(%rip),%rcx        # 0x4ef8
     f3a:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
     f3e:	48 01 c8             	add    %rcx,%rax
     f41:	ff e0                	jmp    *%rax
     f43:	eb 39                	jmp    0xf7e
     f45:	e9 a4 05 00 00       	jmp    0x14ee
     f4a:	e9 3e 01 00 00       	jmp    0x108d
     f4f:	e9 3d 02 00 00       	jmp    0x1191
     f54:	eb 4a                	jmp    0xfa0
     f56:	e9 63 05 00 00       	jmp    0x14be
     f5b:	e9 dc 02 00 00       	jmp    0x123c
     f60:	e9 1a 05 00 00       	jmp    0x147f
     f65:	e9 56 01 00 00       	jmp    0x10c0
     f6a:	e9 26 06 00 00       	jmp    0x1595
     f6f:	e9 46 06 00 00       	jmp    0x15ba
     f74:	e9 10 27 00 00       	jmp    0x3689
     f79:	e9 24 0b 00 00       	jmp    0x1aa2
     f7e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     f82:	8b 4d cc             	mov    -0x34(%rbp),%ecx
     f85:	31 d2                	xor    %edx,%edx
     f87:	89 55 80             	mov    %edx,-0x80(%rbp)
     f8a:	ba 3a 0b 00 00       	mov    $0xb3a,%edx
     f8f:	89 55 84             	mov    %edx,-0x7c(%rbp)
     f92:	48 8b 44 08 38       	mov    0x38(%rax,%rcx,1),%rax
     f97:	48 89 45 88          	mov    %rax,-0x78(%rbp)
     f9b:	e9 24 03 00 00       	jmp    0x12c4
     fa0:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
     fa6:	31 c9                	xor    %ecx,%ecx
     fa8:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     fab:	25 ff 00 00 00       	and    $0xff,%eax
     fb0:	89 85 d0 fe ff ff    	mov    %eax,-0x130(%rbp)
     fb6:	3d 07 00 00 00       	cmp    $0x7,%eax
     fbb:	77 20                	ja     0xfdd
     fbd:	8b 85 d0 fe ff ff    	mov    -0x130(%rbp),%eax
     fc3:	48 8d 0d 0e 40 00 00 	lea    0x400e(%rip),%rcx        # 0x4fd8
     fca:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
     fce:	48 01 c8             	add    %rcx,%rax
     fd1:	ff e0                	jmp    *%rax
     fd3:	e9 85 00 00 00       	jmp    0x105d
     fd8:	e9 96 00 00 00       	jmp    0x1073
     fdd:	e9 b3 f2 ff ff       	jmp    0x295
     fe2:	eb 63                	jmp    0x1047
     fe4:	eb 4a                	jmp    0x1030
     fe6:	eb 2e                	jmp    0x1016
     fe8:	eb 16                	jmp    0x1000
     fea:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     fee:	8b 55 f8             	mov    -0x8(%rbp),%edx
     ff1:	8b 4d cc             	mov    -0x34(%rbp),%ecx
     ff4:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
     ff8:	89 14 08             	mov    %edx,(%rax,%rcx,1)
     ffb:	e9 95 f2 ff ff       	jmp    0x295
    1000:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1004:	8b 55 f8             	mov    -0x8(%rbp),%edx
    1007:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    100a:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    100e:	89 14 08             	mov    %edx,(%rax,%rcx,1)
    1011:	e9 7f f2 ff ff       	jmp    0x295
    1016:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    101a:	8b 55 f8             	mov    -0x8(%rbp),%edx
    101d:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1020:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    1024:	48 63 d2             	movslq %edx,%rdx
    1027:	48 89 14 08          	mov    %rdx,(%rax,%rcx,1)
    102b:	e9 65 f2 ff ff       	jmp    0x295
    1030:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1034:	8b 55 f8             	mov    -0x8(%rbp),%edx
    1037:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    103a:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    103e:	66 89 14 08          	mov    %dx,(%rax,%rcx,1)
    1042:	e9 4e f2 ff ff       	jmp    0x295
    1047:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    104b:	8b 55 f8             	mov    -0x8(%rbp),%edx
    104e:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1051:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    1055:	88 14 08             	mov    %dl,(%rax,%rcx,1)
    1058:	e9 38 f2 ff ff       	jmp    0x295
    105d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1061:	8b 55 f8             	mov    -0x8(%rbp),%edx
    1064:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1067:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    106b:	89 14 08             	mov    %edx,(%rax,%rcx,1)
    106e:	e9 22 f2 ff ff       	jmp    0x295
    1073:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1077:	8b 55 f8             	mov    -0x8(%rbp),%edx
    107a:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    107d:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    1081:	48 63 d2             	movslq %edx,%rdx
    1084:	48 89 14 08          	mov    %rdx,(%rax,%rcx,1)
    1088:	e9 08 f2 ff ff       	jmp    0x295
    108d:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    1093:	8b b5 5c ff ff ff    	mov    -0xa4(%rbp),%esi
    1099:	89 f2                	mov    %esi,%edx
    109b:	b9 08 00 00 00       	mov    $0x8,%ecx
    10a0:	83 fe 08             	cmp    $0x8,%esi
    10a3:	0f 47 ca             	cmova  %edx,%ecx
    10a6:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    10ac:	83 c8 08             	or     $0x8,%eax
    10af:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
    10b5:	b8 78 00 00 00       	mov    $0x78,%eax
    10ba:	89 85 7c ff ff ff    	mov    %eax,-0x84(%rbp)
    10c0:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    10c4:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    10c7:	31 d2                	xor    %edx,%edx
    10c9:	89 55 80             	mov    %edx,-0x80(%rbp)
    10cc:	ba 3a 0b 00 00       	mov    $0xb3a,%edx
    10d1:	89 55 84             	mov    %edx,-0x7c(%rbp)
    10d4:	48 8b 44 08 38       	mov    0x38(%rax,%rcx,1),%rax
    10d9:	48 89 c1             	mov    %rax,%rcx
    10dc:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
    10e0:	48 85 c0             	test   %rax,%rax
    10e3:	75 0e                	jne    0x10f3
    10e5:	8b 45 f0             	mov    -0x10(%rbp),%eax
    10e8:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    10ee:	e9 d8 02 00 00       	jmp    0x13cb
    10f3:	8b 45 f0             	mov    -0x10(%rbp),%eax
    10f6:	8b 8d 7c ff ff ff    	mov    -0x84(%rbp),%ecx
    10fc:	83 e1 20             	and    $0x20,%ecx
    10ff:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    1102:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    1108:	48 8b 45 88          	mov    -0x78(%rbp),%rax
    110c:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    1110:	8b 7d fc             	mov    -0x4(%rbp),%edi
    1113:	8b 95 50 ff ff ff    	mov    -0xb0(%rbp),%edx
    1119:	8d 52 ff             	lea    -0x1(%rdx),%edx
    111c:	89 d6                	mov    %edx,%esi
    111e:	89 b5 50 ff ff ff    	mov    %esi,-0xb0(%rbp)
    1124:	48 89 c6             	mov    %rax,%rsi
    1127:	89 f6                	mov    %esi,%esi
    1129:	83 e6 0f             	and    $0xf,%esi
    112c:	8d b6 b0 0d 00 00    	lea    0xdb0(%rsi),%esi
    1132:	0f b6 34 31          	movzbl (%rcx,%rsi,1),%esi
    1136:	09 fe                	or     %edi,%esi
    1138:	40 88 34 11          	mov    %sil,(%rcx,%rdx,1)
    113c:	48 c1 e8 04          	shr    $0x4,%rax
    1140:	48 89 c1             	mov    %rax,%rcx
    1143:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
    1147:	48 85 c0             	test   %rax,%rax
    114a:	75 bc                	jne    0x1108
    114c:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    1152:	83 e0 08             	and    $0x8,%eax
    1155:	85 c0                	test   %eax,%eax
    1157:	0f 84 6e 02 00 00    	je     0x13cb
    115d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1161:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1164:	48 8b 44 08 38       	mov    0x38(%rax,%rcx,1),%rax
    1169:	48 85 c0             	test   %rax,%rax
    116c:	0f 84 59 02 00 00    	je     0x13cb
    1172:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    1178:	c1 f8 04             	sar    $0x4,%eax
    117b:	8d 80 3a 0b 00 00    	lea    0xb3a(%rax),%eax
    1181:	89 45 84             	mov    %eax,-0x7c(%rbp)
    1184:	b8 02 00 00 00       	mov    $0x2,%eax
    1189:	89 45 80             	mov    %eax,-0x80(%rbp)
    118c:	e9 3a 02 00 00       	jmp    0x13cb
    1191:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1195:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1198:	8b 55 f0             	mov    -0x10(%rbp),%edx
    119b:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    11a1:	48 8b 44 08 38       	mov    0x38(%rax,%rcx,1),%rax
    11a6:	48 89 c1             	mov    %rax,%rcx
    11a9:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
    11ad:	48 85 c0             	test   %rax,%rax
    11b0:	74 41                	je     0x11f3
    11b2:	8b 45 f0             	mov    -0x10(%rbp),%eax
    11b5:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    11bb:	48 8b 45 88          	mov    -0x78(%rbp),%rax
    11bf:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    11c3:	8b 95 50 ff ff ff    	mov    -0xb0(%rbp),%edx
    11c9:	8d 52 ff             	lea    -0x1(%rdx),%edx
    11cc:	89 d6                	mov    %edx,%esi
    11ce:	89 b5 50 ff ff ff    	mov    %esi,-0xb0(%rbp)
    11d4:	48 89 c6             	mov    %rax,%rsi
    11d7:	89 f6                	mov    %esi,%esi
    11d9:	83 e6 07             	and    $0x7,%esi
    11dc:	83 ce 30             	or     $0x30,%esi
    11df:	40 88 34 11          	mov    %sil,(%rcx,%rdx,1)
    11e3:	48 c1 e8 03          	shr    $0x3,%rax
    11e7:	48 89 c1             	mov    %rax,%rcx
    11ea:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
    11ee:	48 85 c0             	test   %rax,%rax
    11f1:	75 c8                	jne    0x11bb
    11f3:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    11f9:	31 c9                	xor    %ecx,%ecx
    11fb:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    11fe:	b9 3a 0b 00 00       	mov    $0xb3a,%ecx
    1203:	89 4d 84             	mov    %ecx,-0x7c(%rbp)
    1206:	83 e0 08             	and    $0x8,%eax
    1209:	85 c0                	test   %eax,%eax
    120b:	0f 84 ba 01 00 00    	je     0x13cb
    1211:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    1217:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    121d:	8b 45 f0             	mov    -0x10(%rbp),%eax
    1220:	89 d1                	mov    %edx,%ecx
    1222:	29 f0                	sub    %esi,%eax
    1224:	89 c6                	mov    %eax,%esi
    1226:	89 75 fc             	mov    %esi,-0x4(%rbp)
    1229:	8d 40 01             	lea    0x1(%rax),%eax
    122c:	39 f2                	cmp    %esi,%edx
    122e:	0f 4f c1             	cmovg  %ecx,%eax
    1231:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    1237:	e9 8f 01 00 00       	jmp    0x13cb
    123c:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1240:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1243:	48 8b 44 08 38       	mov    0x38(%rax,%rcx,1),%rax
    1248:	48 89 c1             	mov    %rax,%rcx
    124b:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
    124f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    1253:	7f 2e                	jg     0x1283
    1255:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1259:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
    125d:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1260:	31 d2                	xor    %edx,%edx
    1262:	48 29 f2             	sub    %rsi,%rdx
    1265:	48 89 d6             	mov    %rdx,%rsi
    1268:	48 89 75 88          	mov    %rsi,-0x78(%rbp)
    126c:	48 89 54 08 38       	mov    %rdx,0x38(%rax,%rcx,1)
    1271:	b8 01 00 00 00       	mov    $0x1,%eax
    1276:	89 45 80             	mov    %eax,-0x80(%rbp)
    1279:	b8 3a 0b 00 00       	mov    $0xb3a,%eax
    127e:	89 45 84             	mov    %eax,-0x7c(%rbp)
    1281:	eb 41                	jmp    0x12c4
    1283:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    1289:	25 00 08 00 00       	and    $0x800,%eax
    128e:	85 c0                	test   %eax,%eax
    1290:	74 12                	je     0x12a4
    1292:	b8 01 00 00 00       	mov    $0x1,%eax
    1297:	89 45 80             	mov    %eax,-0x80(%rbp)
    129a:	b8 3b 0b 00 00       	mov    $0xb3b,%eax
    129f:	89 45 84             	mov    %eax,-0x7c(%rbp)
    12a2:	eb 20                	jmp    0x12c4
    12a4:	8b 95 64 ff ff ff    	mov    -0x9c(%rbp),%edx
    12aa:	83 e2 01             	and    $0x1,%edx
    12ad:	89 d0                	mov    %edx,%eax
    12af:	89 45 80             	mov    %eax,-0x80(%rbp)
    12b2:	b9 3c 0b 00 00       	mov    $0xb3c,%ecx
    12b7:	b8 3a 0b 00 00       	mov    $0xb3a,%eax
    12bc:	85 d2                	test   %edx,%edx
    12be:	0f 45 c1             	cmovne %ecx,%eax
    12c1:	89 45 84             	mov    %eax,-0x7c(%rbp)
    12c4:	48 8b 45 88          	mov    -0x78(%rbp),%rax
    12c8:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    12cf:	00 00 00 
    12d2:	48 39 c8             	cmp    %rcx,%rax
    12d5:	73 13                	jae    0x12ea
    12d7:	8b 45 f0             	mov    -0x10(%rbp),%eax
    12da:	48 8b 4d 88          	mov    -0x78(%rbp),%rcx
    12de:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
    12e2:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    12e8:	eb 6c                	jmp    0x1356
    12ea:	8b 45 f0             	mov    -0x10(%rbp),%eax
    12ed:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    12f3:	48 8b 45 88          	mov    -0x78(%rbp),%rax
    12f7:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    12fd:	8d 71 ff             	lea    -0x1(%rcx),%esi
    1300:	89 f1                	mov    %esi,%ecx
    1302:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    1308:	48 89 c7             	mov    %rax,%rdi
    130b:	b9 0a 00 00 00       	mov    $0xa,%ecx
    1310:	48 31 d2             	xor    %rdx,%rdx
    1313:	48 f7 f1             	div    %rcx
    1316:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    131a:	49 89 c0             	mov    %rax,%r8
    131d:	48 8b 45 88          	mov    -0x78(%rbp),%rax
    1321:	4c 89 c1             	mov    %r8,%rcx
    1324:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
    1328:	4d 6b c0 0a          	imul   $0xa,%r8,%r8
    132c:	4c 29 c7             	sub    %r8,%rdi
    132f:	89 ff                	mov    %edi,%edi
    1331:	83 cf 30             	or     $0x30,%edi
    1334:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    1338:	48 ba ff ff ff ff 09 	movabs $0x9ffffffff,%rdx
    133f:	00 00 00 
    1342:	48 39 d0             	cmp    %rdx,%rax
    1345:	0f 97 c0             	seta   %al
    1348:	0f b6 c0             	movzbl %al,%eax
    134b:	89 45 fc             	mov    %eax,-0x4(%rbp)
    134e:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
    1352:	85 c0                	test   %eax,%eax
    1354:	75 9d                	jne    0x12f3
    1356:	48 8b 45 90          	mov    -0x70(%rbp),%rax
    135a:	89 c0                	mov    %eax,%eax
    135c:	89 c1                	mov    %eax,%ecx
    135e:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    1361:	85 c0                	test   %eax,%eax
    1363:	74 66                	je     0x13cb
    1365:	8b 45 fc             	mov    -0x4(%rbp),%eax
    1368:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    136c:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    1372:	8d 71 ff             	lea    -0x1(%rcx),%esi
    1375:	89 f1                	mov    %esi,%ecx
    1377:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    137d:	89 c7                	mov    %eax,%edi
    137f:	89 c1                	mov    %eax,%ecx
    1381:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
    1387:	89 c9                	mov    %ecx,%ecx
    1389:	49 b8 cd cc cc cc 00 	movabs $0xcccccccd,%r8
    1390:	00 00 00 
    1393:	49 0f af c8          	imul   %r8,%rcx
    1397:	48 c1 e9 23          	shr    $0x23,%rcx
    139b:	41 89 c8             	mov    %ecx,%r8d
    139e:	44 89 c1             	mov    %r8d,%ecx
    13a1:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    13a7:	45 6b c0 0a          	imul   $0xa,%r8d,%r8d
    13ab:	44 29 c7             	sub    %r8d,%edi
    13ae:	83 cf 30             	or     $0x30,%edi
    13b1:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    13b5:	83 f8 09             	cmp    $0x9,%eax
    13b8:	0f 97 c0             	seta   %al
    13bb:	0f b6 c0             	movzbl %al,%eax
    13be:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    13c4:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    13c7:	85 c0                	test   %eax,%eax
    13c9:	75 9a                	jne    0x1365
    13cb:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    13d1:	85 c0                	test   %eax,%eax
    13d3:	74 0e                	je     0x13e3
    13d5:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    13db:	85 c0                	test   %eax,%eax
    13dd:	0f 8c 80 3a 00 00    	jl     0x4e63
    13e3:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    13e9:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    13ed:	8b 55 cc             	mov    -0x34(%rbp),%edx
    13f0:	44 8b 85 6c ff ff ff 	mov    -0x94(%rbp),%r8d
    13f7:	8b b5 64 ff ff ff    	mov    -0x9c(%rbp),%esi
    13fd:	89 f7                	mov    %esi,%edi
    13ff:	81 e7 ff ff fe ff    	and    $0xfffeffff,%edi
    1405:	45 85 c0             	test   %r8d,%r8d
    1408:	0f 45 f7             	cmovne %edi,%esi
    140b:	89 b5 78 ff ff ff    	mov    %esi,-0x88(%rbp)
    1411:	48 8b 4c 11 38       	mov    0x38(%rcx,%rdx,1),%rcx
    1416:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
    141a:	85 c0                	test   %eax,%eax
    141c:	75 24                	jne    0x1442
    141e:	48 8b 45 88          	mov    -0x78(%rbp),%rax
    1422:	31 c9                	xor    %ecx,%ecx
    1424:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
    142a:	48 85 c0             	test   %rax,%rax
    142d:	75 13                	jne    0x1442
    142f:	8b 45 f0             	mov    -0x10(%rbp),%eax
    1432:	89 c1                	mov    %eax,%ecx
    1434:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    143a:	89 45 fc             	mov    %eax,-0x4(%rbp)
    143d:	e9 72 22 00 00       	jmp    0x36b4
    1442:	8b 45 f0             	mov    -0x10(%rbp),%eax
    1445:	8b b5 5c ff ff ff    	mov    -0xa4(%rbp),%esi
    144b:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    144f:	44 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%r8d
    1456:	89 f2                	mov    %esi,%edx
    1458:	89 c1                	mov    %eax,%ecx
    145a:	44 29 c1             	sub    %r8d,%ecx
    145d:	48 85 ff             	test   %rdi,%rdi
    1460:	40 0f 94 c7          	sete   %dil
    1464:	40 0f b6 ff          	movzbl %dil,%edi
    1468:	01 f9                	add    %edi,%ecx
    146a:	89 cf                	mov    %ecx,%edi
    146c:	39 fe                	cmp    %edi,%esi
    146e:	0f 4f ca             	cmovg  %edx,%ecx
    1471:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
    1477:	89 45 fc             	mov    %eax,-0x4(%rbp)
    147a:	e9 35 22 00 00       	jmp    0x36b4
    147f:	8b 45 f0             	mov    -0x10(%rbp),%eax
    1482:	8b 4d d0             	mov    -0x30(%rbp),%ecx
    1485:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    1489:	8b 7d cc             	mov    -0x34(%rbp),%edi
    148c:	89 fe                	mov    %edi,%esi
    148e:	48 8b 7c 3a 38       	mov    0x38(%rdx,%rdi,1),%rdi
    1493:	40 88 7c 32 37       	mov    %dil,0x37(%rdx,%rsi,1)
    1498:	31 d2                	xor    %edx,%edx
    149a:	89 55 80             	mov    %edx,-0x80(%rbp)
    149d:	ba 3a 0b 00 00       	mov    $0xb3a,%edx
    14a2:	89 55 84             	mov    %edx,-0x7c(%rbp)
    14a5:	ba 01 00 00 00       	mov    $0x1,%edx
    14aa:	89 95 74 ff ff ff    	mov    %edx,-0x8c(%rbp)
    14b0:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    14b6:	89 45 fc             	mov    %eax,-0x4(%rbp)
    14b9:	e9 f6 21 00 00       	jmp    0x36b4
    14be:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    14c2:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    14c9:	8b b0 d0 10 00 00    	mov    0x10d0(%rax),%esi
    14cf:	e8 62 5c fe ff       	call   0xfffffffffffe7136
    14d4:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    14db:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    14e2:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    14e6:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    14ec:	eb 20                	jmp    0x150e
    14ee:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    14f2:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    14f5:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    14f9:	89 ca                	mov    %ecx,%edx
    14fb:	89 55 fc             	mov    %edx,-0x4(%rbp)
    14fe:	b8 44 0b 00 00       	mov    $0xb44,%eax
    1503:	85 d2                	test   %edx,%edx
    1505:	0f 45 c1             	cmovne %ecx,%eax
    1508:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    150e:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    1514:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    151b:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    1521:	31 c0                	xor    %eax,%eax
    1523:	89 45 80             	mov    %eax,-0x80(%rbp)
    1526:	89 f0                	mov    %esi,%eax
    1528:	89 85 cc fe ff ff    	mov    %eax,-0x134(%rbp)
    152e:	89 ca                	mov    %ecx,%edx
    1530:	b8 ff ff ff 7f       	mov    $0x7fffffff,%eax
    1535:	85 c9                	test   %ecx,%ecx
    1537:	0f 4c d0             	cmovl  %eax,%edx
    153a:	e8 65 5c fe ff       	call   0xfffffffffffe71a4
    153f:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
    1546:	8b 8d cc fe ff ff    	mov    -0x134(%rbp),%ecx
    154c:	89 c2                	mov    %eax,%edx
    154e:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    1554:	48 8b b6 b8 11 00 00 	mov    0x11b8(%rsi),%rsi
    155b:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
    155f:	89 d6                	mov    %edx,%esi
    1561:	89 b5 74 ff ff ff    	mov    %esi,-0x8c(%rbp)
    1567:	01 d1                	add    %edx,%ecx
    1569:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    156c:	b9 3a 0b 00 00       	mov    $0xb3a,%ecx
    1571:	89 4d 84             	mov    %ecx,-0x7c(%rbp)
    1574:	83 f8 ff             	cmp    $0xffffffff,%eax
    1577:	0f 8f 37 21 00 00    	jg     0x36b4
    157d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1581:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    1584:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    1588:	85 c0                	test   %eax,%eax
    158a:	0f 84 24 21 00 00    	je     0x36b4
    1590:	e9 ce 38 00 00       	jmp    0x4e63
    1595:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    159b:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    159f:	8b 55 cc             	mov    -0x34(%rbp),%edx
    15a2:	8b 4c 11 38          	mov    0x38(%rcx,%rdx,1),%ecx
    15a6:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    15ac:	85 c0                	test   %eax,%eax
    15ae:	75 47                	jne    0x15f7
    15b0:	31 c0                	xor    %eax,%eax
    15b2:	89 45 fc             	mov    %eax,-0x4(%rbp)
    15b5:	e9 0e 01 00 00       	jmp    0x16c8
    15ba:	8b 45 cc             	mov    -0x34(%rbp),%eax
    15bd:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    15c1:	89 c2                	mov    %eax,%edx
    15c3:	31 f6                	xor    %esi,%esi
    15c5:	89 74 11 0c          	mov    %esi,0xc(%rcx,%rdx,1)
    15c9:	89 c2                	mov    %eax,%edx
    15cb:	89 c6                	mov    %eax,%esi
    15cd:	48 8b 74 31 38       	mov    0x38(%rcx,%rsi,1),%rsi
    15d2:	89 f6                	mov    %esi,%esi
    15d4:	89 74 11 08          	mov    %esi,0x8(%rcx,%rdx,1)
    15d8:	89 c2                	mov    %eax,%edx
    15da:	89 c6                	mov    %eax,%esi
    15dc:	8d 76 08             	lea    0x8(%rsi),%esi
    15df:	89 74 11 38          	mov    %esi,0x38(%rcx,%rdx,1)
    15e3:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    15e8:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    15ee:	8d 40 08             	lea    0x8(%rax),%eax
    15f1:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    15f7:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    15fd:	31 c9                	xor    %ecx,%ecx
    15ff:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    1602:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    1608:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    160c:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    1612:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1615:	89 c1                	mov    %eax,%ecx
    1617:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    161d:	85 c0                	test   %eax,%eax
    161f:	0f 84 98 00 00 00    	je     0x16bd
    1625:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    162b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1632:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1635:	8d 70 04             	lea    0x4(%rax),%esi
    1638:	e8 ad 5b fe ff       	call   0xfffffffffffe71ea
    163d:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    1644:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    164b:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    164f:	89 c1                	mov    %eax,%ecx
    1651:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    1657:	85 c0                	test   %eax,%eax
    1659:	0f 9c c0             	setl   %al
    165c:	0f b6 c0             	movzbl %al,%eax
    165f:	89 c1                	mov    %eax,%ecx
    1661:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    1667:	85 c0                	test   %eax,%eax
    1669:	75 44                	jne    0x16af
    166b:	8b 55 fc             	mov    -0x4(%rbp),%edx
    166e:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    1674:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    167a:	29 d1                	sub    %edx,%ecx
    167c:	39 c8                	cmp    %ecx,%eax
    167e:	77 2f                	ja     0x16af
    1680:	8b 55 fc             	mov    -0x4(%rbp),%edx
    1683:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    1689:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    168f:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    1695:	8d 76 04             	lea    0x4(%rsi),%esi
    1698:	89 b5 54 ff ff ff    	mov    %esi,-0xac(%rbp)
    169e:	01 d1                	add    %edx,%ecx
    16a0:	89 ca                	mov    %ecx,%edx
    16a2:	89 55 fc             	mov    %edx,-0x4(%rbp)
    16a5:	39 c8                	cmp    %ecx,%eax
    16a7:	0f 87 5b ff ff ff    	ja     0x1608
    16ad:	eb 0e                	jmp    0x16bd
    16af:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    16b5:	85 c0                	test   %eax,%eax
    16b7:	0f 85 b5 37 00 00    	jne    0x4e72
    16bd:	8b 45 fc             	mov    -0x4(%rbp),%eax
    16c0:	85 c0                	test   %eax,%eax
    16c2:	0f 8c 9b 37 00 00    	jl     0x4e63
    16c8:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    16ce:	25 00 20 01 00       	and    $0x12000,%eax
    16d3:	89 c1                	mov    %eax,%ecx
    16d5:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    16db:	85 c0                	test   %eax,%eax
    16dd:	0f 85 5a 01 00 00    	jne    0x183d
    16e3:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    16e6:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    16ec:	39 c8                	cmp    %ecx,%eax
    16ee:	0f 8e 49 01 00 00    	jle    0x183d
    16f4:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    16fb:	8b 55 fc             	mov    -0x4(%rbp),%edx
    16fe:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    1704:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1707:	29 d0                	sub    %edx,%eax
    1709:	41 89 c0             	mov    %eax,%r8d
    170c:	44 89 85 54 ff ff ff 	mov    %r8d,-0xac(%rbp)
    1713:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    171a:	0f 92 c2             	setb   %dl
    171d:	0f b6 d2             	movzbl %dl,%edx
    1720:	89 95 74 ff ff ff    	mov    %edx,-0x8c(%rbp)
    1726:	8d 71 40             	lea    0x40(%rcx),%esi
    1729:	ba 20 00 00 00       	mov    $0x20,%edx
    172e:	b9 00 01 00 00       	mov    $0x100,%ecx
    1733:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    173a:	0f 42 c8             	cmovb  %eax,%ecx
    173d:	e8 76 5a fe ff       	call   0xfffffffffffe71b8
    1742:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    1749:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    174f:	89 c6                	mov    %eax,%esi
    1751:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
    1757:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    175e:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    1762:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    1765:	89 ca                	mov    %ecx,%edx
    1767:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    176d:	83 e1 20             	and    $0x20,%ecx
    1770:	85 c9                	test   %ecx,%ecx
    1772:	0f 94 c1             	sete   %cl
    1775:	0f b6 c9             	movzbl %cl,%ecx
    1778:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    177e:	85 c0                	test   %eax,%eax
    1780:	75 7f                	jne    0x1801
    1782:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    1788:	83 e0 01             	and    $0x1,%eax
    178b:	85 c0                	test   %eax,%eax
    178d:	74 40                	je     0x17cf
    178f:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1795:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    179c:	8b 45 cc             	mov    -0x34(%rbp),%eax
    179f:	8d 70 40             	lea    0x40(%rax),%esi
    17a2:	ba 00 01 00 00       	mov    $0x100,%edx
    17a7:	e8 26 59 fe ff       	call   0xfffffffffffe70d2
    17ac:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    17b2:	89 c2                	mov    %eax,%edx
    17b4:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    17bb:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    17c2:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    17c6:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    17c9:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    17cf:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    17d5:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    17db:	83 e1 20             	and    $0x20,%ecx
    17de:	85 c9                	test   %ecx,%ecx
    17e0:	0f 94 c1             	sete   %cl
    17e3:	0f b6 c9             	movzbl %cl,%ecx
    17e6:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    17ec:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    17f2:	89 c1                	mov    %eax,%ecx
    17f4:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    17fa:	3d ff 00 00 00       	cmp    $0xff,%eax
    17ff:	77 81                	ja     0x1782
    1801:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    1807:	85 c0                	test   %eax,%eax
    1809:	74 32                	je     0x183d
    180b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1812:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1818:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    181e:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1821:	8d 70 40             	lea    0x40(%rax),%esi
    1824:	e8 a9 58 fe ff       	call   0xfffffffffffe70d2
    1829:	89 c1                	mov    %eax,%ecx
    182b:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1832:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    1839:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    183d:	8b 45 fc             	mov    -0x4(%rbp),%eax
    1840:	85 c0                	test   %eax,%eax
    1842:	0f 84 d5 00 00 00    	je     0x191d
    1848:	31 c0                	xor    %eax,%eax
    184a:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    1850:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1854:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    185a:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    185d:	89 c1                	mov    %eax,%ecx
    185f:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    1865:	85 c0                	test   %eax,%eax
    1867:	0f 84 b0 00 00 00    	je     0x191d
    186d:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    1873:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    187a:	8b 45 cc             	mov    -0x34(%rbp),%eax
    187d:	8d 70 04             	lea    0x4(%rax),%esi
    1880:	e8 65 59 fe ff       	call   0xfffffffffffe71ea
    1885:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
    188c:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    1892:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    1895:	48 8b b6 b8 11 00 00 	mov    0x11b8(%rsi),%rsi
    189c:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
    18a0:	89 c6                	mov    %eax,%esi
    18a2:	89 b5 58 ff ff ff    	mov    %esi,-0xa8(%rbp)
    18a8:	01 d0                	add    %edx,%eax
    18aa:	89 c2                	mov    %eax,%edx
    18ac:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    18b2:	39 c8                	cmp    %ecx,%eax
    18b4:	77 67                	ja     0x191d
    18b6:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    18ba:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    18c0:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    18c4:	83 e0 20             	and    $0x20,%eax
    18c7:	85 c0                	test   %eax,%eax
    18c9:	75 32                	jne    0x18fd
    18cb:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    18d2:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    18d8:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    18de:	8b 45 cc             	mov    -0x34(%rbp),%eax
    18e1:	8d 70 04             	lea    0x4(%rax),%esi
    18e4:	e8 e9 57 fe ff       	call   0xfffffffffffe70d2
    18e9:	89 c1                	mov    %eax,%ecx
    18eb:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    18f2:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    18f9:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    18fd:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    1900:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    1906:	8b 95 50 ff ff ff    	mov    -0xb0(%rbp),%edx
    190c:	8d 52 04             	lea    0x4(%rdx),%edx
    190f:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    1915:	39 c8                	cmp    %ecx,%eax
    1917:	0f 82 33 ff ff ff    	jb     0x1850
    191d:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    1923:	3d 00 20 00 00       	cmp    $0x2000,%eax
    1928:	0f 85 5a 01 00 00    	jne    0x1a88
    192e:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    1931:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    1937:	39 c8                	cmp    %ecx,%eax
    1939:	0f 8e 49 01 00 00    	jle    0x1a88
    193f:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1946:	8b 55 fc             	mov    -0x4(%rbp),%edx
    1949:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    194f:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1952:	29 d0                	sub    %edx,%eax
    1954:	41 89 c0             	mov    %eax,%r8d
    1957:	44 89 85 54 ff ff ff 	mov    %r8d,-0xac(%rbp)
    195e:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1965:	0f 92 c2             	setb   %dl
    1968:	0f b6 d2             	movzbl %dl,%edx
    196b:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    1971:	8d 71 40             	lea    0x40(%rcx),%esi
    1974:	ba 20 00 00 00       	mov    $0x20,%edx
    1979:	b9 00 01 00 00       	mov    $0x100,%ecx
    197e:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1985:	0f 42 c8             	cmovb  %eax,%ecx
    1988:	e8 2b 58 fe ff       	call   0xfffffffffffe71b8
    198d:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    1994:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    199a:	89 c6                	mov    %eax,%esi
    199c:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    19a2:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    19a9:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    19ad:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    19b0:	89 ca                	mov    %ecx,%edx
    19b2:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    19b8:	83 e1 20             	and    $0x20,%ecx
    19bb:	85 c9                	test   %ecx,%ecx
    19bd:	0f 94 c1             	sete   %cl
    19c0:	0f b6 c9             	movzbl %cl,%ecx
    19c3:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    19c9:	85 c0                	test   %eax,%eax
    19cb:	75 7f                	jne    0x1a4c
    19cd:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    19d3:	83 e0 01             	and    $0x1,%eax
    19d6:	85 c0                	test   %eax,%eax
    19d8:	74 40                	je     0x1a1a
    19da:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    19e0:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    19e7:	8b 45 cc             	mov    -0x34(%rbp),%eax
    19ea:	8d 70 40             	lea    0x40(%rax),%esi
    19ed:	ba 00 01 00 00       	mov    $0x100,%edx
    19f2:	e8 db 56 fe ff       	call   0xfffffffffffe70d2
    19f7:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    19fd:	89 c2                	mov    %eax,%edx
    19ff:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1a06:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    1a0d:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1a11:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1a14:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    1a1a:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    1a20:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    1a26:	83 e1 20             	and    $0x20,%ecx
    1a29:	85 c9                	test   %ecx,%ecx
    1a2b:	0f 94 c1             	sete   %cl
    1a2e:	0f b6 c9             	movzbl %cl,%ecx
    1a31:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    1a37:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    1a3d:	89 c1                	mov    %eax,%ecx
    1a3f:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    1a45:	3d ff 00 00 00       	cmp    $0xff,%eax
    1a4a:	77 81                	ja     0x19cd
    1a4c:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    1a52:	85 c0                	test   %eax,%eax
    1a54:	74 32                	je     0x1a88
    1a56:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1a5d:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1a63:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    1a69:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1a6c:	8d 70 40             	lea    0x40(%rax),%esi
    1a6f:	e8 5e 56 fe ff       	call   0xfffffffffffe70d2
    1a74:	89 c1                	mov    %eax,%ecx
    1a76:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1a7d:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    1a84:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1a88:	8b 75 fc             	mov    -0x4(%rbp),%esi
    1a8b:	8b 95 68 ff ff ff    	mov    -0x98(%rbp),%edx
    1a91:	89 d1                	mov    %edx,%ecx
    1a93:	89 f0                	mov    %esi,%eax
    1a95:	39 f2                	cmp    %esi,%edx
    1a97:	0f 4f c1             	cmovg  %ecx,%eax
    1a9a:	89 45 fc             	mov    %eax,-0x4(%rbp)
    1a9d:	e9 f3 e7 ff ff       	jmp    0x295
    1aa2:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    1aa8:	83 f8 ff             	cmp    $0xffffffff,%eax
    1aab:	7f 0e                	jg     0x1abb
    1aad:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    1ab3:	85 c0                	test   %eax,%eax
    1ab5:	0f 85 a8 33 00 00    	jne    0x4e63
    1abb:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1abf:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1ac2:	89 ca                	mov    %ecx,%edx
    1ac4:	f2 0f 10 44 10 38    	movsd  0x38(%rax,%rdx,1),%xmm0
    1aca:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
    1acf:	31 d2                	xor    %edx,%edx
    1ad1:	89 94 08 6c 01 00 00 	mov    %edx,0x16c(%rax,%rcx,1)
    1ad8:	66 48 0f 7e c0       	movq   %xmm0,%rax
    1add:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    1ae1:	7f 38                	jg     0x1b1b
    1ae3:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    1ae8:	66 48 0f 7e c0       	movq   %xmm0,%rax
    1aed:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    1af4:	00 00 80 
    1af7:	48 31 c8             	xor    %rcx,%rax
    1afa:	66 48 0f 6e c0       	movq   %rax,%xmm0
    1aff:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
    1b04:	b8 01 00 00 00       	mov    $0x1,%eax
    1b09:	89 45 a0             	mov    %eax,-0x60(%rbp)
    1b0c:	31 c0                	xor    %eax,%eax
    1b0e:	89 45 a4             	mov    %eax,-0x5c(%rbp)
    1b11:	b8 c0 0d 00 00       	mov    $0xdc0,%eax
    1b16:	89 45 a8             	mov    %eax,-0x58(%rbp)
    1b19:	eb 51                	jmp    0x1b6c
    1b1b:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    1b21:	25 00 08 00 00       	and    $0x800,%eax
    1b26:	85 c0                	test   %eax,%eax
    1b28:	74 17                	je     0x1b41
    1b2a:	b8 01 00 00 00       	mov    $0x1,%eax
    1b2f:	89 45 a0             	mov    %eax,-0x60(%rbp)
    1b32:	31 c0                	xor    %eax,%eax
    1b34:	89 45 a4             	mov    %eax,-0x5c(%rbp)
    1b37:	b8 c3 0d 00 00       	mov    $0xdc3,%eax
    1b3c:	89 45 a8             	mov    %eax,-0x58(%rbp)
    1b3f:	eb 2b                	jmp    0x1b6c
    1b41:	8b b5 64 ff ff ff    	mov    -0x9c(%rbp),%esi
    1b47:	83 e6 01             	and    $0x1,%esi
    1b4a:	89 f0                	mov    %esi,%eax
    1b4c:	89 45 a0             	mov    %eax,-0x60(%rbp)
    1b4f:	ba c6 0d 00 00       	mov    $0xdc6,%edx
    1b54:	b9 c1 0d 00 00       	mov    $0xdc1,%ecx
    1b59:	85 f6                	test   %esi,%esi
    1b5b:	0f 45 ca             	cmovne %edx,%ecx
    1b5e:	89 4d a8             	mov    %ecx,-0x58(%rbp)
    1b61:	85 c0                	test   %eax,%eax
    1b63:	0f 94 c0             	sete   %al
    1b66:	0f b6 c0             	movzbl %al,%eax
    1b69:	89 45 a4             	mov    %eax,-0x5c(%rbp)
    1b6c:	f2 0f 10 85 f8 fe ff 	movsd  -0x108(%rbp),%xmm0
    1b73:	ff 
    1b74:	f2 0f 10 4d 98       	movsd  -0x68(%rbp),%xmm1
    1b79:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
    1b80:	ff ff 7f 
    1b83:	66 48 0f 6e d0       	movq   %rax,%xmm2
    1b88:	66 0f 54 ca          	andpd  %xmm2,%xmm1
    1b8c:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    1b90:	0f 87 c8 03 00 00    	ja     0x1f5e
    1b96:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    1b9c:	8b 4d a0             	mov    -0x60(%rbp),%ecx
    1b9f:	8d 49 03             	lea    0x3(%rcx),%ecx
    1ba2:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    1ba8:	25 00 20 00 00       	and    $0x2000,%eax
    1bad:	85 c0                	test   %eax,%eax
    1baf:	0f 85 54 01 00 00    	jne    0x1d09
    1bb5:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    1bbb:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    1bc1:	39 c8                	cmp    %ecx,%eax
    1bc3:	0f 8e 40 01 00 00    	jle    0x1d09
    1bc9:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1bd0:	8b 95 50 ff ff ff    	mov    -0xb0(%rbp),%edx
    1bd6:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    1bdc:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1bdf:	29 d0                	sub    %edx,%eax
    1be1:	41 89 c0             	mov    %eax,%r8d
    1be4:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    1be8:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1bef:	0f 92 c2             	setb   %dl
    1bf2:	0f b6 d2             	movzbl %dl,%edx
    1bf5:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    1bfb:	8d 71 40             	lea    0x40(%rcx),%esi
    1bfe:	ba 20 00 00 00       	mov    $0x20,%edx
    1c03:	b9 00 01 00 00       	mov    $0x100,%ecx
    1c08:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1c0f:	0f 42 c8             	cmovb  %eax,%ecx
    1c12:	e8 a1 55 fe ff       	call   0xfffffffffffe71b8
    1c17:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    1c1e:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    1c24:	89 c6                	mov    %eax,%esi
    1c26:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    1c2c:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    1c33:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    1c37:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    1c3a:	89 ca                	mov    %ecx,%edx
    1c3c:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    1c42:	83 e1 20             	and    $0x20,%ecx
    1c45:	85 c9                	test   %ecx,%ecx
    1c47:	0f 94 c1             	sete   %cl
    1c4a:	0f b6 c9             	movzbl %cl,%ecx
    1c4d:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    1c53:	85 c0                	test   %eax,%eax
    1c55:	75 79                	jne    0x1cd0
    1c57:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    1c5d:	83 e0 01             	and    $0x1,%eax
    1c60:	85 c0                	test   %eax,%eax
    1c62:	74 40                	je     0x1ca4
    1c64:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1c6a:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1c71:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1c74:	8d 70 40             	lea    0x40(%rax),%esi
    1c77:	ba 00 01 00 00       	mov    $0x100,%edx
    1c7c:	e8 51 54 fe ff       	call   0xfffffffffffe70d2
    1c81:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1c87:	89 c2                	mov    %eax,%edx
    1c89:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1c90:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    1c97:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1c9b:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1c9e:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    1ca4:	8b 45 fc             	mov    -0x4(%rbp),%eax
    1ca7:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    1cad:	83 e1 20             	and    $0x20,%ecx
    1cb0:	85 c9                	test   %ecx,%ecx
    1cb2:	0f 94 c1             	sete   %cl
    1cb5:	0f b6 c9             	movzbl %cl,%ecx
    1cb8:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    1cbe:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    1cc4:	89 c1                	mov    %eax,%ecx
    1cc6:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    1cc9:	3d ff 00 00 00       	cmp    $0xff,%eax
    1cce:	77 87                	ja     0x1c57
    1cd0:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    1cd6:	85 c0                	test   %eax,%eax
    1cd8:	74 2f                	je     0x1d09
    1cda:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1ce1:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1ce7:	8b 55 fc             	mov    -0x4(%rbp),%edx
    1cea:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1ced:	8d 70 40             	lea    0x40(%rax),%esi
    1cf0:	e8 dd 53 fe ff       	call   0xfffffffffffe70d2
    1cf5:	89 c1                	mov    %eax,%ecx
    1cf7:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1cfe:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    1d05:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1d09:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1d0d:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1d13:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1d16:	89 c1                	mov    %eax,%ecx
    1d18:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    1d1b:	83 e0 20             	and    $0x20,%eax
    1d1e:	85 c0                	test   %eax,%eax
    1d20:	75 38                	jne    0x1d5a
    1d22:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1d28:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1d2f:	8b 55 a0             	mov    -0x60(%rbp),%edx
    1d32:	8b 75 a8             	mov    -0x58(%rbp),%esi
    1d35:	e8 98 53 fe ff       	call   0xfffffffffffe70d2
    1d3a:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1d40:	89 c2                	mov    %eax,%edx
    1d42:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1d49:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    1d50:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1d54:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1d57:	89 45 fc             	mov    %eax,-0x4(%rbp)
    1d5a:	8b 45 fc             	mov    -0x4(%rbp),%eax
    1d5d:	83 e0 20             	and    $0x20,%eax
    1d60:	85 c0                	test   %eax,%eax
    1d62:	75 73                	jne    0x1dd7
    1d64:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1d6b:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1d71:	f2 0f 10 4d 98       	movsd  -0x68(%rbp),%xmm1
    1d76:	8b b5 7c ff ff ff    	mov    -0x84(%rbp),%esi
    1d7c:	83 e6 20             	and    $0x20,%esi
    1d7f:	41 89 f0             	mov    %esi,%r8d
    1d82:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    1d86:	0f 28 c1             	movaps %xmm1,%xmm0
    1d89:	ba db 0d 00 00       	mov    $0xddb,%edx
    1d8e:	b8 df 0d 00 00       	mov    $0xddf,%eax
    1d93:	85 f6                	test   %esi,%esi
    1d95:	0f 45 c2             	cmovne %edx,%eax
    1d98:	ba d3 0d 00 00       	mov    $0xdd3,%edx
    1d9d:	be d7 0d 00 00       	mov    $0xdd7,%esi
    1da2:	45 85 c0             	test   %r8d,%r8d
    1da5:	0f 45 f2             	cmovne %edx,%esi
    1da8:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    1dac:	41 0f 9a c0          	setp   %r8b
    1db0:	0f 95 c2             	setne  %dl
    1db3:	44 08 c2             	or     %r8b,%dl
    1db6:	0f 45 f0             	cmovne %eax,%esi
    1db9:	ba 03 00 00 00       	mov    $0x3,%edx
    1dbe:	e8 0f 53 fe ff       	call   0xfffffffffffe70d2
    1dc3:	89 c1                	mov    %eax,%ecx
    1dc5:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1dcc:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    1dd3:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1dd7:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    1ddd:	25 00 20 01 00       	and    $0x12000,%eax
    1de2:	3d 00 20 00 00       	cmp    $0x2000,%eax
    1de7:	0f 85 54 01 00 00    	jne    0x1f41
    1ded:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    1df3:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    1df9:	39 c8                	cmp    %ecx,%eax
    1dfb:	0f 8e 40 01 00 00    	jle    0x1f41
    1e01:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1e08:	8b 95 50 ff ff ff    	mov    -0xb0(%rbp),%edx
    1e0e:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    1e14:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1e17:	29 d0                	sub    %edx,%eax
    1e19:	41 89 c0             	mov    %eax,%r8d
    1e1c:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    1e20:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1e27:	0f 92 c2             	setb   %dl
    1e2a:	0f b6 d2             	movzbl %dl,%edx
    1e2d:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    1e33:	8d 71 40             	lea    0x40(%rcx),%esi
    1e36:	ba 20 00 00 00       	mov    $0x20,%edx
    1e3b:	b9 00 01 00 00       	mov    $0x100,%ecx
    1e40:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1e47:	0f 42 c8             	cmovb  %eax,%ecx
    1e4a:	e8 69 53 fe ff       	call   0xfffffffffffe71b8
    1e4f:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    1e56:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    1e5c:	89 c6                	mov    %eax,%esi
    1e5e:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    1e64:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    1e6b:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    1e6f:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    1e72:	89 ca                	mov    %ecx,%edx
    1e74:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    1e7a:	83 e1 20             	and    $0x20,%ecx
    1e7d:	85 c9                	test   %ecx,%ecx
    1e7f:	0f 94 c1             	sete   %cl
    1e82:	0f b6 c9             	movzbl %cl,%ecx
    1e85:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    1e8b:	85 c0                	test   %eax,%eax
    1e8d:	75 79                	jne    0x1f08
    1e8f:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    1e95:	83 e0 01             	and    $0x1,%eax
    1e98:	85 c0                	test   %eax,%eax
    1e9a:	74 40                	je     0x1edc
    1e9c:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1ea2:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1ea9:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1eac:	8d 70 40             	lea    0x40(%rax),%esi
    1eaf:	ba 00 01 00 00       	mov    $0x100,%edx
    1eb4:	e8 19 52 fe ff       	call   0xfffffffffffe70d2
    1eb9:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1ebf:	89 c2                	mov    %eax,%edx
    1ec1:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1ec8:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    1ecf:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1ed3:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1ed6:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    1edc:	8b 45 fc             	mov    -0x4(%rbp),%eax
    1edf:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    1ee5:	83 e1 20             	and    $0x20,%ecx
    1ee8:	85 c9                	test   %ecx,%ecx
    1eea:	0f 94 c1             	sete   %cl
    1eed:	0f b6 c9             	movzbl %cl,%ecx
    1ef0:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    1ef6:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    1efc:	89 c1                	mov    %eax,%ecx
    1efe:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    1f01:	3d ff 00 00 00       	cmp    $0xff,%eax
    1f06:	77 87                	ja     0x1e8f
    1f08:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    1f0e:	85 c0                	test   %eax,%eax
    1f10:	74 2f                	je     0x1f41
    1f12:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1f19:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1f1f:	8b 55 fc             	mov    -0x4(%rbp),%edx
    1f22:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1f25:	8d 70 40             	lea    0x40(%rax),%esi
    1f28:	e8 a5 51 fe ff       	call   0xfffffffffffe70d2
    1f2d:	89 c1                	mov    %eax,%ecx
    1f2f:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1f36:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    1f3d:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1f41:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    1f47:	8b 95 68 ff ff ff    	mov    -0x98(%rbp),%edx
    1f4d:	89 d1                	mov    %edx,%ecx
    1f4f:	89 f0                	mov    %esi,%eax
    1f51:	39 f2                	cmp    %esi,%edx
    1f53:	0f 4f c1             	cmovg  %ecx,%eax
    1f56:	89 45 fc             	mov    %eax,-0x4(%rbp)
    1f59:	e9 fa 2e 00 00       	jmp    0x4e58
    1f5e:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    1f63:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1f6a:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1f6d:	8d b0 6c 01 00 00    	lea    0x16c(%rax),%esi
    1f73:	e8 86 52 fe ff       	call   0xfffffffffffe71fe
    1f78:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1f7f:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    1f86:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1f8a:	0f 28 c8             	movaps %xmm0,%xmm1
    1f8d:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    1f91:	0f 28 c8             	movaps %xmm0,%xmm1
    1f94:	f2 0f 11 4d 98       	movsd  %xmm1,-0x68(%rbp)
    1f99:	0f 57 c9             	xorps  %xmm1,%xmm1
    1f9c:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    1fa0:	0f 94 c0             	sete   %al
    1fa3:	0f 9b c1             	setnp  %cl
    1fa6:	20 c8                	and    %cl,%al
    1fa8:	0f b6 c0             	movzbl %al,%eax
    1fab:	85 c0                	test   %eax,%eax
    1fad:	75 37                	jne    0x1fe6
    1faf:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    1fb5:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    1fb9:	8b 75 cc             	mov    -0x34(%rbp),%esi
    1fbc:	89 f2                	mov    %esi,%edx
    1fbe:	8b b4 31 6c 01 00 00 	mov    0x16c(%rcx,%rsi,1),%esi
    1fc5:	89 f7                	mov    %esi,%edi
    1fc7:	89 7d fc             	mov    %edi,-0x4(%rbp)
    1fca:	8d 76 ff             	lea    -0x1(%rsi),%esi
    1fcd:	89 b4 11 6c 01 00 00 	mov    %esi,0x16c(%rcx,%rdx,1)
    1fd4:	83 c8 20             	or     $0x20,%eax
    1fd7:	89 c1                	mov    %eax,%ecx
    1fd9:	89 4d 84             	mov    %ecx,-0x7c(%rbp)
    1fdc:	83 f8 61             	cmp    $0x61,%eax
    1fdf:	75 4a                	jne    0x202b
    1fe1:	e9 6e 23 00 00       	jmp    0x4354
    1fe6:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    1fec:	83 c8 20             	or     $0x20,%eax
    1fef:	89 c1                	mov    %eax,%ecx
    1ff1:	89 4d 84             	mov    %ecx,-0x7c(%rbp)
    1ff4:	83 f8 61             	cmp    $0x61,%eax
    1ff7:	0f 84 57 23 00 00    	je     0x4354
    1ffd:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2001:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    2004:	8b bd 5c ff ff ff    	mov    -0xa4(%rbp),%edi
    200a:	89 fa                	mov    %edi,%edx
    200c:	be 06 00 00 00       	mov    $0x6,%esi
    2011:	85 ff                	test   %edi,%edi
    2013:	0f 4c d6             	cmovl  %esi,%edx
    2016:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    201c:	8b 84 08 6c 01 00 00 	mov    0x16c(%rax,%rcx,1),%eax
    2023:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    2029:	eb 4a                	jmp    0x2075
    202b:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    2030:	f2 0f 10 8d 00 ff ff 	movsd  -0x100(%rbp),%xmm1
    2037:	ff 
    2038:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    203e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2042:	8b 75 fc             	mov    -0x4(%rbp),%esi
    2045:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    2048:	8d 76 e3             	lea    -0x1d(%rsi),%esi
    204b:	89 f7                	mov    %esi,%edi
    204d:	89 bd 50 ff ff ff    	mov    %edi,-0xb0(%rbp)
    2053:	89 b4 08 6c 01 00 00 	mov    %esi,0x16c(%rax,%rcx,1)
    205a:	89 d0                	mov    %edx,%eax
    205c:	b9 06 00 00 00       	mov    $0x6,%ecx
    2061:	85 d2                	test   %edx,%edx
    2063:	0f 4c c1             	cmovl  %ecx,%eax
    2066:	89 85 78 ff ff ff    	mov    %eax,-0x88(%rbp)
    206c:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    2070:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
    2075:	8b 95 50 ff ff ff    	mov    -0xb0(%rbp),%edx
    207b:	8b 45 e4             	mov    -0x1c(%rbp),%eax
    207e:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    2081:	85 d2                	test   %edx,%edx
    2083:	40 0f 9c c6          	setl   %sil
    2087:	40 0f b6 f6          	movzbl %sil,%esi
    208b:	89 75 ac             	mov    %esi,-0x54(%rbp)
    208e:	8d 89 70 01 00 00    	lea    0x170(%rcx),%ecx
    2094:	85 d2                	test   %edx,%edx
    2096:	0f 4c c1             	cmovl  %ecx,%eax
    2099:	89 c1                	mov    %eax,%ecx
    209b:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    209e:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    20a4:	f2 0f 10 8d 08 ff ff 	movsd  -0xf8(%rbp),%xmm1
    20ab:	ff 
    20ac:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    20b1:	0f 28 d0             	movaps %xmm0,%xmm2
    20b4:	66 0f 2e ca          	ucomisd %xmm2,%xmm1
    20b8:	0f 97 c0             	seta   %al
    20bb:	0f b6 c0             	movzbl %al,%eax
    20be:	0f 57 c9             	xorps  %xmm1,%xmm1
    20c1:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    20c5:	0f 93 c1             	setae  %cl
    20c8:	0f b6 c9             	movzbl %cl,%ecx
    20cb:	21 c8                	and    %ecx,%eax
    20cd:	85 c0                	test   %eax,%eax
    20cf:	74 48                	je     0x2119
    20d1:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    20d6:	f2 0f 11 85 b8 fe ff 	movsd  %xmm0,-0x148(%rbp)
    20dd:	ff 
    20de:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
    20e3:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
    20ea:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    20ef:	48 39 c8             	cmp    %rcx,%rax
    20f2:	76 17                	jbe    0x210b
    20f4:	f2 0f 10 85 b8 fe ff 	movsd  -0x148(%rbp),%xmm0
    20fb:	ff 
    20fc:	66 0f 2e c0          	ucomisd %xmm0,%xmm0
    2100:	0f 8a af 2d 00 00    	jp     0x4eb5
    2106:	e9 9d 2d 00 00       	jmp    0x4ea8
    210b:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
    2112:	89 c0                	mov    %eax,%eax
    2114:	89 45 fc             	mov    %eax,-0x4(%rbp)
    2117:	eb 05                	jmp    0x211e
    2119:	31 c0                	xor    %eax,%eax
    211b:	89 45 fc             	mov    %eax,-0x4(%rbp)
    211e:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    2123:	f2 0f 10 8d 10 ff ff 	movsd  -0xf0(%rbp),%xmm1
    212a:	ff 
    212b:	8b 45 fc             	mov    -0x4(%rbp),%eax
    212e:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    2134:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    2138:	89 ce                	mov    %ecx,%esi
    213a:	89 c7                	mov    %eax,%edi
    213c:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
    213f:	8d 49 04             	lea    0x4(%rcx),%ecx
    2142:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    2148:	0f 57 d2             	xorps  %xmm2,%xmm2
    214b:	f2 48 0f 2a d0       	cvtsi2sd %rax,%xmm2
    2150:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    2154:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    2158:	0f 28 c8             	movaps %xmm0,%xmm1
    215b:	f2 0f 11 4d 98       	movsd  %xmm1,-0x68(%rbp)
    2160:	0f 57 c9             	xorps  %xmm1,%xmm1
    2163:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    2167:	0f 95 c0             	setne  %al
    216a:	0f 9a c1             	setp   %cl
    216d:	08 c8                	or     %cl,%al
    216f:	0f b6 c0             	movzbl %al,%eax
    2172:	85 c0                	test   %eax,%eax
    2174:	0f 85 2a ff ff ff    	jne    0x20a4
    217a:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    2180:	83 f8 01             	cmp    $0x1,%eax
    2183:	7d 17                	jge    0x219c
    2185:	8b 45 80             	mov    -0x80(%rbp),%eax
    2188:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    218e:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2191:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2197:	e9 4b 01 00 00       	jmp    0x22e7
    219c:	8b 45 80             	mov    -0x80(%rbp),%eax
    219f:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    21a5:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    21ab:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    21b1:	8b bd 50 ff ff ff    	mov    -0xb0(%rbp),%edi
    21b7:	89 fe                	mov    %edi,%esi
    21b9:	ba 1d 00 00 00       	mov    $0x1d,%edx
    21be:	83 ff 1d             	cmp    $0x1d,%edi
    21c1:	0f 4c d6             	cmovl  %esi,%edx
    21c4:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    21ca:	8d 40 fc             	lea    -0x4(%rax),%eax
    21cd:	89 c2                	mov    %eax,%edx
    21cf:	89 55 fc             	mov    %edx,-0x4(%rbp)
    21d2:	39 c8                	cmp    %ecx,%eax
    21d4:	0f 82 a7 00 00 00    	jb     0x2281
    21da:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    21e0:	89 c0                	mov    %eax,%eax
    21e2:	48 89 45 90          	mov    %rax,-0x70(%rbp)
    21e6:	31 c0                	xor    %eax,%eax
    21e8:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    21ec:	44 8b 45 fc          	mov    -0x4(%rbp),%r8d
    21f0:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
    21f4:	48 8b 45 88          	mov    -0x78(%rbp),%rax
    21f8:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
    21fc:	44 89 c6             	mov    %r8d,%esi
    21ff:	42 8b 3c 07          	mov    (%rdi,%r8,1),%edi
    2203:	48 d3 e7             	shl    %cl,%rdi
    2206:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    220c:	49 b8 ff ff ff ff 00 	movabs $0xffffffff,%r8
    2213:	00 00 00 
    2216:	4c 21 c0             	and    %r8,%rax
    2219:	48 01 c7             	add    %rax,%rdi
    221c:	48 89 f8             	mov    %rdi,%rax
    221f:	41 b8 00 ca 9a 3b    	mov    $0x3b9aca00,%r8d
    2225:	48 31 d2             	xor    %rdx,%rdx
    2228:	49 f7 f0             	div    %r8
    222b:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    222f:	49 89 c0             	mov    %rax,%r8
    2232:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2235:	4d 89 c1             	mov    %r8,%r9
    2238:	4c 89 4d 88          	mov    %r9,-0x78(%rbp)
    223c:	4d 69 c0 00 ca 9a 3b 	imul   $0x3b9aca00,%r8,%r8
    2243:	4c 29 c7             	sub    %r8,%rdi
    2246:	89 ff                	mov    %edi,%edi
    2248:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
    224b:	8d 40 fc             	lea    -0x4(%rax),%eax
    224e:	89 c2                	mov    %eax,%edx
    2250:	89 55 fc             	mov    %edx,-0x4(%rbp)
    2253:	39 c8                	cmp    %ecx,%eax
    2255:	73 95                	jae    0x21ec
    2257:	48 8b 45 88          	mov    -0x78(%rbp),%rax
    225b:	89 c0                	mov    %eax,%eax
    225d:	89 c1                	mov    %eax,%ecx
    225f:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2262:	85 c0                	test   %eax,%eax
    2264:	74 1b                	je     0x2281
    2266:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    226a:	8b 55 fc             	mov    -0x4(%rbp),%edx
    226d:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    2273:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    2276:	89 ce                	mov    %ecx,%esi
    2278:	89 b5 54 ff ff ff    	mov    %esi,-0xac(%rbp)
    227e:	89 14 08             	mov    %edx,(%rax,%rcx,1)
    2281:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    2287:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    228d:	89 c2                	mov    %eax,%edx
    228f:	89 55 fc             	mov    %edx,-0x4(%rbp)
    2292:	39 c8                	cmp    %ecx,%eax
    2294:	76 19                	jbe    0x22af
    2296:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    229a:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    229d:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    22a0:	89 ca                	mov    %ecx,%edx
    22a2:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    22a8:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    22ab:	85 c0                	test   %eax,%eax
    22ad:	74 d2                	je     0x2281
    22af:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    22b5:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    22b8:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    22bc:	8b 7d cc             	mov    -0x34(%rbp),%edi
    22bf:	89 fe                	mov    %edi,%esi
    22c1:	8b bc 3a 6c 01 00 00 	mov    0x16c(%rdx,%rdi,1),%edi
    22c8:	29 c7                	sub    %eax,%edi
    22ca:	89 f8                	mov    %edi,%eax
    22cc:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    22d2:	89 bc 32 6c 01 00 00 	mov    %edi,0x16c(%rdx,%rsi,1)
    22d9:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    22df:	85 c0                	test   %eax,%eax
    22e1:	0f 8f be fe ff ff    	jg     0x21a5
    22e7:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    22ed:	83 f8 ff             	cmp    $0xffffffff,%eax
    22f0:	0f 8f cb 01 00 00    	jg     0x24c1
    22f6:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    22fc:	8d 40 19             	lea    0x19(%rax),%eax
    22ff:	b9 09 00 00 00       	mov    $0x9,%ecx
    2304:	89 c0                	mov    %eax,%eax
    2306:	48 69 c0 39 8e e3 38 	imul   $0x38e38e39,%rax,%rax
    230d:	48 c1 e8 21          	shr    $0x21,%rax
    2311:	89 c0                	mov    %eax,%eax
    2313:	8d 40 01             	lea    0x1(%rax),%eax
    2316:	89 85 6c ff ff ff    	mov    %eax,-0x94(%rbp)
    231c:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    231f:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    2325:	8b bd 50 ff ff ff    	mov    -0xb0(%rbp),%edi
    232b:	41 89 f8             	mov    %edi,%r8d
    232e:	be 09 00 00 00       	mov    $0x9,%esi
    2333:	31 d2                	xor    %edx,%edx
    2335:	44 29 c2             	sub    %r8d,%edx
    2338:	83 ff f7             	cmp    $0xfffffff7,%edi
    233b:	0f 4c d6             	cmovl  %esi,%edx
    233e:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    2344:	39 c8                	cmp    %ecx,%eax
    2346:	72 24                	jb     0x236c
    2348:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    234e:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    2352:	89 f1                	mov    %esi,%ecx
    2354:	89 f0                	mov    %esi,%eax
    2356:	8b 14 32             	mov    (%rdx,%rsi,1),%edx
    2359:	8d 40 04             	lea    0x4(%rax),%eax
    235c:	85 d2                	test   %edx,%edx
    235e:	0f 45 c1             	cmovne %ecx,%eax
    2361:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2367:	e9 df 00 00 00       	jmp    0x244b
    236c:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    2372:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    2378:	ba 00 ca 9a 3b       	mov    $0x3b9aca00,%edx
    237d:	d3 ea                	shr    %cl,%edx
    237f:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    2385:	89 95 74 ff ff ff    	mov    %edx,-0x8c(%rbp)
    238b:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    2390:	d3 e2                	shl    %cl,%edx
    2392:	89 d1                	mov    %edx,%ecx
    2394:	81 f1 ff ff ff ff    	xor    $0xffffffff,%ecx
    239a:	89 8d 70 ff ff ff    	mov    %ecx,-0x90(%rbp)
    23a0:	31 c9                	xor    %ecx,%ecx
    23a2:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    23a8:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    23ae:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    23b4:	44 8b 9d 50 ff ff ff 	mov    -0xb0(%rbp),%r11d
    23bb:	8b b5 74 ff ff ff    	mov    -0x8c(%rbp),%esi
    23c1:	8b bd 70 ff ff ff    	mov    -0x90(%rbp),%edi
    23c7:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
    23cb:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    23d1:	41 89 c1             	mov    %eax,%r9d
    23d4:	89 c2                	mov    %eax,%edx
    23d6:	45 8b 14 10          	mov    (%r8,%rdx,1),%r10d
    23da:	44 89 d2             	mov    %r10d,%edx
    23dd:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    23e3:	41 d3 ea             	shr    %cl,%r10d
    23e6:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    23e9:	45 01 da             	add    %r11d,%r10d
    23ec:	47 89 14 08          	mov    %r10d,(%r8,%r9,1)
    23f0:	21 fa                	and    %edi,%edx
    23f2:	0f af d6             	imul   %esi,%edx
    23f5:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    23fb:	8d 40 04             	lea    0x4(%rax),%eax
    23fe:	89 c2                	mov    %eax,%edx
    2400:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    2406:	39 c8                	cmp    %ecx,%eax
    2408:	72 a4                	jb     0x23ae
    240a:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    2410:	8b bd 54 ff ff ff    	mov    -0xac(%rbp),%edi
    2416:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    241a:	89 fa                	mov    %edi,%edx
    241c:	89 f9                	mov    %edi,%ecx
    241e:	8b 34 3e             	mov    (%rsi,%rdi,1),%esi
    2421:	8d 49 04             	lea    0x4(%rcx),%ecx
    2424:	85 f6                	test   %esi,%esi
    2426:	0f 45 ca             	cmovne %edx,%ecx
    2429:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    242f:	85 c0                	test   %eax,%eax
    2431:	74 18                	je     0x244b
    2433:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2436:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    243a:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    2440:	89 c2                	mov    %eax,%edx
    2442:	89 34 11             	mov    %esi,(%rcx,%rdx,1)
    2445:	8d 40 04             	lea    0x4(%rax),%eax
    2448:	89 45 fc             	mov    %eax,-0x4(%rbp)
    244b:	8b 75 fc             	mov    -0x4(%rbp),%esi
    244e:	8b bd 6c ff ff ff    	mov    -0x94(%rbp),%edi
    2454:	44 8b 45 84          	mov    -0x7c(%rbp),%r8d
    2458:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    245e:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    2461:	4c 8b 4d c0          	mov    -0x40(%rbp),%r9
    2465:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    246b:	44 8b 5d cc          	mov    -0x34(%rbp),%r11d
    246f:	45 89 da             	mov    %r11d,%r10d
    2472:	47 8b 9c 19 6c 01 00 	mov    0x16c(%r9,%r11,1),%r11d
    2479:	00 
    247a:	41 01 c3             	add    %eax,%r11d
    247d:	44 89 d8             	mov    %r11d,%eax
    2480:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    2486:	47 89 9c 11 6c 01 00 	mov    %r11d,0x16c(%r9,%r10,1)
    248d:	00 
    248e:	41 83 f8 66          	cmp    $0x66,%r8d
    2492:	0f 44 d1             	cmove  %ecx,%edx
    2495:	41 89 d0             	mov    %edx,%r8d
    2498:	44 89 85 58 ff ff ff 	mov    %r8d,-0xa8(%rbp)
    249f:	41 89 f9             	mov    %edi,%r9d
    24a2:	89 f1                	mov    %esi,%ecx
    24a4:	41 c1 e1 02          	shl    $0x2,%r9d
    24a8:	44 01 ca             	add    %r9d,%edx
    24ab:	44 29 c6             	sub    %r8d,%esi
    24ae:	c1 fe 02             	sar    $0x2,%esi
    24b1:	39 fe                	cmp    %edi,%esi
    24b3:	0f 4f ca             	cmovg  %edx,%ecx
    24b6:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    24b9:	85 c0                	test   %eax,%eax
    24bb:	0f 8c 5b fe ff ff    	jl     0x231c
    24c1:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    24c4:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    24ca:	31 d2                	xor    %edx,%edx
    24cc:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    24d2:	39 c8                	cmp    %ecx,%eax
    24d4:	73 62                	jae    0x2538
    24d6:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    24da:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    24e0:	8b 55 80             	mov    -0x80(%rbp),%edx
    24e3:	89 ce                	mov    %ecx,%esi
    24e5:	29 f2                	sub    %esi,%edx
    24e7:	c1 fa 02             	sar    $0x2,%edx
    24ea:	6b d2 09             	imul   $0x9,%edx,%edx
    24ed:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    24f3:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    24f6:	89 c1                	mov    %eax,%ecx
    24f8:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    24fe:	83 f8 0a             	cmp    $0xa,%eax
    2501:	72 35                	jb     0x2538
    2503:	b8 0a 00 00 00       	mov    $0xa,%eax
    2508:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    250e:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    2514:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    251a:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    2520:	8d 52 01             	lea    0x1(%rdx),%edx
    2523:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    2529:	6b c9 0a             	imul   $0xa,%ecx,%ecx
    252c:	89 ca                	mov    %ecx,%edx
    252e:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    2534:	39 c8                	cmp    %ecx,%eax
    2536:	73 d6                	jae    0x250e
    2538:	8b 55 80             	mov    -0x80(%rbp),%edx
    253b:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    253e:	8b 7d 84             	mov    -0x7c(%rbp),%edi
    2541:	8b b5 78 ff ff ff    	mov    -0x88(%rbp),%esi
    2547:	44 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%r8d
    254e:	89 f0                	mov    %esi,%eax
    2550:	41 89 fa             	mov    %edi,%r10d
    2553:	83 ff 67             	cmp    $0x67,%edi
    2556:	40 0f 94 c7          	sete   %dil
    255a:	40 0f b6 ff          	movzbl %dil,%edi
    255e:	41 89 f9             	mov    %edi,%r9d
    2561:	44 89 8d 6c ff ff ff 	mov    %r9d,-0x94(%rbp)
    2568:	45 31 c9             	xor    %r9d,%r9d
    256b:	41 83 fa 66          	cmp    $0x66,%r10d
    256f:	45 0f 44 c1          	cmove  %r9d,%r8d
    2573:	44 29 c0             	sub    %r8d,%eax
    2576:	85 f6                	test   %esi,%esi
    2578:	40 0f 95 c6          	setne  %sil
    257c:	40 0f b6 f6          	movzbl %sil,%esi
    2580:	21 fe                	and    %edi,%esi
    2582:	29 f0                	sub    %esi,%eax
    2584:	89 c6                	mov    %eax,%esi
    2586:	89 b5 50 ff ff ff    	mov    %esi,-0xb0(%rbp)
    258c:	29 d1                	sub    %edx,%ecx
    258e:	c1 f9 02             	sar    $0x2,%ecx
    2591:	6b c9 09             	imul   $0x9,%ecx,%ecx
    2594:	8d 49 f7             	lea    -0x9(%rcx),%ecx
    2597:	39 c8                	cmp    %ecx,%eax
    2599:	0f 8d 53 04 00 00    	jge    0x29f2
    259f:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    25a5:	8d 80 00 24 00 00    	lea    0x2400(%rax),%eax
    25ab:	89 c1                	mov    %eax,%ecx
    25ad:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    25b3:	89 85 b0 fe ff ff    	mov    %eax,-0x150(%rbp)
    25b9:	b9 09 00 00 00       	mov    $0x9,%ecx
    25be:	89 8d b4 fe ff ff    	mov    %ecx,-0x14c(%rbp)
    25c4:	3d 00 00 00 80       	cmp    $0x80000000,%eax
    25c9:	75 0f                	jne    0x25da
    25cb:	8b 85 b4 fe ff ff    	mov    -0x14c(%rbp),%eax
    25d1:	83 f8 ff             	cmp    $0xffffffff,%eax
    25d4:	0f 84 ce 28 00 00    	je     0x4ea8
    25da:	44 8b 45 ac          	mov    -0x54(%rbp),%r8d
    25de:	8b 75 dc             	mov    -0x24(%rbp),%esi
    25e1:	8b 7d e0             	mov    -0x20(%rbp),%edi
    25e4:	8b 8d b4 fe ff ff    	mov    -0x14c(%rbp),%ecx
    25ea:	8b 85 b0 fe ff ff    	mov    -0x150(%rbp),%eax
    25f0:	99                   	cltd
    25f1:	f7 f9                	idiv   %ecx
    25f3:	89 c2                	mov    %eax,%edx
    25f5:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    25fb:	89 d1                	mov    %edx,%ecx
    25fd:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    2603:	c1 e2 02             	shl    $0x2,%edx
    2606:	45 85 c0             	test   %r8d,%r8d
    2609:	0f 45 f7             	cmovne %edi,%esi
    260c:	01 f2                	add    %esi,%edx
    260e:	89 d6                	mov    %edx,%esi
    2610:	89 75 ac             	mov    %esi,-0x54(%rbp)
    2613:	8d 92 00 f0 ff ff    	lea    -0x1000(%rdx),%edx
    2619:	89 95 70 ff ff ff    	mov    %edx,-0x90(%rbp)
    261f:	ba 0a 00 00 00       	mov    $0xa,%edx
    2624:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    262a:	6b c9 09             	imul   $0x9,%ecx,%ecx
    262d:	29 c8                	sub    %ecx,%eax
    262f:	89 c1                	mov    %eax,%ecx
    2631:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    2637:	83 f8 07             	cmp    $0x7,%eax
    263a:	7f 54                	jg     0x2690
    263c:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    2642:	8d 40 f8             	lea    -0x8(%rax),%eax
    2645:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    264b:	b8 0a 00 00 00       	mov    $0xa,%eax
    2650:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    2656:	8b 95 50 ff ff ff    	mov    -0xb0(%rbp),%edx
    265c:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    2662:	6b c0 0a             	imul   $0xa,%eax,%eax
    2665:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    266b:	89 d0                	mov    %edx,%eax
    266d:	8d 40 01             	lea    0x1(%rax),%eax
    2670:	89 c1                	mov    %eax,%ecx
    2672:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    2678:	39 d0                	cmp    %edx,%eax
    267a:	0f 93 c0             	setae  %al
    267d:	0f b6 c0             	movzbl %al,%eax
    2680:	89 85 74 ff ff ff    	mov    %eax,-0x8c(%rbp)
    2686:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    268c:	85 c0                	test   %eax,%eax
    268e:	75 c6                	jne    0x2656
    2690:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    2693:	8b b5 70 ff ff ff    	mov    -0x90(%rbp),%esi
    2699:	8b bd 60 ff ff ff    	mov    -0xa0(%rbp),%edi
    269f:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    26a3:	8b 04 30             	mov    (%rax,%rsi,1),%eax
    26a6:	89 85 ac fe ff ff    	mov    %eax,-0x154(%rbp)
    26ac:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    26b2:	89 fe                	mov    %edi,%esi
    26b4:	31 d2                	xor    %edx,%edx
    26b6:	f7 f6                	div    %esi
    26b8:	8b 95 ac fe ff ff    	mov    -0x154(%rbp),%edx
    26be:	89 c6                	mov    %eax,%esi
    26c0:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    26c6:	41 89 f0             	mov    %esi,%r8d
    26c9:	44 89 85 74 ff ff ff 	mov    %r8d,-0x8c(%rbp)
    26d0:	0f af f7             	imul   %edi,%esi
    26d3:	29 f2                	sub    %esi,%edx
    26d5:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    26db:	8d 40 04             	lea    0x4(%rax),%eax
    26de:	89 c2                	mov    %eax,%edx
    26e0:	89 55 84             	mov    %edx,-0x7c(%rbp)
    26e3:	39 c8                	cmp    %ecx,%eax
    26e5:	75 0e                	jne    0x26f5
    26e7:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    26ed:	85 c0                	test   %eax,%eax
    26ef:	0f 84 df 02 00 00    	je     0x29d4
    26f5:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
    26fb:	83 e0 01             	and    $0x1,%eax
    26fe:	85 c0                	test   %eax,%eax
    2700:	75 42                	jne    0x2744
    2702:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    2708:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    270e:	f2 0f 10 85 18 ff ff 	movsd  -0xe8(%rbp),%xmm0
    2715:	ff 
    2716:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
    271b:	39 c8                	cmp    %ecx,%eax
    271d:	76 32                	jbe    0x2751
    271f:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    2725:	3d 00 ca 9a 3b       	cmp    $0x3b9aca00,%eax
    272a:	75 25                	jne    0x2751
    272c:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2730:	8b 8d 70 ff ff ff    	mov    -0x90(%rbp),%ecx
    2736:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    2739:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    273d:	83 e0 01             	and    $0x1,%eax
    2740:	85 c0                	test   %eax,%eax
    2742:	74 0d                	je     0x2751
    2744:	f2 0f 10 85 20 ff ff 	movsd  -0xe0(%rbp),%xmm0
    274b:	ff 
    274c:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
    2751:	f2 0f 10 85 30 ff ff 	movsd  -0xd0(%rbp),%xmm0
    2758:	ff 
    2759:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    275f:	8b 7d fc             	mov    -0x4(%rbp),%edi
    2762:	44 8b 45 84          	mov    -0x7c(%rbp),%r8d
    2766:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    276c:	89 f0                	mov    %esi,%eax
    276e:	c1 e9 01             	shr    $0x1,%ecx
    2771:	89 ca                	mov    %ecx,%edx
    2773:	89 95 74 ff ff ff    	mov    %edx,-0x8c(%rbp)
    2779:	44 89 85 90 fe ff ff 	mov    %r8d,-0x170(%rbp)
    2780:	89 bd 94 fe ff ff    	mov    %edi,-0x16c(%rbp)
    2786:	89 b5 98 fe ff ff    	mov    %esi,-0x168(%rbp)
    278c:	89 95 9c fe ff ff    	mov    %edx,-0x164(%rbp)
    2792:	39 c8                	cmp    %ecx,%eax
    2794:	f2 0f 11 85 a0 fe ff 	movsd  %xmm0,-0x160(%rbp)
    279b:	ff 
    279c:	74 10                	je     0x27ae
    279e:	f2 0f 10 85 38 ff ff 	movsd  -0xc8(%rbp),%xmm0
    27a5:	ff 
    27a6:	f2 0f 11 85 a0 fe ff 	movsd  %xmm0,-0x160(%rbp)
    27ad:	ff 
    27ae:	f2 0f 10 85 a0 fe ff 	movsd  -0x160(%rbp),%xmm0
    27b5:	ff 
    27b6:	8b 85 90 fe ff ff    	mov    -0x170(%rbp),%eax
    27bc:	8b 8d 94 fe ff ff    	mov    -0x16c(%rbp),%ecx
    27c2:	39 c8                	cmp    %ecx,%eax
    27c4:	f2 0f 11 85 88 fe ff 	movsd  %xmm0,-0x178(%rbp)
    27cb:	ff 
    27cc:	74 10                	je     0x27de
    27ce:	f2 0f 10 85 38 ff ff 	movsd  -0xc8(%rbp),%xmm0
    27d5:	ff 
    27d6:	f2 0f 11 85 88 fe ff 	movsd  %xmm0,-0x178(%rbp)
    27dd:	ff 
    27de:	f2 0f 10 85 28 ff ff 	movsd  -0xd8(%rbp),%xmm0
    27e5:	ff 
    27e6:	8b 85 98 fe ff ff    	mov    -0x168(%rbp),%eax
    27ec:	8b 8d 9c fe ff ff    	mov    -0x164(%rbp),%ecx
    27f2:	39 c8                	cmp    %ecx,%eax
    27f4:	f2 0f 11 85 80 fe ff 	movsd  %xmm0,-0x180(%rbp)
    27fb:	ff 
    27fc:	72 10                	jb     0x280e
    27fe:	f2 0f 10 85 88 fe ff 	movsd  -0x178(%rbp),%xmm0
    2805:	ff 
    2806:	f2 0f 11 85 80 fe ff 	movsd  %xmm0,-0x180(%rbp)
    280d:	ff 
    280e:	8b 45 a4             	mov    -0x5c(%rbp),%eax
    2811:	f2 0f 10 85 80 fe ff 	movsd  -0x180(%rbp),%xmm0
    2818:	ff 
    2819:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    281e:	85 c0                	test   %eax,%eax
    2820:	75 52                	jne    0x2874
    2822:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2826:	8b 4d a8             	mov    -0x58(%rbp),%ecx
    2829:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    282d:	83 f8 2d             	cmp    $0x2d,%eax
    2830:	75 42                	jne    0x2874
    2832:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    2837:	f2 0f 10 4d b0       	movsd  -0x50(%rbp),%xmm1
    283c:	66 48 0f 7e c8       	movq   %xmm1,%rax
    2841:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    2848:	00 00 80 
    284b:	48 31 c8             	xor    %rcx,%rax
    284e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    2853:	f2 0f 11 4d b0       	movsd  %xmm1,-0x50(%rbp)
    2858:	66 48 0f 7e c0       	movq   %xmm0,%rax
    285d:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    2864:	00 00 80 
    2867:	48 31 c8             	xor    %rcx,%rax
    286a:	66 48 0f 6e c0       	movq   %rax,%xmm0
    286f:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
    2874:	f2 0f 10 4d 98       	movsd  -0x68(%rbp),%xmm1
    2879:	f2 0f 10 55 b0       	movsd  -0x50(%rbp),%xmm2
    287e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2882:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    2888:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    288e:	8b 8d 70 ff ff ff    	mov    -0x90(%rbp),%ecx
    2894:	29 f2                	sub    %esi,%edx
    2896:	89 d6                	mov    %edx,%esi
    2898:	89 b5 50 ff ff ff    	mov    %esi,-0xb0(%rbp)
    289e:	89 14 08             	mov    %edx,(%rax,%rcx,1)
    28a1:	0f 28 c1             	movaps %xmm1,%xmm0
    28a4:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
    28a8:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    28ac:	0f 94 c0             	sete   %al
    28af:	0f 9b c1             	setnp  %cl
    28b2:	20 c8                	and    %cl,%al
    28b4:	0f b6 c0             	movzbl %al,%eax
    28b7:	85 c0                	test   %eax,%eax
    28b9:	0f 85 15 01 00 00    	jne    0x29d4
    28bf:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    28c3:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    28c9:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    28cf:	8b 95 70 ff ff ff    	mov    -0x90(%rbp),%edx
    28d5:	01 c6                	add    %eax,%esi
    28d7:	89 f0                	mov    %esi,%eax
    28d9:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    28df:	89 34 11             	mov    %esi,(%rcx,%rdx,1)
    28e2:	3d 00 ca 9a 3b       	cmp    $0x3b9aca00,%eax
    28e7:	0f 82 85 00 00 00    	jb     0x2972
    28ed:	8b 45 ac             	mov    -0x54(%rbp),%eax
    28f0:	8d 80 fc ef ff ff    	lea    -0x1004(%rax),%eax
    28f6:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    28fc:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    2902:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    2908:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    290c:	89 c6                	mov    %eax,%esi
    290e:	8d 76 04             	lea    0x4(%rsi),%esi
    2911:	31 ff                	xor    %edi,%edi
    2913:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
    2916:	39 c8                	cmp    %ecx,%eax
    2918:	73 1a                	jae    0x2934
    291a:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    291e:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    2924:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    2927:	89 ca                	mov    %ecx,%edx
    2929:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    292f:	31 d2                	xor    %edx,%edx
    2931:	89 14 08             	mov    %edx,(%rax,%rcx,1)
    2934:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    293a:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    293e:	89 ce                	mov    %ecx,%esi
    2940:	89 c8                	mov    %ecx,%eax
    2942:	8b 04 02             	mov    (%rdx,%rax,1),%eax
    2945:	8d 78 01             	lea    0x1(%rax),%edi
    2948:	89 f8                	mov    %edi,%eax
    294a:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    2950:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
    2953:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    2956:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    295c:	3d ff c9 9a 3b       	cmp    $0x3b9ac9ff,%eax
    2961:	77 99                	ja     0x28fc
    2963:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    2969:	8d 40 04             	lea    0x4(%rax),%eax
    296c:	89 85 70 ff ff ff    	mov    %eax,-0x90(%rbp)
    2972:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2976:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    297c:	8b 55 80             	mov    -0x80(%rbp),%edx
    297f:	89 ce                	mov    %ecx,%esi
    2981:	29 f2                	sub    %esi,%edx
    2983:	c1 fa 02             	sar    $0x2,%edx
    2986:	6b d2 09             	imul   $0x9,%edx,%edx
    2989:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    298f:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    2992:	89 c1                	mov    %eax,%ecx
    2994:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    299a:	83 f8 0a             	cmp    $0xa,%eax
    299d:	72 35                	jb     0x29d4
    299f:	b8 0a 00 00 00       	mov    $0xa,%eax
    29a4:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    29aa:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    29b0:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    29b6:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    29bc:	8d 52 01             	lea    0x1(%rdx),%edx
    29bf:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    29c5:	6b c9 0a             	imul   $0xa,%ecx,%ecx
    29c8:	89 ca                	mov    %ecx,%edx
    29ca:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    29d0:	39 c8                	cmp    %ecx,%eax
    29d2:	73 d6                	jae    0x29aa
    29d4:	8b 55 fc             	mov    -0x4(%rbp),%edx
    29d7:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    29dd:	8d 48 04             	lea    0x4(%rax),%ecx
    29e0:	89 ce                	mov    %ecx,%esi
    29e2:	89 b5 50 ff ff ff    	mov    %esi,-0xb0(%rbp)
    29e8:	89 d0                	mov    %edx,%eax
    29ea:	39 f2                	cmp    %esi,%edx
    29ec:	0f 47 c1             	cmova  %ecx,%eax
    29ef:	89 45 fc             	mov    %eax,-0x4(%rbp)
    29f2:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    29f8:	8b 45 fc             	mov    -0x4(%rbp),%eax
    29fb:	89 c2                	mov    %eax,%edx
    29fd:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    2a03:	39 c8                	cmp    %ecx,%eax
    2a05:	77 07                	ja     0x2a0e
    2a07:	31 c0                	xor    %eax,%eax
    2a09:	89 45 84             	mov    %eax,-0x7c(%rbp)
    2a0c:	eb 21                	jmp    0x2a2f
    2a0e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2a12:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    2a18:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    2a1b:	89 ca                	mov    %ecx,%edx
    2a1d:	89 55 fc             	mov    %edx,-0x4(%rbp)
    2a20:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    2a23:	85 c0                	test   %eax,%eax
    2a25:	74 cb                	je     0x29f2
    2a27:	b8 01 00 00 00       	mov    $0x1,%eax
    2a2c:	89 45 84             	mov    %eax,-0x7c(%rbp)
    2a2f:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    2a35:	85 c0                	test   %eax,%eax
    2a37:	75 14                	jne    0x2a4d
    2a39:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    2a3f:	83 e0 08             	and    $0x8,%eax
    2a42:	89 85 70 ff ff ff    	mov    %eax,-0x90(%rbp)
    2a48:	e9 c9 01 00 00       	jmp    0x2c16
    2a4d:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    2a53:	8b 95 7c ff ff ff    	mov    -0x84(%rbp),%edx
    2a59:	44 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%r9d
    2a60:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    2a66:	41 89 c8             	mov    %ecx,%r8d
    2a69:	44 89 ce             	mov    %r9d,%esi
    2a6c:	bf 01 00 00 00       	mov    $0x1,%edi
    2a71:	45 85 c9             	test   %r9d,%r9d
    2a74:	0f 45 fe             	cmovne %esi,%edi
    2a77:	89 fe                	mov    %edi,%esi
    2a79:	89 75 fc             	mov    %esi,-0x4(%rbp)
    2a7c:	41 89 c9             	mov    %ecx,%r9d
    2a7f:	44 39 cf             	cmp    %r9d,%edi
    2a82:	40 0f 9f c7          	setg   %dil
    2a86:	44 0f b6 cf          	movzbl %dil,%r9d
    2a8a:	83 f9 fb             	cmp    $0xfffffffb,%ecx
    2a8d:	0f 9f c1             	setg   %cl
    2a90:	0f b6 c9             	movzbl %cl,%ecx
    2a93:	41 21 c9             	and    %ecx,%r9d
    2a96:	44 89 cf             	mov    %r9d,%edi
    2a99:	89 bd 50 ff ff ff    	mov    %edi,-0xb0(%rbp)
    2a9f:	41 81 f0 ff ff ff ff 	xor    $0xffffffff,%r8d
    2aa6:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    2aab:	45 85 c9             	test   %r9d,%r9d
    2aae:	41 0f 45 c8          	cmovne %r8d,%ecx
    2ab2:	01 f1                	add    %esi,%ecx
    2ab4:	89 8d 78 ff ff ff    	mov    %ecx,-0x88(%rbp)
    2aba:	be ff ff ff ff       	mov    $0xffffffff,%esi
    2abf:	b9 fe ff ff ff       	mov    $0xfffffffe,%ecx
    2ac4:	85 ff                	test   %edi,%edi
    2ac6:	0f 45 ce             	cmovne %esi,%ecx
    2ac9:	01 d1                	add    %edx,%ecx
    2acb:	89 8d 7c ff ff ff    	mov    %ecx,-0x84(%rbp)
    2ad1:	83 e0 08             	and    $0x8,%eax
    2ad4:	89 c1                	mov    %eax,%ecx
    2ad6:	89 8d 70 ff ff ff    	mov    %ecx,-0x90(%rbp)
    2adc:	85 c0                	test   %eax,%eax
    2ade:	0f 85 32 01 00 00    	jne    0x2c16
    2ae4:	8b 45 84             	mov    -0x7c(%rbp),%eax
    2ae7:	b9 09 00 00 00       	mov    $0x9,%ecx
    2aec:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2aef:	85 c0                	test   %eax,%eax
    2af1:	0f 84 83 00 00 00    	je     0x2b7a
    2af7:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2afb:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    2b01:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    2b04:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    2b07:	89 c1                	mov    %eax,%ecx
    2b09:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    2b0f:	85 c0                	test   %eax,%eax
    2b11:	74 67                	je     0x2b7a
    2b13:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2b19:	31 c9                	xor    %ecx,%ecx
    2b1b:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2b1e:	b9 0a 00 00 00       	mov    $0xa,%ecx
    2b23:	89 c1                	mov    %eax,%ecx
    2b25:	48 ba cd cc cc cc 00 	movabs $0xcccccccd,%rdx
    2b2c:	00 00 00 
    2b2f:	48 0f af ca          	imul   %rdx,%rcx
    2b33:	48 c1 e9 23          	shr    $0x23,%rcx
    2b37:	89 c9                	mov    %ecx,%ecx
    2b39:	6b c9 0a             	imul   $0xa,%ecx,%ecx
    2b3c:	29 c8                	sub    %ecx,%eax
    2b3e:	85 c0                	test   %eax,%eax
    2b40:	75 38                	jne    0x2b7a
    2b42:	b8 0a 00 00 00       	mov    $0xa,%eax
    2b47:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    2b4d:	31 c0                	xor    %eax,%eax
    2b4f:	89 45 fc             	mov    %eax,-0x4(%rbp)
    2b52:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    2b58:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2b5e:	8b 75 fc             	mov    -0x4(%rbp),%esi
    2b61:	8d 76 01             	lea    0x1(%rsi),%esi
    2b64:	89 75 fc             	mov    %esi,-0x4(%rbp)
    2b67:	6b c9 0a             	imul   $0xa,%ecx,%ecx
    2b6a:	89 ce                	mov    %ecx,%esi
    2b6c:	89 b5 50 ff ff ff    	mov    %esi,-0xb0(%rbp)
    2b72:	31 d2                	xor    %edx,%edx
    2b74:	f7 f1                	div    %ecx
    2b76:	85 d2                	test   %edx,%edx
    2b78:	74 d8                	je     0x2b52
    2b7a:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    2b80:	8b 55 80             	mov    -0x80(%rbp),%edx
    2b83:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    2b89:	29 d1                	sub    %edx,%ecx
    2b8b:	c1 f9 02             	sar    $0x2,%ecx
    2b8e:	6b c9 09             	imul   $0x9,%ecx,%ecx
    2b91:	8d 49 f7             	lea    -0x9(%rcx),%ecx
    2b94:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    2b9a:	25 df ff ff ff       	and    $0xffffffdf,%eax
    2b9f:	83 f8 46             	cmp    $0x46,%eax
    2ba2:	75 36                	jne    0x2bda
    2ba4:	8b 95 78 ff ff ff    	mov    -0x88(%rbp),%edx
    2baa:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2bad:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    2bb3:	31 c9                	xor    %ecx,%ecx
    2bb5:	89 8d 70 ff ff ff    	mov    %ecx,-0x90(%rbp)
    2bbb:	89 d1                	mov    %edx,%ecx
    2bbd:	29 c6                	sub    %eax,%esi
    2bbf:	89 f7                	mov    %esi,%edi
    2bc1:	31 c0                	xor    %eax,%eax
    2bc3:	85 ff                	test   %edi,%edi
    2bc5:	0f 4f c6             	cmovg  %esi,%eax
    2bc8:	89 c6                	mov    %eax,%esi
    2bca:	89 75 fc             	mov    %esi,-0x4(%rbp)
    2bcd:	39 f2                	cmp    %esi,%edx
    2bcf:	0f 4c c1             	cmovl  %ecx,%eax
    2bd2:	89 85 78 ff ff ff    	mov    %eax,-0x88(%rbp)
    2bd8:	eb 3c                	jmp    0x2c16
    2bda:	8b 95 78 ff ff ff    	mov    -0x88(%rbp),%edx
    2be0:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2be3:	8b bd 58 ff ff ff    	mov    -0xa8(%rbp),%edi
    2be9:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    2bef:	31 c9                	xor    %ecx,%ecx
    2bf1:	89 8d 70 ff ff ff    	mov    %ecx,-0x90(%rbp)
    2bf7:	89 d1                	mov    %edx,%ecx
    2bf9:	01 fe                	add    %edi,%esi
    2bfb:	29 c6                	sub    %eax,%esi
    2bfd:	89 f7                	mov    %esi,%edi
    2bff:	31 c0                	xor    %eax,%eax
    2c01:	85 ff                	test   %edi,%edi
    2c03:	0f 4f c6             	cmovg  %esi,%eax
    2c06:	89 c6                	mov    %eax,%esi
    2c08:	89 75 fc             	mov    %esi,-0x4(%rbp)
    2c0b:	39 f2                	cmp    %esi,%edx
    2c0d:	0f 4c c1             	cmovl  %ecx,%eax
    2c10:	89 85 78 ff ff ff    	mov    %eax,-0x88(%rbp)
    2c16:	8b 8d 70 ff ff ff    	mov    -0x90(%rbp),%ecx
    2c1c:	8b b5 78 ff ff ff    	mov    -0x88(%rbp),%esi
    2c22:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    2c27:	89 45 fc             	mov    %eax,-0x4(%rbp)
    2c2a:	89 f0                	mov    %esi,%eax
    2c2c:	09 ce                	or     %ecx,%esi
    2c2e:	89 f1                	mov    %esi,%ecx
    2c30:	89 8d 6c ff ff ff    	mov    %ecx,-0x94(%rbp)
    2c36:	ba fd ff ff 7f       	mov    $0x7ffffffd,%edx
    2c3b:	b9 fe ff ff 7f       	mov    $0x7ffffffe,%ecx
    2c40:	85 f6                	test   %esi,%esi
    2c42:	0f 45 ca             	cmovne %edx,%ecx
    2c45:	39 c8                	cmp    %ecx,%eax
    2c47:	0f 8f 0b 22 00 00    	jg     0x4e58
    2c4d:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    2c53:	8b 95 6c ff ff ff    	mov    -0x94(%rbp),%edx
    2c59:	8b 8d 78 ff ff ff    	mov    -0x88(%rbp),%ecx
    2c5f:	85 d2                	test   %edx,%edx
    2c61:	0f 95 c2             	setne  %dl
    2c64:	0f b6 d2             	movzbl %dl,%edx
    2c67:	01 d1                	add    %edx,%ecx
    2c69:	8d 49 01             	lea    0x1(%rcx),%ecx
    2c6c:	89 4d a4             	mov    %ecx,-0x5c(%rbp)
    2c6f:	25 df ff ff ff       	and    $0xffffffdf,%eax
    2c74:	83 f8 46             	cmp    $0x46,%eax
    2c77:	0f 95 c0             	setne  %al
    2c7a:	0f b6 c0             	movzbl %al,%eax
    2c7d:	89 c1                	mov    %eax,%ecx
    2c7f:	89 4d bc             	mov    %ecx,-0x44(%rbp)
    2c82:	85 c0                	test   %eax,%eax
    2c84:	75 32                	jne    0x2cb8
    2c86:	8b 55 a4             	mov    -0x5c(%rbp),%edx
    2c89:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    2c8f:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
    2c94:	29 d1                	sub    %edx,%ecx
    2c96:	39 c8                	cmp    %ecx,%eax
    2c98:	0f 8f ba 21 00 00    	jg     0x4e58
    2c9e:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    2ca4:	89 d1                	mov    %edx,%ecx
    2ca6:	31 c0                	xor    %eax,%eax
    2ca8:	85 d2                	test   %edx,%edx
    2caa:	0f 4f c1             	cmovg  %ecx,%eax
    2cad:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    2cb3:	e9 51 01 00 00       	jmp    0x2e09
    2cb8:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    2cbe:	8b 45 e8             	mov    -0x18(%rbp),%eax
    2cc1:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    2cc7:	89 d0                	mov    %edx,%eax
    2cc9:	c1 fa 1f             	sar    $0x1f,%edx
    2ccc:	89 d1                	mov    %edx,%ecx
    2cce:	01 d0                	add    %edx,%eax
    2cd0:	31 c8                	xor    %ecx,%eax
    2cd2:	89 c1                	mov    %eax,%ecx
    2cd4:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2cd7:	85 c0                	test   %eax,%eax
    2cd9:	74 66                	je     0x2d41
    2cdb:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2cde:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    2ce2:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    2ce8:	8d 71 ff             	lea    -0x1(%rcx),%esi
    2ceb:	89 f1                	mov    %esi,%ecx
    2ced:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    2cf3:	89 c7                	mov    %eax,%edi
    2cf5:	89 c1                	mov    %eax,%ecx
    2cf7:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
    2cfd:	89 c9                	mov    %ecx,%ecx
    2cff:	49 b8 cd cc cc cc 00 	movabs $0xcccccccd,%r8
    2d06:	00 00 00 
    2d09:	49 0f af c8          	imul   %r8,%rcx
    2d0d:	48 c1 e9 23          	shr    $0x23,%rcx
    2d11:	41 89 c8             	mov    %ecx,%r8d
    2d14:	44 89 c1             	mov    %r8d,%ecx
    2d17:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    2d1d:	45 6b c0 0a          	imul   $0xa,%r8d,%r8d
    2d21:	44 29 c7             	sub    %r8d,%edi
    2d24:	83 cf 30             	or     $0x30,%edi
    2d27:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    2d2b:	83 f8 09             	cmp    $0x9,%eax
    2d2e:	0f 97 c0             	seta   %al
    2d31:	0f b6 c0             	movzbl %al,%eax
    2d34:	89 85 74 ff ff ff    	mov    %eax,-0x8c(%rbp)
    2d3a:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2d3d:	85 c0                	test   %eax,%eax
    2d3f:	75 9a                	jne    0x2cdb
    2d41:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    2d47:	8b 45 e8             	mov    -0x18(%rbp),%eax
    2d4a:	29 c8                	sub    %ecx,%eax
    2d4c:	83 f8 01             	cmp    $0x1,%eax
    2d4f:	7f 4d                	jg     0x2d9e
    2d51:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    2d57:	8d 40 ff             	lea    -0x1(%rax),%eax
    2d5a:	89 45 fc             	mov    %eax,-0x4(%rbp)
    2d5d:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    2d60:	8b 45 e8             	mov    -0x18(%rbp),%eax
    2d63:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    2d67:	89 ce                	mov    %ecx,%esi
    2d69:	bf 30 00 00 00       	mov    $0x30,%edi
    2d6e:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    2d72:	89 ca                	mov    %ecx,%edx
    2d74:	29 d0                	sub    %edx,%eax
    2d76:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    2d7c:	8d 49 ff             	lea    -0x1(%rcx),%ecx
    2d7f:	89 ca                	mov    %ecx,%edx
    2d81:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    2d87:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2d8a:	83 f8 02             	cmp    $0x2,%eax
    2d8d:	7c ce                	jl     0x2d5d
    2d8f:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2d95:	8d 40 01             	lea    0x1(%rax),%eax
    2d98:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    2d9e:	8b 55 a4             	mov    -0x5c(%rbp),%edx
    2da1:	44 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%r10d
    2da8:	8b 45 e8             	mov    -0x18(%rbp),%eax
    2dab:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    2daf:	8b bd 50 ff ff ff    	mov    -0xb0(%rbp),%edi
    2db5:	44 8b 8d 7c ff ff ff 	mov    -0x84(%rbp),%r9d
    2dbc:	89 f9                	mov    %edi,%ecx
    2dbe:	44 8d 41 fe          	lea    -0x2(%rcx),%r8d
    2dc2:	44 89 c1             	mov    %r8d,%ecx
    2dc5:	89 4d ac             	mov    %ecx,-0x54(%rbp)
    2dc8:	46 88 0c 06          	mov    %r9b,(%rsi,%r8,1)
    2dcc:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    2dd2:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    2dd6:	8d 7f ff             	lea    -0x1(%rdi),%edi
    2dd9:	41 b9 2d 00 00 00    	mov    $0x2d,%r9d
    2ddf:	41 b8 2b 00 00 00    	mov    $0x2b,%r8d
    2de5:	45 85 d2             	test   %r10d,%r10d
    2de8:	45 0f 4c c1          	cmovl  %r9d,%r8d
    2dec:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
    2df0:	29 c8                	sub    %ecx,%eax
    2df2:	89 c1                	mov    %eax,%ecx
    2df4:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    2dfa:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
    2dff:	29 d1                	sub    %edx,%ecx
    2e01:	39 c8                	cmp    %ecx,%eax
    2e03:	0f 8f 4f 20 00 00    	jg     0x4e58
    2e09:	8b 4d a0             	mov    -0x60(%rbp),%ecx
    2e0c:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    2e12:	8b 55 a4             	mov    -0x5c(%rbp),%edx
    2e15:	be ff ff ff ff       	mov    $0xffffffff,%esi
    2e1a:	89 75 fc             	mov    %esi,-0x4(%rbp)
    2e1d:	01 d0                	add    %edx,%eax
    2e1f:	89 c2                	mov    %eax,%edx
    2e21:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    2e27:	81 f1 ff ff ff 7f    	xor    $0x7fffffff,%ecx
    2e2d:	39 c8                	cmp    %ecx,%eax
    2e2f:	0f 8f 23 20 00 00    	jg     0x4e58
    2e35:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    2e3b:	8b 55 a0             	mov    -0x60(%rbp),%edx
    2e3e:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    2e44:	01 d1                	add    %edx,%ecx
    2e46:	89 8d 7c ff ff ff    	mov    %ecx,-0x84(%rbp)
    2e4c:	25 00 20 01 00       	and    $0x12000,%eax
    2e51:	89 c1                	mov    %eax,%ecx
    2e53:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
    2e59:	85 c0                	test   %eax,%eax
    2e5b:	0f 85 54 01 00 00    	jne    0x2fb5
    2e61:	8b 8d 7c ff ff ff    	mov    -0x84(%rbp),%ecx
    2e67:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    2e6d:	39 c8                	cmp    %ecx,%eax
    2e6f:	0f 8e 40 01 00 00    	jle    0x2fb5
    2e75:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    2e7c:	8b 95 7c ff ff ff    	mov    -0x84(%rbp),%edx
    2e82:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    2e88:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    2e8b:	29 d0                	sub    %edx,%eax
    2e8d:	41 89 c0             	mov    %eax,%r8d
    2e90:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    2e94:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    2e9b:	0f 92 c2             	setb   %dl
    2e9e:	0f b6 d2             	movzbl %dl,%edx
    2ea1:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    2ea7:	8d 71 40             	lea    0x40(%rcx),%esi
    2eaa:	ba 20 00 00 00       	mov    $0x20,%edx
    2eaf:	b9 00 01 00 00       	mov    $0x100,%ecx
    2eb4:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    2ebb:	0f 42 c8             	cmovb  %eax,%ecx
    2ebe:	e8 f5 42 fe ff       	call   0xfffffffffffe71b8
    2ec3:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    2eca:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    2ed0:	89 c6                	mov    %eax,%esi
    2ed2:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2ed8:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    2edf:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    2ee3:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    2ee6:	89 ca                	mov    %ecx,%edx
    2ee8:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    2eee:	83 e1 20             	and    $0x20,%ecx
    2ef1:	85 c9                	test   %ecx,%ecx
    2ef3:	0f 94 c1             	sete   %cl
    2ef6:	0f b6 c9             	movzbl %cl,%ecx
    2ef9:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    2eff:	85 c0                	test   %eax,%eax
    2f01:	75 79                	jne    0x2f7c
    2f03:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    2f09:	83 e0 01             	and    $0x1,%eax
    2f0c:	85 c0                	test   %eax,%eax
    2f0e:	74 40                	je     0x2f50
    2f10:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    2f16:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    2f1d:	8b 45 cc             	mov    -0x34(%rbp),%eax
    2f20:	8d 70 40             	lea    0x40(%rax),%esi
    2f23:	ba 00 01 00 00       	mov    $0x100,%edx
    2f28:	e8 a5 41 fe ff       	call   0xfffffffffffe70d2
    2f2d:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    2f33:	89 c2                	mov    %eax,%edx
    2f35:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    2f3c:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    2f43:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    2f47:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    2f4a:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    2f50:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2f53:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    2f59:	83 e1 20             	and    $0x20,%ecx
    2f5c:	85 c9                	test   %ecx,%ecx
    2f5e:	0f 94 c1             	sete   %cl
    2f61:	0f b6 c9             	movzbl %cl,%ecx
    2f64:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    2f6a:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    2f70:	89 c1                	mov    %eax,%ecx
    2f72:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2f75:	3d ff 00 00 00       	cmp    $0xff,%eax
    2f7a:	77 87                	ja     0x2f03
    2f7c:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    2f82:	85 c0                	test   %eax,%eax
    2f84:	74 2f                	je     0x2fb5
    2f86:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    2f8d:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    2f93:	8b 55 fc             	mov    -0x4(%rbp),%edx
    2f96:	8b 45 cc             	mov    -0x34(%rbp),%eax
    2f99:	8d 70 40             	lea    0x40(%rax),%esi
    2f9c:	e8 31 41 fe ff       	call   0xfffffffffffe70d2
    2fa1:	89 c1                	mov    %eax,%ecx
    2fa3:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    2faa:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    2fb1:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    2fb5:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2fb9:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    2fbf:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    2fc3:	83 e0 20             	and    $0x20,%eax
    2fc6:	85 c0                	test   %eax,%eax
    2fc8:	75 2c                	jne    0x2ff6
    2fca:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    2fd1:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    2fd7:	8b 55 a0             	mov    -0x60(%rbp),%edx
    2fda:	8b 75 a8             	mov    -0x58(%rbp),%esi
    2fdd:	e8 f0 40 fe ff       	call   0xfffffffffffe70d2
    2fe2:	89 c1                	mov    %eax,%ecx
    2fe4:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    2feb:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    2ff2:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    2ff6:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    2ffc:	3d 00 00 01 00       	cmp    $0x10000,%eax
    3001:	0f 85 54 01 00 00    	jne    0x315b
    3007:	8b 8d 7c ff ff ff    	mov    -0x84(%rbp),%ecx
    300d:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    3013:	39 c8                	cmp    %ecx,%eax
    3015:	0f 8e 40 01 00 00    	jle    0x315b
    301b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3022:	8b 95 7c ff ff ff    	mov    -0x84(%rbp),%edx
    3028:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    302e:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3031:	29 d0                	sub    %edx,%eax
    3033:	41 89 c0             	mov    %eax,%r8d
    3036:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    303a:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3041:	0f 92 c2             	setb   %dl
    3044:	0f b6 d2             	movzbl %dl,%edx
    3047:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    304d:	8d 71 40             	lea    0x40(%rcx),%esi
    3050:	ba 30 00 00 00       	mov    $0x30,%edx
    3055:	b9 00 01 00 00       	mov    $0x100,%ecx
    305a:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3061:	0f 42 c8             	cmovb  %eax,%ecx
    3064:	e8 4f 41 fe ff       	call   0xfffffffffffe71b8
    3069:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    3070:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    3076:	89 c6                	mov    %eax,%esi
    3078:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    307e:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    3085:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    3089:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    308c:	89 ca                	mov    %ecx,%edx
    308e:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    3094:	83 e1 20             	and    $0x20,%ecx
    3097:	85 c9                	test   %ecx,%ecx
    3099:	0f 94 c1             	sete   %cl
    309c:	0f b6 c9             	movzbl %cl,%ecx
    309f:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    30a5:	85 c0                	test   %eax,%eax
    30a7:	75 79                	jne    0x3122
    30a9:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    30af:	83 e0 01             	and    $0x1,%eax
    30b2:	85 c0                	test   %eax,%eax
    30b4:	74 40                	je     0x30f6
    30b6:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    30bc:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    30c3:	8b 45 cc             	mov    -0x34(%rbp),%eax
    30c6:	8d 70 40             	lea    0x40(%rax),%esi
    30c9:	ba 00 01 00 00       	mov    $0x100,%edx
    30ce:	e8 ff 3f fe ff       	call   0xfffffffffffe70d2
    30d3:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    30d9:	89 c2                	mov    %eax,%edx
    30db:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    30e2:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    30e9:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    30ed:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    30f0:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    30f6:	8b 45 fc             	mov    -0x4(%rbp),%eax
    30f9:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    30ff:	83 e1 20             	and    $0x20,%ecx
    3102:	85 c9                	test   %ecx,%ecx
    3104:	0f 94 c1             	sete   %cl
    3107:	0f b6 c9             	movzbl %cl,%ecx
    310a:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3110:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    3116:	89 c1                	mov    %eax,%ecx
    3118:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    311b:	3d ff 00 00 00       	cmp    $0xff,%eax
    3120:	77 87                	ja     0x30a9
    3122:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3128:	85 c0                	test   %eax,%eax
    312a:	74 2f                	je     0x315b
    312c:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3133:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3139:	8b 55 fc             	mov    -0x4(%rbp),%edx
    313c:	8b 45 cc             	mov    -0x34(%rbp),%eax
    313f:	8d 70 40             	lea    0x40(%rax),%esi
    3142:	e8 8b 3f fe ff       	call   0xfffffffffffe70d2
    3147:	89 c1                	mov    %eax,%ecx
    3149:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3150:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3157:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    315b:	8b 45 bc             	mov    -0x44(%rbp),%eax
    315e:	85 c0                	test   %eax,%eax
    3160:	0f 85 00 0c 00 00    	jne    0x3d66
    3166:	8b 75 80             	mov    -0x80(%rbp),%esi
    3169:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    316f:	89 f1                	mov    %esi,%ecx
    3171:	89 d0                	mov    %edx,%eax
    3173:	39 f2                	cmp    %esi,%edx
    3175:	0f 47 c1             	cmova  %ecx,%eax
    3178:	89 c1                	mov    %eax,%ecx
    317a:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
    3180:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    3186:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    318a:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    3190:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    3193:	89 c1                	mov    %eax,%ecx
    3195:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    3198:	85 c0                	test   %eax,%eax
    319a:	0f 84 c9 00 00 00    	je     0x3269
    31a0:	31 c0                	xor    %eax,%eax
    31a2:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    31a8:	8b 45 fc             	mov    -0x4(%rbp),%eax
    31ab:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    31b1:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    31b5:	8b 7d cc             	mov    -0x34(%rbp),%edi
    31b8:	41 89 d2             	mov    %edx,%r10d
    31bb:	41 89 c0             	mov    %eax,%r8d
    31be:	89 c1                	mov    %eax,%ecx
    31c0:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
    31c6:	89 c9                	mov    %ecx,%ecx
    31c8:	49 b9 cd cc cc cc 00 	movabs $0xcccccccd,%r9
    31cf:	00 00 00 
    31d2:	49 0f af c9          	imul   %r9,%rcx
    31d6:	48 c1 e9 23          	shr    $0x23,%rcx
    31da:	41 89 c9             	mov    %ecx,%r9d
    31dd:	44 89 c9             	mov    %r9d,%ecx
    31e0:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    31e6:	8d bf 50 01 00 00    	lea    0x150(%rdi),%edi
    31ec:	44 01 d7             	add    %r10d,%edi
    31ef:	8d 7f 08             	lea    0x8(%rdi),%edi
    31f2:	45 6b c9 0a          	imul   $0xa,%r9d,%r9d
    31f6:	45 29 c8             	sub    %r9d,%r8d
    31f9:	41 83 c8 30          	or     $0x30,%r8d
    31fd:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
    3201:	8d 52 ff             	lea    -0x1(%rdx),%edx
    3204:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    320a:	83 f8 09             	cmp    $0x9,%eax
    320d:	0f 97 c0             	seta   %al
    3210:	0f b6 c0             	movzbl %al,%eax
    3213:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    3219:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    321c:	85 c0                	test   %eax,%eax
    321e:	75 88                	jne    0x31a8
    3220:	8b 8d 74 ff ff ff    	mov    -0x8c(%rbp),%ecx
    3226:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    322c:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    3232:	8b 55 cc             	mov    -0x34(%rbp),%edx
    3235:	8d 92 50 01 00 00    	lea    0x150(%rdx),%edx
    323b:	01 f2                	add    %esi,%edx
    323d:	8d 52 09             	lea    0x9(%rdx),%edx
    3240:	89 55 fc             	mov    %edx,-0x4(%rbp)
    3243:	39 c8                	cmp    %ecx,%eax
    3245:	74 16                	je     0x325d
    3247:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    324a:	8b 45 fc             	mov    -0x4(%rbp),%eax
    324d:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    3253:	39 c8                	cmp    %ecx,%eax
    3255:	0f 86 88 00 00 00    	jbe    0x32e3
    325b:	eb 43                	jmp    0x32a0
    325d:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    3263:	85 c0                	test   %eax,%eax
    3265:	75 7c                	jne    0x32e3
    3267:	eb 1e                	jmp    0x3287
    3269:	8b 8d 74 ff ff ff    	mov    -0x8c(%rbp),%ecx
    326f:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3275:	8b 55 d8             	mov    -0x28(%rbp),%edx
    3278:	31 f6                	xor    %esi,%esi
    327a:	89 b5 54 ff ff ff    	mov    %esi,-0xac(%rbp)
    3280:	89 55 fc             	mov    %edx,-0x4(%rbp)
    3283:	39 c8                	cmp    %ecx,%eax
    3285:	75 19                	jne    0x32a0
    3287:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    328b:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    328e:	8d 49 ff             	lea    -0x1(%rcx),%ecx
    3291:	89 ca                	mov    %ecx,%edx
    3293:	89 55 fc             	mov    %edx,-0x4(%rbp)
    3296:	ba 30 00 00 00       	mov    $0x30,%edx
    329b:	88 14 08             	mov    %dl,(%rax,%rcx,1)
    329e:	eb 43                	jmp    0x32e3
    32a0:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    32a3:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    32aa:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    32b0:	8d b1 50 01 00 00    	lea    0x150(%rcx),%esi
    32b6:	ba 30 00 00 00       	mov    $0x30,%edx
    32bb:	8d 48 09             	lea    0x9(%rax),%ecx
    32be:	e8 f5 3e fe ff       	call   0xfffffffffffe71b8
    32c3:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    32ca:	89 c2                	mov    %eax,%edx
    32cc:	8b 45 cc             	mov    -0x34(%rbp),%eax
    32cf:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    32d6:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    32da:	8d 80 50 01 00 00    	lea    0x150(%rax),%eax
    32e0:	89 45 fc             	mov    %eax,-0x4(%rbp)
    32e3:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    32e7:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    32ed:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    32f1:	83 e0 20             	and    $0x20,%eax
    32f4:	85 c0                	test   %eax,%eax
    32f6:	75 30                	jne    0x3328
    32f8:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    32ff:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3305:	8b 45 fc             	mov    -0x4(%rbp),%eax
    3308:	8b 55 d8             	mov    -0x28(%rbp),%edx
    330b:	89 c6                	mov    %eax,%esi
    330d:	29 c2                	sub    %eax,%edx
    330f:	e8 be 3d fe ff       	call   0xfffffffffffe70d2
    3314:	89 c1                	mov    %eax,%ecx
    3316:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    331d:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3324:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3328:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    332b:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3331:	8d 40 04             	lea    0x4(%rax),%eax
    3334:	89 c2                	mov    %eax,%edx
    3336:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    333c:	39 c8                	cmp    %ecx,%eax
    333e:	0f 86 42 fe ff ff    	jbe    0x3186
    3344:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    334a:	85 c0                	test   %eax,%eax
    334c:	74 45                	je     0x3393
    334e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3352:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3358:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    335c:	83 e0 20             	and    $0x20,%eax
    335f:	85 c0                	test   %eax,%eax
    3361:	75 30                	jne    0x3393
    3363:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    336a:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3370:	be e3 0d 00 00       	mov    $0xde3,%esi
    3375:	ba 01 00 00 00       	mov    $0x1,%edx
    337a:	e8 53 3d fe ff       	call   0xfffffffffffe70d2
    337f:	89 c1                	mov    %eax,%ecx
    3381:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3388:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    338f:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3393:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    3399:	83 f8 01             	cmp    $0x1,%eax
    339c:	7d 0e                	jge    0x33ac
    339e:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    33a4:	89 45 fc             	mov    %eax,-0x4(%rbp)
    33a7:	e9 96 01 00 00       	jmp    0x3542
    33ac:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    33b2:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    33b8:	39 c8                	cmp    %ecx,%eax
    33ba:	72 0e                	jb     0x33ca
    33bc:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    33c2:	89 45 fc             	mov    %eax,-0x4(%rbp)
    33c5:	e9 78 01 00 00       	jmp    0x3542
    33ca:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    33ce:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    33d4:	8b 55 d8             	mov    -0x28(%rbp),%edx
    33d7:	89 55 fc             	mov    %edx,-0x4(%rbp)
    33da:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    33dd:	89 c1                	mov    %eax,%ecx
    33df:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    33e5:	85 c0                	test   %eax,%eax
    33e7:	74 7c                	je     0x3465
    33e9:	8b 45 d8             	mov    -0x28(%rbp),%eax
    33ec:	89 45 fc             	mov    %eax,-0x4(%rbp)
    33ef:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    33f5:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    33f9:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    33fc:	8d 71 ff             	lea    -0x1(%rcx),%esi
    33ff:	89 f1                	mov    %esi,%ecx
    3401:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    3404:	89 c7                	mov    %eax,%edi
    3406:	89 c1                	mov    %eax,%ecx
    3408:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
    340e:	89 c9                	mov    %ecx,%ecx
    3410:	49 b8 cd cc cc cc 00 	movabs $0xcccccccd,%r8
    3417:	00 00 00 
    341a:	49 0f af c8          	imul   %r8,%rcx
    341e:	48 c1 e9 23          	shr    $0x23,%rcx
    3422:	41 89 c8             	mov    %ecx,%r8d
    3425:	44 89 c1             	mov    %r8d,%ecx
    3428:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    342e:	45 6b c0 0a          	imul   $0xa,%r8d,%r8d
    3432:	44 29 c7             	sub    %r8d,%edi
    3435:	83 cf 30             	or     $0x30,%edi
    3438:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    343c:	83 f8 09             	cmp    $0x9,%eax
    343f:	0f 97 c0             	seta   %al
    3442:	0f b6 c0             	movzbl %al,%eax
    3445:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    344b:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    3451:	85 c0                	test   %eax,%eax
    3453:	75 9a                	jne    0x33ef
    3455:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3458:	8b 45 fc             	mov    -0x4(%rbp),%eax
    345b:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    3461:	39 c8                	cmp    %ecx,%eax
    3463:	76 4e                	jbe    0x34b3
    3465:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    346c:	8b 45 ec             	mov    -0x14(%rbp),%eax
    346f:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    3472:	8b 55 cc             	mov    -0x34(%rbp),%edx
    3475:	8d b2 50 01 00 00    	lea    0x150(%rdx),%esi
    347b:	ba 30 00 00 00       	mov    $0x30,%edx
    3480:	01 c1                	add    %eax,%ecx
    3482:	e8 31 3d fe ff       	call   0xfffffffffffe71b8
    3487:	89 c1                	mov    %eax,%ecx
    3489:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3490:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3497:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    349b:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    349e:	8b 45 fc             	mov    -0x4(%rbp),%eax
    34a1:	8d 40 ff             	lea    -0x1(%rax),%eax
    34a4:	89 c2                	mov    %eax,%edx
    34a6:	89 55 fc             	mov    %edx,-0x4(%rbp)
    34a9:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    34af:	39 c8                	cmp    %ecx,%eax
    34b1:	77 e8                	ja     0x349b
    34b3:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    34b7:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    34bd:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    34c1:	83 e0 20             	and    $0x20,%eax
    34c4:	85 c0                	test   %eax,%eax
    34c6:	75 3f                	jne    0x3507
    34c8:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    34cf:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    34d5:	44 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%r8d
    34dc:	8b 75 fc             	mov    -0x4(%rbp),%esi
    34df:	44 89 c0             	mov    %r8d,%eax
    34e2:	ba 09 00 00 00       	mov    $0x9,%edx
    34e7:	41 83 f8 09          	cmp    $0x9,%r8d
    34eb:	0f 4c d0             	cmovl  %eax,%edx
    34ee:	e8 df 3b fe ff       	call   0xfffffffffffe70d2
    34f3:	89 c1                	mov    %eax,%ecx
    34f5:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    34fc:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3503:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3507:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    350d:	89 c1                	mov    %eax,%ecx
    350f:	8d 49 f7             	lea    -0x9(%rcx),%ecx
    3512:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    3515:	83 f8 0a             	cmp    $0xa,%eax
    3518:	7c 28                	jl     0x3542
    351a:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    3520:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3526:	8b 55 fc             	mov    -0x4(%rbp),%edx
    3529:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    352f:	8d 40 04             	lea    0x4(%rax),%eax
    3532:	89 c2                	mov    %eax,%edx
    3534:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    353a:	39 c8                	cmp    %ecx,%eax
    353c:	0f 82 88 fe ff ff    	jb     0x33ca
    3542:	8b 45 fc             	mov    -0x4(%rbp),%eax
    3545:	83 f8 01             	cmp    $0x1,%eax
    3548:	0f 8c 84 0c 00 00    	jl     0x41d2
    354e:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3555:	44 8b 45 fc          	mov    -0x4(%rbp),%r8d
    3559:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    355c:	44 89 c0             	mov    %r8d,%eax
    355f:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3566:	0f 92 c2             	setb   %dl
    3569:	0f b6 d2             	movzbl %dl,%edx
    356c:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    3572:	8d 71 40             	lea    0x40(%rcx),%esi
    3575:	ba 30 00 00 00       	mov    $0x30,%edx
    357a:	b9 00 01 00 00       	mov    $0x100,%ecx
    357f:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3586:	0f 42 c8             	cmovb  %eax,%ecx
    3589:	e8 2a 3c fe ff       	call   0xfffffffffffe71b8
    358e:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    3595:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    359b:	89 c6                	mov    %eax,%esi
    359d:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    35a3:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    35aa:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    35ae:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    35b1:	89 ca                	mov    %ecx,%edx
    35b3:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    35b9:	83 e1 20             	and    $0x20,%ecx
    35bc:	85 c9                	test   %ecx,%ecx
    35be:	0f 94 c1             	sete   %cl
    35c1:	0f b6 c9             	movzbl %cl,%ecx
    35c4:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    35ca:	85 c0                	test   %eax,%eax
    35cc:	75 79                	jne    0x3647
    35ce:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    35d4:	83 e0 01             	and    $0x1,%eax
    35d7:	85 c0                	test   %eax,%eax
    35d9:	74 40                	je     0x361b
    35db:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    35e1:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    35e8:	8b 45 cc             	mov    -0x34(%rbp),%eax
    35eb:	8d 70 40             	lea    0x40(%rax),%esi
    35ee:	ba 00 01 00 00       	mov    $0x100,%edx
    35f3:	e8 da 3a fe ff       	call   0xfffffffffffe70d2
    35f8:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    35fe:	89 c2                	mov    %eax,%edx
    3600:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3607:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    360e:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3612:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    3615:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    361b:	8b 45 fc             	mov    -0x4(%rbp),%eax
    361e:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    3624:	83 e1 20             	and    $0x20,%ecx
    3627:	85 c9                	test   %ecx,%ecx
    3629:	0f 94 c1             	sete   %cl
    362c:	0f b6 c9             	movzbl %cl,%ecx
    362f:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    3635:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    363b:	89 c1                	mov    %eax,%ecx
    363d:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    3640:	3d ff 00 00 00       	cmp    $0xff,%eax
    3645:	77 87                	ja     0x35ce
    3647:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    364d:	85 c0                	test   %eax,%eax
    364f:	0f 84 7d 0b 00 00    	je     0x41d2
    3655:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    365c:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3662:	8b 55 fc             	mov    -0x4(%rbp),%edx
    3665:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3668:	8d 70 40             	lea    0x40(%rax),%esi
    366b:	e8 62 3a fe ff       	call   0xfffffffffffe70d2
    3670:	89 c1                	mov    %eax,%ecx
    3672:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3679:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3680:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3684:	e9 49 0b 00 00       	jmp    0x41d2
    3689:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    368f:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    3695:	8b 55 f0             	mov    -0x10(%rbp),%edx
    3698:	31 f6                	xor    %esi,%esi
    369a:	89 75 80             	mov    %esi,-0x80(%rbp)
    369d:	be 3a 0b 00 00       	mov    $0xb3a,%esi
    36a2:	89 75 84             	mov    %esi,-0x7c(%rbp)
    36a5:	89 55 fc             	mov    %edx,-0x4(%rbp)
    36a8:	89 8d 78 ff ff ff    	mov    %ecx,-0x88(%rbp)
    36ae:	89 85 74 ff ff ff    	mov    %eax,-0x8c(%rbp)
    36b4:	8b 55 80             	mov    -0x80(%rbp),%edx
    36b7:	8b b5 74 ff ff ff    	mov    -0x8c(%rbp),%esi
    36bd:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    36c3:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    36c6:	29 c1                	sub    %eax,%ecx
    36c8:	89 cf                	mov    %ecx,%edi
    36ca:	89 bd 70 ff ff ff    	mov    %edi,-0x90(%rbp)
    36d0:	89 f0                	mov    %esi,%eax
    36d2:	39 fe                	cmp    %edi,%esi
    36d4:	0f 4c c1             	cmovl  %ecx,%eax
    36d7:	89 c1                	mov    %eax,%ecx
    36d9:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
    36df:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
    36e4:	29 d1                	sub    %edx,%ecx
    36e6:	39 c8                	cmp    %ecx,%eax
    36e8:	0f 8f 75 17 00 00    	jg     0x4e63
    36ee:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    36f4:	8b b5 68 ff ff ff    	mov    -0x98(%rbp),%esi
    36fa:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    3700:	8b 55 80             	mov    -0x80(%rbp),%edx
    3703:	01 c2                	add    %eax,%edx
    3705:	89 d7                	mov    %edx,%edi
    3707:	89 bd 5c ff ff ff    	mov    %edi,-0xa4(%rbp)
    370d:	89 f0                	mov    %esi,%eax
    370f:	39 fe                	cmp    %edi,%esi
    3711:	0f 4c c2             	cmovl  %edx,%eax
    3714:	89 c2                	mov    %eax,%edx
    3716:	89 55 fc             	mov    %edx,-0x4(%rbp)
    3719:	39 c8                	cmp    %ecx,%eax
    371b:	0f 8f 42 17 00 00    	jg     0x4e63
    3721:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    3727:	25 00 20 01 00       	and    $0x12000,%eax
    372c:	89 c1                	mov    %eax,%ecx
    372e:	89 8d 6c ff ff ff    	mov    %ecx,-0x94(%rbp)
    3734:	85 c0                	test   %eax,%eax
    3736:	0f 85 5d 01 00 00    	jne    0x3899
    373c:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
    3742:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3748:	39 c8                	cmp    %ecx,%eax
    374a:	0f 8d 49 01 00 00    	jge    0x3899
    3750:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3757:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    375d:	8b 45 fc             	mov    -0x4(%rbp),%eax
    3760:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3763:	29 d0                	sub    %edx,%eax
    3765:	41 89 c0             	mov    %eax,%r8d
    3768:	44 89 85 54 ff ff ff 	mov    %r8d,-0xac(%rbp)
    376f:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3776:	0f 92 c2             	setb   %dl
    3779:	0f b6 d2             	movzbl %dl,%edx
    377c:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    3782:	8d 71 40             	lea    0x40(%rcx),%esi
    3785:	ba 20 00 00 00       	mov    $0x20,%edx
    378a:	b9 00 01 00 00       	mov    $0x100,%ecx
    378f:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3796:	0f 42 c8             	cmovb  %eax,%ecx
    3799:	e8 1a 3a fe ff       	call   0xfffffffffffe71b8
    379e:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    37a5:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    37ab:	89 c6                	mov    %eax,%esi
    37ad:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    37b3:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    37ba:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    37be:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    37c1:	89 ca                	mov    %ecx,%edx
    37c3:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    37c9:	83 e1 20             	and    $0x20,%ecx
    37cc:	85 c9                	test   %ecx,%ecx
    37ce:	0f 94 c1             	sete   %cl
    37d1:	0f b6 c9             	movzbl %cl,%ecx
    37d4:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    37da:	85 c0                	test   %eax,%eax
    37dc:	75 7f                	jne    0x385d
    37de:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    37e4:	83 e0 01             	and    $0x1,%eax
    37e7:	85 c0                	test   %eax,%eax
    37e9:	74 40                	je     0x382b
    37eb:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    37f1:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    37f8:	8b 45 cc             	mov    -0x34(%rbp),%eax
    37fb:	8d 70 40             	lea    0x40(%rax),%esi
    37fe:	ba 00 01 00 00       	mov    $0x100,%edx
    3803:	e8 ca 38 fe ff       	call   0xfffffffffffe70d2
    3808:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    380e:	89 c2                	mov    %eax,%edx
    3810:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3817:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    381e:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3822:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    3825:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    382b:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    3831:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    3837:	83 e1 20             	and    $0x20,%ecx
    383a:	85 c9                	test   %ecx,%ecx
    383c:	0f 94 c1             	sete   %cl
    383f:	0f b6 c9             	movzbl %cl,%ecx
    3842:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3848:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    384e:	89 c1                	mov    %eax,%ecx
    3850:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    3856:	3d ff 00 00 00       	cmp    $0xff,%eax
    385b:	77 81                	ja     0x37de
    385d:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3863:	85 c0                	test   %eax,%eax
    3865:	74 32                	je     0x3899
    3867:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    386e:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3874:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    387a:	8b 45 cc             	mov    -0x34(%rbp),%eax
    387d:	8d 70 40             	lea    0x40(%rax),%esi
    3880:	e8 4d 38 fe ff       	call   0xfffffffffffe70d2
    3885:	89 c1                	mov    %eax,%ecx
    3887:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    388e:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3895:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3899:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    389d:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    38a3:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    38a7:	83 e0 20             	and    $0x20,%eax
    38aa:	85 c0                	test   %eax,%eax
    38ac:	75 2c                	jne    0x38da
    38ae:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    38b5:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    38bb:	8b 55 80             	mov    -0x80(%rbp),%edx
    38be:	8b 75 84             	mov    -0x7c(%rbp),%esi
    38c1:	e8 0c 38 fe ff       	call   0xfffffffffffe70d2
    38c6:	89 c1                	mov    %eax,%ecx
    38c8:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    38cf:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    38d6:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    38da:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    38e0:	3d 00 00 01 00       	cmp    $0x10000,%eax
    38e5:	0f 85 5d 01 00 00    	jne    0x3a48
    38eb:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
    38f1:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    38f7:	39 c8                	cmp    %ecx,%eax
    38f9:	0f 8d 49 01 00 00    	jge    0x3a48
    38ff:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3906:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    390c:	8b 45 fc             	mov    -0x4(%rbp),%eax
    390f:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3912:	29 d0                	sub    %edx,%eax
    3914:	41 89 c0             	mov    %eax,%r8d
    3917:	44 89 85 54 ff ff ff 	mov    %r8d,-0xac(%rbp)
    391e:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3925:	0f 92 c2             	setb   %dl
    3928:	0f b6 d2             	movzbl %dl,%edx
    392b:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    3931:	8d 71 40             	lea    0x40(%rcx),%esi
    3934:	ba 30 00 00 00       	mov    $0x30,%edx
    3939:	b9 00 01 00 00       	mov    $0x100,%ecx
    393e:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3945:	0f 42 c8             	cmovb  %eax,%ecx
    3948:	e8 6b 38 fe ff       	call   0xfffffffffffe71b8
    394d:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    3954:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    395a:	89 c6                	mov    %eax,%esi
    395c:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    3962:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    3969:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    396d:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    3970:	89 ca                	mov    %ecx,%edx
    3972:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    3978:	83 e1 20             	and    $0x20,%ecx
    397b:	85 c9                	test   %ecx,%ecx
    397d:	0f 94 c1             	sete   %cl
    3980:	0f b6 c9             	movzbl %cl,%ecx
    3983:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3989:	85 c0                	test   %eax,%eax
    398b:	75 7f                	jne    0x3a0c
    398d:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3993:	83 e0 01             	and    $0x1,%eax
    3996:	85 c0                	test   %eax,%eax
    3998:	74 40                	je     0x39da
    399a:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    39a0:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    39a7:	8b 45 cc             	mov    -0x34(%rbp),%eax
    39aa:	8d 70 40             	lea    0x40(%rax),%esi
    39ad:	ba 00 01 00 00       	mov    $0x100,%edx
    39b2:	e8 1b 37 fe ff       	call   0xfffffffffffe70d2
    39b7:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    39bd:	89 c2                	mov    %eax,%edx
    39bf:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    39c6:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    39cd:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    39d1:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    39d4:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    39da:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    39e0:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    39e6:	83 e1 20             	and    $0x20,%ecx
    39e9:	85 c9                	test   %ecx,%ecx
    39eb:	0f 94 c1             	sete   %cl
    39ee:	0f b6 c9             	movzbl %cl,%ecx
    39f1:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    39f7:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    39fd:	89 c1                	mov    %eax,%ecx
    39ff:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    3a05:	3d ff 00 00 00       	cmp    $0xff,%eax
    3a0a:	77 81                	ja     0x398d
    3a0c:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3a12:	85 c0                	test   %eax,%eax
    3a14:	74 32                	je     0x3a48
    3a16:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3a1d:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3a23:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    3a29:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3a2c:	8d 70 40             	lea    0x40(%rax),%esi
    3a2f:	e8 9e 36 fe ff       	call   0xfffffffffffe70d2
    3a34:	89 c1                	mov    %eax,%ecx
    3a36:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3a3d:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3a44:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3a48:	8b 8d 74 ff ff ff    	mov    -0x8c(%rbp),%ecx
    3a4e:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    3a54:	39 c8                	cmp    %ecx,%eax
    3a56:	0f 8d 4c 01 00 00    	jge    0x3ba8
    3a5c:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3a63:	8b 95 70 ff ff ff    	mov    -0x90(%rbp),%edx
    3a69:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    3a6f:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3a72:	29 d0                	sub    %edx,%eax
    3a74:	41 89 c0             	mov    %eax,%r8d
    3a77:	44 89 85 54 ff ff ff 	mov    %r8d,-0xac(%rbp)
    3a7e:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3a85:	0f 92 c2             	setb   %dl
    3a88:	0f b6 d2             	movzbl %dl,%edx
    3a8b:	89 95 74 ff ff ff    	mov    %edx,-0x8c(%rbp)
    3a91:	8d 71 40             	lea    0x40(%rcx),%esi
    3a94:	ba 30 00 00 00       	mov    $0x30,%edx
    3a99:	b9 00 01 00 00       	mov    $0x100,%ecx
    3a9e:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3aa5:	0f 42 c8             	cmovb  %eax,%ecx
    3aa8:	e8 0b 37 fe ff       	call   0xfffffffffffe71b8
    3aad:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    3ab4:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    3aba:	89 c6                	mov    %eax,%esi
    3abc:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
    3ac2:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    3ac9:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    3acd:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    3ad0:	89 ca                	mov    %ecx,%edx
    3ad2:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    3ad8:	83 e1 20             	and    $0x20,%ecx
    3adb:	85 c9                	test   %ecx,%ecx
    3add:	0f 94 c1             	sete   %cl
    3ae0:	0f b6 c9             	movzbl %cl,%ecx
    3ae3:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3ae9:	85 c0                	test   %eax,%eax
    3aeb:	75 7f                	jne    0x3b6c
    3aed:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3af3:	83 e0 01             	and    $0x1,%eax
    3af6:	85 c0                	test   %eax,%eax
    3af8:	74 40                	je     0x3b3a
    3afa:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3b00:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3b07:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3b0a:	8d 70 40             	lea    0x40(%rax),%esi
    3b0d:	ba 00 01 00 00       	mov    $0x100,%edx
    3b12:	e8 bb 35 fe ff       	call   0xfffffffffffe70d2
    3b17:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3b1d:	89 c2                	mov    %eax,%edx
    3b1f:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3b26:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3b2d:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3b31:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    3b34:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    3b3a:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    3b40:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    3b46:	83 e1 20             	and    $0x20,%ecx
    3b49:	85 c9                	test   %ecx,%ecx
    3b4b:	0f 94 c1             	sete   %cl
    3b4e:	0f b6 c9             	movzbl %cl,%ecx
    3b51:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3b57:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    3b5d:	89 c1                	mov    %eax,%ecx
    3b5f:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    3b65:	3d ff 00 00 00       	cmp    $0xff,%eax
    3b6a:	77 81                	ja     0x3aed
    3b6c:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3b72:	85 c0                	test   %eax,%eax
    3b74:	74 32                	je     0x3ba8
    3b76:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3b7d:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3b83:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    3b89:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3b8c:	8d 70 40             	lea    0x40(%rax),%esi
    3b8f:	e8 3e 35 fe ff       	call   0xfffffffffffe70d2
    3b94:	89 c1                	mov    %eax,%ecx
    3b96:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3b9d:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3ba4:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3ba8:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3bac:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3bb2:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    3bb6:	83 e0 20             	and    $0x20,%eax
    3bb9:	85 c0                	test   %eax,%eax
    3bbb:	75 32                	jne    0x3bef
    3bbd:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3bc4:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3bca:	8b 95 70 ff ff ff    	mov    -0x90(%rbp),%edx
    3bd0:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    3bd6:	e8 f7 34 fe ff       	call   0xfffffffffffe70d2
    3bdb:	89 c1                	mov    %eax,%ecx
    3bdd:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3be4:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3beb:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3bef:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    3bf5:	3d 00 20 00 00       	cmp    $0x2000,%eax
    3bfa:	0f 85 95 c6 ff ff    	jne    0x295
    3c00:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
    3c06:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3c0c:	39 c8                	cmp    %ecx,%eax
    3c0e:	0f 8d 81 c6 ff ff    	jge    0x295
    3c14:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3c1b:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    3c21:	8b 45 fc             	mov    -0x4(%rbp),%eax
    3c24:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3c27:	29 d0                	sub    %edx,%eax
    3c29:	41 89 c0             	mov    %eax,%r8d
    3c2c:	44 89 85 54 ff ff ff 	mov    %r8d,-0xac(%rbp)
    3c33:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3c3a:	0f 92 c2             	setb   %dl
    3c3d:	0f b6 d2             	movzbl %dl,%edx
    3c40:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    3c46:	8d 71 40             	lea    0x40(%rcx),%esi
    3c49:	ba 20 00 00 00       	mov    $0x20,%edx
    3c4e:	b9 00 01 00 00       	mov    $0x100,%ecx
    3c53:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3c5a:	0f 42 c8             	cmovb  %eax,%ecx
    3c5d:	e8 56 35 fe ff       	call   0xfffffffffffe71b8
    3c62:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    3c69:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    3c6f:	89 c6                	mov    %eax,%esi
    3c71:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    3c77:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    3c7e:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    3c82:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    3c85:	89 ca                	mov    %ecx,%edx
    3c87:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    3c8d:	83 e1 20             	and    $0x20,%ecx
    3c90:	85 c9                	test   %ecx,%ecx
    3c92:	0f 94 c1             	sete   %cl
    3c95:	0f b6 c9             	movzbl %cl,%ecx
    3c98:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3c9e:	85 c0                	test   %eax,%eax
    3ca0:	75 7f                	jne    0x3d21
    3ca2:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3ca8:	83 e0 01             	and    $0x1,%eax
    3cab:	85 c0                	test   %eax,%eax
    3cad:	74 40                	je     0x3cef
    3caf:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3cb5:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3cbc:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3cbf:	8d 70 40             	lea    0x40(%rax),%esi
    3cc2:	ba 00 01 00 00       	mov    $0x100,%edx
    3cc7:	e8 06 34 fe ff       	call   0xfffffffffffe70d2
    3ccc:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3cd2:	89 c2                	mov    %eax,%edx
    3cd4:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3cdb:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3ce2:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3ce6:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    3ce9:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    3cef:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    3cf5:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    3cfb:	83 e1 20             	and    $0x20,%ecx
    3cfe:	85 c9                	test   %ecx,%ecx
    3d00:	0f 94 c1             	sete   %cl
    3d03:	0f b6 c9             	movzbl %cl,%ecx
    3d06:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3d0c:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    3d12:	89 c1                	mov    %eax,%ecx
    3d14:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    3d1a:	3d ff 00 00 00       	cmp    $0xff,%eax
    3d1f:	77 81                	ja     0x3ca2
    3d21:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3d27:	85 c0                	test   %eax,%eax
    3d29:	0f 84 66 c5 ff ff    	je     0x295
    3d2f:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3d36:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3d3c:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    3d42:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3d45:	8d 70 40             	lea    0x40(%rax),%esi
    3d48:	e8 85 33 fe ff       	call   0xfffffffffffe70d2
    3d4d:	89 c1                	mov    %eax,%ecx
    3d4f:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3d56:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3d5d:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3d61:	e9 2f c5 ff ff       	jmp    0x295
    3d66:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    3d6c:	85 c0                	test   %eax,%eax
    3d6e:	0f 8c 19 04 00 00    	jl     0x418d
    3d74:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    3d7a:	8b 75 84             	mov    -0x7c(%rbp),%esi
    3d7d:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
    3d83:	89 c1                	mov    %eax,%ecx
    3d85:	8d 49 04             	lea    0x4(%rcx),%ecx
    3d88:	85 f6                	test   %esi,%esi
    3d8a:	0f 45 ca             	cmovne %edx,%ecx
    3d8d:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
    3d93:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    3d99:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3d9d:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    3da3:	8b 55 d8             	mov    -0x28(%rbp),%edx
    3da6:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    3dac:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    3daf:	89 c1                	mov    %eax,%ecx
    3db1:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    3db4:	85 c0                	test   %eax,%eax
    3db6:	0f 84 a0 00 00 00    	je     0x3e5c
    3dbc:	31 c0                	xor    %eax,%eax
    3dbe:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    3dc4:	8b 45 fc             	mov    -0x4(%rbp),%eax
    3dc7:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    3dcd:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    3dd1:	8b 7d cc             	mov    -0x34(%rbp),%edi
    3dd4:	41 89 d2             	mov    %edx,%r10d
    3dd7:	41 89 c0             	mov    %eax,%r8d
    3dda:	89 c1                	mov    %eax,%ecx
    3ddc:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
    3de2:	89 c9                	mov    %ecx,%ecx
    3de4:	49 b9 cd cc cc cc 00 	movabs $0xcccccccd,%r9
    3deb:	00 00 00 
    3dee:	49 0f af c9          	imul   %r9,%rcx
    3df2:	48 c1 e9 23          	shr    $0x23,%rcx
    3df6:	41 89 c9             	mov    %ecx,%r9d
    3df9:	44 89 c9             	mov    %r9d,%ecx
    3dfc:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    3e02:	8d bf 50 01 00 00    	lea    0x150(%rdi),%edi
    3e08:	44 01 d7             	add    %r10d,%edi
    3e0b:	8d 7f 08             	lea    0x8(%rdi),%edi
    3e0e:	45 6b c9 0a          	imul   $0xa,%r9d,%r9d
    3e12:	45 29 c8             	sub    %r9d,%r8d
    3e15:	41 83 c8 30          	or     $0x30,%r8d
    3e19:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
    3e1d:	8d 52 ff             	lea    -0x1(%rdx),%edx
    3e20:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    3e26:	83 f8 09             	cmp    $0x9,%eax
    3e29:	0f 97 c0             	seta   %al
    3e2c:	0f b6 c0             	movzbl %al,%eax
    3e2f:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    3e35:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    3e38:	85 c0                	test   %eax,%eax
    3e3a:	75 88                	jne    0x3dc4
    3e3c:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3e42:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3e45:	89 c2                	mov    %eax,%edx
    3e47:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    3e4d:	01 d1                	add    %edx,%ecx
    3e4f:	8d 49 09             	lea    0x9(%rcx),%ecx
    3e52:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    3e58:	85 c0                	test   %eax,%eax
    3e5a:	75 1d                	jne    0x3e79
    3e5c:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3e60:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    3e66:	8d 49 ff             	lea    -0x1(%rcx),%ecx
    3e69:	89 ca                	mov    %ecx,%edx
    3e6b:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    3e71:	ba 30 00 00 00       	mov    $0x30,%edx
    3e76:	88 14 08             	mov    %dl,(%rax,%rcx,1)
    3e79:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    3e7f:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3e85:	39 c8                	cmp    %ecx,%eax
    3e87:	74 73                	je     0x3efc
    3e89:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3e8c:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    3e92:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    3e98:	39 c8                	cmp    %ecx,%eax
    3e9a:	0f 86 0b 01 00 00    	jbe    0x3fab
    3ea0:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3ea7:	8b 45 ec             	mov    -0x14(%rbp),%eax
    3eaa:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    3eb0:	8b 55 cc             	mov    -0x34(%rbp),%edx
    3eb3:	8d b2 50 01 00 00    	lea    0x150(%rdx),%esi
    3eb9:	ba 30 00 00 00       	mov    $0x30,%edx
    3ebe:	01 c1                	add    %eax,%ecx
    3ec0:	e8 f3 32 fe ff       	call   0xfffffffffffe71b8
    3ec5:	89 c1                	mov    %eax,%ecx
    3ec7:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3ece:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3ed5:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3ed9:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3edc:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    3ee2:	8d 40 ff             	lea    -0x1(%rax),%eax
    3ee5:	89 c2                	mov    %eax,%edx
    3ee7:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    3eed:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    3ef3:	39 c8                	cmp    %ecx,%eax
    3ef5:	77 e2                	ja     0x3ed9
    3ef7:	e9 af 00 00 00       	jmp    0x3fab
    3efc:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3f00:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3f06:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    3f0a:	83 e0 20             	and    $0x20,%eax
    3f0d:	85 c0                	test   %eax,%eax
    3f0f:	75 31                	jne    0x3f42
    3f11:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3f18:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3f1e:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    3f24:	ba 01 00 00 00       	mov    $0x1,%edx
    3f29:	e8 a4 31 fe ff       	call   0xfffffffffffe70d2
    3f2e:	89 c1                	mov    %eax,%ecx
    3f30:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3f37:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3f3e:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3f42:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    3f48:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    3f4e:	8d 49 01             	lea    0x1(%rcx),%ecx
    3f51:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    3f57:	85 c0                	test   %eax,%eax
    3f59:	75 0b                	jne    0x3f66
    3f5b:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    3f61:	83 f8 01             	cmp    $0x1,%eax
    3f64:	7c 45                	jl     0x3fab
    3f66:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3f6a:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3f70:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    3f74:	83 e0 20             	and    $0x20,%eax
    3f77:	85 c0                	test   %eax,%eax
    3f79:	75 30                	jne    0x3fab
    3f7b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3f82:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3f88:	be e3 0d 00 00       	mov    $0xde3,%esi
    3f8d:	ba 01 00 00 00       	mov    $0x1,%edx
    3f92:	e8 3b 31 fe ff       	call   0xfffffffffffe70d2
    3f97:	89 c1                	mov    %eax,%ecx
    3f99:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3fa0:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    3fa7:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3fab:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3faf:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3fb5:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    3fbb:	8b 55 d8             	mov    -0x28(%rbp),%edx
    3fbe:	29 f2                	sub    %esi,%edx
    3fc0:	89 55 fc             	mov    %edx,-0x4(%rbp)
    3fc3:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    3fc7:	83 e0 20             	and    $0x20,%eax
    3fca:	85 c0                	test   %eax,%eax
    3fcc:	75 43                	jne    0x4011
    3fce:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3fd5:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3fdb:	44 8b 4d fc          	mov    -0x4(%rbp),%r9d
    3fdf:	44 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%r8d
    3fe6:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    3fec:	44 89 c8             	mov    %r9d,%eax
    3fef:	44 89 c2             	mov    %r8d,%edx
    3ff2:	45 39 c8             	cmp    %r9d,%r8d
    3ff5:	0f 4f d0             	cmovg  %eax,%edx
    3ff8:	e8 d5 30 fe ff       	call   0xfffffffffffe70d2
    3ffd:	89 c1                	mov    %eax,%ecx
    3fff:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4006:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    400d:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4011:	8b 8d 74 ff ff ff    	mov    -0x8c(%rbp),%ecx
    4017:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    401d:	8b 95 78 ff ff ff    	mov    -0x88(%rbp),%edx
    4023:	8b 75 fc             	mov    -0x4(%rbp),%esi
    4026:	29 f2                	sub    %esi,%edx
    4028:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    402e:	8d 40 04             	lea    0x4(%rax),%eax
    4031:	89 c2                	mov    %eax,%edx
    4033:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    4039:	39 c8                	cmp    %ecx,%eax
    403b:	73 0f                	jae    0x404c
    403d:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    4043:	83 f8 ff             	cmp    $0xffffffff,%eax
    4046:	0f 8f 4d fd ff ff    	jg     0x3d99
    404c:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    4052:	83 f8 01             	cmp    $0x1,%eax
    4055:	0f 8c 32 01 00 00    	jl     0x418d
    405b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4062:	44 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%r8d
    4069:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    406c:	44 89 c0             	mov    %r8d,%eax
    406f:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4076:	0f 92 c2             	setb   %dl
    4079:	0f b6 d2             	movzbl %dl,%edx
    407c:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    4082:	8d 71 40             	lea    0x40(%rcx),%esi
    4085:	ba 30 00 00 00       	mov    $0x30,%edx
    408a:	b9 00 01 00 00       	mov    $0x100,%ecx
    408f:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4096:	0f 42 c8             	cmovb  %eax,%ecx
    4099:	e8 1a 31 fe ff       	call   0xfffffffffffe71b8
    409e:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    40a5:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    40ab:	89 c6                	mov    %eax,%esi
    40ad:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    40b3:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    40ba:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    40be:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    40c1:	89 ca                	mov    %ecx,%edx
    40c3:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    40c9:	83 e1 20             	and    $0x20,%ecx
    40cc:	85 c9                	test   %ecx,%ecx
    40ce:	0f 94 c1             	sete   %cl
    40d1:	0f b6 c9             	movzbl %cl,%ecx
    40d4:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    40d7:	85 c0                	test   %eax,%eax
    40d9:	75 79                	jne    0x4154
    40db:	8b 45 fc             	mov    -0x4(%rbp),%eax
    40de:	83 e0 01             	and    $0x1,%eax
    40e1:	85 c0                	test   %eax,%eax
    40e3:	74 40                	je     0x4125
    40e5:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    40eb:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    40f2:	8b 45 cc             	mov    -0x34(%rbp),%eax
    40f5:	8d 70 40             	lea    0x40(%rax),%esi
    40f8:	ba 00 01 00 00       	mov    $0x100,%edx
    40fd:	e8 d0 2f fe ff       	call   0xfffffffffffe70d2
    4102:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4108:	89 c2                	mov    %eax,%edx
    410a:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4111:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4118:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    411c:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    411f:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    4125:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    412b:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    4131:	83 e1 20             	and    $0x20,%ecx
    4134:	85 c9                	test   %ecx,%ecx
    4136:	0f 94 c1             	sete   %cl
    4139:	0f b6 c9             	movzbl %cl,%ecx
    413c:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    413f:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    4145:	89 c1                	mov    %eax,%ecx
    4147:	89 8d 78 ff ff ff    	mov    %ecx,-0x88(%rbp)
    414d:	3d ff 00 00 00       	cmp    $0xff,%eax
    4152:	77 87                	ja     0x40db
    4154:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4157:	85 c0                	test   %eax,%eax
    4159:	74 32                	je     0x418d
    415b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4162:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4168:	8b 95 78 ff ff ff    	mov    -0x88(%rbp),%edx
    416e:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4171:	8d 70 40             	lea    0x40(%rax),%esi
    4174:	e8 59 2f fe ff       	call   0xfffffffffffe70d2
    4179:	89 c1                	mov    %eax,%ecx
    417b:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4182:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4189:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    418d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4191:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4197:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    419b:	83 e0 20             	and    $0x20,%eax
    419e:	85 c0                	test   %eax,%eax
    41a0:	75 30                	jne    0x41d2
    41a2:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    41a9:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    41af:	8b 45 ac             	mov    -0x54(%rbp),%eax
    41b2:	8b 55 e8             	mov    -0x18(%rbp),%edx
    41b5:	89 c6                	mov    %eax,%esi
    41b7:	29 c2                	sub    %eax,%edx
    41b9:	e8 14 2f fe ff       	call   0xfffffffffffe70d2
    41be:	89 c1                	mov    %eax,%ecx
    41c0:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    41c7:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    41ce:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    41d2:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    41d8:	3d 00 20 00 00       	cmp    $0x2000,%eax
    41dd:	0f 85 54 01 00 00    	jne    0x4337
    41e3:	8b 8d 7c ff ff ff    	mov    -0x84(%rbp),%ecx
    41e9:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    41ef:	39 c8                	cmp    %ecx,%eax
    41f1:	0f 8e 40 01 00 00    	jle    0x4337
    41f7:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    41fe:	8b 95 7c ff ff ff    	mov    -0x84(%rbp),%edx
    4204:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    420a:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    420d:	29 d0                	sub    %edx,%eax
    420f:	41 89 c0             	mov    %eax,%r8d
    4212:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    4216:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    421d:	0f 92 c2             	setb   %dl
    4220:	0f b6 d2             	movzbl %dl,%edx
    4223:	89 95 50 ff ff ff    	mov    %edx,-0xb0(%rbp)
    4229:	8d 71 40             	lea    0x40(%rcx),%esi
    422c:	ba 20 00 00 00       	mov    $0x20,%edx
    4231:	b9 00 01 00 00       	mov    $0x100,%ecx
    4236:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    423d:	0f 42 c8             	cmovb  %eax,%ecx
    4240:	e8 73 2f fe ff       	call   0xfffffffffffe71b8
    4245:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    424c:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    4252:	89 c6                	mov    %eax,%esi
    4254:	8b 85 50 ff ff ff    	mov    -0xb0(%rbp),%eax
    425a:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    4261:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    4265:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    4268:	89 ca                	mov    %ecx,%edx
    426a:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    4270:	83 e1 20             	and    $0x20,%ecx
    4273:	85 c9                	test   %ecx,%ecx
    4275:	0f 94 c1             	sete   %cl
    4278:	0f b6 c9             	movzbl %cl,%ecx
    427b:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    4281:	85 c0                	test   %eax,%eax
    4283:	75 79                	jne    0x42fe
    4285:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    428b:	83 e0 01             	and    $0x1,%eax
    428e:	85 c0                	test   %eax,%eax
    4290:	74 40                	je     0x42d2
    4292:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4298:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    429f:	8b 45 cc             	mov    -0x34(%rbp),%eax
    42a2:	8d 70 40             	lea    0x40(%rax),%esi
    42a5:	ba 00 01 00 00       	mov    $0x100,%edx
    42aa:	e8 23 2e fe ff       	call   0xfffffffffffe70d2
    42af:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    42b5:	89 c2                	mov    %eax,%edx
    42b7:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    42be:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    42c5:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    42c9:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    42cc:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    42d2:	8b 45 fc             	mov    -0x4(%rbp),%eax
    42d5:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    42db:	83 e1 20             	and    $0x20,%ecx
    42de:	85 c9                	test   %ecx,%ecx
    42e0:	0f 94 c1             	sete   %cl
    42e3:	0f b6 c9             	movzbl %cl,%ecx
    42e6:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    42ec:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    42f2:	89 c1                	mov    %eax,%ecx
    42f4:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    42f7:	3d ff 00 00 00       	cmp    $0xff,%eax
    42fc:	77 87                	ja     0x4285
    42fe:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    4304:	85 c0                	test   %eax,%eax
    4306:	74 2f                	je     0x4337
    4308:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    430f:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4315:	8b 55 fc             	mov    -0x4(%rbp),%edx
    4318:	8b 45 cc             	mov    -0x34(%rbp),%eax
    431b:	8d 70 40             	lea    0x40(%rax),%esi
    431e:	e8 af 2d fe ff       	call   0xfffffffffffe70d2
    4323:	89 c1                	mov    %eax,%ecx
    4325:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    432c:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4333:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4337:	8b b5 7c ff ff ff    	mov    -0x84(%rbp),%esi
    433d:	8b 95 68 ff ff ff    	mov    -0x98(%rbp),%edx
    4343:	89 d1                	mov    %edx,%ecx
    4345:	89 f0                	mov    %esi,%eax
    4347:	39 f2                	cmp    %esi,%edx
    4349:	0f 4f c1             	cmovg  %ecx,%eax
    434c:	89 45 fc             	mov    %eax,-0x4(%rbp)
    434f:	e9 04 0b 00 00       	jmp    0x4e58
    4354:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    435a:	8b b5 7c ff ff ff    	mov    -0x84(%rbp),%esi
    4360:	8b 4d a8             	mov    -0x58(%rbp),%ecx
    4363:	89 ca                	mov    %ecx,%edx
    4365:	83 e6 20             	and    $0x20,%esi
    4368:	89 f7                	mov    %esi,%edi
    436a:	89 bd 60 ff ff ff    	mov    %edi,-0xa0(%rbp)
    4370:	8d 52 09             	lea    0x9(%rdx),%edx
    4373:	85 f6                	test   %esi,%esi
    4375:	0f 45 ca             	cmovne %edx,%ecx
    4378:	89 8d 78 ff ff ff    	mov    %ecx,-0x88(%rbp)
    437e:	83 f8 0b             	cmp    $0xb,%eax
    4381:	0f 87 e0 00 00 00    	ja     0x4467
    4387:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    438d:	b8 0c 00 00 00       	mov    $0xc,%eax
    4392:	29 c8                	sub    %ecx,%eax
    4394:	85 c0                	test   %eax,%eax
    4396:	0f 84 cb 00 00 00    	je     0x4467
    439c:	f2 0f 10 85 40 ff ff 	movsd  -0xc0(%rbp),%xmm0
    43a3:	ff 
    43a4:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    43aa:	8d 40 f4             	lea    -0xc(%rax),%eax
    43ad:	89 45 fc             	mov    %eax,-0x4(%rbp)
    43b0:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    43b5:	8b 55 fc             	mov    -0x4(%rbp),%edx
    43b8:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    43bd:	f2 0f 10 8d 40 ff ff 	movsd  -0xc0(%rbp),%xmm1
    43c4:	ff 
    43c5:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    43c9:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    43ce:	89 d0                	mov    %edx,%eax
    43d0:	8d 40 01             	lea    0x1(%rax),%eax
    43d3:	89 c1                	mov    %eax,%ecx
    43d5:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    43db:	39 d0                	cmp    %edx,%eax
    43dd:	0f 93 c0             	setae  %al
    43e0:	0f b6 c0             	movzbl %al,%eax
    43e3:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    43e9:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    43ec:	85 c0                	test   %eax,%eax
    43ee:	75 c5                	jne    0x43b5
    43f0:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    43f4:	8b 8d 78 ff ff ff    	mov    -0x88(%rbp),%ecx
    43fa:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    43fe:	83 f8 2d             	cmp    $0x2d,%eax
    4401:	75 4a                	jne    0x444d
    4403:	f2 0f 10 4d 98       	movsd  -0x68(%rbp),%xmm1
    4408:	f2 0f 10 55 b0       	movsd  -0x50(%rbp),%xmm2
    440d:	0f 28 c2             	movaps %xmm2,%xmm0
    4410:	66 48 0f 7e c8       	movq   %xmm1,%rax
    4415:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    441c:	00 00 80 
    441f:	48 31 c8             	xor    %rcx,%rax
    4422:	66 48 0f 6e c8       	movq   %rax,%xmm1
    4427:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
    442b:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    442f:	66 48 0f 7e c0       	movq   %xmm0,%rax
    4434:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    443b:	00 00 80 
    443e:	48 31 c8             	xor    %rcx,%rax
    4441:	66 48 0f 6e c0       	movq   %rax,%xmm0
    4446:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
    444b:	eb 1a                	jmp    0x4467
    444d:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    4452:	f2 0f 10 4d b0       	movsd  -0x50(%rbp),%xmm1
    4457:	0f 28 d1             	movaps %xmm1,%xmm2
    445a:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
    445e:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
    4462:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
    4467:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    446b:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    446e:	8b 55 e8             	mov    -0x18(%rbp),%edx
    4471:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    4477:	8b 84 08 6c 01 00 00 	mov    0x16c(%rax,%rcx,1),%eax
    447e:	89 c2                	mov    %eax,%edx
    4480:	89 95 74 ff ff ff    	mov    %edx,-0x8c(%rbp)
    4486:	c1 fa 1f             	sar    $0x1f,%edx
    4489:	89 d1                	mov    %edx,%ecx
    448b:	01 d0                	add    %edx,%eax
    448d:	31 c8                	xor    %ecx,%eax
    448f:	89 c1                	mov    %eax,%ecx
    4491:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4494:	85 c0                	test   %eax,%eax
    4496:	0f 84 a0 00 00 00    	je     0x453c
    449c:	31 c0                	xor    %eax,%eax
    449e:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    44a4:	8b 45 fc             	mov    -0x4(%rbp),%eax
    44a7:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    44ad:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    44b1:	8b 7d cc             	mov    -0x34(%rbp),%edi
    44b4:	41 89 d2             	mov    %edx,%r10d
    44b7:	41 89 c0             	mov    %eax,%r8d
    44ba:	89 c1                	mov    %eax,%ecx
    44bc:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
    44c2:	89 c9                	mov    %ecx,%ecx
    44c4:	49 b9 cd cc cc cc 00 	movabs $0xcccccccd,%r9
    44cb:	00 00 00 
    44ce:	49 0f af c9          	imul   %r9,%rcx
    44d2:	48 c1 e9 23          	shr    $0x23,%rcx
    44d6:	41 89 c9             	mov    %ecx,%r9d
    44d9:	44 89 c9             	mov    %r9d,%ecx
    44dc:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    44e2:	8d bf 44 01 00 00    	lea    0x144(%rdi),%edi
    44e8:	44 01 d7             	add    %r10d,%edi
    44eb:	8d 7f 0b             	lea    0xb(%rdi),%edi
    44ee:	45 6b c9 0a          	imul   $0xa,%r9d,%r9d
    44f2:	45 29 c8             	sub    %r9d,%r8d
    44f5:	41 83 c8 30          	or     $0x30,%r8d
    44f9:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
    44fd:	8d 52 ff             	lea    -0x1(%rdx),%edx
    4500:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    4506:	83 f8 09             	cmp    $0x9,%eax
    4509:	0f 97 c0             	seta   %al
    450c:	0f b6 c0             	movzbl %al,%eax
    450f:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
    4515:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4518:	85 c0                	test   %eax,%eax
    451a:	75 88                	jne    0x44a4
    451c:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    4522:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    4525:	89 c2                	mov    %eax,%edx
    4527:	8d 89 44 01 00 00    	lea    0x144(%rcx),%ecx
    452d:	01 d1                	add    %edx,%ecx
    452f:	8d 49 0c             	lea    0xc(%rcx),%ecx
    4532:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    4538:	85 c0                	test   %eax,%eax
    453a:	75 1d                	jne    0x4559
    453c:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4540:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    4546:	8d 49 ff             	lea    -0x1(%rcx),%ecx
    4549:	89 ca                	mov    %ecx,%edx
    454b:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    4551:	ba 30 00 00 00       	mov    $0x30,%edx
    4556:	88 14 08             	mov    %dl,(%rax,%rcx,1)
    4559:	8b 45 cc             	mov    -0x34(%rbp),%eax
    455c:	8b b5 58 ff ff ff    	mov    -0xa8(%rbp),%esi
    4562:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    4568:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    456c:	44 8b 8d 74 ff ff ff 	mov    -0x8c(%rbp),%r9d
    4573:	44 8b 85 7c ff ff ff 	mov    -0x84(%rbp),%r8d
    457a:	8b 7d a0             	mov    -0x60(%rbp),%edi
    457d:	83 cf 02             	or     $0x2,%edi
    4580:	89 bd 70 ff ff ff    	mov    %edi,-0x90(%rbp)
    4586:	89 f7                	mov    %esi,%edi
    4588:	8d 7f fe             	lea    -0x2(%rdi),%edi
    458b:	41 89 fa             	mov    %edi,%r10d
    458e:	44 89 95 6c ff ff ff 	mov    %r10d,-0x94(%rbp)
    4595:	45 8d 40 0f          	lea    0xf(%r8),%r8d
    4599:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
    459d:	8d 76 ff             	lea    -0x1(%rsi),%esi
    45a0:	41 b8 2d 00 00 00    	mov    $0x2d,%r8d
    45a6:	bf 2b 00 00 00       	mov    $0x2b,%edi
    45ab:	45 85 c9             	test   %r9d,%r9d
    45ae:	41 0f 4c f8          	cmovl  %r8d,%edi
    45b2:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    45b6:	83 e1 08             	and    $0x8,%ecx
    45b9:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    45bf:	8d 80 50 01 00 00    	lea    0x150(%rax),%eax
    45c5:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    45cb:	f2 0f 10 85 48 ff ff 	movsd  -0xb8(%rbp),%xmm0
    45d2:	ff 
    45d3:	f2 0f 10 4d 98       	movsd  -0x68(%rbp),%xmm1
    45d8:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    45de:	89 45 fc             	mov    %eax,-0x4(%rbp)
    45e1:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
    45e8:	ff ff 7f 
    45eb:	66 48 0f 6e d0       	movq   %rax,%xmm2
    45f0:	66 0f 54 ca          	andpd  %xmm2,%xmm1
    45f4:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    45f8:	0f 97 c0             	seta   %al
    45fb:	0f b6 c0             	movzbl %al,%eax
    45fe:	85 c0                	test   %eax,%eax
    4600:	74 72                	je     0x4674
    4602:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    4607:	f2 0f 11 85 70 fe ff 	movsd  %xmm0,-0x190(%rbp)
    460e:	ff 
    460f:	f2 0f 2c c0          	cvttsd2si %xmm0,%eax
    4613:	89 85 7c fe ff ff    	mov    %eax,-0x184(%rbp)
    4619:	83 f8 01             	cmp    $0x1,%eax
    461c:	71 48                	jno    0x4666
    461e:	f2 0f 10 85 70 fe ff 	movsd  -0x190(%rbp),%xmm0
    4625:	ff 
    4626:	66 0f 2e c0          	ucomisd %xmm0,%xmm0
    462a:	0f 8a 85 08 00 00    	jp     0x4eb5
    4630:	f2 0f 10 85 70 fe ff 	movsd  -0x190(%rbp),%xmm0
    4637:	ff 
    4638:	48 b8 00 00 20 00 00 	movabs $0xc1e0000000200000,%rax
    463f:	00 e0 c1 
    4642:	66 48 0f 6e c8       	movq   %rax,%xmm1
    4647:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    464b:	0f 86 57 08 00 00    	jbe    0x4ea8
    4651:	f2 0f 10 85 70 fe ff 	movsd  -0x190(%rbp),%xmm0
    4658:	ff 
    4659:	0f 57 c9             	xorps  %xmm1,%xmm1
    465c:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    4660:	0f 87 42 08 00 00    	ja     0x4ea8
    4666:	8b 85 7c fe ff ff    	mov    -0x184(%rbp),%eax
    466c:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    4672:	eb 0b                	jmp    0x467f
    4674:	b8 00 00 00 80       	mov    $0x80000000,%eax
    4679:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    467f:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    4682:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    4688:	8b 45 fc             	mov    -0x4(%rbp),%eax
    468b:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    4690:	f2 0f 10 8d 40 ff ff 	movsd  -0xc0(%rbp),%xmm1
    4697:	ff 
    4698:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    469c:	44 8b 8d 60 ff ff ff 	mov    -0xa0(%rbp),%r9d
    46a3:	89 c7                	mov    %eax,%edi
    46a5:	41 89 d0             	mov    %edx,%r8d
    46a8:	45 8d 80 b0 0d 00 00 	lea    0xdb0(%r8),%r8d
    46af:	46 0f b6 04 06       	movzbl (%rsi,%r8,1),%r8d
    46b4:	45 09 c8             	or     %r9d,%r8d
    46b7:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
    46bb:	0f 57 d2             	xorps  %xmm2,%xmm2
    46be:	f2 0f 2a d2          	cvtsi2sd %edx,%xmm2
    46c2:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    46c6:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    46ca:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
    46cf:	8d 40 01             	lea    0x1(%rax),%eax
    46d2:	89 c2                	mov    %eax,%edx
    46d4:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    46da:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    46e0:	29 c8                	sub    %ecx,%eax
    46e2:	83 f8 01             	cmp    $0x1,%eax
    46e5:	75 4b                	jne    0x4732
    46e7:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    46ed:	85 c0                	test   %eax,%eax
    46ef:	75 25                	jne    0x4716
    46f1:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    46f7:	85 c0                	test   %eax,%eax
    46f9:	7f 1b                	jg     0x4716
    46fb:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    4700:	0f 57 c9             	xorps  %xmm1,%xmm1
    4703:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    4707:	0f 94 c0             	sete   %al
    470a:	0f 9b c1             	setnp  %cl
    470d:	20 c8                	and    %cl,%al
    470f:	0f b6 c0             	movzbl %al,%eax
    4712:	85 c0                	test   %eax,%eax
    4714:	75 1c                	jne    0x4732
    4716:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4719:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    471d:	89 c2                	mov    %eax,%edx
    471f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4724:	40 88 74 11 01       	mov    %sil,0x1(%rcx,%rdx,1)
    4729:	8d 40 02             	lea    0x2(%rax),%eax
    472c:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    4732:	f2 0f 10 45 98       	movsd  -0x68(%rbp),%xmm0
    4737:	0f 57 c9             	xorps  %xmm1,%xmm1
    473a:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    473e:	0f 95 c0             	setne  %al
    4741:	0f 9a c1             	setp   %cl
    4744:	08 c8                	or     %cl,%al
    4746:	0f b6 c0             	movzbl %al,%eax
    4749:	85 c0                	test   %eax,%eax
    474b:	0f 85 7a fe ff ff    	jne    0x45cb
    4751:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    4757:	8b b5 6c ff ff ff    	mov    -0x94(%rbp),%esi
    475d:	8b 45 e8             	mov    -0x18(%rbp),%eax
    4760:	8b 95 70 ff ff ff    	mov    -0x90(%rbp),%edx
    4766:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    476b:	89 7d fc             	mov    %edi,-0x4(%rbp)
    476e:	29 f0                	sub    %esi,%eax
    4770:	89 c6                	mov    %eax,%esi
    4772:	89 b5 74 ff ff ff    	mov    %esi,-0x8c(%rbp)
    4778:	01 c2                	add    %eax,%edx
    477a:	89 d0                	mov    %edx,%eax
    477c:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    4782:	b8 fd ff ff 7f       	mov    $0x7ffffffd,%eax
    4787:	29 d0                	sub    %edx,%eax
    4789:	39 c8                	cmp    %ecx,%eax
    478b:	0f 8c c7 06 00 00    	jl     0x4e58
    4791:	8b bd 5c ff ff ff    	mov    -0xa4(%rbp),%edi
    4797:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    479d:	44 8b 9d 54 ff ff ff 	mov    -0xac(%rbp),%r11d
    47a4:	44 8b 4d d4          	mov    -0x2c(%rbp),%r9d
    47a8:	8b 55 cc             	mov    -0x34(%rbp),%edx
    47ab:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    47b1:	41 89 f8             	mov    %edi,%r8d
    47b4:	44 89 de             	mov    %r11d,%esi
    47b7:	8d 92 50 01 00 00    	lea    0x150(%rdx),%edx
    47bd:	29 d6                	sub    %edx,%esi
    47bf:	89 f2                	mov    %esi,%edx
    47c1:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    47c7:	41 89 fa             	mov    %edi,%r10d
    47ca:	45 8d 40 02          	lea    0x2(%r8),%r8d
    47ce:	45 01 d9             	add    %r11d,%r9d
    47d1:	45 39 d1             	cmp    %r10d,%r9d
    47d4:	41 0f 4c f0          	cmovl  %r8d,%esi
    47d8:	85 ff                	test   %edi,%edi
    47da:	0f 45 d6             	cmovne %esi,%edx
    47dd:	89 d6                	mov    %edx,%esi
    47df:	89 75 80             	mov    %esi,-0x80(%rbp)
    47e2:	01 d1                	add    %edx,%ecx
    47e4:	89 8d 50 ff ff ff    	mov    %ecx,-0xb0(%rbp)
    47ea:	25 00 20 01 00       	and    $0x12000,%eax
    47ef:	89 c1                	mov    %eax,%ecx
    47f1:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    47f7:	85 c0                	test   %eax,%eax
    47f9:	0f 85 54 01 00 00    	jne    0x4953
    47ff:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    4805:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    480b:	39 c8                	cmp    %ecx,%eax
    480d:	0f 8e 40 01 00 00    	jle    0x4953
    4813:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    481a:	8b 95 50 ff ff ff    	mov    -0xb0(%rbp),%edx
    4820:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    4826:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    4829:	29 d0                	sub    %edx,%eax
    482b:	41 89 c0             	mov    %eax,%r8d
    482e:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    4832:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4839:	0f 92 c2             	setb   %dl
    483c:	0f b6 d2             	movzbl %dl,%edx
    483f:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    4845:	8d 71 40             	lea    0x40(%rcx),%esi
    4848:	ba 20 00 00 00       	mov    $0x20,%edx
    484d:	b9 00 01 00 00       	mov    $0x100,%ecx
    4852:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4859:	0f 42 c8             	cmovb  %eax,%ecx
    485c:	e8 57 29 fe ff       	call   0xfffffffffffe71b8
    4861:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    4868:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    486e:	89 c6                	mov    %eax,%esi
    4870:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    4876:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    487d:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    4881:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    4884:	89 ca                	mov    %ecx,%edx
    4886:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    488c:	83 e1 20             	and    $0x20,%ecx
    488f:	85 c9                	test   %ecx,%ecx
    4891:	0f 94 c1             	sete   %cl
    4894:	0f b6 c9             	movzbl %cl,%ecx
    4897:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    489d:	85 c0                	test   %eax,%eax
    489f:	75 79                	jne    0x491a
    48a1:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    48a7:	83 e0 01             	and    $0x1,%eax
    48aa:	85 c0                	test   %eax,%eax
    48ac:	74 40                	je     0x48ee
    48ae:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    48b4:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    48bb:	8b 45 cc             	mov    -0x34(%rbp),%eax
    48be:	8d 70 40             	lea    0x40(%rax),%esi
    48c1:	ba 00 01 00 00       	mov    $0x100,%edx
    48c6:	e8 07 28 fe ff       	call   0xfffffffffffe70d2
    48cb:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    48d1:	89 c2                	mov    %eax,%edx
    48d3:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    48da:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    48e1:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    48e5:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    48e8:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    48ee:	8b 45 fc             	mov    -0x4(%rbp),%eax
    48f1:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    48f7:	83 e1 20             	and    $0x20,%ecx
    48fa:	85 c9                	test   %ecx,%ecx
    48fc:	0f 94 c1             	sete   %cl
    48ff:	0f b6 c9             	movzbl %cl,%ecx
    4902:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    4908:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    490e:	89 c1                	mov    %eax,%ecx
    4910:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4913:	3d ff 00 00 00       	cmp    $0xff,%eax
    4918:	77 87                	ja     0x48a1
    491a:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    4920:	85 c0                	test   %eax,%eax
    4922:	74 2f                	je     0x4953
    4924:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    492b:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4931:	8b 55 fc             	mov    -0x4(%rbp),%edx
    4934:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4937:	8d 70 40             	lea    0x40(%rax),%esi
    493a:	e8 93 27 fe ff       	call   0xfffffffffffe70d2
    493f:	89 c1                	mov    %eax,%ecx
    4941:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4948:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    494f:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4953:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4957:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    495d:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    4961:	83 e0 20             	and    $0x20,%eax
    4964:	85 c0                	test   %eax,%eax
    4966:	75 32                	jne    0x499a
    4968:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    496f:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4975:	8b 95 70 ff ff ff    	mov    -0x90(%rbp),%edx
    497b:	8b b5 78 ff ff ff    	mov    -0x88(%rbp),%esi
    4981:	e8 4c 27 fe ff       	call   0xfffffffffffe70d2
    4986:	89 c1                	mov    %eax,%ecx
    4988:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    498f:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4996:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    499a:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    49a0:	3d 00 00 01 00       	cmp    $0x10000,%eax
    49a5:	0f 85 54 01 00 00    	jne    0x4aff
    49ab:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    49b1:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    49b7:	39 c8                	cmp    %ecx,%eax
    49b9:	0f 8e 40 01 00 00    	jle    0x4aff
    49bf:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    49c6:	8b 95 50 ff ff ff    	mov    -0xb0(%rbp),%edx
    49cc:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    49d2:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    49d5:	29 d0                	sub    %edx,%eax
    49d7:	41 89 c0             	mov    %eax,%r8d
    49da:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    49de:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    49e5:	0f 92 c2             	setb   %dl
    49e8:	0f b6 d2             	movzbl %dl,%edx
    49eb:	89 95 70 ff ff ff    	mov    %edx,-0x90(%rbp)
    49f1:	8d 71 40             	lea    0x40(%rcx),%esi
    49f4:	ba 30 00 00 00       	mov    $0x30,%edx
    49f9:	b9 00 01 00 00       	mov    $0x100,%ecx
    49fe:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4a05:	0f 42 c8             	cmovb  %eax,%ecx
    4a08:	e8 ab 27 fe ff       	call   0xfffffffffffe71b8
    4a0d:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    4a14:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    4a1a:	89 c6                	mov    %eax,%esi
    4a1c:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    4a22:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    4a29:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    4a2d:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    4a30:	89 ca                	mov    %ecx,%edx
    4a32:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    4a38:	83 e1 20             	and    $0x20,%ecx
    4a3b:	85 c9                	test   %ecx,%ecx
    4a3d:	0f 94 c1             	sete   %cl
    4a40:	0f b6 c9             	movzbl %cl,%ecx
    4a43:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    4a49:	85 c0                	test   %eax,%eax
    4a4b:	75 79                	jne    0x4ac6
    4a4d:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    4a53:	83 e0 01             	and    $0x1,%eax
    4a56:	85 c0                	test   %eax,%eax
    4a58:	74 40                	je     0x4a9a
    4a5a:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4a60:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4a67:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4a6a:	8d 70 40             	lea    0x40(%rax),%esi
    4a6d:	ba 00 01 00 00       	mov    $0x100,%edx
    4a72:	e8 5b 26 fe ff       	call   0xfffffffffffe70d2
    4a77:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4a7d:	89 c2                	mov    %eax,%edx
    4a7f:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4a86:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4a8d:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4a91:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    4a94:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    4a9a:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4a9d:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    4aa3:	83 e1 20             	and    $0x20,%ecx
    4aa6:	85 c9                	test   %ecx,%ecx
    4aa8:	0f 94 c1             	sete   %cl
    4aab:	0f b6 c9             	movzbl %cl,%ecx
    4aae:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    4ab4:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    4aba:	89 c1                	mov    %eax,%ecx
    4abc:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4abf:	3d ff 00 00 00       	cmp    $0xff,%eax
    4ac4:	77 87                	ja     0x4a4d
    4ac6:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    4acc:	85 c0                	test   %eax,%eax
    4ace:	74 2f                	je     0x4aff
    4ad0:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4ad7:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4add:	8b 55 fc             	mov    -0x4(%rbp),%edx
    4ae0:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4ae3:	8d 70 40             	lea    0x40(%rax),%esi
    4ae6:	e8 e7 25 fe ff       	call   0xfffffffffffe70d2
    4aeb:	89 c1                	mov    %eax,%ecx
    4aed:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4af4:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4afb:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4aff:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4b03:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4b09:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    4b0d:	83 e0 20             	and    $0x20,%eax
    4b10:	85 c0                	test   %eax,%eax
    4b12:	75 35                	jne    0x4b49
    4b14:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4b1b:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4b21:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
    4b27:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4b2a:	8d b0 50 01 00 00    	lea    0x150(%rax),%esi
    4b30:	e8 9d 25 fe ff       	call   0xfffffffffffe70d2
    4b35:	89 c1                	mov    %eax,%ecx
    4b37:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4b3e:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4b45:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4b49:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    4b4f:	8b 45 80             	mov    -0x80(%rbp),%eax
    4b52:	29 c8                	sub    %ecx,%eax
    4b54:	89 c1                	mov    %eax,%ecx
    4b56:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4b59:	83 f8 01             	cmp    $0x1,%eax
    4b5c:	0f 8c 32 01 00 00    	jl     0x4c94
    4b62:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4b69:	44 8b 45 fc          	mov    -0x4(%rbp),%r8d
    4b6d:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    4b70:	44 89 c0             	mov    %r8d,%eax
    4b73:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4b7a:	0f 92 c2             	setb   %dl
    4b7d:	0f b6 d2             	movzbl %dl,%edx
    4b80:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    4b86:	8d 71 40             	lea    0x40(%rcx),%esi
    4b89:	ba 30 00 00 00       	mov    $0x30,%edx
    4b8e:	b9 00 01 00 00       	mov    $0x100,%ecx
    4b93:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4b9a:	0f 42 c8             	cmovb  %eax,%ecx
    4b9d:	e8 16 26 fe ff       	call   0xfffffffffffe71b8
    4ba2:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    4ba9:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    4baf:	89 c6                	mov    %eax,%esi
    4bb1:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    4bb7:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    4bbe:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    4bc2:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    4bc5:	89 ca                	mov    %ecx,%edx
    4bc7:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    4bcd:	83 e1 20             	and    $0x20,%ecx
    4bd0:	85 c9                	test   %ecx,%ecx
    4bd2:	0f 94 c1             	sete   %cl
    4bd5:	0f b6 c9             	movzbl %cl,%ecx
    4bd8:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    4bde:	85 c0                	test   %eax,%eax
    4be0:	75 79                	jne    0x4c5b
    4be2:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    4be8:	83 e0 01             	and    $0x1,%eax
    4beb:	85 c0                	test   %eax,%eax
    4bed:	74 40                	je     0x4c2f
    4bef:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4bf5:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4bfc:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4bff:	8d 70 40             	lea    0x40(%rax),%esi
    4c02:	ba 00 01 00 00       	mov    $0x100,%edx
    4c07:	e8 c6 24 fe ff       	call   0xfffffffffffe70d2
    4c0c:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4c12:	89 c2                	mov    %eax,%edx
    4c14:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4c1b:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4c22:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4c26:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    4c29:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    4c2f:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4c32:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    4c38:	83 e1 20             	and    $0x20,%ecx
    4c3b:	85 c9                	test   %ecx,%ecx
    4c3d:	0f 94 c1             	sete   %cl
    4c40:	0f b6 c9             	movzbl %cl,%ecx
    4c43:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    4c49:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    4c4f:	89 c1                	mov    %eax,%ecx
    4c51:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4c54:	3d ff 00 00 00       	cmp    $0xff,%eax
    4c59:	77 87                	ja     0x4be2
    4c5b:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    4c61:	85 c0                	test   %eax,%eax
    4c63:	74 2f                	je     0x4c94
    4c65:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4c6c:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4c72:	8b 55 fc             	mov    -0x4(%rbp),%edx
    4c75:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4c78:	8d 70 40             	lea    0x40(%rax),%esi
    4c7b:	e8 52 24 fe ff       	call   0xfffffffffffe70d2
    4c80:	89 c1                	mov    %eax,%ecx
    4c82:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4c89:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4c90:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4c94:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4c98:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4c9e:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    4ca2:	83 e0 20             	and    $0x20,%eax
    4ca5:	85 c0                	test   %eax,%eax
    4ca7:	75 32                	jne    0x4cdb
    4ca9:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4cb0:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4cb6:	8b 95 74 ff ff ff    	mov    -0x8c(%rbp),%edx
    4cbc:	8b b5 6c ff ff ff    	mov    -0x94(%rbp),%esi
    4cc2:	e8 0b 24 fe ff       	call   0xfffffffffffe70d2
    4cc7:	89 c1                	mov    %eax,%ecx
    4cc9:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4cd0:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4cd7:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4cdb:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    4ce1:	3d 00 20 00 00       	cmp    $0x2000,%eax
    4ce6:	0f 85 54 01 00 00    	jne    0x4e40
    4cec:	8b 8d 50 ff ff ff    	mov    -0xb0(%rbp),%ecx
    4cf2:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    4cf8:	39 c8                	cmp    %ecx,%eax
    4cfa:	0f 8e 40 01 00 00    	jle    0x4e40
    4d00:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4d07:	8b 95 50 ff ff ff    	mov    -0xb0(%rbp),%edx
    4d0d:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    4d13:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    4d16:	29 d0                	sub    %edx,%eax
    4d18:	41 89 c0             	mov    %eax,%r8d
    4d1b:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    4d1f:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4d26:	0f 92 c2             	setb   %dl
    4d29:	0f b6 d2             	movzbl %dl,%edx
    4d2c:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    4d32:	8d 71 40             	lea    0x40(%rcx),%esi
    4d35:	ba 20 00 00 00       	mov    $0x20,%edx
    4d3a:	b9 00 01 00 00       	mov    $0x100,%ecx
    4d3f:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4d46:	0f 42 c8             	cmovb  %eax,%ecx
    4d49:	e8 6a 24 fe ff       	call   0xfffffffffffe71b8
    4d4e:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    4d55:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    4d5b:	89 c6                	mov    %eax,%esi
    4d5d:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    4d63:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
    4d6a:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    4d6e:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    4d71:	89 ca                	mov    %ecx,%edx
    4d73:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    4d79:	83 e1 20             	and    $0x20,%ecx
    4d7c:	85 c9                	test   %ecx,%ecx
    4d7e:	0f 94 c1             	sete   %cl
    4d81:	0f b6 c9             	movzbl %cl,%ecx
    4d84:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    4d8a:	85 c0                	test   %eax,%eax
    4d8c:	75 79                	jne    0x4e07
    4d8e:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    4d94:	83 e0 01             	and    $0x1,%eax
    4d97:	85 c0                	test   %eax,%eax
    4d99:	74 40                	je     0x4ddb
    4d9b:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4da1:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4da8:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4dab:	8d 70 40             	lea    0x40(%rax),%esi
    4dae:	ba 00 01 00 00       	mov    $0x100,%edx
    4db3:	e8 1a 23 fe ff       	call   0xfffffffffffe70d2
    4db8:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4dbe:	89 c2                	mov    %eax,%edx
    4dc0:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4dc7:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4dce:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4dd2:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    4dd5:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    4ddb:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4dde:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    4de4:	83 e1 20             	and    $0x20,%ecx
    4de7:	85 c9                	test   %ecx,%ecx
    4de9:	0f 94 c1             	sete   %cl
    4dec:	0f b6 c9             	movzbl %cl,%ecx
    4def:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    4df5:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    4dfb:	89 c1                	mov    %eax,%ecx
    4dfd:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4e00:	3d ff 00 00 00       	cmp    $0xff,%eax
    4e05:	77 87                	ja     0x4d8e
    4e07:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    4e0d:	85 c0                	test   %eax,%eax
    4e0f:	74 2f                	je     0x4e40
    4e11:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4e18:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4e1e:	8b 55 fc             	mov    -0x4(%rbp),%edx
    4e21:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4e24:	8d 70 40             	lea    0x40(%rax),%esi
    4e27:	e8 a6 22 fe ff       	call   0xfffffffffffe70d2
    4e2c:	89 c1                	mov    %eax,%ecx
    4e2e:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4e35:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
    4e3c:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4e40:	8b b5 50 ff ff ff    	mov    -0xb0(%rbp),%esi
    4e46:	8b 95 68 ff ff ff    	mov    -0x98(%rbp),%edx
    4e4c:	89 d1                	mov    %edx,%ecx
    4e4e:	89 f0                	mov    %esi,%eax
    4e50:	39 f2                	cmp    %esi,%edx
    4e52:	0f 4f c1             	cmovg  %ecx,%eax
    4e55:	89 45 fc             	mov    %eax,-0x4(%rbp)
    4e58:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4e5b:	85 c0                	test   %eax,%eax
    4e5d:	0f 8d 32 b4 ff ff    	jge    0x295
    4e63:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4e67:	b9 3d 00 00 00       	mov    $0x3d,%ecx
    4e6c:	89 88 d0 10 00 00    	mov    %ecx,0x10d0(%rax)
    4e72:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    4e77:	89 45 f8             	mov    %eax,-0x8(%rbp)
    4e7a:	8b 45 f8             	mov    -0x8(%rbp),%eax
    4e7d:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    4e84:	8b 55 cc             	mov    -0x34(%rbp),%edx
    4e87:	8d 92 70 03 00 00    	lea    0x370(%rdx),%edx
    4e8d:	89 91 78 11 00 00    	mov    %edx,0x1178(%rcx)
    4e93:	89 85 6c fe ff ff    	mov    %eax,-0x194(%rbp)
    4e99:	8b 85 6c fe ff ff    	mov    -0x194(%rbp),%eax
    4e9f:	48 81 c4 a0 01 00 00 	add    $0x1a0,%rsp
    4ea6:	5d                   	pop    %rbp
    4ea7:	c3                   	ret
    4ea8:	b8 6a 00 00 00       	mov    $0x6a,%eax
    4ead:	89 85 68 fe ff ff    	mov    %eax,-0x198(%rbp)
    4eb3:	eb 0b                	jmp    0x4ec0
    4eb5:	b8 6d 00 00 00       	mov    $0x6d,%eax
    4eba:	89 85 68 fe ff ff    	mov    %eax,-0x198(%rbp)
    4ec0:	8b b5 68 fe ff ff    	mov    -0x198(%rbp),%esi
    4ec6:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4ecd:	48 b8 b0 34 c5 4d a6 	movabs $0x55a64dc534b0,%rax
    4ed4:	55 00 00 
    4ed7:	ff d0                	call   *%rax
    4ed9:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4ee0:	48 b8 10 35 c5 4d a6 	movabs $0x55a64dc53510,%rax
    4ee7:	55 00 00 
    4eea:	ff d0                	call   *%rax
    4eec:	31 c0                	xor    %eax,%eax
    4eee:	48 81 c4 a0 01 00 00 	add    $0x1a0,%rsp
    4ef5:	5d                   	pop    %rbp
    4ef6:	c3                   	ret
    4ef7:	90                   	nop
    4ef8:	81 c0 ff ff 7c c0    	add    $0xc07cffff,%eax
    4efe:	ff                   	(bad)
    4eff:	ff 77 c0             	push   -0x40(%rdi)
    4f02:	ff                   	(bad)
    4f03:	ff                   	(bad)
    4f04:	7c c0                	jl     0x4ec6
    4f06:	ff                   	(bad)
    4f07:	ff 81 c0 ff ff 81    	incl   -0x7e000040(%rcx)
    4f0d:	c0 ff ff             	sar    $0xff,%bh
    4f10:	81 c0 ff ff 7c c0    	add    $0xc07cffff,%eax
    4f16:	ff                   	(bad)
    4f17:	ff                   	(bad)
    4f18:	7c c0                	jl     0x4eda
    4f1a:	ff                   	(bad)
    4f1b:	ff                   	(bad)
    4f1c:	7c c0                	jl     0x4ede
    4f1e:	ff                   	(bad)
    4f1f:	ff                   	(bad)
    4f20:	7c c0                	jl     0x4ee2
    4f22:	ff                   	(bad)
    4f23:	ff                   	(bad)
    4f24:	7c c0                	jl     0x4ee6
    4f26:	ff                   	(bad)
    4f27:	ff                   	(bad)
    4f28:	7c c0                	jl     0x4eea
    4f2a:	ff                   	(bad)
    4f2b:	ff                   	(bad)
    4f2c:	7c c0                	jl     0x4eee
    4f2e:	ff                   	(bad)
    4f2f:	ff                   	(bad)
    4f30:	7c c0                	jl     0x4ef2
    4f32:	ff                   	(bad)
    4f33:	ff                   	(bad)
    4f34:	7c c0                	jl     0x4ef6
    4f36:	ff                   	(bad)
    4f37:	ff                   	(bad)
    4f38:	7c c0                	jl     0x4efa
    4f3a:	ff                   	(bad)
    4f3b:	ff                   	(bad)
    4f3c:	7c c0                	jl     0x4efe
    4f3e:	ff                   	(bad)
    4f3f:	ff 72 c0             	push   -0x40(%rdx)
    4f42:	ff                   	(bad)
    4f43:	ff                   	(bad)
    4f44:	7c c0                	jl     0x4f06
    4f46:	ff                   	(bad)
    4f47:	ff                   	(bad)
    4f48:	7c c0                	jl     0x4f0a
    4f4a:	ff                   	(bad)
    4f4b:	ff                   	(bad)
    4f4c:	7c c0                	jl     0x4f0e
    4f4e:	ff                   	(bad)
    4f4f:	ff                   	(bad)
    4f50:	7c c0                	jl     0x4f12
    4f52:	ff                   	(bad)
    4f53:	ff 6d c0             	ljmp   *-0x40(%rbp)
    4f56:	ff                   	(bad)
    4f57:	ff                   	(bad)
    4f58:	7c c0                	jl     0x4f1a
    4f5a:	ff                   	(bad)
    4f5b:	ff                   	(bad)
    4f5c:	7c c0                	jl     0x4f1e
    4f5e:	ff                   	(bad)
    4f5f:	ff                   	(bad)
    4f60:	7c c0                	jl     0x4f22
    4f62:	ff                   	(bad)
    4f63:	ff                   	(bad)
    4f64:	7c c0                	jl     0x4f26
    4f66:	ff                   	(bad)
    4f67:	ff                   	(bad)
    4f68:	7c c0                	jl     0x4f2a
    4f6a:	ff                   	(bad)
    4f6b:	ff                   	(bad)
    4f6c:	7c c0                	jl     0x4f2e
    4f6e:	ff                   	(bad)
    4f6f:	ff                   	(bad)
    4f70:	7c c0                	jl     0x4f32
    4f72:	ff                   	(bad)
    4f73:	ff                   	(bad)
    4f74:	7c c0                	jl     0x4f36
    4f76:	ff                   	(bad)
    4f77:	ff 81 c0 ff ff 7c    	incl   0x7cffffc0(%rcx)
    4f7d:	c0 ff ff             	sar    $0xff,%bh
    4f80:	68 c0 ff ff 63       	push   $0x63ffffc0
    4f85:	c0 ff ff             	sar    $0xff,%bh
    4f88:	81 c0 ff ff 81 c0    	add    $0xc081ffff,%eax
    4f8e:	ff                   	(bad)
    4f8f:	ff 81 c0 ff ff 7c    	incl   0x7cffffc0(%rcx)
    4f95:	c0 ff ff             	sar    $0xff,%bh
    4f98:	63 c0                	movsxd %eax,%eax
    4f9a:	ff                   	(bad)
    4f9b:	ff                   	(bad)
    4f9c:	7c c0                	jl     0x4f5e
    4f9e:	ff                   	(bad)
    4f9f:	ff                   	(bad)
    4fa0:	7c c0                	jl     0x4f62
    4fa2:	ff                   	(bad)
    4fa3:	ff                   	(bad)
    4fa4:	7c c0                	jl     0x4f66
    4fa6:	ff                   	(bad)
    4fa7:	ff 5e c0             	lcall  *-0x40(%rsi)
    4faa:	ff                   	(bad)
    4fab:	ff 5c c0 ff          	lcall  *-0x1(%rax,%rax,8)
    4faf:	ff 57 c0             	call   *-0x40(%rdi)
    4fb2:	ff                   	(bad)
    4fb3:	ff 52 c0             	call   *-0x40(%rdx)
    4fb6:	ff                   	(bad)
    4fb7:	ff                   	(bad)
    4fb8:	7c c0                	jl     0x4f7a
    4fba:	ff                   	(bad)
    4fbb:	ff                   	(bad)
    4fbc:	7c c0                	jl     0x4f7e
    4fbe:	ff                   	(bad)
    4fbf:	ff 4d c0             	decl   -0x40(%rbp)
    4fc2:	ff                   	(bad)
    4fc3:	ff                   	(bad)
    4fc4:	7c c0                	jl     0x4f86
    4fc6:	ff                   	(bad)
    4fc7:	ff 4b c0             	decl   -0x40(%rbx)
    4fca:	ff                   	(bad)
    4fcb:	ff                   	(bad)
    4fcc:	7c c0                	jl     0x4f8e
    4fce:	ff                   	(bad)
    4fcf:	ff                   	(bad)
    4fd0:	7c c0                	jl     0x4f92
    4fd2:	ff                   	(bad)
    4fd3:	ff 6d c0             	ljmp   *-0x40(%rbp)
    4fd6:	ff                   	(bad)
    4fd7:	ff 12                	call   *(%rdx)
    4fd9:	c0 ff ff             	sar    $0xff,%bh
    4fdc:	10 c0                	adc    %al,%al
    4fde:	ff                   	(bad)
    4fdf:	ff 0e                	decl   (%rsi)
    4fe1:	c0 ff ff             	sar    $0xff,%bh
    4fe4:	0c c0                	or     $0xc0,%al
    4fe6:	ff                   	(bad)
    4fe7:	ff 0a                	decl   (%rdx)
    4fe9:	c0 ff ff             	sar    $0xff,%bh
    4fec:	05 c0 ff ff fb       	add    $0xfbffffc0,%eax
    4ff1:	bf ff ff 00 c0       	mov    $0xc000ffff,%edi
    4ff6:	ff                   	(bad)
    4ff7:	ff                   	.byte 0xff
