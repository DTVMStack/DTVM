
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-combined/func-40-0-7fd818a18000.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	48 83 ec 40          	sub    $0x40,%rsp
   8:	48 89 7d f0          	mov    %rdi,-0x10(%rbp)
   c:	89 75 d8             	mov    %esi,-0x28(%rbp)
   f:	89 55 dc             	mov    %edx,-0x24(%rbp)
  12:	41 89 c8             	mov    %ecx,%r8d
  15:	44 89 45 e0          	mov    %r8d,-0x20(%rbp)
  19:	31 c0                	xor    %eax,%eax
  1b:	31 c0                	xor    %eax,%eax
  1d:	89 45 e4             	mov    %eax,-0x1c(%rbp)
  20:	31 c0                	xor    %eax,%eax
  22:	89 45 e8             	mov    %eax,-0x18(%rbp)
  25:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
  2c:	ff 
  2d:	48 8b 8f b8 11 00 00 	mov    0x11b8(%rdi),%rcx
  34:	8b b7 78 11 00 00    	mov    0x1178(%rdi),%esi
  3a:	89 f0                	mov    %esi,%eax
  3c:	8d 80 30 ff ff ff    	lea    -0xd0(%rax),%eax
  42:	89 45 ec             	mov    %eax,-0x14(%rbp)
  45:	8d b6 30 ff ff ff    	lea    -0xd0(%rsi),%esi
  4b:	89 b7 78 11 00 00    	mov    %esi,0x1178(%rdi)
  51:	89 c6                	mov    %eax,%esi
  53:	45 89 c1             	mov    %r8d,%r9d
  56:	44 89 8c 31 cc 00 00 	mov    %r9d,0xcc(%rcx,%rsi,1)
  5d:	00 
  5e:	89 c6                	mov    %eax,%esi
  60:	8d b6 c0 00 00 00    	lea    0xc0(%rsi),%esi
  66:	45 31 c9             	xor    %r9d,%r9d
  69:	4c 89 0c 31          	mov    %r9,(%rcx,%rsi,1)
  6d:	89 c6                	mov    %eax,%esi
  6f:	8d b6 b8 00 00 00    	lea    0xb8(%rsi),%esi
  75:	45 31 c9             	xor    %r9d,%r9d
  78:	4c 89 0c 31          	mov    %r9,(%rcx,%rsi,1)
  7c:	89 c6                	mov    %eax,%esi
  7e:	8d b6 b0 00 00 00    	lea    0xb0(%rsi),%esi
  84:	45 31 c9             	xor    %r9d,%r9d
  87:	4c 89 0c 31          	mov    %r9,(%rcx,%rsi,1)
  8b:	89 c6                	mov    %eax,%esi
  8d:	45 31 c9             	xor    %r9d,%r9d
  90:	4c 89 8c 31 a8 00 00 	mov    %r9,0xa8(%rcx,%rsi,1)
  97:	00 
  98:	89 c6                	mov    %eax,%esi
  9a:	45 31 c9             	xor    %r9d,%r9d
  9d:	4c 89 8c 31 a0 00 00 	mov    %r9,0xa0(%rcx,%rsi,1)
  a4:	00 
  a5:	89 c6                	mov    %eax,%esi
  a7:	44 89 84 31 c8 00 00 	mov    %r8d,0xc8(%rcx,%rsi,1)
  ae:	00 
  af:	89 c1                	mov    %eax,%ecx
  b1:	41 89 c0             	mov    %eax,%r8d
  b4:	31 f6                	xor    %esi,%esi
  b6:	8d 89 c8 00 00 00    	lea    0xc8(%rcx),%ecx
  bc:	45 8d 40 50          	lea    0x50(%r8),%r8d
  c0:	44 8d 88 a0 00 00 00 	lea    0xa0(%rax),%r9d
  c7:	e8 88 80 fe ff       	call   0xfffffffffffe8154
  cc:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
  d0:	48 8b 8f b8 11 00 00 	mov    0x11b8(%rdi),%rcx
  d7:	48 89 4d f8          	mov    %rcx,-0x8(%rbp)
  db:	85 c0                	test   %eax,%eax
  dd:	7d 0d                	jge    0xec
  df:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  e4:	89 45 d8             	mov    %eax,-0x28(%rbp)
  e7:	e9 fa 01 00 00       	jmp    0x2e6
  ec:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
  f0:	8b 4d d8             	mov    -0x28(%rbp),%ecx
  f3:	89 ca                	mov    %ecx,%edx
  f5:	8b 14 10             	mov    (%rax,%rdx,1),%edx
  f8:	89 55 e4             	mov    %edx,-0x1c(%rbp)
  fb:	8b 44 08 3c          	mov    0x3c(%rax,%rcx,1),%eax
  ff:	85 c0                	test   %eax,%eax
 101:	7f 13                	jg     0x116
 103:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
 107:	8b 55 e4             	mov    -0x1c(%rbp),%edx
 10a:	8b 4d d8             	mov    -0x28(%rbp),%ecx
 10d:	81 e2 df ff ff ff    	and    $0xffffffdf,%edx
 113:	89 14 08             	mov    %edx,(%rax,%rcx,1)
 116:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
 11a:	8b 4d d8             	mov    -0x28(%rbp),%ecx
 11d:	8b 44 08 2c          	mov    0x2c(%rax,%rcx,1),%eax
 121:	85 c0                	test   %eax,%eax
 123:	75 35                	jne    0x15a
 125:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
 129:	8b 55 ec             	mov    -0x14(%rbp),%edx
 12c:	8b 4d d8             	mov    -0x28(%rbp),%ecx
 12f:	89 ce                	mov    %ecx,%esi
 131:	bf 50 00 00 00       	mov    $0x50,%edi
 136:	89 7c 30 2c          	mov    %edi,0x2c(%rax,%rsi,1)
 13a:	89 ce                	mov    %ecx,%esi
 13c:	31 ff                	xor    %edi,%edi
 13e:	89 7c 30 18          	mov    %edi,0x18(%rax,%rsi,1)
 142:	89 ce                	mov    %ecx,%esi
 144:	31 ff                	xor    %edi,%edi
 146:	48 89 7c 30 10       	mov    %rdi,0x10(%rax,%rsi,1)
 14b:	89 ce                	mov    %ecx,%esi
 14d:	8b 74 30 28          	mov    0x28(%rax,%rsi,1),%esi
 151:	89 75 e8             	mov    %esi,-0x18(%rbp)
 154:	89 54 08 28          	mov    %edx,0x28(%rax,%rcx,1)
 158:	eb 14                	jmp    0x16e
 15a:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
 15e:	8b 4d d8             	mov    -0x28(%rbp),%ecx
 161:	31 d2                	xor    %edx,%edx
 163:	89 55 e8             	mov    %edx,-0x18(%rbp)
 166:	8b 44 08 10          	mov    0x10(%rax,%rcx,1),%eax
 16a:	85 c0                	test   %eax,%eax
 16c:	75 27                	jne    0x195
 16e:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
 172:	8b 75 d8             	mov    -0x28(%rbp),%esi
 175:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 17a:	89 45 e0             	mov    %eax,-0x20(%rbp)
 17d:	e8 46 7f fe ff       	call   0xfffffffffffe80c8
 182:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 186:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
 18d:	48 89 4d f8          	mov    %rcx,-0x8(%rbp)
 191:	85 c0                	test   %eax,%eax
 193:	75 3a                	jne    0x1cf
 195:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
 199:	8b 45 ec             	mov    -0x14(%rbp),%eax
 19c:	8b 55 dc             	mov    -0x24(%rbp),%edx
 19f:	8b 75 d8             	mov    -0x28(%rbp),%esi
 1a2:	89 c1                	mov    %eax,%ecx
 1a4:	41 89 c0             	mov    %eax,%r8d
 1a7:	8d 89 c8 00 00 00    	lea    0xc8(%rcx),%ecx
 1ad:	45 8d 40 50          	lea    0x50(%r8),%r8d
 1b1:	44 8d 88 a0 00 00 00 	lea    0xa0(%rax),%r9d
 1b8:	e8 97 7f fe ff       	call   0xfffffffffffe8154
 1bd:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 1c1:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
 1c8:	48 89 4d f8          	mov    %rcx,-0x8(%rbp)
 1cc:	89 45 e0             	mov    %eax,-0x20(%rbp)
 1cf:	8b 45 e8             	mov    -0x18(%rbp),%eax
 1d2:	8b 4d e4             	mov    -0x1c(%rbp),%ecx
 1d5:	83 e1 20             	and    $0x20,%ecx
 1d8:	89 4d dc             	mov    %ecx,-0x24(%rbp)
 1db:	85 c0                	test   %eax,%eax
 1dd:	0f 84 d5 00 00 00    	je     0x2b8
 1e3:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 1e7:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
 1eb:	8b 55 d8             	mov    -0x28(%rbp),%edx
 1ee:	89 d6                	mov    %edx,%esi
 1f0:	89 75 d0             	mov    %esi,-0x30(%rbp)
 1f3:	8b 44 10 20          	mov    0x20(%rax,%rdx,1),%eax
 1f7:	89 45 d4             	mov    %eax,-0x2c(%rbp)
 1fa:	8b 89 80 11 00 00    	mov    0x1180(%rcx),%ecx
 200:	39 c8                	cmp    %ecx,%eax
 202:	0f 83 0a 01 00 00    	jae    0x312
 208:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 20c:	8b 4d d4             	mov    -0x2c(%rbp),%ecx
 20f:	8b 84 88 90 11 00 00 	mov    0x1190(%rax,%rcx,4),%eax
 216:	89 45 cc             	mov    %eax,-0x34(%rbp)
 219:	83 f8 ff             	cmp    $0xffffffff,%eax
 21c:	0f 84 fa 00 00 00    	je     0x31c
 222:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 226:	8b 4d cc             	mov    -0x34(%rbp),%ecx
 229:	8b 84 88 a8 13 00 00 	mov    0x13a8(%rax,%rcx,4),%eax
 230:	85 c0                	test   %eax,%eax
 232:	0f 85 d0 00 00 00    	jne    0x308
 238:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
 23c:	8b 75 d0             	mov    -0x30(%rbp),%esi
 23f:	8b 45 cc             	mov    -0x34(%rbp),%eax
 242:	48 8b 84 c7 d0 11 00 	mov    0x11d0(%rdi,%rax,8),%rax
 249:	00 
 24a:	31 d2                	xor    %edx,%edx
 24c:	31 c9                	xor    %ecx,%ecx
 24e:	ff d0                	call   *%rax
 250:	89 c1                	mov    %eax,%ecx
 252:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 256:	8b 80 84 00 00 00    	mov    0x84(%rax),%eax
 25c:	85 c0                	test   %eax,%eax
 25e:	0f 85 d3 00 00 00    	jne    0x337
 264:	8b 4d e0             	mov    -0x20(%rbp),%ecx
 267:	8b 7d e8             	mov    -0x18(%rbp),%edi
 26a:	8b 75 d8             	mov    -0x28(%rbp),%esi
 26d:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 271:	48 8b 80 b8 11 00 00 	mov    0x11b8(%rax),%rax
 278:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
 27c:	89 f2                	mov    %esi,%edx
 27e:	45 31 c0             	xor    %r8d,%r8d
 281:	44 89 44 10 2c       	mov    %r8d,0x2c(%rax,%rdx,1)
 286:	89 f2                	mov    %esi,%edx
 288:	89 7c 10 28          	mov    %edi,0x28(%rax,%rdx,1)
 28c:	89 f2                	mov    %esi,%edx
 28e:	31 ff                	xor    %edi,%edi
 290:	89 7c 10 18          	mov    %edi,0x18(%rax,%rdx,1)
 294:	89 f2                	mov    %esi,%edx
 296:	31 ff                	xor    %edi,%edi
 298:	89 7c 10 10          	mov    %edi,0x10(%rax,%rdx,1)
 29c:	89 f2                	mov    %esi,%edx
 29e:	8b 54 10 14          	mov    0x14(%rax,%rdx,1),%edx
 2a2:	89 55 e8             	mov    %edx,-0x18(%rbp)
 2a5:	31 ff                	xor    %edi,%edi
 2a7:	89 7c 30 14          	mov    %edi,0x14(%rax,%rsi,1)
 2ab:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
 2b0:	85 d2                	test   %edx,%edx
 2b2:	0f 45 c1             	cmovne %ecx,%eax
 2b5:	89 45 e0             	mov    %eax,-0x20(%rbp)
 2b8:	8b 55 d8             	mov    -0x28(%rbp),%edx
 2bb:	8b 45 e0             	mov    -0x20(%rbp),%eax
 2be:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
 2c2:	44 8b 45 dc          	mov    -0x24(%rbp),%r8d
 2c6:	89 d6                	mov    %edx,%esi
 2c8:	8b 3c 11             	mov    (%rcx,%rdx,1),%edi
 2cb:	89 fa                	mov    %edi,%edx
 2cd:	89 55 e8             	mov    %edx,-0x18(%rbp)
 2d0:	44 09 c7             	or     %r8d,%edi
 2d3:	89 3c 31             	mov    %edi,(%rcx,%rsi,1)
 2d6:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
 2db:	83 e2 20             	and    $0x20,%edx
 2de:	85 d2                	test   %edx,%edx
 2e0:	0f 45 c1             	cmovne %ecx,%eax
 2e3:	89 45 d8             	mov    %eax,-0x28(%rbp)
 2e6:	8b 45 d8             	mov    -0x28(%rbp),%eax
 2e9:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 2ed:	8b 55 ec             	mov    -0x14(%rbp),%edx
 2f0:	8d 92 d0 00 00 00    	lea    0xd0(%rdx),%edx
 2f6:	89 91 78 11 00 00    	mov    %edx,0x1178(%rcx)
 2fc:	89 45 c8             	mov    %eax,-0x38(%rbp)
 2ff:	8b 45 c8             	mov    -0x38(%rbp),%eax
 302:	48 83 c4 40          	add    $0x40,%rsp
 306:	5d                   	pop    %rbp
 307:	c3                   	ret
 308:	b8 6f 00 00 00       	mov    $0x6f,%eax
 30d:	89 45 c4             	mov    %eax,-0x3c(%rbp)
 310:	eb 12                	jmp    0x324
 312:	b8 70 00 00 00       	mov    $0x70,%eax
 317:	89 45 c4             	mov    %eax,-0x3c(%rbp)
 31a:	eb 08                	jmp    0x324
 31c:	b8 72 00 00 00       	mov    $0x72,%eax
 321:	89 45 c4             	mov    %eax,-0x3c(%rbp)
 324:	8b 75 c4             	mov    -0x3c(%rbp),%esi
 327:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
 32b:	48 b8 b0 34 c5 4d a6 	movabs $0x55a64dc534b0,%rax
 332:	55 00 00 
 335:	ff d0                	call   *%rax
 337:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
 33b:	48 b8 10 35 c5 4d a6 	movabs $0x55a64dc53510,%rax
 342:	55 00 00 
 345:	ff d0                	call   *%rax
 347:	31 c0                	xor    %eax,%eax
 349:	48 83 c4 40          	add    $0x40,%rsp
 34d:	5d                   	pop    %rbp
 34e:	c3                   	ret
