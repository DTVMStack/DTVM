
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-combined/func-50-0-7fd818a1f000.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	48 83 ec 38          	sub    $0x38,%rsp
   8:	89 75 d4             	mov    %esi,-0x2c(%rbp)
   b:	89 d0                	mov    %edx,%eax
   d:	89 45 d8             	mov    %eax,-0x28(%rbp)
  10:	89 c8                	mov    %ecx,%eax
  12:	89 45 f4             	mov    %eax,-0xc(%rbp)
  15:	31 c0                	xor    %eax,%eax
  17:	89 45 dc             	mov    %eax,-0x24(%rbp)
  1a:	31 c0                	xor    %eax,%eax
  1c:	89 45 e0             	mov    %eax,-0x20(%rbp)
  1f:	31 c0                	xor    %eax,%eax
  21:	89 45 e4             	mov    %eax,-0x1c(%rbp)
  24:	31 c0                	xor    %eax,%eax
  26:	89 45 e8             	mov    %eax,-0x18(%rbp)
  29:	31 c0                	xor    %eax,%eax
  2b:	89 45 ec             	mov    %eax,-0x14(%rbp)
  2e:	31 c0                	xor    %eax,%eax
  30:	89 45 f0             	mov    %eax,-0x10(%rbp)
  33:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
  3a:	ff 
  3b:	8b 45 f4             	mov    -0xc(%rbp),%eax
  3e:	48 8b 8f b8 11 00 00 	mov    0x11b8(%rdi),%rcx
  45:	48 89 4d f8          	mov    %rcx,-0x8(%rbp)
  49:	85 c0                	test   %eax,%eax
  4b:	74 56                	je     0xa3
  4d:	8b 45 d8             	mov    -0x28(%rbp),%eax
  50:	83 e0 03             	and    $0x3,%eax
  53:	85 c0                	test   %eax,%eax
  55:	74 4c                	je     0xa3
  57:	8b 45 d4             	mov    -0x2c(%rbp),%eax
  5a:	89 45 dc             	mov    %eax,-0x24(%rbp)
  5d:	8b 45 f4             	mov    -0xc(%rbp),%eax
  60:	8b 4d d8             	mov    -0x28(%rbp),%ecx
  63:	8b 55 dc             	mov    -0x24(%rbp),%edx
  66:	48 8b 75 f8          	mov    -0x8(%rbp),%rsi
  6a:	89 d7                	mov    %edx,%edi
  6c:	41 89 c8             	mov    %ecx,%r8d
  6f:	46 0f b6 04 06       	movzbl (%rsi,%r8,1),%r8d
  74:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
  78:	89 c6                	mov    %eax,%esi
  7a:	8d 76 ff             	lea    -0x1(%rsi),%esi
  7d:	89 75 e0             	mov    %esi,-0x20(%rbp)
  80:	8d 52 01             	lea    0x1(%rdx),%edx
  83:	89 55 dc             	mov    %edx,-0x24(%rbp)
  86:	8d 49 01             	lea    0x1(%rcx),%ecx
  89:	89 4d d8             	mov    %ecx,-0x28(%rbp)
  8c:	83 f8 01             	cmp    $0x1,%eax
  8f:	74 1e                	je     0xaf
  91:	8b 45 d8             	mov    -0x28(%rbp),%eax
  94:	8b 4d e0             	mov    -0x20(%rbp),%ecx
  97:	89 4d f4             	mov    %ecx,-0xc(%rbp)
  9a:	83 e0 03             	and    $0x3,%eax
  9d:	85 c0                	test   %eax,%eax
  9f:	75 bc                	jne    0x5d
  a1:	eb 0c                	jmp    0xaf
  a3:	8b 45 d4             	mov    -0x2c(%rbp),%eax
  a6:	8b 4d f4             	mov    -0xc(%rbp),%ecx
  a9:	89 4d e0             	mov    %ecx,-0x20(%rbp)
  ac:	89 45 dc             	mov    %eax,-0x24(%rbp)
  af:	8b 45 dc             	mov    -0x24(%rbp),%eax
  b2:	83 e0 03             	and    $0x3,%eax
  b5:	89 c1                	mov    %eax,%ecx
  b7:	89 4d f4             	mov    %ecx,-0xc(%rbp)
  ba:	85 c0                	test   %eax,%eax
  bc:	0f 85 30 01 00 00    	jne    0x1f2
  c2:	8b 45 e0             	mov    -0x20(%rbp),%eax
  c5:	83 f8 10             	cmp    $0x10,%eax
  c8:	72 6f                	jb     0x139
  ca:	8b 45 e0             	mov    -0x20(%rbp),%eax
  cd:	8b 4d d8             	mov    -0x28(%rbp),%ecx
  d0:	8b 55 dc             	mov    -0x24(%rbp),%edx
  d3:	48 8b 75 f8          	mov    -0x8(%rbp),%rsi
  d7:	89 d7                	mov    %edx,%edi
  d9:	41 89 c8             	mov    %ecx,%r8d
  dc:	46 8b 04 06          	mov    (%rsi,%r8,1),%r8d
  e0:	44 89 04 3e          	mov    %r8d,(%rsi,%rdi,1)
  e4:	89 d7                	mov    %edx,%edi
  e6:	41 89 c8             	mov    %ecx,%r8d
  e9:	45 8d 40 04          	lea    0x4(%r8),%r8d
  ed:	46 8b 04 06          	mov    (%rsi,%r8,1),%r8d
  f1:	8d 7f 04             	lea    0x4(%rdi),%edi
  f4:	44 89 04 3e          	mov    %r8d,(%rsi,%rdi,1)
  f8:	89 d7                	mov    %edx,%edi
  fa:	41 89 c8             	mov    %ecx,%r8d
  fd:	45 8d 40 08          	lea    0x8(%r8),%r8d
 101:	46 8b 04 06          	mov    (%rsi,%r8,1),%r8d
 105:	8d 7f 08             	lea    0x8(%rdi),%edi
 108:	44 89 04 3e          	mov    %r8d,(%rsi,%rdi,1)
 10c:	89 d7                	mov    %edx,%edi
 10e:	41 89 c8             	mov    %ecx,%r8d
 111:	45 8d 40 0c          	lea    0xc(%r8),%r8d
 115:	46 8b 04 06          	mov    (%rsi,%r8,1),%r8d
 119:	8d 7f 0c             	lea    0xc(%rdi),%edi
 11c:	44 89 04 3e          	mov    %r8d,(%rsi,%rdi,1)
 120:	8d 52 10             	lea    0x10(%rdx),%edx
 123:	89 55 dc             	mov    %edx,-0x24(%rbp)
 126:	8d 49 10             	lea    0x10(%rcx),%ecx
 129:	89 4d d8             	mov    %ecx,-0x28(%rbp)
 12c:	8d 40 f0             	lea    -0x10(%rax),%eax
 12f:	89 c1                	mov    %eax,%ecx
 131:	89 4d e0             	mov    %ecx,-0x20(%rbp)
 134:	83 f8 0f             	cmp    $0xf,%eax
 137:	77 91                	ja     0xca
 139:	8b 45 e0             	mov    -0x20(%rbp),%eax
 13c:	83 e0 08             	and    $0x8,%eax
 13f:	85 c0                	test   %eax,%eax
 141:	74 22                	je     0x165
 143:	8b 45 dc             	mov    -0x24(%rbp),%eax
 146:	8b 4d d8             	mov    -0x28(%rbp),%ecx
 149:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 14d:	89 c6                	mov    %eax,%esi
 14f:	89 cf                	mov    %ecx,%edi
 151:	48 8b 3c 3a          	mov    (%rdx,%rdi,1),%rdi
 155:	48 89 3c 32          	mov    %rdi,(%rdx,%rsi,1)
 159:	8d 49 08             	lea    0x8(%rcx),%ecx
 15c:	89 4d d8             	mov    %ecx,-0x28(%rbp)
 15f:	8d 40 08             	lea    0x8(%rax),%eax
 162:	89 45 dc             	mov    %eax,-0x24(%rbp)
 165:	8b 45 e0             	mov    -0x20(%rbp),%eax
 168:	83 e0 04             	and    $0x4,%eax
 16b:	85 c0                	test   %eax,%eax
 16d:	74 20                	je     0x18f
 16f:	8b 45 dc             	mov    -0x24(%rbp),%eax
 172:	8b 4d d8             	mov    -0x28(%rbp),%ecx
 175:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 179:	89 c6                	mov    %eax,%esi
 17b:	89 cf                	mov    %ecx,%edi
 17d:	8b 3c 3a             	mov    (%rdx,%rdi,1),%edi
 180:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
 183:	8d 49 04             	lea    0x4(%rcx),%ecx
 186:	89 4d d8             	mov    %ecx,-0x28(%rbp)
 189:	8d 40 04             	lea    0x4(%rax),%eax
 18c:	89 45 dc             	mov    %eax,-0x24(%rbp)
 18f:	8b 45 e0             	mov    -0x20(%rbp),%eax
 192:	83 e0 02             	and    $0x2,%eax
 195:	85 c0                	test   %eax,%eax
 197:	74 30                	je     0x1c9
 199:	8b 45 d8             	mov    -0x28(%rbp),%eax
 19c:	8b 4d dc             	mov    -0x24(%rbp),%ecx
 19f:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 1a3:	89 ce                	mov    %ecx,%esi
 1a5:	89 c7                	mov    %eax,%edi
 1a7:	0f b6 3c 3a          	movzbl (%rdx,%rdi,1),%edi
 1ab:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
 1af:	89 ce                	mov    %ecx,%esi
 1b1:	89 c7                	mov    %eax,%edi
 1b3:	0f b6 7c 3a 01       	movzbl 0x1(%rdx,%rdi,1),%edi
 1b8:	40 88 7c 32 01       	mov    %dil,0x1(%rdx,%rsi,1)
 1bd:	8d 49 02             	lea    0x2(%rcx),%ecx
 1c0:	89 4d dc             	mov    %ecx,-0x24(%rbp)
 1c3:	8d 40 02             	lea    0x2(%rax),%eax
 1c6:	89 45 d8             	mov    %eax,-0x28(%rbp)
 1c9:	8b 45 e0             	mov    -0x20(%rbp),%eax
 1cc:	83 e0 01             	and    $0x1,%eax
 1cf:	85 c0                	test   %eax,%eax
 1d1:	0f 84 e9 05 00 00    	je     0x7c0
 1d7:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 1da:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
 1de:	8b 75 d8             	mov    -0x28(%rbp),%esi
 1e1:	8b 55 dc             	mov    -0x24(%rbp),%edx
 1e4:	0f b6 34 31          	movzbl (%rcx,%rsi,1),%esi
 1e8:	40 88 34 11          	mov    %sil,(%rcx,%rdx,1)
 1ec:	48 83 c4 38          	add    $0x38,%rsp
 1f0:	5d                   	pop    %rbp
 1f1:	c3                   	ret
 1f2:	8b 45 e0             	mov    -0x20(%rbp),%eax
 1f5:	83 f8 20             	cmp    $0x20,%eax
 1f8:	0f 82 91 03 00 00    	jb     0x58f
 1fe:	8b 45 f4             	mov    -0xc(%rbp),%eax
 201:	8d 40 ff             	lea    -0x1(%rax),%eax
 204:	89 45 d0             	mov    %eax,-0x30(%rbp)
 207:	3d 00 00 00 00       	cmp    $0x0,%eax
 20c:	74 23                	je     0x231
 20e:	8b 45 d0             	mov    -0x30(%rbp),%eax
 211:	3d 01 00 00 00       	cmp    $0x1,%eax
 216:	74 14                	je     0x22c
 218:	8b 45 d0             	mov    -0x30(%rbp),%eax
 21b:	3d 02 00 00 00       	cmp    $0x2,%eax
 220:	74 05                	je     0x227
 222:	e9 68 03 00 00       	jmp    0x58f
 227:	e9 57 02 00 00       	jmp    0x483
 22c:	e9 31 01 00 00       	jmp    0x362
 231:	8b 45 dc             	mov    -0x24(%rbp),%eax
 234:	8b 4d e0             	mov    -0x20(%rbp),%ecx
 237:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 23b:	8b 7d d8             	mov    -0x28(%rbp),%edi
 23e:	89 c6                	mov    %eax,%esi
 240:	41 89 f8             	mov    %edi,%r8d
 243:	46 0f b6 44 02 01    	movzbl 0x1(%rdx,%r8,1),%r8d
 249:	44 88 44 32 01       	mov    %r8b,0x1(%rdx,%rsi,1)
 24e:	89 c6                	mov    %eax,%esi
 250:	41 89 f8             	mov    %edi,%r8d
 253:	46 8b 04 02          	mov    (%rdx,%r8,1),%r8d
 257:	45 89 c1             	mov    %r8d,%r9d
 25a:	44 89 4d e4          	mov    %r9d,-0x1c(%rbp)
 25e:	44 88 04 32          	mov    %r8b,(%rdx,%rsi,1)
 262:	89 c6                	mov    %eax,%esi
 264:	0f b6 7c 3a 02       	movzbl 0x2(%rdx,%rdi,1),%edi
 269:	40 88 7c 32 02       	mov    %dil,0x2(%rdx,%rsi,1)
 26e:	8d 49 fd             	lea    -0x3(%rcx),%ecx
 271:	89 4d e0             	mov    %ecx,-0x20(%rbp)
 274:	8d 40 03             	lea    0x3(%rax),%eax
 277:	89 45 e8             	mov    %eax,-0x18(%rbp)
 27a:	31 c0                	xor    %eax,%eax
 27c:	89 45 f4             	mov    %eax,-0xc(%rbp)
 27f:	8b 45 e0             	mov    -0x20(%rbp),%eax
 282:	8b 4d f4             	mov    -0xc(%rbp),%ecx
 285:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 289:	44 8b 5d e4          	mov    -0x1c(%rbp),%r11d
 28d:	44 8b 4d d8          	mov    -0x28(%rbp),%r9d
 291:	44 8b 45 e8          	mov    -0x18(%rbp),%r8d
 295:	89 ce                	mov    %ecx,%esi
 297:	41 01 f0             	add    %esi,%r8d
 29a:	44 89 c6             	mov    %r8d,%esi
 29d:	89 75 dc             	mov    %esi,-0x24(%rbp)
 2a0:	89 cf                	mov    %ecx,%edi
 2a2:	41 01 f9             	add    %edi,%r9d
 2a5:	44 89 cf             	mov    %r9d,%edi
 2a8:	89 7d ec             	mov    %edi,-0x14(%rbp)
 2ab:	45 8d 49 04          	lea    0x4(%r9),%r9d
 2af:	46 8b 0c 0a          	mov    (%rdx,%r9,1),%r9d
 2b3:	45 89 ca             	mov    %r9d,%r10d
 2b6:	41 c1 e1 08          	shl    $0x8,%r9d
 2ba:	41 c1 eb 18          	shr    $0x18,%r11d
 2be:	45 09 d9             	or     %r11d,%r9d
 2c1:	46 89 0c 02          	mov    %r9d,(%rdx,%r8,1)
 2c5:	41 89 f0             	mov    %esi,%r8d
 2c8:	41 89 f9             	mov    %edi,%r9d
 2cb:	45 8d 49 08          	lea    0x8(%r9),%r9d
 2cf:	46 8b 0c 0a          	mov    (%rdx,%r9,1),%r9d
 2d3:	45 89 cb             	mov    %r9d,%r11d
 2d6:	45 8d 40 04          	lea    0x4(%r8),%r8d
 2da:	41 c1 e1 08          	shl    $0x8,%r9d
 2de:	41 c1 ea 18          	shr    $0x18,%r10d
 2e2:	45 09 d1             	or     %r10d,%r9d
 2e5:	46 89 0c 02          	mov    %r9d,(%rdx,%r8,1)
 2e9:	41 89 f1             	mov    %esi,%r9d
 2ec:	41 89 f8             	mov    %edi,%r8d
 2ef:	45 8d 40 0c          	lea    0xc(%r8),%r8d
 2f3:	46 8b 14 02          	mov    (%rdx,%r8,1),%r10d
 2f7:	45 89 d0             	mov    %r10d,%r8d
 2fa:	44 89 45 f0          	mov    %r8d,-0x10(%rbp)
 2fe:	45 8d 49 08          	lea    0x8(%r9),%r9d
 302:	41 c1 e2 08          	shl    $0x8,%r10d
 306:	41 c1 eb 18          	shr    $0x18,%r11d
 30a:	45 09 da             	or     %r11d,%r10d
 30d:	46 89 14 0a          	mov    %r10d,(%rdx,%r9,1)
 311:	8d 7f 10             	lea    0x10(%rdi),%edi
 314:	8b 3c 3a             	mov    (%rdx,%rdi,1),%edi
 317:	41 89 f9             	mov    %edi,%r9d
 31a:	44 89 4d e4          	mov    %r9d,-0x1c(%rbp)
 31e:	8d 76 0c             	lea    0xc(%rsi),%esi
 321:	c1 e7 08             	shl    $0x8,%edi
 324:	41 c1 e8 18          	shr    $0x18,%r8d
 328:	44 09 c7             	or     %r8d,%edi
 32b:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
 32e:	8d 49 10             	lea    0x10(%rcx),%ecx
 331:	89 4d f4             	mov    %ecx,-0xc(%rbp)
 334:	8d 40 f0             	lea    -0x10(%rax),%eax
 337:	89 c1                	mov    %eax,%ecx
 339:	89 4d e0             	mov    %ecx,-0x20(%rbp)
 33c:	83 f8 10             	cmp    $0x10,%eax
 33f:	0f 87 3a ff ff ff    	ja     0x27f
 345:	8b 45 d8             	mov    -0x28(%rbp),%eax
 348:	8b 4d f4             	mov    -0xc(%rbp),%ecx
 34b:	8b 55 e8             	mov    -0x18(%rbp),%edx
 34e:	89 ce                	mov    %ecx,%esi
 350:	01 f2                	add    %esi,%edx
 352:	89 55 dc             	mov    %edx,-0x24(%rbp)
 355:	01 c8                	add    %ecx,%eax
 357:	8d 40 03             	lea    0x3(%rax),%eax
 35a:	89 45 d8             	mov    %eax,-0x28(%rbp)
 35d:	e9 2d 02 00 00       	jmp    0x58f
 362:	8b 45 dc             	mov    -0x24(%rbp),%eax
 365:	8b 4d e0             	mov    -0x20(%rbp),%ecx
 368:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 36c:	8b 7d d8             	mov    -0x28(%rbp),%edi
 36f:	89 c6                	mov    %eax,%esi
 371:	41 89 f8             	mov    %edi,%r8d
 374:	46 8b 04 02          	mov    (%rdx,%r8,1),%r8d
 378:	45 89 c1             	mov    %r8d,%r9d
 37b:	44 89 4d e4          	mov    %r9d,-0x1c(%rbp)
 37f:	44 88 04 32          	mov    %r8b,(%rdx,%rsi,1)
 383:	89 c6                	mov    %eax,%esi
 385:	0f b6 7c 3a 01       	movzbl 0x1(%rdx,%rdi,1),%edi
 38a:	40 88 7c 32 01       	mov    %dil,0x1(%rdx,%rsi,1)
 38f:	8d 49 fe             	lea    -0x2(%rcx),%ecx
 392:	89 4d e0             	mov    %ecx,-0x20(%rbp)
 395:	8d 40 02             	lea    0x2(%rax),%eax
 398:	89 45 e8             	mov    %eax,-0x18(%rbp)
 39b:	31 c0                	xor    %eax,%eax
 39d:	89 45 f4             	mov    %eax,-0xc(%rbp)
 3a0:	8b 45 e0             	mov    -0x20(%rbp),%eax
 3a3:	8b 4d f4             	mov    -0xc(%rbp),%ecx
 3a6:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 3aa:	44 8b 5d e4          	mov    -0x1c(%rbp),%r11d
 3ae:	44 8b 4d d8          	mov    -0x28(%rbp),%r9d
 3b2:	44 8b 45 e8          	mov    -0x18(%rbp),%r8d
 3b6:	89 ce                	mov    %ecx,%esi
 3b8:	41 01 f0             	add    %esi,%r8d
 3bb:	44 89 c6             	mov    %r8d,%esi
 3be:	89 75 dc             	mov    %esi,-0x24(%rbp)
 3c1:	89 cf                	mov    %ecx,%edi
 3c3:	41 01 f9             	add    %edi,%r9d
 3c6:	44 89 cf             	mov    %r9d,%edi
 3c9:	89 7d ec             	mov    %edi,-0x14(%rbp)
 3cc:	45 8d 49 04          	lea    0x4(%r9),%r9d
 3d0:	46 8b 0c 0a          	mov    (%rdx,%r9,1),%r9d
 3d4:	45 89 ca             	mov    %r9d,%r10d
 3d7:	41 c1 e1 10          	shl    $0x10,%r9d
 3db:	41 c1 eb 10          	shr    $0x10,%r11d
 3df:	45 09 d9             	or     %r11d,%r9d
 3e2:	46 89 0c 02          	mov    %r9d,(%rdx,%r8,1)
 3e6:	41 89 f0             	mov    %esi,%r8d
 3e9:	41 89 f9             	mov    %edi,%r9d
 3ec:	45 8d 49 08          	lea    0x8(%r9),%r9d
 3f0:	46 8b 0c 0a          	mov    (%rdx,%r9,1),%r9d
 3f4:	45 89 cb             	mov    %r9d,%r11d
 3f7:	45 8d 40 04          	lea    0x4(%r8),%r8d
 3fb:	41 c1 e1 10          	shl    $0x10,%r9d
 3ff:	41 c1 ea 10          	shr    $0x10,%r10d
 403:	45 09 d1             	or     %r10d,%r9d
 406:	46 89 0c 02          	mov    %r9d,(%rdx,%r8,1)
 40a:	41 89 f1             	mov    %esi,%r9d
 40d:	41 89 f8             	mov    %edi,%r8d
 410:	45 8d 40 0c          	lea    0xc(%r8),%r8d
 414:	46 8b 14 02          	mov    (%rdx,%r8,1),%r10d
 418:	45 89 d0             	mov    %r10d,%r8d
 41b:	44 89 45 f0          	mov    %r8d,-0x10(%rbp)
 41f:	45 8d 49 08          	lea    0x8(%r9),%r9d
 423:	41 c1 e2 10          	shl    $0x10,%r10d
 427:	41 c1 eb 10          	shr    $0x10,%r11d
 42b:	45 09 da             	or     %r11d,%r10d
 42e:	46 89 14 0a          	mov    %r10d,(%rdx,%r9,1)
 432:	8d 7f 10             	lea    0x10(%rdi),%edi
 435:	8b 3c 3a             	mov    (%rdx,%rdi,1),%edi
 438:	41 89 f9             	mov    %edi,%r9d
 43b:	44 89 4d e4          	mov    %r9d,-0x1c(%rbp)
 43f:	8d 76 0c             	lea    0xc(%rsi),%esi
 442:	c1 e7 10             	shl    $0x10,%edi
 445:	41 c1 e8 10          	shr    $0x10,%r8d
 449:	44 09 c7             	or     %r8d,%edi
 44c:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
 44f:	8d 49 10             	lea    0x10(%rcx),%ecx
 452:	89 4d f4             	mov    %ecx,-0xc(%rbp)
 455:	8d 40 f0             	lea    -0x10(%rax),%eax
 458:	89 c1                	mov    %eax,%ecx
 45a:	89 4d e0             	mov    %ecx,-0x20(%rbp)
 45d:	83 f8 11             	cmp    $0x11,%eax
 460:	0f 87 3a ff ff ff    	ja     0x3a0
 466:	8b 45 d8             	mov    -0x28(%rbp),%eax
 469:	8b 4d f4             	mov    -0xc(%rbp),%ecx
 46c:	8b 55 e8             	mov    -0x18(%rbp),%edx
 46f:	89 ce                	mov    %ecx,%esi
 471:	01 f2                	add    %esi,%edx
 473:	89 55 dc             	mov    %edx,-0x24(%rbp)
 476:	01 c8                	add    %ecx,%eax
 478:	8d 40 02             	lea    0x2(%rax),%eax
 47b:	89 45 d8             	mov    %eax,-0x28(%rbp)
 47e:	e9 0c 01 00 00       	jmp    0x58f
 483:	8b 45 dc             	mov    -0x24(%rbp),%eax
 486:	8b 4d e0             	mov    -0x20(%rbp),%ecx
 489:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 48d:	8b 7d d8             	mov    -0x28(%rbp),%edi
 490:	89 c6                	mov    %eax,%esi
 492:	8b 3c 3a             	mov    (%rdx,%rdi,1),%edi
 495:	41 89 f8             	mov    %edi,%r8d
 498:	44 89 45 e4          	mov    %r8d,-0x1c(%rbp)
 49c:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
 4a0:	8d 49 ff             	lea    -0x1(%rcx),%ecx
 4a3:	89 4d e0             	mov    %ecx,-0x20(%rbp)
 4a6:	8d 40 01             	lea    0x1(%rax),%eax
 4a9:	89 45 e8             	mov    %eax,-0x18(%rbp)
 4ac:	31 c0                	xor    %eax,%eax
 4ae:	89 45 f4             	mov    %eax,-0xc(%rbp)
 4b1:	8b 45 e0             	mov    -0x20(%rbp),%eax
 4b4:	8b 4d f4             	mov    -0xc(%rbp),%ecx
 4b7:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 4bb:	44 8b 5d e4          	mov    -0x1c(%rbp),%r11d
 4bf:	44 8b 4d d8          	mov    -0x28(%rbp),%r9d
 4c3:	44 8b 45 e8          	mov    -0x18(%rbp),%r8d
 4c7:	89 ce                	mov    %ecx,%esi
 4c9:	41 01 f0             	add    %esi,%r8d
 4cc:	44 89 c6             	mov    %r8d,%esi
 4cf:	89 75 dc             	mov    %esi,-0x24(%rbp)
 4d2:	89 cf                	mov    %ecx,%edi
 4d4:	41 01 f9             	add    %edi,%r9d
 4d7:	44 89 cf             	mov    %r9d,%edi
 4da:	89 7d ec             	mov    %edi,-0x14(%rbp)
 4dd:	45 8d 49 04          	lea    0x4(%r9),%r9d
 4e1:	46 8b 0c 0a          	mov    (%rdx,%r9,1),%r9d
 4e5:	45 89 ca             	mov    %r9d,%r10d
 4e8:	41 c1 e1 18          	shl    $0x18,%r9d
 4ec:	41 c1 eb 08          	shr    $0x8,%r11d
 4f0:	45 09 d9             	or     %r11d,%r9d
 4f3:	46 89 0c 02          	mov    %r9d,(%rdx,%r8,1)
 4f7:	41 89 f0             	mov    %esi,%r8d
 4fa:	41 89 f9             	mov    %edi,%r9d
 4fd:	45 8d 49 08          	lea    0x8(%r9),%r9d
 501:	46 8b 0c 0a          	mov    (%rdx,%r9,1),%r9d
 505:	45 89 cb             	mov    %r9d,%r11d
 508:	45 8d 40 04          	lea    0x4(%r8),%r8d
 50c:	41 c1 e1 18          	shl    $0x18,%r9d
 510:	41 c1 ea 08          	shr    $0x8,%r10d
 514:	45 09 d1             	or     %r10d,%r9d
 517:	46 89 0c 02          	mov    %r9d,(%rdx,%r8,1)
 51b:	41 89 f1             	mov    %esi,%r9d
 51e:	41 89 f8             	mov    %edi,%r8d
 521:	45 8d 40 0c          	lea    0xc(%r8),%r8d
 525:	46 8b 14 02          	mov    (%rdx,%r8,1),%r10d
 529:	45 89 d0             	mov    %r10d,%r8d
 52c:	44 89 45 f0          	mov    %r8d,-0x10(%rbp)
 530:	45 8d 49 08          	lea    0x8(%r9),%r9d
 534:	41 c1 e2 18          	shl    $0x18,%r10d
 538:	41 c1 eb 08          	shr    $0x8,%r11d
 53c:	45 09 da             	or     %r11d,%r10d
 53f:	46 89 14 0a          	mov    %r10d,(%rdx,%r9,1)
 543:	8d 7f 10             	lea    0x10(%rdi),%edi
 546:	8b 3c 3a             	mov    (%rdx,%rdi,1),%edi
 549:	41 89 f9             	mov    %edi,%r9d
 54c:	44 89 4d e4          	mov    %r9d,-0x1c(%rbp)
 550:	8d 76 0c             	lea    0xc(%rsi),%esi
 553:	c1 e7 18             	shl    $0x18,%edi
 556:	41 c1 e8 08          	shr    $0x8,%r8d
 55a:	44 09 c7             	or     %r8d,%edi
 55d:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
 560:	8d 49 10             	lea    0x10(%rcx),%ecx
 563:	89 4d f4             	mov    %ecx,-0xc(%rbp)
 566:	8d 40 f0             	lea    -0x10(%rax),%eax
 569:	89 c1                	mov    %eax,%ecx
 56b:	89 4d e0             	mov    %ecx,-0x20(%rbp)
 56e:	83 f8 12             	cmp    $0x12,%eax
 571:	0f 87 3a ff ff ff    	ja     0x4b1
 577:	8b 45 d8             	mov    -0x28(%rbp),%eax
 57a:	8b 4d f4             	mov    -0xc(%rbp),%ecx
 57d:	8b 55 e8             	mov    -0x18(%rbp),%edx
 580:	89 ce                	mov    %ecx,%esi
 582:	01 f2                	add    %esi,%edx
 584:	89 55 dc             	mov    %edx,-0x24(%rbp)
 587:	01 c8                	add    %ecx,%eax
 589:	8d 40 01             	lea    0x1(%rax),%eax
 58c:	89 45 d8             	mov    %eax,-0x28(%rbp)
 58f:	8b 45 e0             	mov    -0x20(%rbp),%eax
 592:	83 e0 10             	and    $0x10,%eax
 595:	85 c0                	test   %eax,%eax
 597:	0f 84 e6 00 00 00    	je     0x683
 59d:	8b 45 d8             	mov    -0x28(%rbp),%eax
 5a0:	8b 4d dc             	mov    -0x24(%rbp),%ecx
 5a3:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 5a7:	89 ce                	mov    %ecx,%esi
 5a9:	89 c7                	mov    %eax,%edi
 5ab:	0f b7 3c 3a          	movzwl (%rdx,%rdi,1),%edi
 5af:	66 89 3c 32          	mov    %di,(%rdx,%rsi,1)
 5b3:	89 ce                	mov    %ecx,%esi
 5b5:	89 c7                	mov    %eax,%edi
 5b7:	0f b6 7c 3a 02       	movzbl 0x2(%rdx,%rdi,1),%edi
 5bc:	40 88 7c 32 02       	mov    %dil,0x2(%rdx,%rsi,1)
 5c1:	89 ce                	mov    %ecx,%esi
 5c3:	89 c7                	mov    %eax,%edi
 5c5:	0f b6 7c 3a 03       	movzbl 0x3(%rdx,%rdi,1),%edi
 5ca:	40 88 7c 32 03       	mov    %dil,0x3(%rdx,%rsi,1)
 5cf:	89 ce                	mov    %ecx,%esi
 5d1:	89 c7                	mov    %eax,%edi
 5d3:	0f b6 7c 3a 04       	movzbl 0x4(%rdx,%rdi,1),%edi
 5d8:	40 88 7c 32 04       	mov    %dil,0x4(%rdx,%rsi,1)
 5dd:	89 ce                	mov    %ecx,%esi
 5df:	89 c7                	mov    %eax,%edi
 5e1:	0f b6 7c 3a 05       	movzbl 0x5(%rdx,%rdi,1),%edi
 5e6:	40 88 7c 32 05       	mov    %dil,0x5(%rdx,%rsi,1)
 5eb:	89 ce                	mov    %ecx,%esi
 5ed:	89 c7                	mov    %eax,%edi
 5ef:	0f b6 7c 3a 06       	movzbl 0x6(%rdx,%rdi,1),%edi
 5f4:	40 88 7c 32 06       	mov    %dil,0x6(%rdx,%rsi,1)
 5f9:	89 ce                	mov    %ecx,%esi
 5fb:	89 c7                	mov    %eax,%edi
 5fd:	0f b6 7c 3a 07       	movzbl 0x7(%rdx,%rdi,1),%edi
 602:	40 88 7c 32 07       	mov    %dil,0x7(%rdx,%rsi,1)
 607:	89 ce                	mov    %ecx,%esi
 609:	89 c7                	mov    %eax,%edi
 60b:	0f b6 7c 3a 08       	movzbl 0x8(%rdx,%rdi,1),%edi
 610:	40 88 7c 32 08       	mov    %dil,0x8(%rdx,%rsi,1)
 615:	89 ce                	mov    %ecx,%esi
 617:	89 c7                	mov    %eax,%edi
 619:	0f b6 7c 3a 09       	movzbl 0x9(%rdx,%rdi,1),%edi
 61e:	40 88 7c 32 09       	mov    %dil,0x9(%rdx,%rsi,1)
 623:	89 ce                	mov    %ecx,%esi
 625:	89 c7                	mov    %eax,%edi
 627:	0f b6 7c 3a 0a       	movzbl 0xa(%rdx,%rdi,1),%edi
 62c:	40 88 7c 32 0a       	mov    %dil,0xa(%rdx,%rsi,1)
 631:	89 ce                	mov    %ecx,%esi
 633:	89 c7                	mov    %eax,%edi
 635:	0f b6 7c 3a 0b       	movzbl 0xb(%rdx,%rdi,1),%edi
 63a:	40 88 7c 32 0b       	mov    %dil,0xb(%rdx,%rsi,1)
 63f:	89 ce                	mov    %ecx,%esi
 641:	89 c7                	mov    %eax,%edi
 643:	0f b6 7c 3a 0c       	movzbl 0xc(%rdx,%rdi,1),%edi
 648:	40 88 7c 32 0c       	mov    %dil,0xc(%rdx,%rsi,1)
 64d:	89 ce                	mov    %ecx,%esi
 64f:	89 c7                	mov    %eax,%edi
 651:	0f b6 7c 3a 0d       	movzbl 0xd(%rdx,%rdi,1),%edi
 656:	40 88 7c 32 0d       	mov    %dil,0xd(%rdx,%rsi,1)
 65b:	89 ce                	mov    %ecx,%esi
 65d:	89 c7                	mov    %eax,%edi
 65f:	0f b6 7c 3a 0e       	movzbl 0xe(%rdx,%rdi,1),%edi
 664:	40 88 7c 32 0e       	mov    %dil,0xe(%rdx,%rsi,1)
 669:	89 ce                	mov    %ecx,%esi
 66b:	89 c7                	mov    %eax,%edi
 66d:	0f b6 7c 3a 0f       	movzbl 0xf(%rdx,%rdi,1),%edi
 672:	40 88 7c 32 0f       	mov    %dil,0xf(%rdx,%rsi,1)
 677:	8d 49 10             	lea    0x10(%rcx),%ecx
 67a:	89 4d dc             	mov    %ecx,-0x24(%rbp)
 67d:	8d 40 10             	lea    0x10(%rax),%eax
 680:	89 45 d8             	mov    %eax,-0x28(%rbp)
 683:	8b 45 e0             	mov    -0x20(%rbp),%eax
 686:	83 e0 08             	and    $0x8,%eax
 689:	85 c0                	test   %eax,%eax
 68b:	0f 84 84 00 00 00    	je     0x715
 691:	8b 45 d8             	mov    -0x28(%rbp),%eax
 694:	8b 4d dc             	mov    -0x24(%rbp),%ecx
 697:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 69b:	89 ce                	mov    %ecx,%esi
 69d:	89 c7                	mov    %eax,%edi
 69f:	0f b6 3c 3a          	movzbl (%rdx,%rdi,1),%edi
 6a3:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
 6a7:	89 ce                	mov    %ecx,%esi
 6a9:	89 c7                	mov    %eax,%edi
 6ab:	0f b6 7c 3a 01       	movzbl 0x1(%rdx,%rdi,1),%edi
 6b0:	40 88 7c 32 01       	mov    %dil,0x1(%rdx,%rsi,1)
 6b5:	89 ce                	mov    %ecx,%esi
 6b7:	89 c7                	mov    %eax,%edi
 6b9:	0f b6 7c 3a 02       	movzbl 0x2(%rdx,%rdi,1),%edi
 6be:	40 88 7c 32 02       	mov    %dil,0x2(%rdx,%rsi,1)
 6c3:	89 ce                	mov    %ecx,%esi
 6c5:	89 c7                	mov    %eax,%edi
 6c7:	0f b6 7c 3a 03       	movzbl 0x3(%rdx,%rdi,1),%edi
 6cc:	40 88 7c 32 03       	mov    %dil,0x3(%rdx,%rsi,1)
 6d1:	89 ce                	mov    %ecx,%esi
 6d3:	89 c7                	mov    %eax,%edi
 6d5:	0f b6 7c 3a 04       	movzbl 0x4(%rdx,%rdi,1),%edi
 6da:	40 88 7c 32 04       	mov    %dil,0x4(%rdx,%rsi,1)
 6df:	89 ce                	mov    %ecx,%esi
 6e1:	89 c7                	mov    %eax,%edi
 6e3:	0f b6 7c 3a 05       	movzbl 0x5(%rdx,%rdi,1),%edi
 6e8:	40 88 7c 32 05       	mov    %dil,0x5(%rdx,%rsi,1)
 6ed:	89 ce                	mov    %ecx,%esi
 6ef:	89 c7                	mov    %eax,%edi
 6f1:	0f b6 7c 3a 06       	movzbl 0x6(%rdx,%rdi,1),%edi
 6f6:	40 88 7c 32 06       	mov    %dil,0x6(%rdx,%rsi,1)
 6fb:	89 ce                	mov    %ecx,%esi
 6fd:	89 c7                	mov    %eax,%edi
 6ff:	0f b6 7c 3a 07       	movzbl 0x7(%rdx,%rdi,1),%edi
 704:	40 88 7c 32 07       	mov    %dil,0x7(%rdx,%rsi,1)
 709:	8d 49 08             	lea    0x8(%rcx),%ecx
 70c:	89 4d dc             	mov    %ecx,-0x24(%rbp)
 70f:	8d 40 08             	lea    0x8(%rax),%eax
 712:	89 45 d8             	mov    %eax,-0x28(%rbp)
 715:	8b 45 e0             	mov    -0x20(%rbp),%eax
 718:	83 e0 04             	and    $0x4,%eax
 71b:	85 c0                	test   %eax,%eax
 71d:	74 4c                	je     0x76b
 71f:	8b 45 d8             	mov    -0x28(%rbp),%eax
 722:	8b 4d dc             	mov    -0x24(%rbp),%ecx
 725:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 729:	89 ce                	mov    %ecx,%esi
 72b:	89 c7                	mov    %eax,%edi
 72d:	0f b6 3c 3a          	movzbl (%rdx,%rdi,1),%edi
 731:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
 735:	89 ce                	mov    %ecx,%esi
 737:	89 c7                	mov    %eax,%edi
 739:	0f b6 7c 3a 01       	movzbl 0x1(%rdx,%rdi,1),%edi
 73e:	40 88 7c 32 01       	mov    %dil,0x1(%rdx,%rsi,1)
 743:	89 ce                	mov    %ecx,%esi
 745:	89 c7                	mov    %eax,%edi
 747:	0f b6 7c 3a 02       	movzbl 0x2(%rdx,%rdi,1),%edi
 74c:	40 88 7c 32 02       	mov    %dil,0x2(%rdx,%rsi,1)
 751:	89 ce                	mov    %ecx,%esi
 753:	89 c7                	mov    %eax,%edi
 755:	0f b6 7c 3a 03       	movzbl 0x3(%rdx,%rdi,1),%edi
 75a:	40 88 7c 32 03       	mov    %dil,0x3(%rdx,%rsi,1)
 75f:	8d 49 04             	lea    0x4(%rcx),%ecx
 762:	89 4d dc             	mov    %ecx,-0x24(%rbp)
 765:	8d 40 04             	lea    0x4(%rax),%eax
 768:	89 45 d8             	mov    %eax,-0x28(%rbp)
 76b:	8b 45 e0             	mov    -0x20(%rbp),%eax
 76e:	83 e0 02             	and    $0x2,%eax
 771:	85 c0                	test   %eax,%eax
 773:	74 30                	je     0x7a5
 775:	8b 45 d8             	mov    -0x28(%rbp),%eax
 778:	8b 4d dc             	mov    -0x24(%rbp),%ecx
 77b:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 77f:	89 ce                	mov    %ecx,%esi
 781:	89 c7                	mov    %eax,%edi
 783:	0f b6 3c 3a          	movzbl (%rdx,%rdi,1),%edi
 787:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
 78b:	89 ce                	mov    %ecx,%esi
 78d:	89 c7                	mov    %eax,%edi
 78f:	0f b6 7c 3a 01       	movzbl 0x1(%rdx,%rdi,1),%edi
 794:	40 88 7c 32 01       	mov    %dil,0x1(%rdx,%rsi,1)
 799:	8d 49 02             	lea    0x2(%rcx),%ecx
 79c:	89 4d dc             	mov    %ecx,-0x24(%rbp)
 79f:	8d 40 02             	lea    0x2(%rax),%eax
 7a2:	89 45 d8             	mov    %eax,-0x28(%rbp)
 7a5:	8b 45 e0             	mov    -0x20(%rbp),%eax
 7a8:	83 e0 01             	and    $0x1,%eax
 7ab:	85 c0                	test   %eax,%eax
 7ad:	74 11                	je     0x7c0
 7af:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
 7b3:	8b 55 d8             	mov    -0x28(%rbp),%edx
 7b6:	8b 4d dc             	mov    -0x24(%rbp),%ecx
 7b9:	0f b6 14 10          	movzbl (%rax,%rdx,1),%edx
 7bd:	88 14 08             	mov    %dl,(%rax,%rcx,1)
 7c0:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 7c3:	89 45 cc             	mov    %eax,-0x34(%rbp)
 7c6:	8b 45 cc             	mov    -0x34(%rbp),%eax
 7c9:	48 83 c4 38          	add    $0x38,%rsp
 7cd:	5d                   	pop    %rbp
 7ce:	c3                   	ret
