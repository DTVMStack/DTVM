
/workspace/DTVM/work/combined-optimization/v2/profiles/syr2k-combined/func-28-0-7fd818a1e000.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	48 83 ec 70          	sub    $0x70,%rsp
   8:	48 89 7d c8          	mov    %rdi,-0x38(%rbp)
   c:	89 75 d0             	mov    %esi,-0x30(%rbp)
   f:	89 55 d4             	mov    %edx,-0x2c(%rbp)
  12:	89 4d d8             	mov    %ecx,-0x28(%rbp)
  15:	31 c0                	xor    %eax,%eax
  17:	31 c0                	xor    %eax,%eax
  19:	89 45 dc             	mov    %eax,-0x24(%rbp)
  1c:	31 c0                	xor    %eax,%eax
  1e:	89 45 e0             	mov    %eax,-0x20(%rbp)
  21:	31 c0                	xor    %eax,%eax
  23:	89 45 e4             	mov    %eax,-0x1c(%rbp)
  26:	31 c0                	xor    %eax,%eax
  28:	89 45 e8             	mov    %eax,-0x18(%rbp)
  2b:	31 c0                	xor    %eax,%eax
  2d:	89 45 ec             	mov    %eax,-0x14(%rbp)
  30:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
  37:	ff 
  38:	48 8b 87 b8 11 00 00 	mov    0x11b8(%rdi),%rax
  3f:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
  43:	8b 44 08 10          	mov    0x10(%rax,%rcx,1),%eax
  47:	89 c1                	mov    %eax,%ecx
  49:	89 4d fc             	mov    %ecx,-0x4(%rbp)
  4c:	85 c0                	test   %eax,%eax
  4e:	75 36                	jne    0x86
  50:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
  54:	8b 75 d8             	mov    -0x28(%rbp),%esi
  57:	31 c0                	xor    %eax,%eax
  59:	89 45 dc             	mov    %eax,-0x24(%rbp)
  5c:	e8 67 20 fe ff       	call   0xfffffffffffe20c8
  61:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
  65:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
  6c:	48 89 4d f0          	mov    %rcx,-0x10(%rbp)
  70:	85 c0                	test   %eax,%eax
  72:	0f 85 62 02 00 00    	jne    0x2da
  78:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  7c:	8b 4d d8             	mov    -0x28(%rbp),%ecx
  7f:	8b 44 08 10          	mov    0x10(%rax,%rcx,1),%eax
  83:	89 45 fc             	mov    %eax,-0x4(%rbp)
  86:	8b 4d d4             	mov    -0x2c(%rbp),%ecx
  89:	48 8b 55 f0          	mov    -0x10(%rbp),%rdx
  8d:	8b 75 d8             	mov    -0x28(%rbp),%esi
  90:	8b 45 fc             	mov    -0x4(%rbp),%eax
  93:	8b 54 32 14          	mov    0x14(%rdx,%rsi,1),%edx
  97:	89 d6                	mov    %edx,%esi
  99:	89 75 e0             	mov    %esi,-0x20(%rbp)
  9c:	29 d0                	sub    %edx,%eax
  9e:	39 c8                	cmp    %ecx,%eax
  a0:	0f 83 a8 00 00 00    	jae    0x14e
  a6:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
  aa:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  ae:	8b 55 d8             	mov    -0x28(%rbp),%edx
  b1:	8b 75 d4             	mov    -0x2c(%rbp),%esi
  b4:	8b 7d d0             	mov    -0x30(%rbp),%edi
  b7:	41 89 d0             	mov    %edx,%r8d
  ba:	44 89 45 b8          	mov    %r8d,-0x48(%rbp)
  be:	89 7d bc             	mov    %edi,-0x44(%rbp)
  c1:	89 75 c0             	mov    %esi,-0x40(%rbp)
  c4:	8b 44 10 20          	mov    0x20(%rax,%rdx,1),%eax
  c8:	89 45 c4             	mov    %eax,-0x3c(%rbp)
  cb:	8b 89 80 11 00 00    	mov    0x1180(%rcx),%ecx
  d1:	39 c8                	cmp    %ecx,%eax
  d3:	0f 83 1a 02 00 00    	jae    0x2f3
  d9:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
  dd:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
  e0:	8b 84 88 90 11 00 00 	mov    0x1190(%rax,%rcx,4),%eax
  e7:	89 45 b4             	mov    %eax,-0x4c(%rbp)
  ea:	83 f8 ff             	cmp    $0xffffffff,%eax
  ed:	0f 84 0a 02 00 00    	je     0x2fd
  f3:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
  f7:	8b 4d b4             	mov    -0x4c(%rbp),%ecx
  fa:	8b 84 88 a8 13 00 00 	mov    0x13a8(%rax,%rcx,4),%eax
 101:	85 c0                	test   %eax,%eax
 103:	0f 85 e0 01 00 00    	jne    0x2e9
 109:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 10d:	8b 4d c0             	mov    -0x40(%rbp),%ecx
 110:	8b 55 bc             	mov    -0x44(%rbp),%edx
 113:	8b 75 b8             	mov    -0x48(%rbp),%esi
 116:	8b 45 b4             	mov    -0x4c(%rbp),%eax
 119:	48 8b 84 c7 d0 11 00 	mov    0x11d0(%rdi,%rax,8),%rax
 120:	00 
 121:	ff d0                	call   *%rax
 123:	89 c1                	mov    %eax,%ecx
 125:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 129:	89 4d b0             	mov    %ecx,-0x50(%rbp)
 12c:	8b 80 84 00 00 00    	mov    0x84(%rax),%eax
 132:	85 c0                	test   %eax,%eax
 134:	0f 85 de 01 00 00    	jne    0x318
 13a:	8b 45 b0             	mov    -0x50(%rbp),%eax
 13d:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 141:	48 8b 89 b8 11 00 00 	mov    0x11b8(%rcx),%rcx
 148:	48 83 c4 70          	add    $0x70,%rsp
 14c:	5d                   	pop    %rbp
 14d:	c3                   	ret
 14e:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 152:	8b 4d d8             	mov    -0x28(%rbp),%ecx
 155:	31 d2                	xor    %edx,%edx
 157:	89 55 e4             	mov    %edx,-0x1c(%rbp)
 15a:	8b 44 08 40          	mov    0x40(%rax,%rcx,1),%eax
 15e:	85 c0                	test   %eax,%eax
 160:	0f 8c 33 01 00 00    	jl     0x299
 166:	8b 45 d0             	mov    -0x30(%rbp),%eax
 169:	31 c9                	xor    %ecx,%ecx
 16b:	89 4d e4             	mov    %ecx,-0x1c(%rbp)
 16e:	89 45 dc             	mov    %eax,-0x24(%rbp)
 171:	31 c0                	xor    %eax,%eax
 173:	89 45 fc             	mov    %eax,-0x4(%rbp)
 176:	8b 4d fc             	mov    -0x4(%rbp),%ecx
 179:	8b 45 d4             	mov    -0x2c(%rbp),%eax
 17c:	39 c8                	cmp    %ecx,%eax
 17e:	0f 84 15 01 00 00    	je     0x299
 184:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 188:	8b 55 dc             	mov    -0x24(%rbp),%edx
 18b:	8b 75 d4             	mov    -0x2c(%rbp),%esi
 18e:	8b 4d fc             	mov    -0x4(%rbp),%ecx
 191:	8d 49 01             	lea    0x1(%rcx),%ecx
 194:	89 4d fc             	mov    %ecx,-0x4(%rbp)
 197:	89 d1                	mov    %edx,%ecx
 199:	01 f1                	add    %esi,%ecx
 19b:	89 4d e8             	mov    %ecx,-0x18(%rbp)
 19e:	8d 52 ff             	lea    -0x1(%rdx),%edx
 1a1:	89 d6                	mov    %edx,%esi
 1a3:	89 75 ec             	mov    %esi,-0x14(%rbp)
 1a6:	89 55 dc             	mov    %edx,-0x24(%rbp)
 1a9:	8d 49 ff             	lea    -0x1(%rcx),%ecx
 1ac:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
 1b0:	83 f8 0a             	cmp    $0xa,%eax
 1b3:	75 c1                	jne    0x176
 1b5:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 1b9:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 1bd:	8b 55 d8             	mov    -0x28(%rbp),%edx
 1c0:	8b 7d fc             	mov    -0x4(%rbp),%edi
 1c3:	8b 75 d4             	mov    -0x2c(%rbp),%esi
 1c6:	44 8b 45 d0          	mov    -0x30(%rbp),%r8d
 1ca:	41 89 d1             	mov    %edx,%r9d
 1cd:	44 89 4d a0          	mov    %r9d,-0x60(%rbp)
 1d1:	44 89 45 a4          	mov    %r8d,-0x5c(%rbp)
 1d5:	29 fe                	sub    %edi,%esi
 1d7:	8d 76 01             	lea    0x1(%rsi),%esi
 1da:	89 75 a8             	mov    %esi,-0x58(%rbp)
 1dd:	89 75 e4             	mov    %esi,-0x1c(%rbp)
 1e0:	8b 44 10 20          	mov    0x20(%rax,%rdx,1),%eax
 1e4:	89 45 ac             	mov    %eax,-0x54(%rbp)
 1e7:	8b 89 80 11 00 00    	mov    0x1180(%rcx),%ecx
 1ed:	39 c8                	cmp    %ecx,%eax
 1ef:	0f 83 fe 00 00 00    	jae    0x2f3
 1f5:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1f9:	8b 4d ac             	mov    -0x54(%rbp),%ecx
 1fc:	8b 84 88 90 11 00 00 	mov    0x1190(%rax,%rcx,4),%eax
 203:	89 45 9c             	mov    %eax,-0x64(%rbp)
 206:	83 f8 ff             	cmp    $0xffffffff,%eax
 209:	0f 84 ee 00 00 00    	je     0x2fd
 20f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 213:	8b 4d 9c             	mov    -0x64(%rbp),%ecx
 216:	8b 84 88 a8 13 00 00 	mov    0x13a8(%rax,%rcx,4),%eax
 21d:	85 c0                	test   %eax,%eax
 21f:	0f 85 c4 00 00 00    	jne    0x2e9
 225:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 229:	8b 4d a8             	mov    -0x58(%rbp),%ecx
 22c:	8b 55 a4             	mov    -0x5c(%rbp),%edx
 22f:	8b 75 a0             	mov    -0x60(%rbp),%esi
 232:	8b 45 9c             	mov    -0x64(%rbp),%eax
 235:	48 8b 84 c7 d0 11 00 	mov    0x11d0(%rdi,%rax,8),%rax
 23c:	00 
 23d:	ff d0                	call   *%rax
 23f:	89 c1                	mov    %eax,%ecx
 241:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 245:	89 4d 98             	mov    %ecx,-0x68(%rbp)
 248:	8b 80 84 00 00 00    	mov    0x84(%rax),%eax
 24e:	85 c0                	test   %eax,%eax
 250:	0f 85 c2 00 00 00    	jne    0x318
 256:	8b 45 98             	mov    -0x68(%rbp),%eax
 259:	8b 4d e4             	mov    -0x1c(%rbp),%ecx
 25c:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 260:	48 8b 92 b8 11 00 00 	mov    0x11b8(%rdx),%rdx
 267:	48 89 55 f0          	mov    %rdx,-0x10(%rbp)
 26b:	89 c2                	mov    %eax,%edx
 26d:	89 55 dc             	mov    %edx,-0x24(%rbp)
 270:	39 c8                	cmp    %ecx,%eax
 272:	72 66                	jb     0x2da
 274:	8b 7d d4             	mov    -0x2c(%rbp),%edi
 277:	8b 45 fc             	mov    -0x4(%rbp),%eax
 27a:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 27e:	8b 55 d8             	mov    -0x28(%rbp),%edx
 281:	8b 75 ec             	mov    -0x14(%rbp),%esi
 284:	01 fe                	add    %edi,%esi
 286:	8d 76 01             	lea    0x1(%rsi),%esi
 289:	89 75 d0             	mov    %esi,-0x30(%rbp)
 28c:	8b 4c 11 14          	mov    0x14(%rcx,%rdx,1),%ecx
 290:	89 4d e0             	mov    %ecx,-0x20(%rbp)
 293:	8d 40 ff             	lea    -0x1(%rax),%eax
 296:	89 45 d4             	mov    %eax,-0x2c(%rbp)
 299:	8b 4d d4             	mov    -0x2c(%rbp),%ecx
 29c:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 2a0:	8b 55 d0             	mov    -0x30(%rbp),%edx
 2a3:	8b 75 e0             	mov    -0x20(%rbp),%esi
 2a6:	e8 03 1f fe ff       	call   0xfffffffffffe21ae
 2ab:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 2af:	8b 7d d8             	mov    -0x28(%rbp),%edi
 2b2:	8b 4d d4             	mov    -0x2c(%rbp),%ecx
 2b5:	89 c6                	mov    %eax,%esi
 2b7:	8b 45 e4             	mov    -0x1c(%rbp),%eax
 2ba:	48 8b 92 b8 11 00 00 	mov    0x11b8(%rdx),%rdx
 2c1:	48 89 55 f0          	mov    %rdx,-0x10(%rbp)
 2c5:	89 fe                	mov    %edi,%esi
 2c7:	8b 7c 3a 14          	mov    0x14(%rdx,%rdi,1),%edi
 2cb:	41 89 c8             	mov    %ecx,%r8d
 2ce:	44 01 c7             	add    %r8d,%edi
 2d1:	89 7c 32 14          	mov    %edi,0x14(%rdx,%rsi,1)
 2d5:	01 c8                	add    %ecx,%eax
 2d7:	89 45 dc             	mov    %eax,-0x24(%rbp)
 2da:	8b 45 dc             	mov    -0x24(%rbp),%eax
 2dd:	89 45 94             	mov    %eax,-0x6c(%rbp)
 2e0:	8b 45 94             	mov    -0x6c(%rbp),%eax
 2e3:	48 83 c4 70          	add    $0x70,%rsp
 2e7:	5d                   	pop    %rbp
 2e8:	c3                   	ret
 2e9:	b8 6f 00 00 00       	mov    $0x6f,%eax
 2ee:	89 45 90             	mov    %eax,-0x70(%rbp)
 2f1:	eb 12                	jmp    0x305
 2f3:	b8 70 00 00 00       	mov    $0x70,%eax
 2f8:	89 45 90             	mov    %eax,-0x70(%rbp)
 2fb:	eb 08                	jmp    0x305
 2fd:	b8 72 00 00 00       	mov    $0x72,%eax
 302:	89 45 90             	mov    %eax,-0x70(%rbp)
 305:	8b 75 90             	mov    -0x70(%rbp),%esi
 308:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 30c:	48 b8 b0 34 c5 4d a6 	movabs $0x55a64dc534b0,%rax
 313:	55 00 00 
 316:	ff d0                	call   *%rax
 318:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 31c:	48 b8 10 35 c5 4d a6 	movabs $0x55a64dc53510,%rax
 323:	55 00 00 
 326:	ff d0                	call   *%rax
 328:	31 c0                	xor    %eax,%eax
 32a:	48 83 c4 70          	add    $0x70,%rsp
 32e:	5d                   	pop    %rbp
 32f:	c3                   	ret
