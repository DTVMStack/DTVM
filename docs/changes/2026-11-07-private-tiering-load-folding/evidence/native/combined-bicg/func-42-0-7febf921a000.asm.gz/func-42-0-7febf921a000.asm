
/workspace/DTVM/work/combined-optimization/v2/profiles/bicg-repeat30-main/func-42-0-7febf921a000.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	55                   	push   %rbp
       1:	48 89 e5             	mov    %rsp,%rbp
       4:	48 81 ec a0 01 00 00 	sub    $0x1a0,%rsp
       b:	48 89 bd d8 fe ff ff 	mov    %rdi,-0x128(%rbp)
      12:	89 b5 e4 fe ff ff    	mov    %esi,-0x11c(%rbp)
      18:	89 d0                	mov    %edx,%eax
      1a:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
      20:	89 8d ec fe ff ff    	mov    %ecx,-0x114(%rbp)
      26:	44 89 85 f0 fe ff ff 	mov    %r8d,-0x110(%rbp)
      2d:	44 89 8d f4 fe ff ff 	mov    %r9d,-0x10c(%rbp)
      34:	48 b8 00 00 00 00 00 	movabs $0x7ff0000000000000,%rax
      3b:	00 f0 7f 
      3e:	66 48 0f 6e c0       	movq   %rax,%xmm0
      43:	f2 0f 11 85 f8 fe ff 	movsd  %xmm0,-0x108(%rbp)
      4a:	ff 
      4b:	48 b8 00 00 00 00 00 	movabs $0x41b0000000000000,%rax
      52:	00 b0 41 
      55:	66 48 0f 6e c0       	movq   %rax,%xmm0
      5a:	f2 0f 11 85 00 ff ff 	movsd  %xmm0,-0x100(%rbp)
      61:	ff 
      62:	48 b8 00 00 00 00 00 	movabs $0x41f0000000000000,%rax
      69:	00 f0 41 
      6c:	66 48 0f 6e c0       	movq   %rax,%xmm0
      71:	f2 0f 11 85 08 ff ff 	movsd  %xmm0,-0xf8(%rbp)
      78:	ff 
      79:	48 b8 00 00 00 00 65 	movabs $0x41cdcd6500000000,%rax
      80:	cd cd 41 
      83:	66 48 0f 6e c0       	movq   %rax,%xmm0
      88:	f2 0f 11 85 10 ff ff 	movsd  %xmm0,-0xf0(%rbp)
      8f:	ff 
      90:	48 b8 00 00 00 00 00 	movabs $0x4340000000000000,%rax
      97:	00 40 43 
      9a:	66 48 0f 6e c0       	movq   %rax,%xmm0
      9f:	f2 0f 11 85 18 ff ff 	movsd  %xmm0,-0xe8(%rbp)
      a6:	ff 
      a7:	48 b8 01 00 00 00 00 	movabs $0x4340000000000001,%rax
      ae:	00 40 43 
      b1:	66 48 0f 6e c0       	movq   %rax,%xmm0
      b6:	f2 0f 11 85 20 ff ff 	movsd  %xmm0,-0xe0(%rbp)
      bd:	ff 
      be:	48 b8 00 00 00 00 00 	movabs $0x3fe0000000000000,%rax
      c5:	00 e0 3f 
      c8:	66 48 0f 6e c0       	movq   %rax,%xmm0
      cd:	f2 0f 11 85 28 ff ff 	movsd  %xmm0,-0xd8(%rbp)
      d4:	ff 
      d5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
      dc:	00 f0 3f 
      df:	66 48 0f 6e c0       	movq   %rax,%xmm0
      e4:	f2 0f 11 85 30 ff ff 	movsd  %xmm0,-0xd0(%rbp)
      eb:	ff 
      ec:	48 b8 00 00 00 00 00 	movabs $0x3ff8000000000000,%rax
      f3:	00 f8 3f 
      f6:	66 48 0f 6e c0       	movq   %rax,%xmm0
      fb:	f2 0f 11 85 38 ff ff 	movsd  %xmm0,-0xc8(%rbp)
     102:	ff 
     103:	48 b8 00 00 00 00 00 	movabs $0x4030000000000000,%rax
     10a:	00 30 40 
     10d:	66 48 0f 6e c0       	movq   %rax,%xmm0
     112:	f2 0f 11 85 40 ff ff 	movsd  %xmm0,-0xc0(%rbp)
     119:	ff 
     11a:	48 b8 00 00 00 00 00 	movabs $0x41e0000000000000,%rax
     121:	00 e0 41 
     124:	66 48 0f 6e c0       	movq   %rax,%xmm0
     129:	f2 0f 11 85 48 ff ff 	movsd  %xmm0,-0xb8(%rbp)
     130:	ff 
     131:	31 c0                	xor    %eax,%eax
     133:	31 c0                	xor    %eax,%eax
     135:	31 c0                	xor    %eax,%eax
     137:	31 c0                	xor    %eax,%eax
     139:	31 c0                	xor    %eax,%eax
     13b:	31 c0                	xor    %eax,%eax
     13d:	31 c0                	xor    %eax,%eax
     13f:	31 c0                	xor    %eax,%eax
     141:	31 c0                	xor    %eax,%eax
     143:	31 c0                	xor    %eax,%eax
     145:	31 c0                	xor    %eax,%eax
     147:	31 c0                	xor    %eax,%eax
     149:	31 c0                	xor    %eax,%eax
     14b:	31 c0                	xor    %eax,%eax
     14d:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
     153:	31 c0                	xor    %eax,%eax
     155:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
     15b:	31 c0                	xor    %eax,%eax
     15d:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
     163:	31 c0                	xor    %eax,%eax
     165:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
     16b:	31 c0                	xor    %eax,%eax
     16d:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
     173:	31 c0                	xor    %eax,%eax
     175:	89 85 68 ff ff ff    	mov    %eax,-0x98(%rbp)
     17b:	31 c0                	xor    %eax,%eax
     17d:	89 85 6c ff ff ff    	mov    %eax,-0x94(%rbp)
     183:	31 c0                	xor    %eax,%eax
     185:	89 85 70 ff ff ff    	mov    %eax,-0x90(%rbp)
     18b:	31 c0                	xor    %eax,%eax
     18d:	89 85 74 ff ff ff    	mov    %eax,-0x8c(%rbp)
     193:	31 c0                	xor    %eax,%eax
     195:	89 85 78 ff ff ff    	mov    %eax,-0x88(%rbp)
     19b:	31 c0                	xor    %eax,%eax
     19d:	89 85 7c ff ff ff    	mov    %eax,-0x84(%rbp)
     1a3:	31 c0                	xor    %eax,%eax
     1a5:	89 45 80             	mov    %eax,-0x80(%rbp)
     1a8:	31 c0                	xor    %eax,%eax
     1aa:	89 45 84             	mov    %eax,-0x7c(%rbp)
     1ad:	31 c0                	xor    %eax,%eax
     1af:	89 45 88             	mov    %eax,-0x78(%rbp)
     1b2:	31 c0                	xor    %eax,%eax
     1b4:	89 45 8c             	mov    %eax,-0x74(%rbp)
     1b7:	31 c0                	xor    %eax,%eax
     1b9:	89 45 90             	mov    %eax,-0x70(%rbp)
     1bc:	31 c0                	xor    %eax,%eax
     1be:	89 45 94             	mov    %eax,-0x6c(%rbp)
     1c1:	31 c0                	xor    %eax,%eax
     1c3:	89 45 98             	mov    %eax,-0x68(%rbp)
     1c6:	31 c0                	xor    %eax,%eax
     1c8:	89 45 9c             	mov    %eax,-0x64(%rbp)
     1cb:	31 c0                	xor    %eax,%eax
     1cd:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
     1d1:	31 c0                	xor    %eax,%eax
     1d3:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
     1d7:	0f 57 c0             	xorps  %xmm0,%xmm0
     1da:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
     1df:	0f 57 c0             	xorps  %xmm0,%xmm0
     1e2:	f2 0f 11 45 b8       	movsd  %xmm0,-0x48(%rbp)
     1e7:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
     1ee:	ff 
     1ef:	48 8b 87 90 12 00 00 	mov    0x1290(%rdi),%rax
     1f6:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     1fa:	8b 8f 50 12 00 00    	mov    0x1250(%rdi),%ecx
     200:	89 c8                	mov    %ecx,%eax
     202:	8d 80 90 fc ff ff    	lea    -0x370(%rax),%eax
     208:	89 45 cc             	mov    %eax,-0x34(%rbp)
     20b:	8d 89 90 fc ff ff    	lea    -0x370(%rcx),%ecx
     211:	89 8f 50 12 00 00    	mov    %ecx,0x1250(%rdi)
     217:	89 c1                	mov    %eax,%ecx
     219:	8d 49 37             	lea    0x37(%rcx),%ecx
     21c:	89 4d d0             	mov    %ecx,-0x30(%rbp)
     21f:	89 c2                	mov    %eax,%edx
     221:	b9 fe ff ff ff       	mov    $0xfffffffe,%ecx
     226:	8d 92 50 01 00 00    	lea    0x150(%rdx),%edx
     22c:	29 d1                	sub    %edx,%ecx
     22e:	89 4d d4             	mov    %ecx,-0x2c(%rbp)
     231:	89 c1                	mov    %eax,%ecx
     233:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
     239:	83 c9 09             	or     $0x9,%ecx
     23c:	89 4d d8             	mov    %ecx,-0x28(%rbp)
     23f:	89 c1                	mov    %eax,%ecx
     241:	8d 89 94 02 00 00    	lea    0x294(%rcx),%ecx
     247:	89 4d dc             	mov    %ecx,-0x24(%rbp)
     24a:	89 c1                	mov    %eax,%ecx
     24c:	8d 89 70 01 00 00    	lea    0x170(%rcx),%ecx
     252:	83 c9 04             	or     $0x4,%ecx
     255:	89 4d e0             	mov    %ecx,-0x20(%rbp)
     258:	89 c1                	mov    %eax,%ecx
     25a:	8d 89 90 02 00 00    	lea    0x290(%rcx),%ecx
     260:	89 4d e4             	mov    %ecx,-0x1c(%rbp)
     263:	89 c1                	mov    %eax,%ecx
     265:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
     26b:	89 4d e8             	mov    %ecx,-0x18(%rbp)
     26e:	89 c2                	mov    %eax,%edx
     270:	31 c9                	xor    %ecx,%ecx
     272:	8d 92 50 01 00 00    	lea    0x150(%rdx),%edx
     278:	29 d1                	sub    %edx,%ecx
     27a:	89 4d ec             	mov    %ecx,-0x14(%rbp)
     27d:	8d 40 38             	lea    0x38(%rax),%eax
     280:	89 45 f0             	mov    %eax,-0x10(%rbp)
     283:	31 c0                	xor    %eax,%eax
     285:	89 45 f4             	mov    %eax,-0xc(%rbp)
     288:	31 c0                	xor    %eax,%eax
     28a:	89 45 f8             	mov    %eax,-0x8(%rbp)
     28d:	31 c0                	xor    %eax,%eax
     28f:	89 45 fc             	mov    %eax,-0x4(%rbp)
     292:	8b 55 f8             	mov    -0x8(%rbp),%edx
     295:	8b 45 fc             	mov    -0x4(%rbp),%eax
     298:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     29e:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
     2a4:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
     2a9:	29 d1                	sub    %edx,%ecx
     2ab:	39 c8                	cmp    %ecx,%eax
     2ad:	0f 8f 6b 4b 00 00    	jg     0x4e1e
     2b3:	8b 55 fc             	mov    -0x4(%rbp),%edx
     2b6:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     2ba:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
     2c0:	8b 75 f8             	mov    -0x8(%rbp),%esi
     2c3:	01 f2                	add    %esi,%edx
     2c5:	89 55 f8             	mov    %edx,-0x8(%rbp)
     2c8:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
     2cc:	89 c1                	mov    %eax,%ecx
     2ce:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     2d1:	85 c0                	test   %eax,%eax
     2d3:	0f 84 e4 04 00 00    	je     0x7bd
     2d9:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
     2df:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     2e5:	8b 45 fc             	mov    -0x4(%rbp),%eax
     2e8:	25 ff 00 00 00       	and    $0xff,%eax
     2ed:	89 c1                	mov    %eax,%ecx
     2ef:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     2f2:	85 c0                	test   %eax,%eax
     2f4:	74 73                	je     0x369
     2f6:	8b 45 fc             	mov    -0x4(%rbp),%eax
     2f9:	83 f8 25             	cmp    $0x25,%eax
     2fc:	0f 85 99 04 00 00    	jne    0x79b
     302:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     308:	89 c1                	mov    %eax,%ecx
     30a:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
     310:	89 45 fc             	mov    %eax,-0x4(%rbp)
     313:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     317:	8b 4d fc             	mov    -0x4(%rbp),%ecx
     31a:	8d 49 01             	lea    0x1(%rcx),%ecx
     31d:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
     321:	83 f8 25             	cmp    $0x25,%eax
     324:	74 0b                	je     0x331
     326:	8b 45 fc             	mov    -0x4(%rbp),%eax
     329:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     32f:	eb 44                	jmp    0x375
     331:	8b 4d fc             	mov    -0x4(%rbp),%ecx
     334:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     338:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
     33e:	8d 52 01             	lea    0x1(%rdx),%edx
     341:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
     347:	89 ca                	mov    %ecx,%edx
     349:	0f b6 44 10 02       	movzbl 0x2(%rax,%rdx,1),%eax
     34e:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
     354:	8d 49 02             	lea    0x2(%rcx),%ecx
     357:	89 ca                	mov    %ecx,%edx
     359:	89 95 e8 fe ff ff    	mov    %edx,-0x118(%rbp)
     35f:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     362:	83 f8 25             	cmp    $0x25,%eax
     365:	74 ac                	je     0x313
     367:	eb 0c                	jmp    0x375
     369:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     36f:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
     375:	8b 55 f8             	mov    -0x8(%rbp),%edx
     378:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
     37e:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
     384:	29 c8                	sub    %ecx,%eax
     386:	89 c1                	mov    %eax,%ecx
     388:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     38b:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
     390:	29 d1                	sub    %edx,%ecx
     392:	89 ca                	mov    %ecx,%edx
     394:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
     39a:	39 c8                	cmp    %ecx,%eax
     39c:	0f 8f 7c 4a 00 00    	jg     0x4e1e
     3a2:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     3a8:	85 c0                	test   %eax,%eax
     3aa:	74 44                	je     0x3f0
     3ac:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     3b0:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
     3b6:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
     3ba:	83 e0 20             	and    $0x20,%eax
     3bd:	85 c0                	test   %eax,%eax
     3bf:	75 2f                	jne    0x3f0
     3c1:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     3c8:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
     3ce:	8b 55 fc             	mov    -0x4(%rbp),%edx
     3d1:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
     3d7:	e8 f6 5c fe ff       	call   0xfffffffffffe60d2
     3dc:	89 c1                	mov    %eax,%ecx
     3de:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     3e5:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     3ec:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     3f0:	8b 45 fc             	mov    -0x4(%rbp),%eax
     3f3:	85 c0                	test   %eax,%eax
     3f5:	0f 85 97 fe ff ff    	jne    0x292
     3fb:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     3ff:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     405:	89 ca                	mov    %ecx,%edx
     407:	8d 52 01             	lea    0x1(%rdx),%edx
     40a:	89 55 fc             	mov    %edx,-0x4(%rbp)
     40d:	0f be 44 08 01       	movsbl 0x1(%rax,%rcx,1),%eax
     412:	89 c1                	mov    %eax,%ecx
     414:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
     41a:	8d 40 d0             	lea    -0x30(%rax),%eax
     41d:	89 c1                	mov    %eax,%ecx
     41f:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
     425:	83 f8 09             	cmp    $0x9,%eax
     428:	76 10                	jbe    0x43a
     42a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     42f:	89 85 68 ff ff ff    	mov    %eax,-0x98(%rbp)
     435:	e9 84 00 00 00       	jmp    0x4be
     43a:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     43e:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     444:	8b 55 f4             	mov    -0xc(%rbp),%edx
     447:	44 8b 85 64 ff ff ff 	mov    -0x9c(%rbp),%r8d
     44e:	8b 75 fc             	mov    -0x4(%rbp),%esi
     451:	41 89 c9             	mov    %ecx,%r9d
     454:	89 cf                	mov    %ecx,%edi
     456:	44 0f b6 54 38 02    	movzbl 0x2(%rax,%rdi,1),%r10d
     45c:	41 83 fa 24          	cmp    $0x24,%r10d
     460:	40 0f 94 c7          	sete   %dil
     464:	40 0f b6 ff          	movzbl %dil,%edi
     468:	89 bd 58 ff ff ff    	mov    %edi,-0xa8(%rbp)
     46e:	45 8d 49 03          	lea    0x3(%r9),%r9d
     472:	41 83 fa 24          	cmp    $0x24,%r10d
     476:	41 0f 44 f1          	cmove  %r9d,%esi
     47a:	89 75 fc             	mov    %esi,-0x4(%rbp)
     47d:	41 89 f9             	mov    %edi,%r9d
     480:	be ff ff ff ff       	mov    $0xffffffff,%esi
     485:	45 85 c9             	test   %r9d,%r9d
     488:	41 0f 45 f0          	cmovne %r8d,%esi
     48c:	89 b5 68 ff ff ff    	mov    %esi,-0x98(%rbp)
     492:	41 89 f8             	mov    %edi,%r8d
     495:	be 01 00 00 00       	mov    $0x1,%esi
     49a:	45 85 c0             	test   %r8d,%r8d
     49d:	0f 45 d6             	cmovne %esi,%edx
     4a0:	89 55 f4             	mov    %edx,-0xc(%rbp)
     4a3:	be 03 00 00 00       	mov    $0x3,%esi
     4a8:	ba 01 00 00 00       	mov    $0x1,%edx
     4ad:	85 ff                	test   %edi,%edi
     4af:	0f 45 d6             	cmovne %esi,%edx
     4b2:	01 d1                	add    %edx,%ecx
     4b4:	0f be 04 08          	movsbl (%rax,%rcx,1),%eax
     4b8:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
     4be:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
     4c4:	31 c9                	xor    %ecx,%ecx
     4c6:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
     4cc:	8d 40 e0             	lea    -0x20(%rax),%eax
     4cf:	89 c1                	mov    %eax,%ecx
     4d1:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     4d7:	83 f8 1f             	cmp    $0x1f,%eax
     4da:	76 0e                	jbe    0x4ea
     4dc:	8b 45 fc             	mov    -0x4(%rbp),%eax
     4df:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     4e5:	e9 9b 00 00 00       	jmp    0x585
     4ea:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     4f0:	b8 01 00 00 00       	mov    $0x1,%eax
     4f5:	d3 e0                	shl    %cl,%eax
     4f7:	89 c1                	mov    %eax,%ecx
     4f9:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
     4ff:	25 89 28 01 00       	and    $0x12889,%eax
     504:	85 c0                	test   %eax,%eax
     506:	75 0b                	jne    0x513
     508:	8b 45 fc             	mov    -0x4(%rbp),%eax
     50b:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     511:	eb 72                	jmp    0x585
     513:	31 c0                	xor    %eax,%eax
     515:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
     51b:	8b 95 64 ff ff ff    	mov    -0x9c(%rbp),%edx
     521:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     525:	8b 4d fc             	mov    -0x4(%rbp),%ecx
     528:	8b b5 58 ff ff ff    	mov    -0xa8(%rbp),%esi
     52e:	89 cf                	mov    %ecx,%edi
     530:	8d 7f 01             	lea    0x1(%rdi),%edi
     533:	89 bd e8 fe ff ff    	mov    %edi,-0x118(%rbp)
     539:	09 f2                	or     %esi,%edx
     53b:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
     541:	0f be 44 08 01       	movsbl 0x1(%rax,%rcx,1),%eax
     546:	89 c1                	mov    %eax,%ecx
     548:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
     54e:	8d 40 e0             	lea    -0x20(%rax),%eax
     551:	89 c1                	mov    %eax,%ecx
     553:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
     559:	83 f8 1f             	cmp    $0x1f,%eax
     55c:	77 27                	ja     0x585
     55e:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
     564:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     56a:	89 45 fc             	mov    %eax,-0x4(%rbp)
     56d:	b8 01 00 00 00       	mov    $0x1,%eax
     572:	d3 e0                	shl    %cl,%eax
     574:	89 c1                	mov    %eax,%ecx
     576:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
     57c:	25 89 28 01 00       	and    $0x12889,%eax
     581:	85 c0                	test   %eax,%eax
     583:	75 96                	jne    0x51b
     585:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
     58b:	83 f8 2a             	cmp    $0x2a,%eax
     58e:	0f 85 1a 01 00 00    	jne    0x6ae
     594:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     598:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     59e:	0f be 44 08 01       	movsbl 0x1(%rax,%rcx,1),%eax
     5a3:	8d 40 d0             	lea    -0x30(%rax),%eax
     5a6:	89 c1                	mov    %eax,%ecx
     5a8:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     5ab:	83 f8 09             	cmp    $0x9,%eax
     5ae:	77 68                	ja     0x618
     5b0:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     5b4:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     5ba:	0f b6 44 08 02       	movzbl 0x2(%rax,%rcx,1),%eax
     5bf:	83 f8 24             	cmp    $0x24,%eax
     5c2:	75 54                	jne    0x618
     5c4:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     5c8:	8b 95 f0 fe ff ff    	mov    -0x110(%rbp),%edx
     5ce:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     5d4:	8b 7d fc             	mov    -0x4(%rbp),%edi
     5d7:	8b b5 f4 fe ff ff    	mov    -0x10c(%rbp),%esi
     5dd:	c1 e7 02             	shl    $0x2,%edi
     5e0:	01 fe                	add    %edi,%esi
     5e2:	bf 0a 00 00 00       	mov    $0xa,%edi
     5e7:	89 3c 30             	mov    %edi,(%rax,%rsi,1)
     5ea:	89 ce                	mov    %ecx,%esi
     5ec:	8d 76 03             	lea    0x3(%rsi),%esi
     5ef:	89 b5 64 ff ff ff    	mov    %esi,-0x9c(%rbp)
     5f5:	0f be 4c 08 01       	movsbl 0x1(%rax,%rcx,1),%ecx
     5fa:	c1 e1 03             	shl    $0x3,%ecx
     5fd:	01 d1                	add    %edx,%ecx
     5ff:	8d 89 80 fe ff ff    	lea    -0x180(%rcx),%ecx
     605:	8b 04 08             	mov    (%rax,%rcx,1),%eax
     608:	89 85 6c ff ff ff    	mov    %eax,-0x94(%rbp)
     60e:	b8 01 00 00 00       	mov    $0x1,%eax
     613:	89 45 f4             	mov    %eax,-0xc(%rbp)
     616:	eb 61                	jmp    0x679
     618:	8b 45 f4             	mov    -0xc(%rbp),%eax
     61b:	85 c0                	test   %eax,%eax
     61d:	0f 85 e0 07 00 00    	jne    0xe03
     623:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     629:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     62f:	8d 49 01             	lea    0x1(%rcx),%ecx
     632:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
     638:	85 c0                	test   %eax,%eax
     63a:	75 12                	jne    0x64e
     63c:	31 c0                	xor    %eax,%eax
     63e:	89 45 f4             	mov    %eax,-0xc(%rbp)
     641:	31 c0                	xor    %eax,%eax
     643:	89 85 6c ff ff ff    	mov    %eax,-0x94(%rbp)
     649:	e9 0c 05 00 00       	jmp    0xb5a
     64e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     652:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     658:	89 ca                	mov    %ecx,%edx
     65a:	8b 34 08             	mov    (%rax,%rcx,1),%esi
     65d:	89 f1                	mov    %esi,%ecx
     65f:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     665:	8d 76 04             	lea    0x4(%rsi),%esi
     668:	89 34 10             	mov    %esi,(%rax,%rdx,1)
     66b:	8b 04 08             	mov    (%rax,%rcx,1),%eax
     66e:	89 85 6c ff ff ff    	mov    %eax,-0x94(%rbp)
     674:	31 c0                	xor    %eax,%eax
     676:	89 45 f4             	mov    %eax,-0xc(%rbp)
     679:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
     67f:	83 f8 ff             	cmp    $0xffffffff,%eax
     682:	0f 8f d2 04 00 00    	jg     0xb5a
     688:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
     68e:	8b 95 6c ff ff ff    	mov    -0x94(%rbp),%edx
     694:	31 c9                	xor    %ecx,%ecx
     696:	29 d1                	sub    %edx,%ecx
     698:	89 8d 6c ff ff ff    	mov    %ecx,-0x94(%rbp)
     69e:	0d 00 20 00 00       	or     $0x2000,%eax
     6a3:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
     6a9:	e9 ac 04 00 00       	jmp    0xb5a
     6ae:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
     6b4:	31 c9                	xor    %ecx,%ecx
     6b6:	89 8d 6c ff ff ff    	mov    %ecx,-0x94(%rbp)
     6bc:	8d 40 d0             	lea    -0x30(%rax),%eax
     6bf:	89 c1                	mov    %eax,%ecx
     6c1:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     6c4:	83 f8 09             	cmp    $0x9,%eax
     6c7:	76 11                	jbe    0x6da
     6c9:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     6cf:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
     6d5:	e9 80 04 00 00       	jmp    0xb5a
     6da:	31 c0                	xor    %eax,%eax
     6dc:	89 85 6c ff ff ff    	mov    %eax,-0x94(%rbp)
     6e2:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
     6e8:	3d cc cc cc 0c       	cmp    $0xccccccc,%eax
     6ed:	77 71                	ja     0x760
     6ef:	8b 7d fc             	mov    -0x4(%rbp),%edi
     6f2:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     6f8:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     6fc:	8b 95 6c ff ff ff    	mov    -0x94(%rbp),%edx
     702:	6b d2 0a             	imul   $0xa,%edx,%edx
     705:	41 89 d1             	mov    %edx,%r9d
     708:	41 89 f8             	mov    %edi,%r8d
     70b:	be ff ff ff ff       	mov    $0xffffffff,%esi
     710:	44 01 c2             	add    %r8d,%edx
     713:	41 b8 ff ff ff 7f    	mov    $0x7fffffff,%r8d
     719:	45 29 c8             	sub    %r9d,%r8d
     71c:	44 39 c7             	cmp    %r8d,%edi
     71f:	0f 4f d6             	cmovg  %esi,%edx
     722:	89 95 6c ff ff ff    	mov    %edx,-0x94(%rbp)
     728:	89 ca                	mov    %ecx,%edx
     72a:	0f be 44 10 01       	movsbl 0x1(%rax,%rdx,1),%eax
     72f:	8d 49 01             	lea    0x1(%rcx),%ecx
     732:	89 ca                	mov    %ecx,%edx
     734:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
     73a:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     740:	8d 40 d0             	lea    -0x30(%rax),%eax
     743:	89 c1                	mov    %eax,%ecx
     745:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     748:	83 f8 0a             	cmp    $0xa,%eax
     74b:	72 95                	jb     0x6e2
     74d:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
     753:	85 c0                	test   %eax,%eax
     755:	0f 8c c3 46 00 00    	jl     0x4e1e
     75b:	e9 fa 03 00 00       	jmp    0xb5a
     760:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     766:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     76a:	89 ca                	mov    %ecx,%edx
     76c:	0f be 44 10 01       	movsbl 0x1(%rax,%rdx,1),%eax
     771:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     776:	89 95 6c ff ff ff    	mov    %edx,-0x94(%rbp)
     77c:	8d 49 01             	lea    0x1(%rcx),%ecx
     77f:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     785:	8d 40 d0             	lea    -0x30(%rax),%eax
     788:	89 c1                	mov    %eax,%ecx
     78a:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     78d:	83 f8 0a             	cmp    $0xa,%eax
     790:	0f 82 4c ff ff ff    	jb     0x6e2
     796:	e9 83 46 00 00       	jmp    0x4e1e
     79b:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     7a1:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
     7a5:	89 c2                	mov    %eax,%edx
     7a7:	0f b6 4c 11 01       	movzbl 0x1(%rcx,%rdx,1),%ecx
     7ac:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     7af:	8d 40 01             	lea    0x1(%rax),%eax
     7b2:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     7b8:	e9 28 fb ff ff       	jmp    0x2e5
     7bd:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     7c3:	85 c0                	test   %eax,%eax
     7c5:	0f 85 6a 46 00 00    	jne    0x4e35
     7cb:	8b 45 f4             	mov    -0xc(%rbp),%eax
     7ce:	85 c0                	test   %eax,%eax
     7d0:	75 0a                	jne    0x7dc
     7d2:	31 c0                	xor    %eax,%eax
     7d4:	89 45 f8             	mov    %eax,-0x8(%rbp)
     7d7:	e9 59 46 00 00       	jmp    0x4e35
     7dc:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     7e0:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     7e6:	8b 44 08 04          	mov    0x4(%rax,%rcx,1),%eax
     7ea:	89 c1                	mov    %eax,%ecx
     7ec:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     7f2:	85 c0                	test   %eax,%eax
     7f4:	75 10                	jne    0x806
     7f6:	b8 01 00 00 00       	mov    $0x1,%eax
     7fb:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     801:	e9 05 03 00 00       	jmp    0xb0b
     806:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     80c:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     813:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     819:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     81f:	8d 70 08             	lea    0x8(%rax),%esi
     822:	e8 37 59 fe ff       	call   0xfffffffffffe615e
     827:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     82e:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     834:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     83b:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     83f:	8b 44 08 08          	mov    0x8(%rax,%rcx,1),%eax
     843:	89 c1                	mov    %eax,%ecx
     845:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     84b:	85 c0                	test   %eax,%eax
     84d:	75 10                	jne    0x85f
     84f:	b8 02 00 00 00       	mov    $0x2,%eax
     854:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     85a:	e9 ac 02 00 00       	jmp    0xb0b
     85f:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     865:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     86c:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     872:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     878:	8d 70 10             	lea    0x10(%rax),%esi
     87b:	e8 de 58 fe ff       	call   0xfffffffffffe615e
     880:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     887:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     88d:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     894:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     898:	8b 44 08 0c          	mov    0xc(%rax,%rcx,1),%eax
     89c:	89 c1                	mov    %eax,%ecx
     89e:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     8a4:	85 c0                	test   %eax,%eax
     8a6:	75 10                	jne    0x8b8
     8a8:	b8 03 00 00 00       	mov    $0x3,%eax
     8ad:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     8b3:	e9 53 02 00 00       	jmp    0xb0b
     8b8:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     8be:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     8c5:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     8cb:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     8d1:	8d 70 18             	lea    0x18(%rax),%esi
     8d4:	e8 85 58 fe ff       	call   0xfffffffffffe615e
     8d9:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     8e0:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     8e6:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     8ed:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     8f1:	8b 44 08 10          	mov    0x10(%rax,%rcx,1),%eax
     8f5:	89 c1                	mov    %eax,%ecx
     8f7:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     8fd:	85 c0                	test   %eax,%eax
     8ff:	75 10                	jne    0x911
     901:	b8 04 00 00 00       	mov    $0x4,%eax
     906:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     90c:	e9 fa 01 00 00       	jmp    0xb0b
     911:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     917:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     91e:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     924:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     92a:	8d 70 20             	lea    0x20(%rax),%esi
     92d:	e8 2c 58 fe ff       	call   0xfffffffffffe615e
     932:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     939:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     93f:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     946:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     94a:	8b 44 08 14          	mov    0x14(%rax,%rcx,1),%eax
     94e:	89 c1                	mov    %eax,%ecx
     950:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     956:	85 c0                	test   %eax,%eax
     958:	75 10                	jne    0x96a
     95a:	b8 05 00 00 00       	mov    $0x5,%eax
     95f:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     965:	e9 a1 01 00 00       	jmp    0xb0b
     96a:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     970:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     977:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     97d:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     983:	8d 70 28             	lea    0x28(%rax),%esi
     986:	e8 d3 57 fe ff       	call   0xfffffffffffe615e
     98b:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     992:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     998:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     99f:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     9a3:	8b 44 08 18          	mov    0x18(%rax,%rcx,1),%eax
     9a7:	89 c1                	mov    %eax,%ecx
     9a9:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     9af:	85 c0                	test   %eax,%eax
     9b1:	75 10                	jne    0x9c3
     9b3:	b8 06 00 00 00       	mov    $0x6,%eax
     9b8:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     9be:	e9 48 01 00 00       	jmp    0xb0b
     9c3:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     9c9:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     9d0:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     9d6:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     9dc:	8d 70 30             	lea    0x30(%rax),%esi
     9df:	e8 7a 57 fe ff       	call   0xfffffffffffe615e
     9e4:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     9eb:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     9f1:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     9f8:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     9fc:	8b 44 08 1c          	mov    0x1c(%rax,%rcx,1),%eax
     a00:	89 c1                	mov    %eax,%ecx
     a02:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     a08:	85 c0                	test   %eax,%eax
     a0a:	75 10                	jne    0xa1c
     a0c:	b8 07 00 00 00       	mov    $0x7,%eax
     a11:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     a17:	e9 ef 00 00 00       	jmp    0xb0b
     a1c:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     a22:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     a29:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     a2f:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     a35:	8d 70 38             	lea    0x38(%rax),%esi
     a38:	e8 21 57 fe ff       	call   0xfffffffffffe615e
     a3d:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     a44:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     a4a:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     a51:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     a55:	8b 44 08 20          	mov    0x20(%rax,%rcx,1),%eax
     a59:	89 c1                	mov    %eax,%ecx
     a5b:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     a61:	85 c0                	test   %eax,%eax
     a63:	75 10                	jne    0xa75
     a65:	b8 08 00 00 00       	mov    $0x8,%eax
     a6a:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     a70:	e9 96 00 00 00       	jmp    0xb0b
     a75:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     a7b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     a82:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     a88:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     a8e:	8d 70 40             	lea    0x40(%rax),%esi
     a91:	e8 c8 56 fe ff       	call   0xfffffffffffe615e
     a96:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     a9d:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     aa3:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     aaa:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     aae:	8b 44 08 24          	mov    0x24(%rax,%rcx,1),%eax
     ab2:	89 c1                	mov    %eax,%ecx
     ab4:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     aba:	85 c0                	test   %eax,%eax
     abc:	75 0d                	jne    0xacb
     abe:	b8 09 00 00 00       	mov    $0x9,%eax
     ac3:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     ac9:	eb 40                	jmp    0xb0b
     acb:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     ad2:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     ad8:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     ade:	8b 85 f0 fe ff ff    	mov    -0x110(%rbp),%eax
     ae4:	8d 70 48             	lea    0x48(%rax),%esi
     ae7:	e8 72 56 fe ff       	call   0xfffffffffffe615e
     aec:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     af3:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     afa:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     afe:	b8 01 00 00 00       	mov    $0x1,%eax
     b03:	89 45 f8             	mov    %eax,-0x8(%rbp)
     b06:	e9 2a 43 00 00       	jmp    0x4e35
     b0b:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     b11:	c1 e0 02             	shl    $0x2,%eax
     b14:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     b1a:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     b1e:	8b 95 e8 fe ff ff    	mov    -0x118(%rbp),%edx
     b24:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
     b2a:	01 d1                	add    %edx,%ecx
     b2c:	8b 04 08             	mov    (%rax,%rcx,1),%eax
     b2f:	85 c0                	test   %eax,%eax
     b31:	0f 85 cc 02 00 00    	jne    0xe03
     b37:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     b3d:	8d 40 04             	lea    0x4(%rax),%eax
     b40:	89 c1                	mov    %eax,%ecx
     b42:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     b48:	83 f8 28             	cmp    $0x28,%eax
     b4b:	75 cd                	jne    0xb1a
     b4d:	b8 01 00 00 00       	mov    $0x1,%eax
     b52:	89 45 f8             	mov    %eax,-0x8(%rbp)
     b55:	e9 db 42 00 00       	jmp    0x4e35
     b5a:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     b5e:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
     b64:	31 d2                	xor    %edx,%edx
     b66:	89 55 fc             	mov    %edx,-0x4(%rbp)
     b69:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     b6e:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
     b74:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
     b78:	83 f8 2e             	cmp    $0x2e,%eax
     b7b:	74 19                	je     0xb96
     b7d:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
     b83:	89 85 e8 fe ff ff    	mov    %eax,-0x118(%rbp)
     b89:	31 c0                	xor    %eax,%eax
     b8b:	89 85 70 ff ff ff    	mov    %eax,-0x90(%rbp)
     b91:	e9 f7 01 00 00       	jmp    0xd8d
     b96:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     b9a:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
     ba0:	0f be 44 08 01       	movsbl 0x1(%rax,%rcx,1),%eax
     ba5:	89 c1                	mov    %eax,%ecx
     ba7:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
     bad:	83 f8 2a             	cmp    $0x2a,%eax
     bb0:	0f 85 ef 00 00 00    	jne    0xca5
     bb6:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     bba:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
     bc0:	0f be 44 08 02       	movsbl 0x2(%rax,%rcx,1),%eax
     bc5:	8d 40 d0             	lea    -0x30(%rax),%eax
     bc8:	89 c1                	mov    %eax,%ecx
     bca:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     bd0:	83 f8 09             	cmp    $0x9,%eax
     bd3:	77 63                	ja     0xc38
     bd5:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     bd9:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
     bdf:	0f b6 44 08 03       	movzbl 0x3(%rax,%rcx,1),%eax
     be4:	83 f8 24             	cmp    $0x24,%eax
     be7:	75 4f                	jne    0xc38
     be9:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     bed:	8b 95 f0 fe ff ff    	mov    -0x110(%rbp),%edx
     bf3:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
     bf9:	8b bd e8 fe ff ff    	mov    -0x118(%rbp),%edi
     bff:	8b b5 f4 fe ff ff    	mov    -0x10c(%rbp),%esi
     c05:	c1 e7 02             	shl    $0x2,%edi
     c08:	01 fe                	add    %edi,%esi
     c0a:	bf 0a 00 00 00       	mov    $0xa,%edi
     c0f:	89 3c 30             	mov    %edi,(%rax,%rsi,1)
     c12:	89 ce                	mov    %ecx,%esi
     c14:	8d 76 04             	lea    0x4(%rsi),%esi
     c17:	89 b5 e8 fe ff ff    	mov    %esi,-0x118(%rbp)
     c1d:	0f be 4c 08 02       	movsbl 0x2(%rax,%rcx,1),%ecx
     c22:	c1 e1 03             	shl    $0x3,%ecx
     c25:	01 d1                	add    %edx,%ecx
     c27:	8d 89 80 fe ff ff    	lea    -0x180(%rcx),%ecx
     c2d:	8b 04 08             	mov    (%rax,%rcx,1),%eax
     c30:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
     c36:	eb 54                	jmp    0xc8c
     c38:	8b 45 f4             	mov    -0xc(%rbp),%eax
     c3b:	85 c0                	test   %eax,%eax
     c3d:	0f 85 c0 01 00 00    	jne    0xe03
     c43:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     c49:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
     c4f:	8d 49 02             	lea    0x2(%rcx),%ecx
     c52:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     c58:	85 c0                	test   %eax,%eax
     c5a:	75 0a                	jne    0xc66
     c5c:	31 c0                	xor    %eax,%eax
     c5e:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
     c64:	eb 26                	jmp    0xc8c
     c66:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     c6a:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     c70:	89 ca                	mov    %ecx,%edx
     c72:	8b 34 08             	mov    (%rax,%rcx,1),%esi
     c75:	89 f1                	mov    %esi,%ecx
     c77:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
     c7d:	8d 76 04             	lea    0x4(%rsi),%esi
     c80:	89 34 10             	mov    %esi,(%rax,%rdx,1)
     c83:	8b 04 08             	mov    (%rax,%rcx,1),%eax
     c86:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
     c8c:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
     c92:	35 ff ff ff ff       	xor    $0xffffffff,%eax
     c97:	c1 e8 1f             	shr    $0x1f,%eax
     c9a:	89 85 70 ff ff ff    	mov    %eax,-0x90(%rbp)
     ca0:	e9 e8 00 00 00       	jmp    0xd8d
     ca5:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
     cab:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
     cb1:	8d 49 01             	lea    0x1(%rcx),%ecx
     cb4:	89 8d e8 fe ff ff    	mov    %ecx,-0x118(%rbp)
     cba:	8d 40 d0             	lea    -0x30(%rax),%eax
     cbd:	89 c1                	mov    %eax,%ecx
     cbf:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
     cc5:	83 f8 09             	cmp    $0x9,%eax
     cc8:	76 18                	jbe    0xce2
     cca:	b8 01 00 00 00       	mov    $0x1,%eax
     ccf:	89 85 70 ff ff ff    	mov    %eax,-0x90(%rbp)
     cd5:	31 c0                	xor    %eax,%eax
     cd7:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
     cdd:	e9 ab 00 00 00       	jmp    0xd8d
     ce2:	8b 85 e8 fe ff ff    	mov    -0x118(%rbp),%eax
     ce8:	31 c9                	xor    %ecx,%ecx
     cea:	89 8d 78 ff ff ff    	mov    %ecx,-0x88(%rbp)
     cf0:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
     cf6:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
     cfc:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
     d01:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
     d07:	3d cc cc cc 0c       	cmp    $0xccccccc,%eax
     d0c:	77 32                	ja     0xd40
     d0e:	8b 95 74 ff ff ff    	mov    -0x8c(%rbp),%edx
     d14:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
     d1a:	6b c0 0a             	imul   $0xa,%eax,%eax
     d1d:	89 c7                	mov    %eax,%edi
     d1f:	89 bd e8 fe ff ff    	mov    %edi,-0x118(%rbp)
     d25:	89 d6                	mov    %edx,%esi
     d27:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
     d2c:	01 f0                	add    %esi,%eax
     d2e:	be ff ff ff 7f       	mov    $0x7fffffff,%esi
     d33:	29 fe                	sub    %edi,%esi
     d35:	39 f2                	cmp    %esi,%edx
     d37:	0f 4f c1             	cmovg  %ecx,%eax
     d3a:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
     d40:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
     d46:	8b 95 64 ff ff ff    	mov    -0x9c(%rbp),%edx
     d4c:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     d50:	be 01 00 00 00       	mov    $0x1,%esi
     d55:	89 b5 70 ff ff ff    	mov    %esi,-0x90(%rbp)
     d5b:	89 d6                	mov    %edx,%esi
     d5d:	0f be 44 30 01       	movsbl 0x1(%rax,%rsi,1),%eax
     d62:	8d 52 01             	lea    0x1(%rdx),%edx
     d65:	89 d6                	mov    %edx,%esi
     d67:	89 b5 e8 fe ff ff    	mov    %esi,-0x118(%rbp)
     d6d:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
     d73:	89 8d 78 ff ff ff    	mov    %ecx,-0x88(%rbp)
     d79:	8d 40 d0             	lea    -0x30(%rax),%eax
     d7c:	89 c1                	mov    %eax,%ecx
     d7e:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
     d84:	83 f8 0a             	cmp    $0xa,%eax
     d87:	0f 82 69 ff ff ff    	jb     0xcf6
     d8d:	8b 55 fc             	mov    -0x4(%rbp),%edx
     d90:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     d94:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     d9a:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
     da0:	0f be 04 08          	movsbl (%rax,%rcx,1),%eax
     da4:	8d 40 bf             	lea    -0x41(%rax),%eax
     da7:	89 c1                	mov    %eax,%ecx
     da9:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     dac:	83 f8 39             	cmp    $0x39,%eax
     daf:	77 52                	ja     0xe03
     db1:	8b 55 fc             	mov    -0x4(%rbp),%edx
     db4:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     db8:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
     dbe:	8b b5 e8 fe ff ff    	mov    -0x118(%rbp),%esi
     dc4:	8d 76 01             	lea    0x1(%rsi),%esi
     dc7:	89 b5 e8 fe ff ff    	mov    %esi,-0x118(%rbp)
     dcd:	6b c9 3a             	imul   $0x3a,%ecx,%ecx
     dd0:	01 d1                	add    %edx,%ecx
     dd2:	8d 89 60 0b 00 00    	lea    0xb60(%rcx),%ecx
     dd8:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
     ddc:	89 c1                	mov    %eax,%ecx
     dde:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     de1:	8d 40 ff             	lea    -0x1(%rax),%eax
     de4:	83 f8 08             	cmp    $0x8,%eax
     de7:	72 a4                	jb     0xd8d
     de9:	8b 45 fc             	mov    -0x4(%rbp),%eax
     dec:	85 c0                	test   %eax,%eax
     dee:	74 13                	je     0xe03
     df0:	8b 45 fc             	mov    -0x4(%rbp),%eax
     df3:	83 f8 1b             	cmp    $0x1b,%eax
     df6:	75 1f                	jne    0xe17
     df8:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
     dfe:	83 f8 ff             	cmp    $0xffffffff,%eax
     e01:	7e 57                	jle    0xe5a
     e03:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     e07:	b9 1c 00 00 00       	mov    $0x1c,%ecx
     e0c:	89 88 e0 10 00 00    	mov    %ecx,0x10e0(%rax)
     e12:	e9 16 40 00 00       	jmp    0x4e2d
     e17:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
     e1d:	85 c0                	test   %eax,%eax
     e1f:	7c 4e                	jl     0xe6f
     e21:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     e25:	8b b5 68 ff ff ff    	mov    -0x98(%rbp),%esi
     e2b:	8b 95 f0 fe ff ff    	mov    -0x110(%rbp),%edx
     e31:	8b 4d cc             	mov    -0x34(%rbp),%ecx
     e34:	44 8b 45 fc          	mov    -0x4(%rbp),%r8d
     e38:	8b bd f4 fe ff ff    	mov    -0x10c(%rbp),%edi
     e3e:	41 89 f1             	mov    %esi,%r9d
     e41:	41 c1 e1 02          	shl    $0x2,%r9d
     e45:	44 01 cf             	add    %r9d,%edi
     e48:	44 89 04 38          	mov    %r8d,(%rax,%rdi,1)
     e4c:	c1 e6 03             	shl    $0x3,%esi
     e4f:	01 f2                	add    %esi,%edx
     e51:	48 8b 14 10          	mov    (%rax,%rdx,1),%rdx
     e55:	48 89 54 08 38       	mov    %rdx,0x38(%rax,%rcx,1)
     e5a:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     e60:	31 c9                	xor    %ecx,%ecx
     e62:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     e65:	85 c0                	test   %eax,%eax
     e67:	0f 84 25 f4 ff ff    	je     0x292
     e6d:	eb 41                	jmp    0xeb0
     e6f:	8b 85 e4 fe ff ff    	mov    -0x11c(%rbp),%eax
     e75:	85 c0                	test   %eax,%eax
     e77:	75 0a                	jne    0xe83
     e79:	31 c0                	xor    %eax,%eax
     e7b:	89 45 f8             	mov    %eax,-0x8(%rbp)
     e7e:	e9 b2 3f 00 00       	jmp    0x4e35
     e83:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
     e8a:	8b 8d ec fe ff ff    	mov    -0x114(%rbp),%ecx
     e90:	8b 55 fc             	mov    -0x4(%rbp),%edx
     e93:	8b 45 cc             	mov    -0x34(%rbp),%eax
     e96:	8d 70 38             	lea    0x38(%rax),%esi
     e99:	e8 c0 52 fe ff       	call   0xfffffffffffe615e
     e9e:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
     ea5:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
     eac:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     eb0:	8b 95 64 ff ff ff    	mov    -0x9c(%rbp),%edx
     eb6:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     eba:	8b 8d e8 fe ff ff    	mov    -0x118(%rbp),%ecx
     ec0:	44 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%r8d
     ec7:	44 89 c7             	mov    %r8d,%edi
     eca:	81 e7 ff ff fe ff    	and    $0xfffeffff,%edi
     ed0:	89 fe                	mov    %edi,%esi
     ed2:	89 b5 7c ff ff ff    	mov    %esi,-0x84(%rbp)
     ed8:	44 89 c6             	mov    %r8d,%esi
     edb:	41 81 e0 00 20 00 00 	and    $0x2000,%r8d
     ee2:	45 85 c0             	test   %r8d,%r8d
     ee5:	0f 45 f7             	cmovne %edi,%esi
     ee8:	89 b5 68 ff ff ff    	mov    %esi,-0x98(%rbp)
     eee:	8d 49 ff             	lea    -0x1(%rcx),%ecx
     ef1:	0f be 34 08          	movsbl (%rax,%rcx,1),%esi
     ef5:	89 f0                	mov    %esi,%eax
     ef7:	89 45 fc             	mov    %eax,-0x4(%rbp)
     efa:	89 c1                	mov    %eax,%ecx
     efc:	89 c7                	mov    %eax,%edi
     efe:	81 e6 df ff ff ff    	and    $0xffffffdf,%esi
     f04:	83 e7 0f             	and    $0xf,%edi
     f07:	83 ff 03             	cmp    $0x3,%edi
     f0a:	0f 44 ce             	cmove  %esi,%ecx
     f0d:	85 d2                	test   %edx,%edx
     f0f:	0f 45 c1             	cmovne %ecx,%eax
     f12:	89 c1                	mov    %eax,%ecx
     f14:	89 4d 80             	mov    %ecx,-0x80(%rbp)
     f17:	8d 40 bf             	lea    -0x41(%rax),%eax
     f1a:	89 85 d4 fe ff ff    	mov    %eax,-0x12c(%rbp)
     f20:	3d 37 00 00 00       	cmp    $0x37,%eax
     f25:	77 47                	ja     0xf6e
     f27:	8b 85 d4 fe ff ff    	mov    -0x12c(%rbp),%eax
     f2d:	48 8d 0d 80 3f 00 00 	lea    0x3f80(%rip),%rcx        # 0x4eb4
     f34:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
     f38:	48 01 c8             	add    %rcx,%rax
     f3b:	ff e0                	jmp    *%rax
     f3d:	eb 39                	jmp    0xf78
     f3f:	e9 9b 05 00 00       	jmp    0x14df
     f44:	e9 3e 01 00 00       	jmp    0x1087
     f49:	e9 34 02 00 00       	jmp    0x1182
     f4e:	eb 4a                	jmp    0xf9a
     f50:	e9 5a 05 00 00       	jmp    0x14af
     f55:	e9 d3 02 00 00       	jmp    0x122d
     f5a:	e9 11 05 00 00       	jmp    0x1470
     f5f:	e9 53 01 00 00       	jmp    0x10b7
     f64:	e9 1d 06 00 00       	jmp    0x1586
     f69:	e9 3d 06 00 00       	jmp    0x15ab
     f6e:	e9 e0 26 00 00       	jmp    0x3653
     f73:	e9 1b 0b 00 00       	jmp    0x1a93
     f78:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     f7c:	8b 4d cc             	mov    -0x34(%rbp),%ecx
     f7f:	31 d2                	xor    %edx,%edx
     f81:	89 55 84             	mov    %edx,-0x7c(%rbp)
     f84:	ba 4a 0b 00 00       	mov    $0xb4a,%edx
     f89:	89 55 88             	mov    %edx,-0x78(%rbp)
     f8c:	48 8b 44 08 38       	mov    0x38(%rax,%rcx,1),%rax
     f91:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
     f95:	e9 1b 03 00 00       	jmp    0x12b5
     f9a:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
     fa0:	31 c9                	xor    %ecx,%ecx
     fa2:	89 4d fc             	mov    %ecx,-0x4(%rbp)
     fa5:	25 ff 00 00 00       	and    $0xff,%eax
     faa:	89 85 d0 fe ff ff    	mov    %eax,-0x130(%rbp)
     fb0:	3d 07 00 00 00       	cmp    $0x7,%eax
     fb5:	77 20                	ja     0xfd7
     fb7:	8b 85 d0 fe ff ff    	mov    -0x130(%rbp),%eax
     fbd:	48 8d 0d d0 3f 00 00 	lea    0x3fd0(%rip),%rcx        # 0x4f94
     fc4:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
     fc8:	48 01 c8             	add    %rcx,%rax
     fcb:	ff e0                	jmp    *%rax
     fcd:	e9 85 00 00 00       	jmp    0x1057
     fd2:	e9 96 00 00 00       	jmp    0x106d
     fd7:	e9 b6 f2 ff ff       	jmp    0x292
     fdc:	eb 63                	jmp    0x1041
     fde:	eb 4a                	jmp    0x102a
     fe0:	eb 2e                	jmp    0x1010
     fe2:	eb 16                	jmp    0xffa
     fe4:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     fe8:	8b 55 f8             	mov    -0x8(%rbp),%edx
     feb:	8b 4d cc             	mov    -0x34(%rbp),%ecx
     fee:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
     ff2:	89 14 08             	mov    %edx,(%rax,%rcx,1)
     ff5:	e9 98 f2 ff ff       	jmp    0x292
     ffa:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     ffe:	8b 55 f8             	mov    -0x8(%rbp),%edx
    1001:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1004:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    1008:	89 14 08             	mov    %edx,(%rax,%rcx,1)
    100b:	e9 82 f2 ff ff       	jmp    0x292
    1010:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1014:	8b 55 f8             	mov    -0x8(%rbp),%edx
    1017:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    101a:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    101e:	48 63 d2             	movslq %edx,%rdx
    1021:	48 89 14 08          	mov    %rdx,(%rax,%rcx,1)
    1025:	e9 68 f2 ff ff       	jmp    0x292
    102a:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    102e:	8b 55 f8             	mov    -0x8(%rbp),%edx
    1031:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1034:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    1038:	66 89 14 08          	mov    %dx,(%rax,%rcx,1)
    103c:	e9 51 f2 ff ff       	jmp    0x292
    1041:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1045:	8b 55 f8             	mov    -0x8(%rbp),%edx
    1048:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    104b:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    104f:	88 14 08             	mov    %dl,(%rax,%rcx,1)
    1052:	e9 3b f2 ff ff       	jmp    0x292
    1057:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    105b:	8b 55 f8             	mov    -0x8(%rbp),%edx
    105e:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1061:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    1065:	89 14 08             	mov    %edx,(%rax,%rcx,1)
    1068:	e9 25 f2 ff ff       	jmp    0x292
    106d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1071:	8b 55 f8             	mov    -0x8(%rbp),%edx
    1074:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1077:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    107b:	48 63 d2             	movslq %edx,%rdx
    107e:	48 89 14 08          	mov    %rdx,(%rax,%rcx,1)
    1082:	e9 0b f2 ff ff       	jmp    0x292
    1087:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    108d:	8b b5 60 ff ff ff    	mov    -0xa0(%rbp),%esi
    1093:	89 f2                	mov    %esi,%edx
    1095:	b9 08 00 00 00       	mov    $0x8,%ecx
    109a:	83 fe 08             	cmp    $0x8,%esi
    109d:	0f 47 ca             	cmova  %edx,%ecx
    10a0:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    10a6:	83 c8 08             	or     $0x8,%eax
    10a9:	89 85 68 ff ff ff    	mov    %eax,-0x98(%rbp)
    10af:	b8 78 00 00 00       	mov    $0x78,%eax
    10b4:	89 45 80             	mov    %eax,-0x80(%rbp)
    10b7:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    10bb:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    10be:	31 d2                	xor    %edx,%edx
    10c0:	89 55 84             	mov    %edx,-0x7c(%rbp)
    10c3:	ba 4a 0b 00 00       	mov    $0xb4a,%edx
    10c8:	89 55 88             	mov    %edx,-0x78(%rbp)
    10cb:	48 8b 44 08 38       	mov    0x38(%rax,%rcx,1),%rax
    10d0:	48 89 c1             	mov    %rax,%rcx
    10d3:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    10d7:	48 85 c0             	test   %rax,%rax
    10da:	75 0e                	jne    0x10ea
    10dc:	8b 45 f0             	mov    -0x10(%rbp),%eax
    10df:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    10e5:	e9 d2 02 00 00       	jmp    0x13bc
    10ea:	8b 45 f0             	mov    -0x10(%rbp),%eax
    10ed:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    10f0:	83 e1 20             	and    $0x20,%ecx
    10f3:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    10f6:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    10fc:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    1100:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    1104:	8b 7d fc             	mov    -0x4(%rbp),%edi
    1107:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    110d:	8d 52 ff             	lea    -0x1(%rdx),%edx
    1110:	89 d6                	mov    %edx,%esi
    1112:	89 b5 54 ff ff ff    	mov    %esi,-0xac(%rbp)
    1118:	48 89 c6             	mov    %rax,%rsi
    111b:	89 f6                	mov    %esi,%esi
    111d:	83 e6 0f             	and    $0xf,%esi
    1120:	8d b6 c0 0d 00 00    	lea    0xdc0(%rsi),%esi
    1126:	0f b6 34 31          	movzbl (%rcx,%rsi,1),%esi
    112a:	09 fe                	or     %edi,%esi
    112c:	40 88 34 11          	mov    %sil,(%rcx,%rdx,1)
    1130:	48 c1 e8 04          	shr    $0x4,%rax
    1134:	48 89 c1             	mov    %rax,%rcx
    1137:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    113b:	48 85 c0             	test   %rax,%rax
    113e:	75 bc                	jne    0x10fc
    1140:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    1146:	83 e0 08             	and    $0x8,%eax
    1149:	85 c0                	test   %eax,%eax
    114b:	0f 84 6b 02 00 00    	je     0x13bc
    1151:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1155:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1158:	48 8b 44 08 38       	mov    0x38(%rax,%rcx,1),%rax
    115d:	48 85 c0             	test   %rax,%rax
    1160:	0f 84 56 02 00 00    	je     0x13bc
    1166:	8b 45 80             	mov    -0x80(%rbp),%eax
    1169:	c1 f8 04             	sar    $0x4,%eax
    116c:	8d 80 4a 0b 00 00    	lea    0xb4a(%rax),%eax
    1172:	89 45 88             	mov    %eax,-0x78(%rbp)
    1175:	b8 02 00 00 00       	mov    $0x2,%eax
    117a:	89 45 84             	mov    %eax,-0x7c(%rbp)
    117d:	e9 3a 02 00 00       	jmp    0x13bc
    1182:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1186:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1189:	8b 55 f0             	mov    -0x10(%rbp),%edx
    118c:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    1192:	48 8b 44 08 38       	mov    0x38(%rax,%rcx,1),%rax
    1197:	48 89 c1             	mov    %rax,%rcx
    119a:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    119e:	48 85 c0             	test   %rax,%rax
    11a1:	74 41                	je     0x11e4
    11a3:	8b 45 f0             	mov    -0x10(%rbp),%eax
    11a6:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    11ac:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    11b0:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    11b4:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    11ba:	8d 52 ff             	lea    -0x1(%rdx),%edx
    11bd:	89 d6                	mov    %edx,%esi
    11bf:	89 b5 54 ff ff ff    	mov    %esi,-0xac(%rbp)
    11c5:	48 89 c6             	mov    %rax,%rsi
    11c8:	89 f6                	mov    %esi,%esi
    11ca:	83 e6 07             	and    $0x7,%esi
    11cd:	83 ce 30             	or     $0x30,%esi
    11d0:	40 88 34 11          	mov    %sil,(%rcx,%rdx,1)
    11d4:	48 c1 e8 03          	shr    $0x3,%rax
    11d8:	48 89 c1             	mov    %rax,%rcx
    11db:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    11df:	48 85 c0             	test   %rax,%rax
    11e2:	75 c8                	jne    0x11ac
    11e4:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    11ea:	31 c9                	xor    %ecx,%ecx
    11ec:	89 4d 84             	mov    %ecx,-0x7c(%rbp)
    11ef:	b9 4a 0b 00 00       	mov    $0xb4a,%ecx
    11f4:	89 4d 88             	mov    %ecx,-0x78(%rbp)
    11f7:	83 e0 08             	and    $0x8,%eax
    11fa:	85 c0                	test   %eax,%eax
    11fc:	0f 84 ba 01 00 00    	je     0x13bc
    1202:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
    1208:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    120e:	8b 45 f0             	mov    -0x10(%rbp),%eax
    1211:	89 d1                	mov    %edx,%ecx
    1213:	29 f0                	sub    %esi,%eax
    1215:	89 c6                	mov    %eax,%esi
    1217:	89 75 fc             	mov    %esi,-0x4(%rbp)
    121a:	8d 40 01             	lea    0x1(%rax),%eax
    121d:	39 f2                	cmp    %esi,%edx
    121f:	0f 4f c1             	cmovg  %ecx,%eax
    1222:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    1228:	e9 8f 01 00 00       	jmp    0x13bc
    122d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1231:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1234:	48 8b 44 08 38       	mov    0x38(%rax,%rcx,1),%rax
    1239:	48 89 c1             	mov    %rax,%rcx
    123c:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    1240:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    1244:	7f 2e                	jg     0x1274
    1246:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    124a:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    124e:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1251:	31 d2                	xor    %edx,%edx
    1253:	48 29 f2             	sub    %rsi,%rdx
    1256:	48 89 d6             	mov    %rdx,%rsi
    1259:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
    125d:	48 89 54 08 38       	mov    %rdx,0x38(%rax,%rcx,1)
    1262:	b8 01 00 00 00       	mov    $0x1,%eax
    1267:	89 45 84             	mov    %eax,-0x7c(%rbp)
    126a:	b8 4a 0b 00 00       	mov    $0xb4a,%eax
    126f:	89 45 88             	mov    %eax,-0x78(%rbp)
    1272:	eb 41                	jmp    0x12b5
    1274:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    127a:	25 00 08 00 00       	and    $0x800,%eax
    127f:	85 c0                	test   %eax,%eax
    1281:	74 12                	je     0x1295
    1283:	b8 01 00 00 00       	mov    $0x1,%eax
    1288:	89 45 84             	mov    %eax,-0x7c(%rbp)
    128b:	b8 4b 0b 00 00       	mov    $0xb4b,%eax
    1290:	89 45 88             	mov    %eax,-0x78(%rbp)
    1293:	eb 20                	jmp    0x12b5
    1295:	8b 95 68 ff ff ff    	mov    -0x98(%rbp),%edx
    129b:	83 e2 01             	and    $0x1,%edx
    129e:	89 d0                	mov    %edx,%eax
    12a0:	89 45 84             	mov    %eax,-0x7c(%rbp)
    12a3:	b9 4c 0b 00 00       	mov    $0xb4c,%ecx
    12a8:	b8 4a 0b 00 00       	mov    $0xb4a,%eax
    12ad:	85 d2                	test   %edx,%edx
    12af:	0f 45 c1             	cmovne %ecx,%eax
    12b2:	89 45 88             	mov    %eax,-0x78(%rbp)
    12b5:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    12b9:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    12c0:	00 00 00 
    12c3:	48 39 c8             	cmp    %rcx,%rax
    12c6:	73 13                	jae    0x12db
    12c8:	8b 45 f0             	mov    -0x10(%rbp),%eax
    12cb:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
    12cf:	48 89 4d a8          	mov    %rcx,-0x58(%rbp)
    12d3:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    12d9:	eb 6c                	jmp    0x1347
    12db:	8b 45 f0             	mov    -0x10(%rbp),%eax
    12de:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    12e4:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    12e8:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    12ee:	8d 71 ff             	lea    -0x1(%rcx),%esi
    12f1:	89 f1                	mov    %esi,%ecx
    12f3:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    12f9:	48 89 c7             	mov    %rax,%rdi
    12fc:	b9 0a 00 00 00       	mov    $0xa,%ecx
    1301:	48 31 d2             	xor    %rdx,%rdx
    1304:	48 f7 f1             	div    %rcx
    1307:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    130b:	49 89 c0             	mov    %rax,%r8
    130e:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    1312:	4c 89 c1             	mov    %r8,%rcx
    1315:	48 89 4d a8          	mov    %rcx,-0x58(%rbp)
    1319:	4d 6b c0 0a          	imul   $0xa,%r8,%r8
    131d:	4c 29 c7             	sub    %r8,%rdi
    1320:	89 ff                	mov    %edi,%edi
    1322:	83 cf 30             	or     $0x30,%edi
    1325:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    1329:	48 ba ff ff ff ff 09 	movabs $0x9ffffffff,%rdx
    1330:	00 00 00 
    1333:	48 39 d0             	cmp    %rdx,%rax
    1336:	0f 97 c0             	seta   %al
    1339:	0f b6 c0             	movzbl %al,%eax
    133c:	89 45 fc             	mov    %eax,-0x4(%rbp)
    133f:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    1343:	85 c0                	test   %eax,%eax
    1345:	75 9d                	jne    0x12e4
    1347:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    134b:	89 c0                	mov    %eax,%eax
    134d:	89 c1                	mov    %eax,%ecx
    134f:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    1352:	85 c0                	test   %eax,%eax
    1354:	74 66                	je     0x13bc
    1356:	8b 45 fc             	mov    -0x4(%rbp),%eax
    1359:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    135d:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    1363:	8d 71 ff             	lea    -0x1(%rcx),%esi
    1366:	89 f1                	mov    %esi,%ecx
    1368:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    136e:	89 c7                	mov    %eax,%edi
    1370:	89 c1                	mov    %eax,%ecx
    1372:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
    1378:	89 c9                	mov    %ecx,%ecx
    137a:	49 b8 cd cc cc cc 00 	movabs $0xcccccccd,%r8
    1381:	00 00 00 
    1384:	49 0f af c8          	imul   %r8,%rcx
    1388:	48 c1 e9 23          	shr    $0x23,%rcx
    138c:	41 89 c8             	mov    %ecx,%r8d
    138f:	44 89 c1             	mov    %r8d,%ecx
    1392:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    1398:	45 6b c0 0a          	imul   $0xa,%r8d,%r8d
    139c:	44 29 c7             	sub    %r8d,%edi
    139f:	83 cf 30             	or     $0x30,%edi
    13a2:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    13a6:	83 f8 09             	cmp    $0x9,%eax
    13a9:	0f 97 c0             	seta   %al
    13ac:	0f b6 c0             	movzbl %al,%eax
    13af:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
    13b5:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    13b8:	85 c0                	test   %eax,%eax
    13ba:	75 9a                	jne    0x1356
    13bc:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    13c2:	85 c0                	test   %eax,%eax
    13c4:	74 0e                	je     0x13d4
    13c6:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    13cc:	85 c0                	test   %eax,%eax
    13ce:	0f 8c 4a 3a 00 00    	jl     0x4e1e
    13d4:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    13da:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    13de:	8b 55 cc             	mov    -0x34(%rbp),%edx
    13e1:	44 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%r8d
    13e8:	8b b5 68 ff ff ff    	mov    -0x98(%rbp),%esi
    13ee:	89 f7                	mov    %esi,%edi
    13f0:	81 e7 ff ff fe ff    	and    $0xfffeffff,%edi
    13f6:	45 85 c0             	test   %r8d,%r8d
    13f9:	0f 45 f7             	cmovne %edi,%esi
    13fc:	89 b5 7c ff ff ff    	mov    %esi,-0x84(%rbp)
    1402:	48 8b 4c 11 38       	mov    0x38(%rcx,%rdx,1),%rcx
    1407:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    140b:	85 c0                	test   %eax,%eax
    140d:	75 24                	jne    0x1433
    140f:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    1413:	31 c9                	xor    %ecx,%ecx
    1415:	89 8d 78 ff ff ff    	mov    %ecx,-0x88(%rbp)
    141b:	48 85 c0             	test   %rax,%rax
    141e:	75 13                	jne    0x1433
    1420:	8b 45 f0             	mov    -0x10(%rbp),%eax
    1423:	89 c1                	mov    %eax,%ecx
    1425:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    142b:	89 45 fc             	mov    %eax,-0x4(%rbp)
    142e:	e9 4b 22 00 00       	jmp    0x367e
    1433:	8b 45 f0             	mov    -0x10(%rbp),%eax
    1436:	8b b5 60 ff ff ff    	mov    -0xa0(%rbp),%esi
    143c:	48 8b 7d a0          	mov    -0x60(%rbp),%rdi
    1440:	44 8b 85 54 ff ff ff 	mov    -0xac(%rbp),%r8d
    1447:	89 f2                	mov    %esi,%edx
    1449:	89 c1                	mov    %eax,%ecx
    144b:	44 29 c1             	sub    %r8d,%ecx
    144e:	48 85 ff             	test   %rdi,%rdi
    1451:	40 0f 94 c7          	sete   %dil
    1455:	40 0f b6 ff          	movzbl %dil,%edi
    1459:	01 f9                	add    %edi,%ecx
    145b:	89 cf                	mov    %ecx,%edi
    145d:	39 fe                	cmp    %edi,%esi
    145f:	0f 4f ca             	cmovg  %edx,%ecx
    1462:	89 8d 78 ff ff ff    	mov    %ecx,-0x88(%rbp)
    1468:	89 45 fc             	mov    %eax,-0x4(%rbp)
    146b:	e9 0e 22 00 00       	jmp    0x367e
    1470:	8b 45 f0             	mov    -0x10(%rbp),%eax
    1473:	8b 4d d0             	mov    -0x30(%rbp),%ecx
    1476:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    147a:	8b 7d cc             	mov    -0x34(%rbp),%edi
    147d:	89 fe                	mov    %edi,%esi
    147f:	48 8b 7c 3a 38       	mov    0x38(%rdx,%rdi,1),%rdi
    1484:	40 88 7c 32 37       	mov    %dil,0x37(%rdx,%rsi,1)
    1489:	31 d2                	xor    %edx,%edx
    148b:	89 55 84             	mov    %edx,-0x7c(%rbp)
    148e:	ba 4a 0b 00 00       	mov    $0xb4a,%edx
    1493:	89 55 88             	mov    %edx,-0x78(%rbp)
    1496:	ba 01 00 00 00       	mov    $0x1,%edx
    149b:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    14a1:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    14a7:	89 45 fc             	mov    %eax,-0x4(%rbp)
    14aa:	e9 cf 21 00 00       	jmp    0x367e
    14af:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    14b3:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    14ba:	8b b0 e0 10 00 00    	mov    0x10e0(%rax),%esi
    14c0:	e8 71 4c fe ff       	call   0xfffffffffffe6136
    14c5:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    14cc:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    14d3:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    14d7:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    14dd:	eb 20                	jmp    0x14ff
    14df:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    14e3:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    14e6:	8b 4c 08 38          	mov    0x38(%rax,%rcx,1),%ecx
    14ea:	89 ca                	mov    %ecx,%edx
    14ec:	89 55 fc             	mov    %edx,-0x4(%rbp)
    14ef:	b8 54 0b 00 00       	mov    $0xb54,%eax
    14f4:	85 d2                	test   %edx,%edx
    14f6:	0f 45 c1             	cmovne %ecx,%eax
    14f9:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    14ff:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    1505:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    150c:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    1512:	31 c0                	xor    %eax,%eax
    1514:	89 45 84             	mov    %eax,-0x7c(%rbp)
    1517:	89 f0                	mov    %esi,%eax
    1519:	89 85 cc fe ff ff    	mov    %eax,-0x134(%rbp)
    151f:	89 ca                	mov    %ecx,%edx
    1521:	b8 ff ff ff 7f       	mov    $0x7fffffff,%eax
    1526:	85 c9                	test   %ecx,%ecx
    1528:	0f 4c d0             	cmovl  %eax,%edx
    152b:	e8 74 4c fe ff       	call   0xfffffffffffe61a4
    1530:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
    1537:	8b 8d cc fe ff ff    	mov    -0x134(%rbp),%ecx
    153d:	89 c2                	mov    %eax,%edx
    153f:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    1545:	48 8b b6 90 12 00 00 	mov    0x1290(%rsi),%rsi
    154c:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
    1550:	89 d6                	mov    %edx,%esi
    1552:	89 b5 78 ff ff ff    	mov    %esi,-0x88(%rbp)
    1558:	01 d1                	add    %edx,%ecx
    155a:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    155d:	b9 4a 0b 00 00       	mov    $0xb4a,%ecx
    1562:	89 4d 88             	mov    %ecx,-0x78(%rbp)
    1565:	83 f8 ff             	cmp    $0xffffffff,%eax
    1568:	0f 8f 10 21 00 00    	jg     0x367e
    156e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1572:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    1575:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    1579:	85 c0                	test   %eax,%eax
    157b:	0f 84 fd 20 00 00    	je     0x367e
    1581:	e9 98 38 00 00       	jmp    0x4e1e
    1586:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    158c:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    1590:	8b 55 cc             	mov    -0x34(%rbp),%edx
    1593:	8b 4c 11 38          	mov    0x38(%rcx,%rdx,1),%ecx
    1597:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    159d:	85 c0                	test   %eax,%eax
    159f:	75 47                	jne    0x15e8
    15a1:	31 c0                	xor    %eax,%eax
    15a3:	89 45 fc             	mov    %eax,-0x4(%rbp)
    15a6:	e9 0e 01 00 00       	jmp    0x16b9
    15ab:	8b 45 cc             	mov    -0x34(%rbp),%eax
    15ae:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    15b2:	89 c2                	mov    %eax,%edx
    15b4:	31 f6                	xor    %esi,%esi
    15b6:	89 74 11 0c          	mov    %esi,0xc(%rcx,%rdx,1)
    15ba:	89 c2                	mov    %eax,%edx
    15bc:	89 c6                	mov    %eax,%esi
    15be:	48 8b 74 31 38       	mov    0x38(%rcx,%rsi,1),%rsi
    15c3:	89 f6                	mov    %esi,%esi
    15c5:	89 74 11 08          	mov    %esi,0x8(%rcx,%rdx,1)
    15c9:	89 c2                	mov    %eax,%edx
    15cb:	89 c6                	mov    %eax,%esi
    15cd:	8d 76 08             	lea    0x8(%rsi),%esi
    15d0:	89 74 11 38          	mov    %esi,0x38(%rcx,%rdx,1)
    15d4:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    15d9:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    15df:	8d 40 08             	lea    0x8(%rax),%eax
    15e2:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    15e8:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    15ee:	31 c9                	xor    %ecx,%ecx
    15f0:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    15f3:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    15f9:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    15fd:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    1603:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1606:	89 c1                	mov    %eax,%ecx
    1608:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    160e:	85 c0                	test   %eax,%eax
    1610:	0f 84 98 00 00 00    	je     0x16ae
    1616:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    161c:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1623:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1626:	8d 70 04             	lea    0x4(%rax),%esi
    1629:	e8 bc 4b fe ff       	call   0xfffffffffffe61ea
    162e:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    1635:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    163c:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    1640:	89 c1                	mov    %eax,%ecx
    1642:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    1648:	85 c0                	test   %eax,%eax
    164a:	0f 9c c0             	setl   %al
    164d:	0f b6 c0             	movzbl %al,%eax
    1650:	89 c1                	mov    %eax,%ecx
    1652:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
    1658:	85 c0                	test   %eax,%eax
    165a:	75 44                	jne    0x16a0
    165c:	8b 55 fc             	mov    -0x4(%rbp),%edx
    165f:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    1665:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    166b:	29 d1                	sub    %edx,%ecx
    166d:	39 c8                	cmp    %ecx,%eax
    166f:	77 2f                	ja     0x16a0
    1671:	8b 55 fc             	mov    -0x4(%rbp),%edx
    1674:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    167a:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    1680:	8b b5 58 ff ff ff    	mov    -0xa8(%rbp),%esi
    1686:	8d 76 04             	lea    0x4(%rsi),%esi
    1689:	89 b5 58 ff ff ff    	mov    %esi,-0xa8(%rbp)
    168f:	01 d1                	add    %edx,%ecx
    1691:	89 ca                	mov    %ecx,%edx
    1693:	89 55 fc             	mov    %edx,-0x4(%rbp)
    1696:	39 c8                	cmp    %ecx,%eax
    1698:	0f 87 5b ff ff ff    	ja     0x15f9
    169e:	eb 0e                	jmp    0x16ae
    16a0:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    16a6:	85 c0                	test   %eax,%eax
    16a8:	0f 85 7f 37 00 00    	jne    0x4e2d
    16ae:	8b 45 fc             	mov    -0x4(%rbp),%eax
    16b1:	85 c0                	test   %eax,%eax
    16b3:	0f 8c 65 37 00 00    	jl     0x4e1e
    16b9:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    16bf:	25 00 20 01 00       	and    $0x12000,%eax
    16c4:	89 c1                	mov    %eax,%ecx
    16c6:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    16cc:	85 c0                	test   %eax,%eax
    16ce:	0f 85 5a 01 00 00    	jne    0x182e
    16d4:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    16d7:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    16dd:	39 c8                	cmp    %ecx,%eax
    16df:	0f 8e 49 01 00 00    	jle    0x182e
    16e5:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    16ec:	8b 55 fc             	mov    -0x4(%rbp),%edx
    16ef:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    16f5:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    16f8:	29 d0                	sub    %edx,%eax
    16fa:	41 89 c0             	mov    %eax,%r8d
    16fd:	44 89 85 58 ff ff ff 	mov    %r8d,-0xa8(%rbp)
    1704:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    170b:	0f 92 c2             	setb   %dl
    170e:	0f b6 d2             	movzbl %dl,%edx
    1711:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    1717:	8d 71 40             	lea    0x40(%rcx),%esi
    171a:	ba 20 00 00 00       	mov    $0x20,%edx
    171f:	b9 00 01 00 00       	mov    $0x100,%ecx
    1724:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    172b:	0f 42 c8             	cmovb  %eax,%ecx
    172e:	e8 85 4a fe ff       	call   0xfffffffffffe61b8
    1733:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    173a:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    1740:	89 c6                	mov    %eax,%esi
    1742:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    1748:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    174f:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    1753:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    1756:	89 ca                	mov    %ecx,%edx
    1758:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    175e:	83 e1 20             	and    $0x20,%ecx
    1761:	85 c9                	test   %ecx,%ecx
    1763:	0f 94 c1             	sete   %cl
    1766:	0f b6 c9             	movzbl %cl,%ecx
    1769:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    176f:	85 c0                	test   %eax,%eax
    1771:	75 7f                	jne    0x17f2
    1773:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    1779:	83 e0 01             	and    $0x1,%eax
    177c:	85 c0                	test   %eax,%eax
    177e:	74 40                	je     0x17c0
    1780:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1786:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    178d:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1790:	8d 70 40             	lea    0x40(%rax),%esi
    1793:	ba 00 01 00 00       	mov    $0x100,%edx
    1798:	e8 35 49 fe ff       	call   0xfffffffffffe60d2
    179d:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    17a3:	89 c2                	mov    %eax,%edx
    17a5:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    17ac:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    17b3:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    17b7:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    17ba:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
    17c0:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    17c6:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    17cc:	83 e1 20             	and    $0x20,%ecx
    17cf:	85 c9                	test   %ecx,%ecx
    17d1:	0f 94 c1             	sete   %cl
    17d4:	0f b6 c9             	movzbl %cl,%ecx
    17d7:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    17dd:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    17e3:	89 c1                	mov    %eax,%ecx
    17e5:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    17eb:	3d ff 00 00 00       	cmp    $0xff,%eax
    17f0:	77 81                	ja     0x1773
    17f2:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    17f8:	85 c0                	test   %eax,%eax
    17fa:	74 32                	je     0x182e
    17fc:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1803:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1809:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    180f:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1812:	8d 70 40             	lea    0x40(%rax),%esi
    1815:	e8 b8 48 fe ff       	call   0xfffffffffffe60d2
    181a:	89 c1                	mov    %eax,%ecx
    181c:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1823:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    182a:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    182e:	8b 45 fc             	mov    -0x4(%rbp),%eax
    1831:	85 c0                	test   %eax,%eax
    1833:	0f 84 d5 00 00 00    	je     0x190e
    1839:	31 c0                	xor    %eax,%eax
    183b:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    1841:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1845:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    184b:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    184e:	89 c1                	mov    %eax,%ecx
    1850:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    1856:	85 c0                	test   %eax,%eax
    1858:	0f 84 b0 00 00 00    	je     0x190e
    185e:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    1864:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    186b:	8b 45 cc             	mov    -0x34(%rbp),%eax
    186e:	8d 70 04             	lea    0x4(%rax),%esi
    1871:	e8 74 49 fe ff       	call   0xfffffffffffe61ea
    1876:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
    187d:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    1883:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    1886:	48 8b b6 90 12 00 00 	mov    0x1290(%rsi),%rsi
    188d:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
    1891:	89 c6                	mov    %eax,%esi
    1893:	89 b5 5c ff ff ff    	mov    %esi,-0xa4(%rbp)
    1899:	01 d0                	add    %edx,%eax
    189b:	89 c2                	mov    %eax,%edx
    189d:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    18a3:	39 c8                	cmp    %ecx,%eax
    18a5:	77 67                	ja     0x190e
    18a7:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    18ab:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    18b1:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    18b5:	83 e0 20             	and    $0x20,%eax
    18b8:	85 c0                	test   %eax,%eax
    18ba:	75 32                	jne    0x18ee
    18bc:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    18c3:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    18c9:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    18cf:	8b 45 cc             	mov    -0x34(%rbp),%eax
    18d2:	8d 70 04             	lea    0x4(%rax),%esi
    18d5:	e8 f8 47 fe ff       	call   0xfffffffffffe60d2
    18da:	89 c1                	mov    %eax,%ecx
    18dc:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    18e3:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    18ea:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    18ee:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    18f1:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    18f7:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    18fd:	8d 52 04             	lea    0x4(%rdx),%edx
    1900:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    1906:	39 c8                	cmp    %ecx,%eax
    1908:	0f 82 33 ff ff ff    	jb     0x1841
    190e:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    1914:	3d 00 20 00 00       	cmp    $0x2000,%eax
    1919:	0f 85 5a 01 00 00    	jne    0x1a79
    191f:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    1922:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    1928:	39 c8                	cmp    %ecx,%eax
    192a:	0f 8e 49 01 00 00    	jle    0x1a79
    1930:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1937:	8b 55 fc             	mov    -0x4(%rbp),%edx
    193a:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    1940:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1943:	29 d0                	sub    %edx,%eax
    1945:	41 89 c0             	mov    %eax,%r8d
    1948:	44 89 85 58 ff ff ff 	mov    %r8d,-0xa8(%rbp)
    194f:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1956:	0f 92 c2             	setb   %dl
    1959:	0f b6 d2             	movzbl %dl,%edx
    195c:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    1962:	8d 71 40             	lea    0x40(%rcx),%esi
    1965:	ba 20 00 00 00       	mov    $0x20,%edx
    196a:	b9 00 01 00 00       	mov    $0x100,%ecx
    196f:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1976:	0f 42 c8             	cmovb  %eax,%ecx
    1979:	e8 3a 48 fe ff       	call   0xfffffffffffe61b8
    197e:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    1985:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    198b:	89 c6                	mov    %eax,%esi
    198d:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    1993:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    199a:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    199e:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    19a1:	89 ca                	mov    %ecx,%edx
    19a3:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    19a9:	83 e1 20             	and    $0x20,%ecx
    19ac:	85 c9                	test   %ecx,%ecx
    19ae:	0f 94 c1             	sete   %cl
    19b1:	0f b6 c9             	movzbl %cl,%ecx
    19b4:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    19ba:	85 c0                	test   %eax,%eax
    19bc:	75 7f                	jne    0x1a3d
    19be:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    19c4:	83 e0 01             	and    $0x1,%eax
    19c7:	85 c0                	test   %eax,%eax
    19c9:	74 40                	je     0x1a0b
    19cb:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    19d1:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    19d8:	8b 45 cc             	mov    -0x34(%rbp),%eax
    19db:	8d 70 40             	lea    0x40(%rax),%esi
    19de:	ba 00 01 00 00       	mov    $0x100,%edx
    19e3:	e8 ea 46 fe ff       	call   0xfffffffffffe60d2
    19e8:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    19ee:	89 c2                	mov    %eax,%edx
    19f0:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    19f7:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    19fe:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1a02:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1a05:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    1a0b:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    1a11:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    1a17:	83 e1 20             	and    $0x20,%ecx
    1a1a:	85 c9                	test   %ecx,%ecx
    1a1c:	0f 94 c1             	sete   %cl
    1a1f:	0f b6 c9             	movzbl %cl,%ecx
    1a22:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    1a28:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    1a2e:	89 c1                	mov    %eax,%ecx
    1a30:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    1a36:	3d ff 00 00 00       	cmp    $0xff,%eax
    1a3b:	77 81                	ja     0x19be
    1a3d:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    1a43:	85 c0                	test   %eax,%eax
    1a45:	74 32                	je     0x1a79
    1a47:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1a4e:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1a54:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    1a5a:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1a5d:	8d 70 40             	lea    0x40(%rax),%esi
    1a60:	e8 6d 46 fe ff       	call   0xfffffffffffe60d2
    1a65:	89 c1                	mov    %eax,%ecx
    1a67:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1a6e:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    1a75:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1a79:	8b 75 fc             	mov    -0x4(%rbp),%esi
    1a7c:	8b 95 6c ff ff ff    	mov    -0x94(%rbp),%edx
    1a82:	89 d1                	mov    %edx,%ecx
    1a84:	89 f0                	mov    %esi,%eax
    1a86:	39 f2                	cmp    %esi,%edx
    1a88:	0f 4f c1             	cmovg  %ecx,%eax
    1a8b:	89 45 fc             	mov    %eax,-0x4(%rbp)
    1a8e:	e9 ff e7 ff ff       	jmp    0x292
    1a93:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    1a99:	83 f8 ff             	cmp    $0xffffffff,%eax
    1a9c:	7f 0e                	jg     0x1aac
    1a9e:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    1aa4:	85 c0                	test   %eax,%eax
    1aa6:	0f 85 72 33 00 00    	jne    0x4e1e
    1aac:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1ab0:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1ab3:	89 ca                	mov    %ecx,%edx
    1ab5:	f2 0f 10 44 10 38    	movsd  0x38(%rax,%rdx,1),%xmm0
    1abb:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    1ac0:	31 d2                	xor    %edx,%edx
    1ac2:	89 94 08 6c 01 00 00 	mov    %edx,0x16c(%rax,%rcx,1)
    1ac9:	66 48 0f 7e c0       	movq   %xmm0,%rax
    1ace:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    1ad2:	7f 38                	jg     0x1b0c
    1ad4:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    1ad9:	66 48 0f 7e c0       	movq   %xmm0,%rax
    1ade:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    1ae5:	00 00 80 
    1ae8:	48 31 c8             	xor    %rcx,%rax
    1aeb:	66 48 0f 6e c0       	movq   %rax,%xmm0
    1af0:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    1af5:	b8 01 00 00 00       	mov    $0x1,%eax
    1afa:	89 45 8c             	mov    %eax,-0x74(%rbp)
    1afd:	31 c0                	xor    %eax,%eax
    1aff:	89 45 90             	mov    %eax,-0x70(%rbp)
    1b02:	b8 d0 0d 00 00       	mov    $0xdd0,%eax
    1b07:	89 45 94             	mov    %eax,-0x6c(%rbp)
    1b0a:	eb 51                	jmp    0x1b5d
    1b0c:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    1b12:	25 00 08 00 00       	and    $0x800,%eax
    1b17:	85 c0                	test   %eax,%eax
    1b19:	74 17                	je     0x1b32
    1b1b:	b8 01 00 00 00       	mov    $0x1,%eax
    1b20:	89 45 8c             	mov    %eax,-0x74(%rbp)
    1b23:	31 c0                	xor    %eax,%eax
    1b25:	89 45 90             	mov    %eax,-0x70(%rbp)
    1b28:	b8 d3 0d 00 00       	mov    $0xdd3,%eax
    1b2d:	89 45 94             	mov    %eax,-0x6c(%rbp)
    1b30:	eb 2b                	jmp    0x1b5d
    1b32:	8b b5 68 ff ff ff    	mov    -0x98(%rbp),%esi
    1b38:	83 e6 01             	and    $0x1,%esi
    1b3b:	89 f0                	mov    %esi,%eax
    1b3d:	89 45 8c             	mov    %eax,-0x74(%rbp)
    1b40:	ba d6 0d 00 00       	mov    $0xdd6,%edx
    1b45:	b9 d1 0d 00 00       	mov    $0xdd1,%ecx
    1b4a:	85 f6                	test   %esi,%esi
    1b4c:	0f 45 ca             	cmovne %edx,%ecx
    1b4f:	89 4d 94             	mov    %ecx,-0x6c(%rbp)
    1b52:	85 c0                	test   %eax,%eax
    1b54:	0f 94 c0             	sete   %al
    1b57:	0f b6 c0             	movzbl %al,%eax
    1b5a:	89 45 90             	mov    %eax,-0x70(%rbp)
    1b5d:	f2 0f 10 85 f8 fe ff 	movsd  -0x108(%rbp),%xmm0
    1b64:	ff 
    1b65:	f2 0f 10 4d b0       	movsd  -0x50(%rbp),%xmm1
    1b6a:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
    1b71:	ff ff 7f 
    1b74:	66 48 0f 6e d0       	movq   %rax,%xmm2
    1b79:	66 0f 54 ca          	andpd  %xmm2,%xmm1
    1b7d:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    1b81:	0f 87 c5 03 00 00    	ja     0x1f4c
    1b87:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    1b8d:	8b 4d 8c             	mov    -0x74(%rbp),%ecx
    1b90:	8d 49 03             	lea    0x3(%rcx),%ecx
    1b93:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    1b99:	25 00 20 00 00       	and    $0x2000,%eax
    1b9e:	85 c0                	test   %eax,%eax
    1ba0:	0f 85 54 01 00 00    	jne    0x1cfa
    1ba6:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    1bac:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    1bb2:	39 c8                	cmp    %ecx,%eax
    1bb4:	0f 8e 40 01 00 00    	jle    0x1cfa
    1bba:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1bc1:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    1bc7:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    1bcd:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1bd0:	29 d0                	sub    %edx,%eax
    1bd2:	41 89 c0             	mov    %eax,%r8d
    1bd5:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    1bd9:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1be0:	0f 92 c2             	setb   %dl
    1be3:	0f b6 d2             	movzbl %dl,%edx
    1be6:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    1bec:	8d 71 40             	lea    0x40(%rcx),%esi
    1bef:	ba 20 00 00 00       	mov    $0x20,%edx
    1bf4:	b9 00 01 00 00       	mov    $0x100,%ecx
    1bf9:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1c00:	0f 42 c8             	cmovb  %eax,%ecx
    1c03:	e8 b0 45 fe ff       	call   0xfffffffffffe61b8
    1c08:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    1c0f:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    1c15:	89 c6                	mov    %eax,%esi
    1c17:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    1c1d:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    1c24:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    1c28:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    1c2b:	89 ca                	mov    %ecx,%edx
    1c2d:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    1c33:	83 e1 20             	and    $0x20,%ecx
    1c36:	85 c9                	test   %ecx,%ecx
    1c38:	0f 94 c1             	sete   %cl
    1c3b:	0f b6 c9             	movzbl %cl,%ecx
    1c3e:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    1c44:	85 c0                	test   %eax,%eax
    1c46:	75 79                	jne    0x1cc1
    1c48:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    1c4e:	83 e0 01             	and    $0x1,%eax
    1c51:	85 c0                	test   %eax,%eax
    1c53:	74 40                	je     0x1c95
    1c55:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1c5b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1c62:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1c65:	8d 70 40             	lea    0x40(%rax),%esi
    1c68:	ba 00 01 00 00       	mov    $0x100,%edx
    1c6d:	e8 60 44 fe ff       	call   0xfffffffffffe60d2
    1c72:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1c78:	89 c2                	mov    %eax,%edx
    1c7a:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1c81:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    1c88:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1c8c:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1c8f:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    1c95:	8b 45 fc             	mov    -0x4(%rbp),%eax
    1c98:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    1c9e:	83 e1 20             	and    $0x20,%ecx
    1ca1:	85 c9                	test   %ecx,%ecx
    1ca3:	0f 94 c1             	sete   %cl
    1ca6:	0f b6 c9             	movzbl %cl,%ecx
    1ca9:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    1caf:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    1cb5:	89 c1                	mov    %eax,%ecx
    1cb7:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    1cba:	3d ff 00 00 00       	cmp    $0xff,%eax
    1cbf:	77 87                	ja     0x1c48
    1cc1:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    1cc7:	85 c0                	test   %eax,%eax
    1cc9:	74 2f                	je     0x1cfa
    1ccb:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1cd2:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1cd8:	8b 55 fc             	mov    -0x4(%rbp),%edx
    1cdb:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1cde:	8d 70 40             	lea    0x40(%rax),%esi
    1ce1:	e8 ec 43 fe ff       	call   0xfffffffffffe60d2
    1ce6:	89 c1                	mov    %eax,%ecx
    1ce8:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1cef:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    1cf6:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1cfa:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1cfe:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1d04:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1d07:	89 c1                	mov    %eax,%ecx
    1d09:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    1d0c:	83 e0 20             	and    $0x20,%eax
    1d0f:	85 c0                	test   %eax,%eax
    1d11:	75 38                	jne    0x1d4b
    1d13:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1d19:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1d20:	8b 55 8c             	mov    -0x74(%rbp),%edx
    1d23:	8b 75 94             	mov    -0x6c(%rbp),%esi
    1d26:	e8 a7 43 fe ff       	call   0xfffffffffffe60d2
    1d2b:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1d31:	89 c2                	mov    %eax,%edx
    1d33:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1d3a:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    1d41:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1d45:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1d48:	89 45 fc             	mov    %eax,-0x4(%rbp)
    1d4b:	8b 45 fc             	mov    -0x4(%rbp),%eax
    1d4e:	83 e0 20             	and    $0x20,%eax
    1d51:	85 c0                	test   %eax,%eax
    1d53:	75 70                	jne    0x1dc5
    1d55:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1d5c:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1d62:	f2 0f 10 4d b0       	movsd  -0x50(%rbp),%xmm1
    1d67:	8b 75 80             	mov    -0x80(%rbp),%esi
    1d6a:	83 e6 20             	and    $0x20,%esi
    1d6d:	41 89 f0             	mov    %esi,%r8d
    1d70:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    1d74:	0f 28 c1             	movaps %xmm1,%xmm0
    1d77:	ba eb 0d 00 00       	mov    $0xdeb,%edx
    1d7c:	b8 ef 0d 00 00       	mov    $0xdef,%eax
    1d81:	85 f6                	test   %esi,%esi
    1d83:	0f 45 c2             	cmovne %edx,%eax
    1d86:	ba e3 0d 00 00       	mov    $0xde3,%edx
    1d8b:	be e7 0d 00 00       	mov    $0xde7,%esi
    1d90:	45 85 c0             	test   %r8d,%r8d
    1d93:	0f 45 f2             	cmovne %edx,%esi
    1d96:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    1d9a:	41 0f 9a c0          	setp   %r8b
    1d9e:	0f 95 c2             	setne  %dl
    1da1:	44 08 c2             	or     %r8b,%dl
    1da4:	0f 45 f0             	cmovne %eax,%esi
    1da7:	ba 03 00 00 00       	mov    $0x3,%edx
    1dac:	e8 21 43 fe ff       	call   0xfffffffffffe60d2
    1db1:	89 c1                	mov    %eax,%ecx
    1db3:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1dba:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    1dc1:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1dc5:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    1dcb:	25 00 20 01 00       	and    $0x12000,%eax
    1dd0:	3d 00 20 00 00       	cmp    $0x2000,%eax
    1dd5:	0f 85 54 01 00 00    	jne    0x1f2f
    1ddb:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    1de1:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    1de7:	39 c8                	cmp    %ecx,%eax
    1de9:	0f 8e 40 01 00 00    	jle    0x1f2f
    1def:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1df6:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    1dfc:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    1e02:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1e05:	29 d0                	sub    %edx,%eax
    1e07:	41 89 c0             	mov    %eax,%r8d
    1e0a:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    1e0e:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1e15:	0f 92 c2             	setb   %dl
    1e18:	0f b6 d2             	movzbl %dl,%edx
    1e1b:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    1e21:	8d 71 40             	lea    0x40(%rcx),%esi
    1e24:	ba 20 00 00 00       	mov    $0x20,%edx
    1e29:	b9 00 01 00 00       	mov    $0x100,%ecx
    1e2e:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    1e35:	0f 42 c8             	cmovb  %eax,%ecx
    1e38:	e8 7b 43 fe ff       	call   0xfffffffffffe61b8
    1e3d:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    1e44:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    1e4a:	89 c6                	mov    %eax,%esi
    1e4c:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    1e52:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    1e59:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    1e5d:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    1e60:	89 ca                	mov    %ecx,%edx
    1e62:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    1e68:	83 e1 20             	and    $0x20,%ecx
    1e6b:	85 c9                	test   %ecx,%ecx
    1e6d:	0f 94 c1             	sete   %cl
    1e70:	0f b6 c9             	movzbl %cl,%ecx
    1e73:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    1e79:	85 c0                	test   %eax,%eax
    1e7b:	75 79                	jne    0x1ef6
    1e7d:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    1e83:	83 e0 01             	and    $0x1,%eax
    1e86:	85 c0                	test   %eax,%eax
    1e88:	74 40                	je     0x1eca
    1e8a:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1e90:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1e97:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1e9a:	8d 70 40             	lea    0x40(%rax),%esi
    1e9d:	ba 00 01 00 00       	mov    $0x100,%edx
    1ea2:	e8 2b 42 fe ff       	call   0xfffffffffffe60d2
    1ea7:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1ead:	89 c2                	mov    %eax,%edx
    1eaf:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1eb6:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    1ebd:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1ec1:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    1ec4:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    1eca:	8b 45 fc             	mov    -0x4(%rbp),%eax
    1ecd:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    1ed3:	83 e1 20             	and    $0x20,%ecx
    1ed6:	85 c9                	test   %ecx,%ecx
    1ed8:	0f 94 c1             	sete   %cl
    1edb:	0f b6 c9             	movzbl %cl,%ecx
    1ede:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    1ee4:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    1eea:	89 c1                	mov    %eax,%ecx
    1eec:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    1eef:	3d ff 00 00 00       	cmp    $0xff,%eax
    1ef4:	77 87                	ja     0x1e7d
    1ef6:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    1efc:	85 c0                	test   %eax,%eax
    1efe:	74 2f                	je     0x1f2f
    1f00:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1f07:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    1f0d:	8b 55 fc             	mov    -0x4(%rbp),%edx
    1f10:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1f13:	8d 70 40             	lea    0x40(%rax),%esi
    1f16:	e8 b7 41 fe ff       	call   0xfffffffffffe60d2
    1f1b:	89 c1                	mov    %eax,%ecx
    1f1d:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1f24:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    1f2b:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1f2f:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    1f35:	8b 95 6c ff ff ff    	mov    -0x94(%rbp),%edx
    1f3b:	89 d1                	mov    %edx,%ecx
    1f3d:	89 f0                	mov    %esi,%eax
    1f3f:	39 f2                	cmp    %esi,%edx
    1f41:	0f 4f c1             	cmovg  %ecx,%eax
    1f44:	89 45 fc             	mov    %eax,-0x4(%rbp)
    1f47:	e9 c7 2e 00 00       	jmp    0x4e13
    1f4c:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    1f51:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    1f58:	8b 45 cc             	mov    -0x34(%rbp),%eax
    1f5b:	8d b0 6c 01 00 00    	lea    0x16c(%rax),%esi
    1f61:	e8 98 42 fe ff       	call   0xfffffffffffe61fe
    1f66:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    1f6d:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    1f74:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    1f78:	0f 28 c8             	movaps %xmm0,%xmm1
    1f7b:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    1f7f:	0f 28 c8             	movaps %xmm0,%xmm1
    1f82:	f2 0f 11 4d b0       	movsd  %xmm1,-0x50(%rbp)
    1f87:	0f 57 c9             	xorps  %xmm1,%xmm1
    1f8a:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    1f8e:	0f 94 c0             	sete   %al
    1f91:	0f 9b c1             	setnp  %cl
    1f94:	20 c8                	and    %cl,%al
    1f96:	0f b6 c0             	movzbl %al,%eax
    1f99:	85 c0                	test   %eax,%eax
    1f9b:	75 34                	jne    0x1fd1
    1f9d:	8b 45 80             	mov    -0x80(%rbp),%eax
    1fa0:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    1fa4:	8b 75 cc             	mov    -0x34(%rbp),%esi
    1fa7:	89 f2                	mov    %esi,%edx
    1fa9:	8b b4 31 6c 01 00 00 	mov    0x16c(%rcx,%rsi,1),%esi
    1fb0:	89 f7                	mov    %esi,%edi
    1fb2:	89 7d fc             	mov    %edi,-0x4(%rbp)
    1fb5:	8d 76 ff             	lea    -0x1(%rsi),%esi
    1fb8:	89 b4 11 6c 01 00 00 	mov    %esi,0x16c(%rcx,%rdx,1)
    1fbf:	83 c8 20             	or     $0x20,%eax
    1fc2:	89 c1                	mov    %eax,%ecx
    1fc4:	89 4d 88             	mov    %ecx,-0x78(%rbp)
    1fc7:	83 f8 61             	cmp    $0x61,%eax
    1fca:	75 47                	jne    0x2013
    1fcc:	e9 44 23 00 00       	jmp    0x4315
    1fd1:	8b 45 80             	mov    -0x80(%rbp),%eax
    1fd4:	83 c8 20             	or     $0x20,%eax
    1fd7:	89 c1                	mov    %eax,%ecx
    1fd9:	89 4d 88             	mov    %ecx,-0x78(%rbp)
    1fdc:	83 f8 61             	cmp    $0x61,%eax
    1fdf:	0f 84 30 23 00 00    	je     0x4315
    1fe5:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    1fe9:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    1fec:	8b bd 60 ff ff ff    	mov    -0xa0(%rbp),%edi
    1ff2:	89 fa                	mov    %edi,%edx
    1ff4:	be 06 00 00 00       	mov    $0x6,%esi
    1ff9:	85 ff                	test   %edi,%edi
    1ffb:	0f 4c d6             	cmovl  %esi,%edx
    1ffe:	89 95 7c ff ff ff    	mov    %edx,-0x84(%rbp)
    2004:	8b 84 08 6c 01 00 00 	mov    0x16c(%rax,%rcx,1),%eax
    200b:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2011:	eb 4a                	jmp    0x205d
    2013:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    2018:	f2 0f 10 8d 00 ff ff 	movsd  -0x100(%rbp),%xmm1
    201f:	ff 
    2020:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
    2026:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    202a:	8b 75 fc             	mov    -0x4(%rbp),%esi
    202d:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    2030:	8d 76 e3             	lea    -0x1d(%rsi),%esi
    2033:	89 f7                	mov    %esi,%edi
    2035:	89 bd 54 ff ff ff    	mov    %edi,-0xac(%rbp)
    203b:	89 b4 08 6c 01 00 00 	mov    %esi,0x16c(%rax,%rcx,1)
    2042:	89 d0                	mov    %edx,%eax
    2044:	b9 06 00 00 00       	mov    $0x6,%ecx
    2049:	85 d2                	test   %edx,%edx
    204b:	0f 4c c1             	cmovl  %ecx,%eax
    204e:	89 85 7c ff ff ff    	mov    %eax,-0x84(%rbp)
    2054:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    2058:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    205d:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    2063:	8b 45 e4             	mov    -0x1c(%rbp),%eax
    2066:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    2069:	85 d2                	test   %edx,%edx
    206b:	40 0f 9c c6          	setl   %sil
    206f:	40 0f b6 f6          	movzbl %sil,%esi
    2073:	89 75 98             	mov    %esi,-0x68(%rbp)
    2076:	8d 89 70 01 00 00    	lea    0x170(%rcx),%ecx
    207c:	85 d2                	test   %edx,%edx
    207e:	0f 4c c1             	cmovl  %ecx,%eax
    2081:	89 c1                	mov    %eax,%ecx
    2083:	89 4d 84             	mov    %ecx,-0x7c(%rbp)
    2086:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    208c:	f2 0f 10 8d 08 ff ff 	movsd  -0xf8(%rbp),%xmm1
    2093:	ff 
    2094:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    2099:	0f 28 d0             	movaps %xmm0,%xmm2
    209c:	66 0f 2e ca          	ucomisd %xmm2,%xmm1
    20a0:	0f 97 c0             	seta   %al
    20a3:	0f b6 c0             	movzbl %al,%eax
    20a6:	0f 57 c9             	xorps  %xmm1,%xmm1
    20a9:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    20ad:	0f 93 c1             	setae  %cl
    20b0:	0f b6 c9             	movzbl %cl,%ecx
    20b3:	21 c8                	and    %ecx,%eax
    20b5:	85 c0                	test   %eax,%eax
    20b7:	74 48                	je     0x2101
    20b9:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    20be:	f2 0f 11 85 b8 fe ff 	movsd  %xmm0,-0x148(%rbp)
    20c5:	ff 
    20c6:	f2 48 0f 2c c0       	cvttsd2si %xmm0,%rax
    20cb:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
    20d2:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    20d7:	48 39 c8             	cmp    %rcx,%rax
    20da:	76 17                	jbe    0x20f3
    20dc:	f2 0f 10 85 b8 fe ff 	movsd  -0x148(%rbp),%xmm0
    20e3:	ff 
    20e4:	66 0f 2e c0          	ucomisd %xmm0,%xmm0
    20e8:	0f 8a 82 2d 00 00    	jp     0x4e70
    20ee:	e9 70 2d 00 00       	jmp    0x4e63
    20f3:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
    20fa:	89 c0                	mov    %eax,%eax
    20fc:	89 45 fc             	mov    %eax,-0x4(%rbp)
    20ff:	eb 05                	jmp    0x2106
    2101:	31 c0                	xor    %eax,%eax
    2103:	89 45 fc             	mov    %eax,-0x4(%rbp)
    2106:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    210b:	f2 0f 10 8d 10 ff ff 	movsd  -0xf0(%rbp),%xmm1
    2112:	ff 
    2113:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2116:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    211c:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    2120:	89 ce                	mov    %ecx,%esi
    2122:	89 c7                	mov    %eax,%edi
    2124:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
    2127:	8d 49 04             	lea    0x4(%rcx),%ecx
    212a:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    2130:	0f 57 d2             	xorps  %xmm2,%xmm2
    2133:	f2 48 0f 2a d0       	cvtsi2sd %rax,%xmm2
    2138:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    213c:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    2140:	0f 28 c8             	movaps %xmm0,%xmm1
    2143:	f2 0f 11 4d b0       	movsd  %xmm1,-0x50(%rbp)
    2148:	0f 57 c9             	xorps  %xmm1,%xmm1
    214b:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    214f:	0f 95 c0             	setne  %al
    2152:	0f 9a c1             	setp   %cl
    2155:	08 c8                	or     %cl,%al
    2157:	0f b6 c0             	movzbl %al,%eax
    215a:	85 c0                	test   %eax,%eax
    215c:	0f 85 2a ff ff ff    	jne    0x208c
    2162:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    2168:	83 f8 01             	cmp    $0x1,%eax
    216b:	7d 17                	jge    0x2184
    216d:	8b 45 84             	mov    -0x7c(%rbp),%eax
    2170:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    2176:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2179:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    217f:	e9 4b 01 00 00       	jmp    0x22cf
    2184:	8b 45 84             	mov    -0x7c(%rbp),%eax
    2187:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    218d:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    2193:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2199:	8b bd 54 ff ff ff    	mov    -0xac(%rbp),%edi
    219f:	89 fe                	mov    %edi,%esi
    21a1:	ba 1d 00 00 00       	mov    $0x1d,%edx
    21a6:	83 ff 1d             	cmp    $0x1d,%edi
    21a9:	0f 4c d6             	cmovl  %esi,%edx
    21ac:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    21b2:	8d 40 fc             	lea    -0x4(%rax),%eax
    21b5:	89 c2                	mov    %eax,%edx
    21b7:	89 55 fc             	mov    %edx,-0x4(%rbp)
    21ba:	39 c8                	cmp    %ecx,%eax
    21bc:	0f 82 a7 00 00 00    	jb     0x2269
    21c2:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    21c8:	89 c0                	mov    %eax,%eax
    21ca:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    21ce:	31 c0                	xor    %eax,%eax
    21d0:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    21d4:	44 8b 45 fc          	mov    -0x4(%rbp),%r8d
    21d8:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
    21dc:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    21e0:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
    21e4:	44 89 c6             	mov    %r8d,%esi
    21e7:	42 8b 3c 07          	mov    (%rdi,%r8,1),%edi
    21eb:	48 d3 e7             	shl    %cl,%rdi
    21ee:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    21f4:	49 b8 ff ff ff ff 00 	movabs $0xffffffff,%r8
    21fb:	00 00 00 
    21fe:	4c 21 c0             	and    %r8,%rax
    2201:	48 01 c7             	add    %rax,%rdi
    2204:	48 89 f8             	mov    %rdi,%rax
    2207:	41 b8 00 ca 9a 3b    	mov    $0x3b9aca00,%r8d
    220d:	48 31 d2             	xor    %rdx,%rdx
    2210:	49 f7 f0             	div    %r8
    2213:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    2217:	49 89 c0             	mov    %rax,%r8
    221a:	8b 45 fc             	mov    -0x4(%rbp),%eax
    221d:	4d 89 c1             	mov    %r8,%r9
    2220:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    2224:	4d 69 c0 00 ca 9a 3b 	imul   $0x3b9aca00,%r8,%r8
    222b:	4c 29 c7             	sub    %r8,%rdi
    222e:	89 ff                	mov    %edi,%edi
    2230:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
    2233:	8d 40 fc             	lea    -0x4(%rax),%eax
    2236:	89 c2                	mov    %eax,%edx
    2238:	89 55 fc             	mov    %edx,-0x4(%rbp)
    223b:	39 c8                	cmp    %ecx,%eax
    223d:	73 95                	jae    0x21d4
    223f:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    2243:	89 c0                	mov    %eax,%eax
    2245:	89 c1                	mov    %eax,%ecx
    2247:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    224a:	85 c0                	test   %eax,%eax
    224c:	74 1b                	je     0x2269
    224e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2252:	8b 55 fc             	mov    -0x4(%rbp),%edx
    2255:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    225b:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    225e:	89 ce                	mov    %ecx,%esi
    2260:	89 b5 58 ff ff ff    	mov    %esi,-0xa8(%rbp)
    2266:	89 14 08             	mov    %edx,(%rax,%rcx,1)
    2269:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    226f:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2275:	89 c2                	mov    %eax,%edx
    2277:	89 55 fc             	mov    %edx,-0x4(%rbp)
    227a:	39 c8                	cmp    %ecx,%eax
    227c:	76 19                	jbe    0x2297
    227e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2282:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    2285:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    2288:	89 ca                	mov    %ecx,%edx
    228a:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    2290:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    2293:	85 c0                	test   %eax,%eax
    2295:	74 d2                	je     0x2269
    2297:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    229d:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    22a0:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    22a4:	8b 7d cc             	mov    -0x34(%rbp),%edi
    22a7:	89 fe                	mov    %edi,%esi
    22a9:	8b bc 3a 6c 01 00 00 	mov    0x16c(%rdx,%rdi,1),%edi
    22b0:	29 c7                	sub    %eax,%edi
    22b2:	89 f8                	mov    %edi,%eax
    22b4:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    22ba:	89 bc 32 6c 01 00 00 	mov    %edi,0x16c(%rdx,%rsi,1)
    22c1:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    22c7:	85 c0                	test   %eax,%eax
    22c9:	0f 8f be fe ff ff    	jg     0x218d
    22cf:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    22d5:	83 f8 ff             	cmp    $0xffffffff,%eax
    22d8:	0f 8f cb 01 00 00    	jg     0x24a9
    22de:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    22e4:	8d 40 19             	lea    0x19(%rax),%eax
    22e7:	b9 09 00 00 00       	mov    $0x9,%ecx
    22ec:	89 c0                	mov    %eax,%eax
    22ee:	48 69 c0 39 8e e3 38 	imul   $0x38e38e39,%rax,%rax
    22f5:	48 c1 e8 21          	shr    $0x21,%rax
    22f9:	89 c0                	mov    %eax,%eax
    22fb:	8d 40 01             	lea    0x1(%rax),%eax
    22fe:	89 85 70 ff ff ff    	mov    %eax,-0x90(%rbp)
    2304:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    2307:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    230d:	8b bd 54 ff ff ff    	mov    -0xac(%rbp),%edi
    2313:	41 89 f8             	mov    %edi,%r8d
    2316:	be 09 00 00 00       	mov    $0x9,%esi
    231b:	31 d2                	xor    %edx,%edx
    231d:	44 29 c2             	sub    %r8d,%edx
    2320:	83 ff f7             	cmp    $0xfffffff7,%edi
    2323:	0f 4c d6             	cmovl  %esi,%edx
    2326:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    232c:	39 c8                	cmp    %ecx,%eax
    232e:	72 24                	jb     0x2354
    2330:	8b b5 58 ff ff ff    	mov    -0xa8(%rbp),%esi
    2336:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    233a:	89 f1                	mov    %esi,%ecx
    233c:	89 f0                	mov    %esi,%eax
    233e:	8b 14 32             	mov    (%rdx,%rsi,1),%edx
    2341:	8d 40 04             	lea    0x4(%rax),%eax
    2344:	85 d2                	test   %edx,%edx
    2346:	0f 45 c1             	cmovne %ecx,%eax
    2349:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    234f:	e9 df 00 00 00       	jmp    0x2433
    2354:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    235a:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    2360:	ba 00 ca 9a 3b       	mov    $0x3b9aca00,%edx
    2365:	d3 ea                	shr    %cl,%edx
    2367:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    236d:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    2373:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    2378:	d3 e2                	shl    %cl,%edx
    237a:	89 d1                	mov    %edx,%ecx
    237c:	81 f1 ff ff ff ff    	xor    $0xffffffff,%ecx
    2382:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
    2388:	31 c9                	xor    %ecx,%ecx
    238a:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    2390:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    2396:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    239c:	44 8b 9d 54 ff ff ff 	mov    -0xac(%rbp),%r11d
    23a3:	8b b5 78 ff ff ff    	mov    -0x88(%rbp),%esi
    23a9:	8b bd 74 ff ff ff    	mov    -0x8c(%rbp),%edi
    23af:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
    23b3:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    23b9:	41 89 c1             	mov    %eax,%r9d
    23bc:	89 c2                	mov    %eax,%edx
    23be:	45 8b 14 10          	mov    (%r8,%rdx,1),%r10d
    23c2:	44 89 d2             	mov    %r10d,%edx
    23c5:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    23cb:	41 d3 ea             	shr    %cl,%r10d
    23ce:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    23d1:	45 01 da             	add    %r11d,%r10d
    23d4:	47 89 14 08          	mov    %r10d,(%r8,%r9,1)
    23d8:	21 fa                	and    %edi,%edx
    23da:	0f af d6             	imul   %esi,%edx
    23dd:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    23e3:	8d 40 04             	lea    0x4(%rax),%eax
    23e6:	89 c2                	mov    %eax,%edx
    23e8:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    23ee:	39 c8                	cmp    %ecx,%eax
    23f0:	72 a4                	jb     0x2396
    23f2:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    23f8:	8b bd 58 ff ff ff    	mov    -0xa8(%rbp),%edi
    23fe:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    2402:	89 fa                	mov    %edi,%edx
    2404:	89 f9                	mov    %edi,%ecx
    2406:	8b 34 3e             	mov    (%rsi,%rdi,1),%esi
    2409:	8d 49 04             	lea    0x4(%rcx),%ecx
    240c:	85 f6                	test   %esi,%esi
    240e:	0f 45 ca             	cmovne %edx,%ecx
    2411:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    2417:	85 c0                	test   %eax,%eax
    2419:	74 18                	je     0x2433
    241b:	8b 45 fc             	mov    -0x4(%rbp),%eax
    241e:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    2422:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    2428:	89 c2                	mov    %eax,%edx
    242a:	89 34 11             	mov    %esi,(%rcx,%rdx,1)
    242d:	8d 40 04             	lea    0x4(%rax),%eax
    2430:	89 45 fc             	mov    %eax,-0x4(%rbp)
    2433:	8b 75 fc             	mov    -0x4(%rbp),%esi
    2436:	8b bd 70 ff ff ff    	mov    -0x90(%rbp),%edi
    243c:	44 8b 45 88          	mov    -0x78(%rbp),%r8d
    2440:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    2446:	8b 4d 84             	mov    -0x7c(%rbp),%ecx
    2449:	4c 8b 4d c0          	mov    -0x40(%rbp),%r9
    244d:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    2453:	44 8b 5d cc          	mov    -0x34(%rbp),%r11d
    2457:	45 89 da             	mov    %r11d,%r10d
    245a:	47 8b 9c 19 6c 01 00 	mov    0x16c(%r9,%r11,1),%r11d
    2461:	00 
    2462:	41 01 c3             	add    %eax,%r11d
    2465:	44 89 d8             	mov    %r11d,%eax
    2468:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    246e:	47 89 9c 11 6c 01 00 	mov    %r11d,0x16c(%r9,%r10,1)
    2475:	00 
    2476:	41 83 f8 66          	cmp    $0x66,%r8d
    247a:	0f 44 d1             	cmove  %ecx,%edx
    247d:	41 89 d0             	mov    %edx,%r8d
    2480:	44 89 85 5c ff ff ff 	mov    %r8d,-0xa4(%rbp)
    2487:	41 89 f9             	mov    %edi,%r9d
    248a:	89 f1                	mov    %esi,%ecx
    248c:	41 c1 e1 02          	shl    $0x2,%r9d
    2490:	44 01 ca             	add    %r9d,%edx
    2493:	44 29 c6             	sub    %r8d,%esi
    2496:	c1 fe 02             	sar    $0x2,%esi
    2499:	39 fe                	cmp    %edi,%esi
    249b:	0f 4f ca             	cmovg  %edx,%ecx
    249e:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    24a1:	85 c0                	test   %eax,%eax
    24a3:	0f 8c 5b fe ff ff    	jl     0x2304
    24a9:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    24ac:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    24b2:	31 d2                	xor    %edx,%edx
    24b4:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    24ba:	39 c8                	cmp    %ecx,%eax
    24bc:	73 62                	jae    0x2520
    24be:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    24c2:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    24c8:	8b 55 84             	mov    -0x7c(%rbp),%edx
    24cb:	89 ce                	mov    %ecx,%esi
    24cd:	29 f2                	sub    %esi,%edx
    24cf:	c1 fa 02             	sar    $0x2,%edx
    24d2:	6b d2 09             	imul   $0x9,%edx,%edx
    24d5:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    24db:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    24de:	89 c1                	mov    %eax,%ecx
    24e0:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
    24e6:	83 f8 0a             	cmp    $0xa,%eax
    24e9:	72 35                	jb     0x2520
    24eb:	b8 0a 00 00 00       	mov    $0xa,%eax
    24f0:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    24f6:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    24fc:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    2502:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    2508:	8d 52 01             	lea    0x1(%rdx),%edx
    250b:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    2511:	6b c9 0a             	imul   $0xa,%ecx,%ecx
    2514:	89 ca                	mov    %ecx,%edx
    2516:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    251c:	39 c8                	cmp    %ecx,%eax
    251e:	73 d6                	jae    0x24f6
    2520:	8b 55 84             	mov    -0x7c(%rbp),%edx
    2523:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    2526:	8b 7d 88             	mov    -0x78(%rbp),%edi
    2529:	8b b5 7c ff ff ff    	mov    -0x84(%rbp),%esi
    252f:	44 8b 85 5c ff ff ff 	mov    -0xa4(%rbp),%r8d
    2536:	89 f0                	mov    %esi,%eax
    2538:	41 89 fa             	mov    %edi,%r10d
    253b:	83 ff 67             	cmp    $0x67,%edi
    253e:	40 0f 94 c7          	sete   %dil
    2542:	40 0f b6 ff          	movzbl %dil,%edi
    2546:	41 89 f9             	mov    %edi,%r9d
    2549:	44 89 8d 70 ff ff ff 	mov    %r9d,-0x90(%rbp)
    2550:	45 31 c9             	xor    %r9d,%r9d
    2553:	41 83 fa 66          	cmp    $0x66,%r10d
    2557:	45 0f 44 c1          	cmove  %r9d,%r8d
    255b:	44 29 c0             	sub    %r8d,%eax
    255e:	85 f6                	test   %esi,%esi
    2560:	40 0f 95 c6          	setne  %sil
    2564:	40 0f b6 f6          	movzbl %sil,%esi
    2568:	21 fe                	and    %edi,%esi
    256a:	29 f0                	sub    %esi,%eax
    256c:	89 c6                	mov    %eax,%esi
    256e:	89 b5 54 ff ff ff    	mov    %esi,-0xac(%rbp)
    2574:	29 d1                	sub    %edx,%ecx
    2576:	c1 f9 02             	sar    $0x2,%ecx
    2579:	6b c9 09             	imul   $0x9,%ecx,%ecx
    257c:	8d 49 f7             	lea    -0x9(%rcx),%ecx
    257f:	39 c8                	cmp    %ecx,%eax
    2581:	0f 8d 53 04 00 00    	jge    0x29da
    2587:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    258d:	8d 80 00 24 00 00    	lea    0x2400(%rax),%eax
    2593:	89 c1                	mov    %eax,%ecx
    2595:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    259b:	89 85 b0 fe ff ff    	mov    %eax,-0x150(%rbp)
    25a1:	b9 09 00 00 00       	mov    $0x9,%ecx
    25a6:	89 8d b4 fe ff ff    	mov    %ecx,-0x14c(%rbp)
    25ac:	3d 00 00 00 80       	cmp    $0x80000000,%eax
    25b1:	75 0f                	jne    0x25c2
    25b3:	8b 85 b4 fe ff ff    	mov    -0x14c(%rbp),%eax
    25b9:	83 f8 ff             	cmp    $0xffffffff,%eax
    25bc:	0f 84 a1 28 00 00    	je     0x4e63
    25c2:	44 8b 45 98          	mov    -0x68(%rbp),%r8d
    25c6:	8b 75 dc             	mov    -0x24(%rbp),%esi
    25c9:	8b 7d e0             	mov    -0x20(%rbp),%edi
    25cc:	8b 8d b4 fe ff ff    	mov    -0x14c(%rbp),%ecx
    25d2:	8b 85 b0 fe ff ff    	mov    -0x150(%rbp),%eax
    25d8:	99                   	cltd
    25d9:	f7 f9                	idiv   %ecx
    25db:	89 c2                	mov    %eax,%edx
    25dd:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    25e3:	89 d1                	mov    %edx,%ecx
    25e5:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    25eb:	c1 e2 02             	shl    $0x2,%edx
    25ee:	45 85 c0             	test   %r8d,%r8d
    25f1:	0f 45 f7             	cmovne %edi,%esi
    25f4:	01 f2                	add    %esi,%edx
    25f6:	89 d6                	mov    %edx,%esi
    25f8:	89 75 98             	mov    %esi,-0x68(%rbp)
    25fb:	8d 92 00 f0 ff ff    	lea    -0x1000(%rdx),%edx
    2601:	89 95 74 ff ff ff    	mov    %edx,-0x8c(%rbp)
    2607:	ba 0a 00 00 00       	mov    $0xa,%edx
    260c:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    2612:	6b c9 09             	imul   $0x9,%ecx,%ecx
    2615:	29 c8                	sub    %ecx,%eax
    2617:	89 c1                	mov    %eax,%ecx
    2619:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    261f:	83 f8 07             	cmp    $0x7,%eax
    2622:	7f 54                	jg     0x2678
    2624:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    262a:	8d 40 f8             	lea    -0x8(%rax),%eax
    262d:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2633:	b8 0a 00 00 00       	mov    $0xa,%eax
    2638:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
    263e:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    2644:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    264a:	6b c0 0a             	imul   $0xa,%eax,%eax
    264d:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
    2653:	89 d0                	mov    %edx,%eax
    2655:	8d 40 01             	lea    0x1(%rax),%eax
    2658:	89 c1                	mov    %eax,%ecx
    265a:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    2660:	39 d0                	cmp    %edx,%eax
    2662:	0f 93 c0             	setae  %al
    2665:	0f b6 c0             	movzbl %al,%eax
    2668:	89 85 78 ff ff ff    	mov    %eax,-0x88(%rbp)
    266e:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    2674:	85 c0                	test   %eax,%eax
    2676:	75 c6                	jne    0x263e
    2678:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    267b:	8b b5 74 ff ff ff    	mov    -0x8c(%rbp),%esi
    2681:	8b bd 64 ff ff ff    	mov    -0x9c(%rbp),%edi
    2687:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    268b:	8b 04 30             	mov    (%rax,%rsi,1),%eax
    268e:	89 85 ac fe ff ff    	mov    %eax,-0x154(%rbp)
    2694:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    269a:	89 fe                	mov    %edi,%esi
    269c:	31 d2                	xor    %edx,%edx
    269e:	f7 f6                	div    %esi
    26a0:	8b 95 ac fe ff ff    	mov    -0x154(%rbp),%edx
    26a6:	89 c6                	mov    %eax,%esi
    26a8:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
    26ae:	41 89 f0             	mov    %esi,%r8d
    26b1:	44 89 85 78 ff ff ff 	mov    %r8d,-0x88(%rbp)
    26b8:	0f af f7             	imul   %edi,%esi
    26bb:	29 f2                	sub    %esi,%edx
    26bd:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    26c3:	8d 40 04             	lea    0x4(%rax),%eax
    26c6:	89 c2                	mov    %eax,%edx
    26c8:	89 55 88             	mov    %edx,-0x78(%rbp)
    26cb:	39 c8                	cmp    %ecx,%eax
    26cd:	75 0e                	jne    0x26dd
    26cf:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    26d5:	85 c0                	test   %eax,%eax
    26d7:	0f 84 df 02 00 00    	je     0x29bc
    26dd:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    26e3:	83 e0 01             	and    $0x1,%eax
    26e6:	85 c0                	test   %eax,%eax
    26e8:	75 42                	jne    0x272c
    26ea:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    26f0:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
    26f6:	f2 0f 10 85 18 ff ff 	movsd  -0xe8(%rbp),%xmm0
    26fd:	ff 
    26fe:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    2703:	39 c8                	cmp    %ecx,%eax
    2705:	76 32                	jbe    0x2739
    2707:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    270d:	3d 00 ca 9a 3b       	cmp    $0x3b9aca00,%eax
    2712:	75 25                	jne    0x2739
    2714:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2718:	8b 8d 74 ff ff ff    	mov    -0x8c(%rbp),%ecx
    271e:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    2721:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    2725:	83 e0 01             	and    $0x1,%eax
    2728:	85 c0                	test   %eax,%eax
    272a:	74 0d                	je     0x2739
    272c:	f2 0f 10 85 20 ff ff 	movsd  -0xe0(%rbp),%xmm0
    2733:	ff 
    2734:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    2739:	f2 0f 10 85 30 ff ff 	movsd  -0xd0(%rbp),%xmm0
    2740:	ff 
    2741:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    2747:	8b 7d fc             	mov    -0x4(%rbp),%edi
    274a:	44 8b 45 88          	mov    -0x78(%rbp),%r8d
    274e:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    2754:	89 f0                	mov    %esi,%eax
    2756:	c1 e9 01             	shr    $0x1,%ecx
    2759:	89 ca                	mov    %ecx,%edx
    275b:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    2761:	44 89 85 90 fe ff ff 	mov    %r8d,-0x170(%rbp)
    2768:	89 bd 94 fe ff ff    	mov    %edi,-0x16c(%rbp)
    276e:	89 b5 98 fe ff ff    	mov    %esi,-0x168(%rbp)
    2774:	89 95 9c fe ff ff    	mov    %edx,-0x164(%rbp)
    277a:	39 c8                	cmp    %ecx,%eax
    277c:	f2 0f 11 85 a0 fe ff 	movsd  %xmm0,-0x160(%rbp)
    2783:	ff 
    2784:	74 10                	je     0x2796
    2786:	f2 0f 10 85 38 ff ff 	movsd  -0xc8(%rbp),%xmm0
    278d:	ff 
    278e:	f2 0f 11 85 a0 fe ff 	movsd  %xmm0,-0x160(%rbp)
    2795:	ff 
    2796:	f2 0f 10 85 a0 fe ff 	movsd  -0x160(%rbp),%xmm0
    279d:	ff 
    279e:	8b 85 90 fe ff ff    	mov    -0x170(%rbp),%eax
    27a4:	8b 8d 94 fe ff ff    	mov    -0x16c(%rbp),%ecx
    27aa:	39 c8                	cmp    %ecx,%eax
    27ac:	f2 0f 11 85 88 fe ff 	movsd  %xmm0,-0x178(%rbp)
    27b3:	ff 
    27b4:	74 10                	je     0x27c6
    27b6:	f2 0f 10 85 38 ff ff 	movsd  -0xc8(%rbp),%xmm0
    27bd:	ff 
    27be:	f2 0f 11 85 88 fe ff 	movsd  %xmm0,-0x178(%rbp)
    27c5:	ff 
    27c6:	f2 0f 10 85 28 ff ff 	movsd  -0xd8(%rbp),%xmm0
    27cd:	ff 
    27ce:	8b 85 98 fe ff ff    	mov    -0x168(%rbp),%eax
    27d4:	8b 8d 9c fe ff ff    	mov    -0x164(%rbp),%ecx
    27da:	39 c8                	cmp    %ecx,%eax
    27dc:	f2 0f 11 85 80 fe ff 	movsd  %xmm0,-0x180(%rbp)
    27e3:	ff 
    27e4:	72 10                	jb     0x27f6
    27e6:	f2 0f 10 85 88 fe ff 	movsd  -0x178(%rbp),%xmm0
    27ed:	ff 
    27ee:	f2 0f 11 85 80 fe ff 	movsd  %xmm0,-0x180(%rbp)
    27f5:	ff 
    27f6:	8b 45 90             	mov    -0x70(%rbp),%eax
    27f9:	f2 0f 10 85 80 fe ff 	movsd  -0x180(%rbp),%xmm0
    2800:	ff 
    2801:	f2 0f 11 45 b8       	movsd  %xmm0,-0x48(%rbp)
    2806:	85 c0                	test   %eax,%eax
    2808:	75 52                	jne    0x285c
    280a:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    280e:	8b 4d 94             	mov    -0x6c(%rbp),%ecx
    2811:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    2815:	83 f8 2d             	cmp    $0x2d,%eax
    2818:	75 42                	jne    0x285c
    281a:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    281f:	f2 0f 10 4d b8       	movsd  -0x48(%rbp),%xmm1
    2824:	66 48 0f 7e c8       	movq   %xmm1,%rax
    2829:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    2830:	00 00 80 
    2833:	48 31 c8             	xor    %rcx,%rax
    2836:	66 48 0f 6e c8       	movq   %rax,%xmm1
    283b:	f2 0f 11 4d b8       	movsd  %xmm1,-0x48(%rbp)
    2840:	66 48 0f 7e c0       	movq   %xmm0,%rax
    2845:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    284c:	00 00 80 
    284f:	48 31 c8             	xor    %rcx,%rax
    2852:	66 48 0f 6e c0       	movq   %rax,%xmm0
    2857:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    285c:	f2 0f 10 4d b0       	movsd  -0x50(%rbp),%xmm1
    2861:	f2 0f 10 55 b8       	movsd  -0x48(%rbp),%xmm2
    2866:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    286a:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    2870:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
    2876:	8b 8d 74 ff ff ff    	mov    -0x8c(%rbp),%ecx
    287c:	29 f2                	sub    %esi,%edx
    287e:	89 d6                	mov    %edx,%esi
    2880:	89 b5 54 ff ff ff    	mov    %esi,-0xac(%rbp)
    2886:	89 14 08             	mov    %edx,(%rax,%rcx,1)
    2889:	0f 28 c1             	movaps %xmm1,%xmm0
    288c:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
    2890:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    2894:	0f 94 c0             	sete   %al
    2897:	0f 9b c1             	setnp  %cl
    289a:	20 c8                	and    %cl,%al
    289c:	0f b6 c0             	movzbl %al,%eax
    289f:	85 c0                	test   %eax,%eax
    28a1:	0f 85 15 01 00 00    	jne    0x29bc
    28a7:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    28ab:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    28b1:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    28b7:	8b 95 74 ff ff ff    	mov    -0x8c(%rbp),%edx
    28bd:	01 c6                	add    %eax,%esi
    28bf:	89 f0                	mov    %esi,%eax
    28c1:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    28c7:	89 34 11             	mov    %esi,(%rcx,%rdx,1)
    28ca:	3d 00 ca 9a 3b       	cmp    $0x3b9aca00,%eax
    28cf:	0f 82 85 00 00 00    	jb     0x295a
    28d5:	8b 45 98             	mov    -0x68(%rbp),%eax
    28d8:	8d 80 fc ef ff ff    	lea    -0x1004(%rax),%eax
    28de:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    28e4:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    28ea:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    28f0:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    28f4:	89 c6                	mov    %eax,%esi
    28f6:	8d 76 04             	lea    0x4(%rsi),%esi
    28f9:	31 ff                	xor    %edi,%edi
    28fb:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
    28fe:	39 c8                	cmp    %ecx,%eax
    2900:	73 1a                	jae    0x291c
    2902:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2906:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    290c:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    290f:	89 ca                	mov    %ecx,%edx
    2911:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    2917:	31 d2                	xor    %edx,%edx
    2919:	89 14 08             	mov    %edx,(%rax,%rcx,1)
    291c:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    2922:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    2926:	89 ce                	mov    %ecx,%esi
    2928:	89 c8                	mov    %ecx,%eax
    292a:	8b 04 02             	mov    (%rdx,%rax,1),%eax
    292d:	8d 78 01             	lea    0x1(%rax),%edi
    2930:	89 f8                	mov    %edi,%eax
    2932:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2938:	89 3c 32             	mov    %edi,(%rdx,%rsi,1)
    293b:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    293e:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    2944:	3d ff c9 9a 3b       	cmp    $0x3b9ac9ff,%eax
    2949:	77 99                	ja     0x28e4
    294b:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2951:	8d 40 04             	lea    0x4(%rax),%eax
    2954:	89 85 74 ff ff ff    	mov    %eax,-0x8c(%rbp)
    295a:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    295e:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    2964:	8b 55 84             	mov    -0x7c(%rbp),%edx
    2967:	89 ce                	mov    %ecx,%esi
    2969:	29 f2                	sub    %esi,%edx
    296b:	c1 fa 02             	sar    $0x2,%edx
    296e:	6b d2 09             	imul   $0x9,%edx,%edx
    2971:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    2977:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    297a:	89 c1                	mov    %eax,%ecx
    297c:	89 8d 64 ff ff ff    	mov    %ecx,-0x9c(%rbp)
    2982:	83 f8 0a             	cmp    $0xa,%eax
    2985:	72 35                	jb     0x29bc
    2987:	b8 0a 00 00 00       	mov    $0xa,%eax
    298c:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2992:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    2998:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    299e:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    29a4:	8d 52 01             	lea    0x1(%rdx),%edx
    29a7:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    29ad:	6b c9 0a             	imul   $0xa,%ecx,%ecx
    29b0:	89 ca                	mov    %ecx,%edx
    29b2:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    29b8:	39 c8                	cmp    %ecx,%eax
    29ba:	73 d6                	jae    0x2992
    29bc:	8b 55 fc             	mov    -0x4(%rbp),%edx
    29bf:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
    29c5:	8d 48 04             	lea    0x4(%rax),%ecx
    29c8:	89 ce                	mov    %ecx,%esi
    29ca:	89 b5 54 ff ff ff    	mov    %esi,-0xac(%rbp)
    29d0:	89 d0                	mov    %edx,%eax
    29d2:	39 f2                	cmp    %esi,%edx
    29d4:	0f 47 c1             	cmova  %ecx,%eax
    29d7:	89 45 fc             	mov    %eax,-0x4(%rbp)
    29da:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    29e0:	8b 45 fc             	mov    -0x4(%rbp),%eax
    29e3:	89 c2                	mov    %eax,%edx
    29e5:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    29eb:	39 c8                	cmp    %ecx,%eax
    29ed:	77 07                	ja     0x29f6
    29ef:	31 c0                	xor    %eax,%eax
    29f1:	89 45 88             	mov    %eax,-0x78(%rbp)
    29f4:	eb 21                	jmp    0x2a17
    29f6:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    29fa:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    2a00:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    2a03:	89 ca                	mov    %ecx,%edx
    2a05:	89 55 fc             	mov    %edx,-0x4(%rbp)
    2a08:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    2a0b:	85 c0                	test   %eax,%eax
    2a0d:	74 cb                	je     0x29da
    2a0f:	b8 01 00 00 00       	mov    $0x1,%eax
    2a14:	89 45 88             	mov    %eax,-0x78(%rbp)
    2a17:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    2a1d:	85 c0                	test   %eax,%eax
    2a1f:	75 14                	jne    0x2a35
    2a21:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    2a27:	83 e0 08             	and    $0x8,%eax
    2a2a:	89 85 74 ff ff ff    	mov    %eax,-0x8c(%rbp)
    2a30:	e9 c0 01 00 00       	jmp    0x2bf5
    2a35:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    2a3b:	8b 55 80             	mov    -0x80(%rbp),%edx
    2a3e:	44 8b 8d 7c ff ff ff 	mov    -0x84(%rbp),%r9d
    2a45:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    2a4b:	41 89 c8             	mov    %ecx,%r8d
    2a4e:	44 89 ce             	mov    %r9d,%esi
    2a51:	bf 01 00 00 00       	mov    $0x1,%edi
    2a56:	45 85 c9             	test   %r9d,%r9d
    2a59:	0f 45 fe             	cmovne %esi,%edi
    2a5c:	89 fe                	mov    %edi,%esi
    2a5e:	89 75 fc             	mov    %esi,-0x4(%rbp)
    2a61:	41 89 c9             	mov    %ecx,%r9d
    2a64:	44 39 cf             	cmp    %r9d,%edi
    2a67:	40 0f 9f c7          	setg   %dil
    2a6b:	44 0f b6 cf          	movzbl %dil,%r9d
    2a6f:	83 f9 fb             	cmp    $0xfffffffb,%ecx
    2a72:	0f 9f c1             	setg   %cl
    2a75:	0f b6 c9             	movzbl %cl,%ecx
    2a78:	41 21 c9             	and    %ecx,%r9d
    2a7b:	44 89 cf             	mov    %r9d,%edi
    2a7e:	89 bd 54 ff ff ff    	mov    %edi,-0xac(%rbp)
    2a84:	41 81 f0 ff ff ff ff 	xor    $0xffffffff,%r8d
    2a8b:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    2a90:	45 85 c9             	test   %r9d,%r9d
    2a93:	41 0f 45 c8          	cmovne %r8d,%ecx
    2a97:	01 f1                	add    %esi,%ecx
    2a99:	89 8d 7c ff ff ff    	mov    %ecx,-0x84(%rbp)
    2a9f:	be ff ff ff ff       	mov    $0xffffffff,%esi
    2aa4:	b9 fe ff ff ff       	mov    $0xfffffffe,%ecx
    2aa9:	85 ff                	test   %edi,%edi
    2aab:	0f 45 ce             	cmovne %esi,%ecx
    2aae:	01 d1                	add    %edx,%ecx
    2ab0:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    2ab3:	83 e0 08             	and    $0x8,%eax
    2ab6:	89 c1                	mov    %eax,%ecx
    2ab8:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
    2abe:	85 c0                	test   %eax,%eax
    2ac0:	0f 85 2f 01 00 00    	jne    0x2bf5
    2ac6:	8b 45 88             	mov    -0x78(%rbp),%eax
    2ac9:	b9 09 00 00 00       	mov    $0x9,%ecx
    2ace:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2ad1:	85 c0                	test   %eax,%eax
    2ad3:	0f 84 83 00 00 00    	je     0x2b5c
    2ad9:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2add:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    2ae3:	8d 49 fc             	lea    -0x4(%rcx),%ecx
    2ae6:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    2ae9:	89 c1                	mov    %eax,%ecx
    2aeb:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    2af1:	85 c0                	test   %eax,%eax
    2af3:	74 67                	je     0x2b5c
    2af5:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    2afb:	31 c9                	xor    %ecx,%ecx
    2afd:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2b00:	b9 0a 00 00 00       	mov    $0xa,%ecx
    2b05:	89 c1                	mov    %eax,%ecx
    2b07:	48 ba cd cc cc cc 00 	movabs $0xcccccccd,%rdx
    2b0e:	00 00 00 
    2b11:	48 0f af ca          	imul   %rdx,%rcx
    2b15:	48 c1 e9 23          	shr    $0x23,%rcx
    2b19:	89 c9                	mov    %ecx,%ecx
    2b1b:	6b c9 0a             	imul   $0xa,%ecx,%ecx
    2b1e:	29 c8                	sub    %ecx,%eax
    2b20:	85 c0                	test   %eax,%eax
    2b22:	75 38                	jne    0x2b5c
    2b24:	b8 0a 00 00 00       	mov    $0xa,%eax
    2b29:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2b2f:	31 c0                	xor    %eax,%eax
    2b31:	89 45 fc             	mov    %eax,-0x4(%rbp)
    2b34:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    2b3a:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    2b40:	8b 75 fc             	mov    -0x4(%rbp),%esi
    2b43:	8d 76 01             	lea    0x1(%rsi),%esi
    2b46:	89 75 fc             	mov    %esi,-0x4(%rbp)
    2b49:	6b c9 0a             	imul   $0xa,%ecx,%ecx
    2b4c:	89 ce                	mov    %ecx,%esi
    2b4e:	89 b5 54 ff ff ff    	mov    %esi,-0xac(%rbp)
    2b54:	31 d2                	xor    %edx,%edx
    2b56:	f7 f1                	div    %ecx
    2b58:	85 d2                	test   %edx,%edx
    2b5a:	74 d8                	je     0x2b34
    2b5c:	8b 45 80             	mov    -0x80(%rbp),%eax
    2b5f:	8b 55 84             	mov    -0x7c(%rbp),%edx
    2b62:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    2b68:	29 d1                	sub    %edx,%ecx
    2b6a:	c1 f9 02             	sar    $0x2,%ecx
    2b6d:	6b c9 09             	imul   $0x9,%ecx,%ecx
    2b70:	8d 49 f7             	lea    -0x9(%rcx),%ecx
    2b73:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    2b79:	25 df ff ff ff       	and    $0xffffffdf,%eax
    2b7e:	83 f8 46             	cmp    $0x46,%eax
    2b81:	75 36                	jne    0x2bb9
    2b83:	8b 95 7c ff ff ff    	mov    -0x84(%rbp),%edx
    2b89:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2b8c:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    2b92:	31 c9                	xor    %ecx,%ecx
    2b94:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
    2b9a:	89 d1                	mov    %edx,%ecx
    2b9c:	29 c6                	sub    %eax,%esi
    2b9e:	89 f7                	mov    %esi,%edi
    2ba0:	31 c0                	xor    %eax,%eax
    2ba2:	85 ff                	test   %edi,%edi
    2ba4:	0f 4f c6             	cmovg  %esi,%eax
    2ba7:	89 c6                	mov    %eax,%esi
    2ba9:	89 75 fc             	mov    %esi,-0x4(%rbp)
    2bac:	39 f2                	cmp    %esi,%edx
    2bae:	0f 4c c1             	cmovl  %ecx,%eax
    2bb1:	89 85 7c ff ff ff    	mov    %eax,-0x84(%rbp)
    2bb7:	eb 3c                	jmp    0x2bf5
    2bb9:	8b 95 7c ff ff ff    	mov    -0x84(%rbp),%edx
    2bbf:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2bc2:	8b bd 5c ff ff ff    	mov    -0xa4(%rbp),%edi
    2bc8:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    2bce:	31 c9                	xor    %ecx,%ecx
    2bd0:	89 8d 74 ff ff ff    	mov    %ecx,-0x8c(%rbp)
    2bd6:	89 d1                	mov    %edx,%ecx
    2bd8:	01 fe                	add    %edi,%esi
    2bda:	29 c6                	sub    %eax,%esi
    2bdc:	89 f7                	mov    %esi,%edi
    2bde:	31 c0                	xor    %eax,%eax
    2be0:	85 ff                	test   %edi,%edi
    2be2:	0f 4f c6             	cmovg  %esi,%eax
    2be5:	89 c6                	mov    %eax,%esi
    2be7:	89 75 fc             	mov    %esi,-0x4(%rbp)
    2bea:	39 f2                	cmp    %esi,%edx
    2bec:	0f 4c c1             	cmovl  %ecx,%eax
    2bef:	89 85 7c ff ff ff    	mov    %eax,-0x84(%rbp)
    2bf5:	8b 8d 74 ff ff ff    	mov    -0x8c(%rbp),%ecx
    2bfb:	8b b5 7c ff ff ff    	mov    -0x84(%rbp),%esi
    2c01:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    2c06:	89 45 fc             	mov    %eax,-0x4(%rbp)
    2c09:	89 f0                	mov    %esi,%eax
    2c0b:	09 ce                	or     %ecx,%esi
    2c0d:	89 f1                	mov    %esi,%ecx
    2c0f:	89 8d 70 ff ff ff    	mov    %ecx,-0x90(%rbp)
    2c15:	ba fd ff ff 7f       	mov    $0x7ffffffd,%edx
    2c1a:	b9 fe ff ff 7f       	mov    $0x7ffffffe,%ecx
    2c1f:	85 f6                	test   %esi,%esi
    2c21:	0f 45 ca             	cmovne %edx,%ecx
    2c24:	39 c8                	cmp    %ecx,%eax
    2c26:	0f 8f e7 21 00 00    	jg     0x4e13
    2c2c:	8b 45 80             	mov    -0x80(%rbp),%eax
    2c2f:	8b 95 70 ff ff ff    	mov    -0x90(%rbp),%edx
    2c35:	8b 8d 7c ff ff ff    	mov    -0x84(%rbp),%ecx
    2c3b:	85 d2                	test   %edx,%edx
    2c3d:	0f 95 c2             	setne  %dl
    2c40:	0f b6 d2             	movzbl %dl,%edx
    2c43:	01 d1                	add    %edx,%ecx
    2c45:	8d 49 01             	lea    0x1(%rcx),%ecx
    2c48:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    2c4b:	25 df ff ff ff       	and    $0xffffffdf,%eax
    2c50:	83 f8 46             	cmp    $0x46,%eax
    2c53:	0f 95 c0             	setne  %al
    2c56:	0f b6 c0             	movzbl %al,%eax
    2c59:	89 c1                	mov    %eax,%ecx
    2c5b:	89 4d 9c             	mov    %ecx,-0x64(%rbp)
    2c5e:	85 c0                	test   %eax,%eax
    2c60:	75 32                	jne    0x2c94
    2c62:	8b 55 90             	mov    -0x70(%rbp),%edx
    2c65:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2c6b:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
    2c70:	29 d1                	sub    %edx,%ecx
    2c72:	39 c8                	cmp    %ecx,%eax
    2c74:	0f 8f 99 21 00 00    	jg     0x4e13
    2c7a:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    2c80:	89 d1                	mov    %edx,%ecx
    2c82:	31 c0                	xor    %eax,%eax
    2c84:	85 d2                	test   %edx,%edx
    2c86:	0f 4f c1             	cmovg  %ecx,%eax
    2c89:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    2c8f:	e9 4e 01 00 00       	jmp    0x2de2
    2c94:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    2c9a:	8b 45 e8             	mov    -0x18(%rbp),%eax
    2c9d:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2ca3:	89 d0                	mov    %edx,%eax
    2ca5:	c1 fa 1f             	sar    $0x1f,%edx
    2ca8:	89 d1                	mov    %edx,%ecx
    2caa:	01 d0                	add    %edx,%eax
    2cac:	31 c8                	xor    %ecx,%eax
    2cae:	89 c1                	mov    %eax,%ecx
    2cb0:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2cb3:	85 c0                	test   %eax,%eax
    2cb5:	74 66                	je     0x2d1d
    2cb7:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2cba:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    2cbe:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    2cc4:	8d 71 ff             	lea    -0x1(%rcx),%esi
    2cc7:	89 f1                	mov    %esi,%ecx
    2cc9:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    2ccf:	89 c7                	mov    %eax,%edi
    2cd1:	89 c1                	mov    %eax,%ecx
    2cd3:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
    2cd9:	89 c9                	mov    %ecx,%ecx
    2cdb:	49 b8 cd cc cc cc 00 	movabs $0xcccccccd,%r8
    2ce2:	00 00 00 
    2ce5:	49 0f af c8          	imul   %r8,%rcx
    2ce9:	48 c1 e9 23          	shr    $0x23,%rcx
    2ced:	41 89 c8             	mov    %ecx,%r8d
    2cf0:	44 89 c1             	mov    %r8d,%ecx
    2cf3:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    2cf9:	45 6b c0 0a          	imul   $0xa,%r8d,%r8d
    2cfd:	44 29 c7             	sub    %r8d,%edi
    2d00:	83 cf 30             	or     $0x30,%edi
    2d03:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    2d07:	83 f8 09             	cmp    $0x9,%eax
    2d0a:	0f 97 c0             	seta   %al
    2d0d:	0f b6 c0             	movzbl %al,%eax
    2d10:	89 85 78 ff ff ff    	mov    %eax,-0x88(%rbp)
    2d16:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2d19:	85 c0                	test   %eax,%eax
    2d1b:	75 9a                	jne    0x2cb7
    2d1d:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    2d23:	8b 45 e8             	mov    -0x18(%rbp),%eax
    2d26:	29 c8                	sub    %ecx,%eax
    2d28:	83 f8 01             	cmp    $0x1,%eax
    2d2b:	7f 4d                	jg     0x2d7a
    2d2d:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    2d33:	8d 40 ff             	lea    -0x1(%rax),%eax
    2d36:	89 45 fc             	mov    %eax,-0x4(%rbp)
    2d39:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    2d3c:	8b 45 e8             	mov    -0x18(%rbp),%eax
    2d3f:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    2d43:	89 ce                	mov    %ecx,%esi
    2d45:	bf 30 00 00 00       	mov    $0x30,%edi
    2d4a:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    2d4e:	89 ca                	mov    %ecx,%edx
    2d50:	29 d0                	sub    %edx,%eax
    2d52:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2d58:	8d 49 ff             	lea    -0x1(%rcx),%ecx
    2d5b:	89 ca                	mov    %ecx,%edx
    2d5d:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    2d63:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2d66:	83 f8 02             	cmp    $0x2,%eax
    2d69:	7c ce                	jl     0x2d39
    2d6b:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    2d71:	8d 40 01             	lea    0x1(%rax),%eax
    2d74:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2d7a:	8b 55 90             	mov    -0x70(%rbp),%edx
    2d7d:	44 8b 95 5c ff ff ff 	mov    -0xa4(%rbp),%r10d
    2d84:	8b 45 e8             	mov    -0x18(%rbp),%eax
    2d87:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    2d8b:	8b bd 54 ff ff ff    	mov    -0xac(%rbp),%edi
    2d91:	44 8b 4d 80          	mov    -0x80(%rbp),%r9d
    2d95:	89 f9                	mov    %edi,%ecx
    2d97:	44 8d 41 fe          	lea    -0x2(%rcx),%r8d
    2d9b:	44 89 c1             	mov    %r8d,%ecx
    2d9e:	89 4d 98             	mov    %ecx,-0x68(%rbp)
    2da1:	46 88 0c 06          	mov    %r9b,(%rsi,%r8,1)
    2da5:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    2dab:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    2daf:	8d 7f ff             	lea    -0x1(%rdi),%edi
    2db2:	41 b9 2d 00 00 00    	mov    $0x2d,%r9d
    2db8:	41 b8 2b 00 00 00    	mov    $0x2b,%r8d
    2dbe:	45 85 d2             	test   %r10d,%r10d
    2dc1:	45 0f 4c c1          	cmovl  %r9d,%r8d
    2dc5:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
    2dc9:	29 c8                	sub    %ecx,%eax
    2dcb:	89 c1                	mov    %eax,%ecx
    2dcd:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    2dd3:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
    2dd8:	29 d1                	sub    %edx,%ecx
    2dda:	39 c8                	cmp    %ecx,%eax
    2ddc:	0f 8f 31 20 00 00    	jg     0x4e13
    2de2:	8b 4d 8c             	mov    -0x74(%rbp),%ecx
    2de5:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2deb:	8b 55 90             	mov    -0x70(%rbp),%edx
    2dee:	be ff ff ff ff       	mov    $0xffffffff,%esi
    2df3:	89 75 fc             	mov    %esi,-0x4(%rbp)
    2df6:	01 d0                	add    %edx,%eax
    2df8:	89 c2                	mov    %eax,%edx
    2dfa:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    2e00:	81 f1 ff ff ff 7f    	xor    $0x7fffffff,%ecx
    2e06:	39 c8                	cmp    %ecx,%eax
    2e08:	0f 8f 05 20 00 00    	jg     0x4e13
    2e0e:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    2e14:	8b 55 8c             	mov    -0x74(%rbp),%edx
    2e17:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    2e1d:	01 d1                	add    %edx,%ecx
    2e1f:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    2e22:	25 00 20 01 00       	and    $0x12000,%eax
    2e27:	89 c1                	mov    %eax,%ecx
    2e29:	89 8d 68 ff ff ff    	mov    %ecx,-0x98(%rbp)
    2e2f:	85 c0                	test   %eax,%eax
    2e31:	0f 85 4e 01 00 00    	jne    0x2f85
    2e37:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    2e3a:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    2e40:	39 c8                	cmp    %ecx,%eax
    2e42:	0f 8e 3d 01 00 00    	jle    0x2f85
    2e48:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    2e4f:	8b 55 80             	mov    -0x80(%rbp),%edx
    2e52:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    2e58:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    2e5b:	29 d0                	sub    %edx,%eax
    2e5d:	41 89 c0             	mov    %eax,%r8d
    2e60:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    2e64:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    2e6b:	0f 92 c2             	setb   %dl
    2e6e:	0f b6 d2             	movzbl %dl,%edx
    2e71:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    2e77:	8d 71 40             	lea    0x40(%rcx),%esi
    2e7a:	ba 20 00 00 00       	mov    $0x20,%edx
    2e7f:	b9 00 01 00 00       	mov    $0x100,%ecx
    2e84:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    2e8b:	0f 42 c8             	cmovb  %eax,%ecx
    2e8e:	e8 25 33 fe ff       	call   0xfffffffffffe61b8
    2e93:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    2e9a:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    2ea0:	89 c6                	mov    %eax,%esi
    2ea2:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    2ea8:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    2eaf:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    2eb3:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    2eb6:	89 ca                	mov    %ecx,%edx
    2eb8:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    2ebe:	83 e1 20             	and    $0x20,%ecx
    2ec1:	85 c9                	test   %ecx,%ecx
    2ec3:	0f 94 c1             	sete   %cl
    2ec6:	0f b6 c9             	movzbl %cl,%ecx
    2ec9:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    2ecf:	85 c0                	test   %eax,%eax
    2ed1:	75 79                	jne    0x2f4c
    2ed3:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2ed9:	83 e0 01             	and    $0x1,%eax
    2edc:	85 c0                	test   %eax,%eax
    2ede:	74 40                	je     0x2f20
    2ee0:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    2ee6:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    2eed:	8b 45 cc             	mov    -0x34(%rbp),%eax
    2ef0:	8d 70 40             	lea    0x40(%rax),%esi
    2ef3:	ba 00 01 00 00       	mov    $0x100,%edx
    2ef8:	e8 d5 31 fe ff       	call   0xfffffffffffe60d2
    2efd:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    2f03:	89 c2                	mov    %eax,%edx
    2f05:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    2f0c:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    2f13:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    2f17:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    2f1a:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    2f20:	8b 45 fc             	mov    -0x4(%rbp),%eax
    2f23:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    2f29:	83 e1 20             	and    $0x20,%ecx
    2f2c:	85 c9                	test   %ecx,%ecx
    2f2e:	0f 94 c1             	sete   %cl
    2f31:	0f b6 c9             	movzbl %cl,%ecx
    2f34:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    2f3a:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    2f40:	89 c1                	mov    %eax,%ecx
    2f42:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    2f45:	3d ff 00 00 00       	cmp    $0xff,%eax
    2f4a:	77 87                	ja     0x2ed3
    2f4c:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    2f52:	85 c0                	test   %eax,%eax
    2f54:	74 2f                	je     0x2f85
    2f56:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    2f5d:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    2f63:	8b 55 fc             	mov    -0x4(%rbp),%edx
    2f66:	8b 45 cc             	mov    -0x34(%rbp),%eax
    2f69:	8d 70 40             	lea    0x40(%rax),%esi
    2f6c:	e8 61 31 fe ff       	call   0xfffffffffffe60d2
    2f71:	89 c1                	mov    %eax,%ecx
    2f73:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    2f7a:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    2f81:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    2f85:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    2f89:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    2f8f:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    2f93:	83 e0 20             	and    $0x20,%eax
    2f96:	85 c0                	test   %eax,%eax
    2f98:	75 2c                	jne    0x2fc6
    2f9a:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    2fa1:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    2fa7:	8b 55 8c             	mov    -0x74(%rbp),%edx
    2faa:	8b 75 94             	mov    -0x6c(%rbp),%esi
    2fad:	e8 20 31 fe ff       	call   0xfffffffffffe60d2
    2fb2:	89 c1                	mov    %eax,%ecx
    2fb4:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    2fbb:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    2fc2:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    2fc6:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    2fcc:	3d 00 00 01 00       	cmp    $0x10000,%eax
    2fd1:	0f 85 4e 01 00 00    	jne    0x3125
    2fd7:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    2fda:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    2fe0:	39 c8                	cmp    %ecx,%eax
    2fe2:	0f 8e 3d 01 00 00    	jle    0x3125
    2fe8:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    2fef:	8b 55 80             	mov    -0x80(%rbp),%edx
    2ff2:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    2ff8:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    2ffb:	29 d0                	sub    %edx,%eax
    2ffd:	41 89 c0             	mov    %eax,%r8d
    3000:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    3004:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    300b:	0f 92 c2             	setb   %dl
    300e:	0f b6 d2             	movzbl %dl,%edx
    3011:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    3017:	8d 71 40             	lea    0x40(%rcx),%esi
    301a:	ba 30 00 00 00       	mov    $0x30,%edx
    301f:	b9 00 01 00 00       	mov    $0x100,%ecx
    3024:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    302b:	0f 42 c8             	cmovb  %eax,%ecx
    302e:	e8 85 31 fe ff       	call   0xfffffffffffe61b8
    3033:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    303a:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    3040:	89 c6                	mov    %eax,%esi
    3042:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    3048:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    304f:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    3053:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    3056:	89 ca                	mov    %ecx,%edx
    3058:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    305e:	83 e1 20             	and    $0x20,%ecx
    3061:	85 c9                	test   %ecx,%ecx
    3063:	0f 94 c1             	sete   %cl
    3066:	0f b6 c9             	movzbl %cl,%ecx
    3069:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    306f:	85 c0                	test   %eax,%eax
    3071:	75 79                	jne    0x30ec
    3073:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3079:	83 e0 01             	and    $0x1,%eax
    307c:	85 c0                	test   %eax,%eax
    307e:	74 40                	je     0x30c0
    3080:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3086:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    308d:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3090:	8d 70 40             	lea    0x40(%rax),%esi
    3093:	ba 00 01 00 00       	mov    $0x100,%edx
    3098:	e8 35 30 fe ff       	call   0xfffffffffffe60d2
    309d:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    30a3:	89 c2                	mov    %eax,%edx
    30a5:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    30ac:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    30b3:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    30b7:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    30ba:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    30c0:	8b 45 fc             	mov    -0x4(%rbp),%eax
    30c3:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    30c9:	83 e1 20             	and    $0x20,%ecx
    30cc:	85 c9                	test   %ecx,%ecx
    30ce:	0f 94 c1             	sete   %cl
    30d1:	0f b6 c9             	movzbl %cl,%ecx
    30d4:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    30da:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    30e0:	89 c1                	mov    %eax,%ecx
    30e2:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    30e5:	3d ff 00 00 00       	cmp    $0xff,%eax
    30ea:	77 87                	ja     0x3073
    30ec:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    30f2:	85 c0                	test   %eax,%eax
    30f4:	74 2f                	je     0x3125
    30f6:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    30fd:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3103:	8b 55 fc             	mov    -0x4(%rbp),%edx
    3106:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3109:	8d 70 40             	lea    0x40(%rax),%esi
    310c:	e8 c1 2f fe ff       	call   0xfffffffffffe60d2
    3111:	89 c1                	mov    %eax,%ecx
    3113:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    311a:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3121:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3125:	8b 45 9c             	mov    -0x64(%rbp),%eax
    3128:	85 c0                	test   %eax,%eax
    312a:	0f 85 00 0c 00 00    	jne    0x3d30
    3130:	8b 75 84             	mov    -0x7c(%rbp),%esi
    3133:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    3139:	89 f1                	mov    %esi,%ecx
    313b:	89 d0                	mov    %edx,%eax
    313d:	39 f2                	cmp    %esi,%edx
    313f:	0f 47 c1             	cmova  %ecx,%eax
    3142:	89 c1                	mov    %eax,%ecx
    3144:	89 8d 78 ff ff ff    	mov    %ecx,-0x88(%rbp)
    314a:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    3150:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3154:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    315a:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    315d:	89 c1                	mov    %eax,%ecx
    315f:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    3162:	85 c0                	test   %eax,%eax
    3164:	0f 84 c9 00 00 00    	je     0x3233
    316a:	31 c0                	xor    %eax,%eax
    316c:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    3172:	8b 45 fc             	mov    -0x4(%rbp),%eax
    3175:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    317b:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    317f:	8b 7d cc             	mov    -0x34(%rbp),%edi
    3182:	41 89 d2             	mov    %edx,%r10d
    3185:	41 89 c0             	mov    %eax,%r8d
    3188:	89 c1                	mov    %eax,%ecx
    318a:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
    3190:	89 c9                	mov    %ecx,%ecx
    3192:	49 b9 cd cc cc cc 00 	movabs $0xcccccccd,%r9
    3199:	00 00 00 
    319c:	49 0f af c9          	imul   %r9,%rcx
    31a0:	48 c1 e9 23          	shr    $0x23,%rcx
    31a4:	41 89 c9             	mov    %ecx,%r9d
    31a7:	44 89 c9             	mov    %r9d,%ecx
    31aa:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    31b0:	8d bf 50 01 00 00    	lea    0x150(%rdi),%edi
    31b6:	44 01 d7             	add    %r10d,%edi
    31b9:	8d 7f 08             	lea    0x8(%rdi),%edi
    31bc:	45 6b c9 0a          	imul   $0xa,%r9d,%r9d
    31c0:	45 29 c8             	sub    %r9d,%r8d
    31c3:	41 83 c8 30          	or     $0x30,%r8d
    31c7:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
    31cb:	8d 52 ff             	lea    -0x1(%rdx),%edx
    31ce:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    31d4:	83 f8 09             	cmp    $0x9,%eax
    31d7:	0f 97 c0             	seta   %al
    31da:	0f b6 c0             	movzbl %al,%eax
    31dd:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    31e3:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    31e6:	85 c0                	test   %eax,%eax
    31e8:	75 88                	jne    0x3172
    31ea:	8b 8d 78 ff ff ff    	mov    -0x88(%rbp),%ecx
    31f0:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    31f6:	8b b5 58 ff ff ff    	mov    -0xa8(%rbp),%esi
    31fc:	8b 55 cc             	mov    -0x34(%rbp),%edx
    31ff:	8d 92 50 01 00 00    	lea    0x150(%rdx),%edx
    3205:	01 f2                	add    %esi,%edx
    3207:	8d 52 09             	lea    0x9(%rdx),%edx
    320a:	89 55 fc             	mov    %edx,-0x4(%rbp)
    320d:	39 c8                	cmp    %ecx,%eax
    320f:	74 16                	je     0x3227
    3211:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3214:	8b 45 fc             	mov    -0x4(%rbp),%eax
    3217:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    321d:	39 c8                	cmp    %ecx,%eax
    321f:	0f 86 88 00 00 00    	jbe    0x32ad
    3225:	eb 43                	jmp    0x326a
    3227:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    322d:	85 c0                	test   %eax,%eax
    322f:	75 7c                	jne    0x32ad
    3231:	eb 1e                	jmp    0x3251
    3233:	8b 8d 78 ff ff ff    	mov    -0x88(%rbp),%ecx
    3239:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    323f:	8b 55 d8             	mov    -0x28(%rbp),%edx
    3242:	31 f6                	xor    %esi,%esi
    3244:	89 b5 58 ff ff ff    	mov    %esi,-0xa8(%rbp)
    324a:	89 55 fc             	mov    %edx,-0x4(%rbp)
    324d:	39 c8                	cmp    %ecx,%eax
    324f:	75 19                	jne    0x326a
    3251:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3255:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    3258:	8d 49 ff             	lea    -0x1(%rcx),%ecx
    325b:	89 ca                	mov    %ecx,%edx
    325d:	89 55 fc             	mov    %edx,-0x4(%rbp)
    3260:	ba 30 00 00 00       	mov    $0x30,%edx
    3265:	88 14 08             	mov    %dl,(%rax,%rcx,1)
    3268:	eb 43                	jmp    0x32ad
    326a:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    326d:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3274:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    327a:	8d b1 50 01 00 00    	lea    0x150(%rcx),%esi
    3280:	ba 30 00 00 00       	mov    $0x30,%edx
    3285:	8d 48 09             	lea    0x9(%rax),%ecx
    3288:	e8 2b 2f fe ff       	call   0xfffffffffffe61b8
    328d:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    3294:	89 c2                	mov    %eax,%edx
    3296:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3299:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    32a0:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    32a4:	8d 80 50 01 00 00    	lea    0x150(%rax),%eax
    32aa:	89 45 fc             	mov    %eax,-0x4(%rbp)
    32ad:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    32b1:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    32b7:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    32bb:	83 e0 20             	and    $0x20,%eax
    32be:	85 c0                	test   %eax,%eax
    32c0:	75 30                	jne    0x32f2
    32c2:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    32c9:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    32cf:	8b 45 fc             	mov    -0x4(%rbp),%eax
    32d2:	8b 55 d8             	mov    -0x28(%rbp),%edx
    32d5:	89 c6                	mov    %eax,%esi
    32d7:	29 c2                	sub    %eax,%edx
    32d9:	e8 f4 2d fe ff       	call   0xfffffffffffe60d2
    32de:	89 c1                	mov    %eax,%ecx
    32e0:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    32e7:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    32ee:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    32f2:	8b 4d 84             	mov    -0x7c(%rbp),%ecx
    32f5:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    32fb:	8d 40 04             	lea    0x4(%rax),%eax
    32fe:	89 c2                	mov    %eax,%edx
    3300:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    3306:	39 c8                	cmp    %ecx,%eax
    3308:	0f 86 42 fe ff ff    	jbe    0x3150
    330e:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    3314:	85 c0                	test   %eax,%eax
    3316:	74 45                	je     0x335d
    3318:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    331c:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3322:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    3326:	83 e0 20             	and    $0x20,%eax
    3329:	85 c0                	test   %eax,%eax
    332b:	75 30                	jne    0x335d
    332d:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3334:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    333a:	be f3 0d 00 00       	mov    $0xdf3,%esi
    333f:	ba 01 00 00 00       	mov    $0x1,%edx
    3344:	e8 89 2d fe ff       	call   0xfffffffffffe60d2
    3349:	89 c1                	mov    %eax,%ecx
    334b:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3352:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3359:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    335d:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    3363:	83 f8 01             	cmp    $0x1,%eax
    3366:	7d 0e                	jge    0x3376
    3368:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    336e:	89 45 fc             	mov    %eax,-0x4(%rbp)
    3371:	e9 96 01 00 00       	jmp    0x350c
    3376:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    337c:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    3382:	39 c8                	cmp    %ecx,%eax
    3384:	72 0e                	jb     0x3394
    3386:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    338c:	89 45 fc             	mov    %eax,-0x4(%rbp)
    338f:	e9 78 01 00 00       	jmp    0x350c
    3394:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3398:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    339e:	8b 55 d8             	mov    -0x28(%rbp),%edx
    33a1:	89 55 fc             	mov    %edx,-0x4(%rbp)
    33a4:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    33a7:	89 c1                	mov    %eax,%ecx
    33a9:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    33af:	85 c0                	test   %eax,%eax
    33b1:	74 7c                	je     0x342f
    33b3:	8b 45 d8             	mov    -0x28(%rbp),%eax
    33b6:	89 45 fc             	mov    %eax,-0x4(%rbp)
    33b9:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    33bf:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    33c3:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    33c6:	8d 71 ff             	lea    -0x1(%rcx),%esi
    33c9:	89 f1                	mov    %esi,%ecx
    33cb:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    33ce:	89 c7                	mov    %eax,%edi
    33d0:	89 c1                	mov    %eax,%ecx
    33d2:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
    33d8:	89 c9                	mov    %ecx,%ecx
    33da:	49 b8 cd cc cc cc 00 	movabs $0xcccccccd,%r8
    33e1:	00 00 00 
    33e4:	49 0f af c8          	imul   %r8,%rcx
    33e8:	48 c1 e9 23          	shr    $0x23,%rcx
    33ec:	41 89 c8             	mov    %ecx,%r8d
    33ef:	44 89 c1             	mov    %r8d,%ecx
    33f2:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    33f8:	45 6b c0 0a          	imul   $0xa,%r8d,%r8d
    33fc:	44 29 c7             	sub    %r8d,%edi
    33ff:	83 cf 30             	or     $0x30,%edi
    3402:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    3406:	83 f8 09             	cmp    $0x9,%eax
    3409:	0f 97 c0             	seta   %al
    340c:	0f b6 c0             	movzbl %al,%eax
    340f:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    3415:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    341b:	85 c0                	test   %eax,%eax
    341d:	75 9a                	jne    0x33b9
    341f:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3422:	8b 45 fc             	mov    -0x4(%rbp),%eax
    3425:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    342b:	39 c8                	cmp    %ecx,%eax
    342d:	76 4e                	jbe    0x347d
    342f:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3436:	8b 45 ec             	mov    -0x14(%rbp),%eax
    3439:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    343c:	8b 55 cc             	mov    -0x34(%rbp),%edx
    343f:	8d b2 50 01 00 00    	lea    0x150(%rdx),%esi
    3445:	ba 30 00 00 00       	mov    $0x30,%edx
    344a:	01 c1                	add    %eax,%ecx
    344c:	e8 67 2d fe ff       	call   0xfffffffffffe61b8
    3451:	89 c1                	mov    %eax,%ecx
    3453:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    345a:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3461:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3465:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3468:	8b 45 fc             	mov    -0x4(%rbp),%eax
    346b:	8d 40 ff             	lea    -0x1(%rax),%eax
    346e:	89 c2                	mov    %eax,%edx
    3470:	89 55 fc             	mov    %edx,-0x4(%rbp)
    3473:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    3479:	39 c8                	cmp    %ecx,%eax
    347b:	77 e8                	ja     0x3465
    347d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3481:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3487:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    348b:	83 e0 20             	and    $0x20,%eax
    348e:	85 c0                	test   %eax,%eax
    3490:	75 3f                	jne    0x34d1
    3492:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3499:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    349f:	44 8b 85 7c ff ff ff 	mov    -0x84(%rbp),%r8d
    34a6:	8b 75 fc             	mov    -0x4(%rbp),%esi
    34a9:	44 89 c0             	mov    %r8d,%eax
    34ac:	ba 09 00 00 00       	mov    $0x9,%edx
    34b1:	41 83 f8 09          	cmp    $0x9,%r8d
    34b5:	0f 4c d0             	cmovl  %eax,%edx
    34b8:	e8 15 2c fe ff       	call   0xfffffffffffe60d2
    34bd:	89 c1                	mov    %eax,%ecx
    34bf:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    34c6:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    34cd:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    34d1:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    34d7:	89 c1                	mov    %eax,%ecx
    34d9:	8d 49 f7             	lea    -0x9(%rcx),%ecx
    34dc:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    34df:	83 f8 0a             	cmp    $0xa,%eax
    34e2:	7c 28                	jl     0x350c
    34e4:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    34ea:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    34f0:	8b 55 fc             	mov    -0x4(%rbp),%edx
    34f3:	89 95 7c ff ff ff    	mov    %edx,-0x84(%rbp)
    34f9:	8d 40 04             	lea    0x4(%rax),%eax
    34fc:	89 c2                	mov    %eax,%edx
    34fe:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    3504:	39 c8                	cmp    %ecx,%eax
    3506:	0f 82 88 fe ff ff    	jb     0x3394
    350c:	8b 45 fc             	mov    -0x4(%rbp),%eax
    350f:	83 f8 01             	cmp    $0x1,%eax
    3512:	0f 8c 84 0c 00 00    	jl     0x419c
    3518:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    351f:	44 8b 45 fc          	mov    -0x4(%rbp),%r8d
    3523:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3526:	44 89 c0             	mov    %r8d,%eax
    3529:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3530:	0f 92 c2             	setb   %dl
    3533:	0f b6 d2             	movzbl %dl,%edx
    3536:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    353c:	8d 71 40             	lea    0x40(%rcx),%esi
    353f:	ba 30 00 00 00       	mov    $0x30,%edx
    3544:	b9 00 01 00 00       	mov    $0x100,%ecx
    3549:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3550:	0f 42 c8             	cmovb  %eax,%ecx
    3553:	e8 60 2c fe ff       	call   0xfffffffffffe61b8
    3558:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    355f:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    3565:	89 c6                	mov    %eax,%esi
    3567:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    356d:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    3574:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    3578:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    357b:	89 ca                	mov    %ecx,%edx
    357d:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    3583:	83 e1 20             	and    $0x20,%ecx
    3586:	85 c9                	test   %ecx,%ecx
    3588:	0f 94 c1             	sete   %cl
    358b:	0f b6 c9             	movzbl %cl,%ecx
    358e:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3594:	85 c0                	test   %eax,%eax
    3596:	75 79                	jne    0x3611
    3598:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    359e:	83 e0 01             	and    $0x1,%eax
    35a1:	85 c0                	test   %eax,%eax
    35a3:	74 40                	je     0x35e5
    35a5:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    35ab:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    35b2:	8b 45 cc             	mov    -0x34(%rbp),%eax
    35b5:	8d 70 40             	lea    0x40(%rax),%esi
    35b8:	ba 00 01 00 00       	mov    $0x100,%edx
    35bd:	e8 10 2b fe ff       	call   0xfffffffffffe60d2
    35c2:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    35c8:	89 c2                	mov    %eax,%edx
    35ca:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    35d1:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    35d8:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    35dc:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    35df:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    35e5:	8b 45 fc             	mov    -0x4(%rbp),%eax
    35e8:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    35ee:	83 e1 20             	and    $0x20,%ecx
    35f1:	85 c9                	test   %ecx,%ecx
    35f3:	0f 94 c1             	sete   %cl
    35f6:	0f b6 c9             	movzbl %cl,%ecx
    35f9:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    35ff:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    3605:	89 c1                	mov    %eax,%ecx
    3607:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    360a:	3d ff 00 00 00       	cmp    $0xff,%eax
    360f:	77 87                	ja     0x3598
    3611:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3617:	85 c0                	test   %eax,%eax
    3619:	0f 84 7d 0b 00 00    	je     0x419c
    361f:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3626:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    362c:	8b 55 fc             	mov    -0x4(%rbp),%edx
    362f:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3632:	8d 70 40             	lea    0x40(%rax),%esi
    3635:	e8 98 2a fe ff       	call   0xfffffffffffe60d2
    363a:	89 c1                	mov    %eax,%ecx
    363c:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3643:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    364a:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    364e:	e9 49 0b 00 00       	jmp    0x419c
    3653:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    3659:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
    365f:	8b 55 f0             	mov    -0x10(%rbp),%edx
    3662:	31 f6                	xor    %esi,%esi
    3664:	89 75 84             	mov    %esi,-0x7c(%rbp)
    3667:	be 4a 0b 00 00       	mov    $0xb4a,%esi
    366c:	89 75 88             	mov    %esi,-0x78(%rbp)
    366f:	89 55 fc             	mov    %edx,-0x4(%rbp)
    3672:	89 8d 7c ff ff ff    	mov    %ecx,-0x84(%rbp)
    3678:	89 85 78 ff ff ff    	mov    %eax,-0x88(%rbp)
    367e:	8b 55 84             	mov    -0x7c(%rbp),%edx
    3681:	8b b5 78 ff ff ff    	mov    -0x88(%rbp),%esi
    3687:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    368d:	8b 4d fc             	mov    -0x4(%rbp),%ecx
    3690:	29 c1                	sub    %eax,%ecx
    3692:	89 cf                	mov    %ecx,%edi
    3694:	89 bd 74 ff ff ff    	mov    %edi,-0x8c(%rbp)
    369a:	89 f0                	mov    %esi,%eax
    369c:	39 fe                	cmp    %edi,%esi
    369e:	0f 4c c1             	cmovl  %ecx,%eax
    36a1:	89 c1                	mov    %eax,%ecx
    36a3:	89 8d 68 ff ff ff    	mov    %ecx,-0x98(%rbp)
    36a9:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
    36ae:	29 d1                	sub    %edx,%ecx
    36b0:	39 c8                	cmp    %ecx,%eax
    36b2:	0f 8f 66 17 00 00    	jg     0x4e1e
    36b8:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    36be:	8b b5 6c ff ff ff    	mov    -0x94(%rbp),%esi
    36c4:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    36ca:	8b 55 84             	mov    -0x7c(%rbp),%edx
    36cd:	01 c2                	add    %eax,%edx
    36cf:	89 d7                	mov    %edx,%edi
    36d1:	89 bd 60 ff ff ff    	mov    %edi,-0xa0(%rbp)
    36d7:	89 f0                	mov    %esi,%eax
    36d9:	39 fe                	cmp    %edi,%esi
    36db:	0f 4c c2             	cmovl  %edx,%eax
    36de:	89 c2                	mov    %eax,%edx
    36e0:	89 55 fc             	mov    %edx,-0x4(%rbp)
    36e3:	39 c8                	cmp    %ecx,%eax
    36e5:	0f 8f 33 17 00 00    	jg     0x4e1e
    36eb:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    36f1:	25 00 20 01 00       	and    $0x12000,%eax
    36f6:	89 c1                	mov    %eax,%ecx
    36f8:	89 8d 70 ff ff ff    	mov    %ecx,-0x90(%rbp)
    36fe:	85 c0                	test   %eax,%eax
    3700:	0f 85 5d 01 00 00    	jne    0x3863
    3706:	8b 8d 6c ff ff ff    	mov    -0x94(%rbp),%ecx
    370c:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    3712:	39 c8                	cmp    %ecx,%eax
    3714:	0f 8d 49 01 00 00    	jge    0x3863
    371a:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3721:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
    3727:	8b 45 fc             	mov    -0x4(%rbp),%eax
    372a:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    372d:	29 d0                	sub    %edx,%eax
    372f:	41 89 c0             	mov    %eax,%r8d
    3732:	44 89 85 58 ff ff ff 	mov    %r8d,-0xa8(%rbp)
    3739:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3740:	0f 92 c2             	setb   %dl
    3743:	0f b6 d2             	movzbl %dl,%edx
    3746:	89 95 7c ff ff ff    	mov    %edx,-0x84(%rbp)
    374c:	8d 71 40             	lea    0x40(%rcx),%esi
    374f:	ba 20 00 00 00       	mov    $0x20,%edx
    3754:	b9 00 01 00 00       	mov    $0x100,%ecx
    3759:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3760:	0f 42 c8             	cmovb  %eax,%ecx
    3763:	e8 50 2a fe ff       	call   0xfffffffffffe61b8
    3768:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    376f:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    3775:	89 c6                	mov    %eax,%esi
    3777:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    377d:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    3784:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    3788:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    378b:	89 ca                	mov    %ecx,%edx
    378d:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    3793:	83 e1 20             	and    $0x20,%ecx
    3796:	85 c9                	test   %ecx,%ecx
    3798:	0f 94 c1             	sete   %cl
    379b:	0f b6 c9             	movzbl %cl,%ecx
    379e:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    37a4:	85 c0                	test   %eax,%eax
    37a6:	75 7f                	jne    0x3827
    37a8:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    37ae:	83 e0 01             	and    $0x1,%eax
    37b1:	85 c0                	test   %eax,%eax
    37b3:	74 40                	je     0x37f5
    37b5:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    37bb:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    37c2:	8b 45 cc             	mov    -0x34(%rbp),%eax
    37c5:	8d 70 40             	lea    0x40(%rax),%esi
    37c8:	ba 00 01 00 00       	mov    $0x100,%edx
    37cd:	e8 00 29 fe ff       	call   0xfffffffffffe60d2
    37d2:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    37d8:	89 c2                	mov    %eax,%edx
    37da:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    37e1:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    37e8:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    37ec:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    37ef:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
    37f5:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    37fb:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    3801:	83 e1 20             	and    $0x20,%ecx
    3804:	85 c9                	test   %ecx,%ecx
    3806:	0f 94 c1             	sete   %cl
    3809:	0f b6 c9             	movzbl %cl,%ecx
    380c:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    3812:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    3818:	89 c1                	mov    %eax,%ecx
    381a:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3820:	3d ff 00 00 00       	cmp    $0xff,%eax
    3825:	77 81                	ja     0x37a8
    3827:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    382d:	85 c0                	test   %eax,%eax
    382f:	74 32                	je     0x3863
    3831:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3838:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    383e:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    3844:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3847:	8d 70 40             	lea    0x40(%rax),%esi
    384a:	e8 83 28 fe ff       	call   0xfffffffffffe60d2
    384f:	89 c1                	mov    %eax,%ecx
    3851:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3858:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    385f:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3863:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3867:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    386d:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    3871:	83 e0 20             	and    $0x20,%eax
    3874:	85 c0                	test   %eax,%eax
    3876:	75 2c                	jne    0x38a4
    3878:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    387f:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3885:	8b 55 84             	mov    -0x7c(%rbp),%edx
    3888:	8b 75 88             	mov    -0x78(%rbp),%esi
    388b:	e8 42 28 fe ff       	call   0xfffffffffffe60d2
    3890:	89 c1                	mov    %eax,%ecx
    3892:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3899:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    38a0:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    38a4:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    38aa:	3d 00 00 01 00       	cmp    $0x10000,%eax
    38af:	0f 85 5d 01 00 00    	jne    0x3a12
    38b5:	8b 8d 6c ff ff ff    	mov    -0x94(%rbp),%ecx
    38bb:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    38c1:	39 c8                	cmp    %ecx,%eax
    38c3:	0f 8d 49 01 00 00    	jge    0x3a12
    38c9:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    38d0:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
    38d6:	8b 45 fc             	mov    -0x4(%rbp),%eax
    38d9:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    38dc:	29 d0                	sub    %edx,%eax
    38de:	41 89 c0             	mov    %eax,%r8d
    38e1:	44 89 85 58 ff ff ff 	mov    %r8d,-0xa8(%rbp)
    38e8:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    38ef:	0f 92 c2             	setb   %dl
    38f2:	0f b6 d2             	movzbl %dl,%edx
    38f5:	89 95 7c ff ff ff    	mov    %edx,-0x84(%rbp)
    38fb:	8d 71 40             	lea    0x40(%rcx),%esi
    38fe:	ba 30 00 00 00       	mov    $0x30,%edx
    3903:	b9 00 01 00 00       	mov    $0x100,%ecx
    3908:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    390f:	0f 42 c8             	cmovb  %eax,%ecx
    3912:	e8 a1 28 fe ff       	call   0xfffffffffffe61b8
    3917:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    391e:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    3924:	89 c6                	mov    %eax,%esi
    3926:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    392c:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    3933:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    3937:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    393a:	89 ca                	mov    %ecx,%edx
    393c:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    3942:	83 e1 20             	and    $0x20,%ecx
    3945:	85 c9                	test   %ecx,%ecx
    3947:	0f 94 c1             	sete   %cl
    394a:	0f b6 c9             	movzbl %cl,%ecx
    394d:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    3953:	85 c0                	test   %eax,%eax
    3955:	75 7f                	jne    0x39d6
    3957:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    395d:	83 e0 01             	and    $0x1,%eax
    3960:	85 c0                	test   %eax,%eax
    3962:	74 40                	je     0x39a4
    3964:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    396a:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3971:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3974:	8d 70 40             	lea    0x40(%rax),%esi
    3977:	ba 00 01 00 00       	mov    $0x100,%edx
    397c:	e8 51 27 fe ff       	call   0xfffffffffffe60d2
    3981:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3987:	89 c2                	mov    %eax,%edx
    3989:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3990:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3997:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    399b:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    399e:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
    39a4:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    39aa:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    39b0:	83 e1 20             	and    $0x20,%ecx
    39b3:	85 c9                	test   %ecx,%ecx
    39b5:	0f 94 c1             	sete   %cl
    39b8:	0f b6 c9             	movzbl %cl,%ecx
    39bb:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    39c1:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    39c7:	89 c1                	mov    %eax,%ecx
    39c9:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    39cf:	3d ff 00 00 00       	cmp    $0xff,%eax
    39d4:	77 81                	ja     0x3957
    39d6:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    39dc:	85 c0                	test   %eax,%eax
    39de:	74 32                	je     0x3a12
    39e0:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    39e7:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    39ed:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    39f3:	8b 45 cc             	mov    -0x34(%rbp),%eax
    39f6:	8d 70 40             	lea    0x40(%rax),%esi
    39f9:	e8 d4 26 fe ff       	call   0xfffffffffffe60d2
    39fe:	89 c1                	mov    %eax,%ecx
    3a00:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3a07:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3a0e:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3a12:	8b 8d 78 ff ff ff    	mov    -0x88(%rbp),%ecx
    3a18:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
    3a1e:	39 c8                	cmp    %ecx,%eax
    3a20:	0f 8d 4c 01 00 00    	jge    0x3b72
    3a26:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3a2d:	8b 95 74 ff ff ff    	mov    -0x8c(%rbp),%edx
    3a33:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    3a39:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3a3c:	29 d0                	sub    %edx,%eax
    3a3e:	41 89 c0             	mov    %eax,%r8d
    3a41:	44 89 85 58 ff ff ff 	mov    %r8d,-0xa8(%rbp)
    3a48:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3a4f:	0f 92 c2             	setb   %dl
    3a52:	0f b6 d2             	movzbl %dl,%edx
    3a55:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    3a5b:	8d 71 40             	lea    0x40(%rcx),%esi
    3a5e:	ba 30 00 00 00       	mov    $0x30,%edx
    3a63:	b9 00 01 00 00       	mov    $0x100,%ecx
    3a68:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3a6f:	0f 42 c8             	cmovb  %eax,%ecx
    3a72:	e8 41 27 fe ff       	call   0xfffffffffffe61b8
    3a77:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    3a7e:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    3a84:	89 c6                	mov    %eax,%esi
    3a86:	8b 85 78 ff ff ff    	mov    -0x88(%rbp),%eax
    3a8c:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    3a93:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    3a97:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    3a9a:	89 ca                	mov    %ecx,%edx
    3a9c:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    3aa2:	83 e1 20             	and    $0x20,%ecx
    3aa5:	85 c9                	test   %ecx,%ecx
    3aa7:	0f 94 c1             	sete   %cl
    3aaa:	0f b6 c9             	movzbl %cl,%ecx
    3aad:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    3ab3:	85 c0                	test   %eax,%eax
    3ab5:	75 7f                	jne    0x3b36
    3ab7:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3abd:	83 e0 01             	and    $0x1,%eax
    3ac0:	85 c0                	test   %eax,%eax
    3ac2:	74 40                	je     0x3b04
    3ac4:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3aca:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3ad1:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3ad4:	8d 70 40             	lea    0x40(%rax),%esi
    3ad7:	ba 00 01 00 00       	mov    $0x100,%edx
    3adc:	e8 f1 25 fe ff       	call   0xfffffffffffe60d2
    3ae1:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3ae7:	89 c2                	mov    %eax,%edx
    3ae9:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3af0:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3af7:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3afb:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    3afe:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
    3b04:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3b0a:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    3b10:	83 e1 20             	and    $0x20,%ecx
    3b13:	85 c9                	test   %ecx,%ecx
    3b15:	0f 94 c1             	sete   %cl
    3b18:	0f b6 c9             	movzbl %cl,%ecx
    3b1b:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    3b21:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    3b27:	89 c1                	mov    %eax,%ecx
    3b29:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3b2f:	3d ff 00 00 00       	cmp    $0xff,%eax
    3b34:	77 81                	ja     0x3ab7
    3b36:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3b3c:	85 c0                	test   %eax,%eax
    3b3e:	74 32                	je     0x3b72
    3b40:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3b47:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3b4d:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    3b53:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3b56:	8d 70 40             	lea    0x40(%rax),%esi
    3b59:	e8 74 25 fe ff       	call   0xfffffffffffe60d2
    3b5e:	89 c1                	mov    %eax,%ecx
    3b60:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3b67:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3b6e:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3b72:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3b76:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3b7c:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    3b80:	83 e0 20             	and    $0x20,%eax
    3b83:	85 c0                	test   %eax,%eax
    3b85:	75 32                	jne    0x3bb9
    3b87:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3b8e:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3b94:	8b 95 74 ff ff ff    	mov    -0x8c(%rbp),%edx
    3b9a:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    3ba0:	e8 2d 25 fe ff       	call   0xfffffffffffe60d2
    3ba5:	89 c1                	mov    %eax,%ecx
    3ba7:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3bae:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3bb5:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3bb9:	8b 85 70 ff ff ff    	mov    -0x90(%rbp),%eax
    3bbf:	3d 00 20 00 00       	cmp    $0x2000,%eax
    3bc4:	0f 85 c8 c6 ff ff    	jne    0x292
    3bca:	8b 8d 6c ff ff ff    	mov    -0x94(%rbp),%ecx
    3bd0:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    3bd6:	39 c8                	cmp    %ecx,%eax
    3bd8:	0f 8d b4 c6 ff ff    	jge    0x292
    3bde:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3be5:	8b 95 60 ff ff ff    	mov    -0xa0(%rbp),%edx
    3beb:	8b 45 fc             	mov    -0x4(%rbp),%eax
    3bee:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3bf1:	29 d0                	sub    %edx,%eax
    3bf3:	41 89 c0             	mov    %eax,%r8d
    3bf6:	44 89 85 58 ff ff ff 	mov    %r8d,-0xa8(%rbp)
    3bfd:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3c04:	0f 92 c2             	setb   %dl
    3c07:	0f b6 d2             	movzbl %dl,%edx
    3c0a:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    3c10:	8d 71 40             	lea    0x40(%rcx),%esi
    3c13:	ba 20 00 00 00       	mov    $0x20,%edx
    3c18:	b9 00 01 00 00       	mov    $0x100,%ecx
    3c1d:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    3c24:	0f 42 c8             	cmovb  %eax,%ecx
    3c27:	e8 8c 25 fe ff       	call   0xfffffffffffe61b8
    3c2c:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    3c33:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    3c39:	89 c6                	mov    %eax,%esi
    3c3b:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    3c41:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    3c48:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    3c4c:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    3c4f:	89 ca                	mov    %ecx,%edx
    3c51:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    3c57:	83 e1 20             	and    $0x20,%ecx
    3c5a:	85 c9                	test   %ecx,%ecx
    3c5c:	0f 94 c1             	sete   %cl
    3c5f:	0f b6 c9             	movzbl %cl,%ecx
    3c62:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    3c68:	85 c0                	test   %eax,%eax
    3c6a:	75 7f                	jne    0x3ceb
    3c6c:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3c72:	83 e0 01             	and    $0x1,%eax
    3c75:	85 c0                	test   %eax,%eax
    3c77:	74 40                	je     0x3cb9
    3c79:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3c7f:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3c86:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3c89:	8d 70 40             	lea    0x40(%rax),%esi
    3c8c:	ba 00 01 00 00       	mov    $0x100,%edx
    3c91:	e8 3c 24 fe ff       	call   0xfffffffffffe60d2
    3c96:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3c9c:	89 c2                	mov    %eax,%edx
    3c9e:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3ca5:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3cac:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3cb0:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    3cb3:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    3cb9:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3cbf:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    3cc5:	83 e1 20             	and    $0x20,%ecx
    3cc8:	85 c9                	test   %ecx,%ecx
    3cca:	0f 94 c1             	sete   %cl
    3ccd:	0f b6 c9             	movzbl %cl,%ecx
    3cd0:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    3cd6:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    3cdc:	89 c1                	mov    %eax,%ecx
    3cde:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    3ce4:	3d ff 00 00 00       	cmp    $0xff,%eax
    3ce9:	77 81                	ja     0x3c6c
    3ceb:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3cf1:	85 c0                	test   %eax,%eax
    3cf3:	0f 84 99 c5 ff ff    	je     0x292
    3cf9:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3d00:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3d06:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    3d0c:	8b 45 cc             	mov    -0x34(%rbp),%eax
    3d0f:	8d 70 40             	lea    0x40(%rax),%esi
    3d12:	e8 bb 23 fe ff       	call   0xfffffffffffe60d2
    3d17:	89 c1                	mov    %eax,%ecx
    3d19:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3d20:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3d27:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3d2b:	e9 62 c5 ff ff       	jmp    0x292
    3d30:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    3d36:	85 c0                	test   %eax,%eax
    3d38:	0f 8c 19 04 00 00    	jl     0x4157
    3d3e:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    3d44:	8b 75 88             	mov    -0x78(%rbp),%esi
    3d47:	8b 95 64 ff ff ff    	mov    -0x9c(%rbp),%edx
    3d4d:	89 c1                	mov    %eax,%ecx
    3d4f:	8d 49 04             	lea    0x4(%rcx),%ecx
    3d52:	85 f6                	test   %esi,%esi
    3d54:	0f 45 ca             	cmovne %edx,%ecx
    3d57:	89 8d 78 ff ff ff    	mov    %ecx,-0x88(%rbp)
    3d5d:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
    3d63:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3d67:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    3d6d:	8b 55 d8             	mov    -0x28(%rbp),%edx
    3d70:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    3d76:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    3d79:	89 c1                	mov    %eax,%ecx
    3d7b:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    3d7e:	85 c0                	test   %eax,%eax
    3d80:	0f 84 a0 00 00 00    	je     0x3e26
    3d86:	31 c0                	xor    %eax,%eax
    3d88:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    3d8e:	8b 45 fc             	mov    -0x4(%rbp),%eax
    3d91:	8b 95 5c ff ff ff    	mov    -0xa4(%rbp),%edx
    3d97:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    3d9b:	8b 7d cc             	mov    -0x34(%rbp),%edi
    3d9e:	41 89 d2             	mov    %edx,%r10d
    3da1:	41 89 c0             	mov    %eax,%r8d
    3da4:	89 c1                	mov    %eax,%ecx
    3da6:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
    3dac:	89 c9                	mov    %ecx,%ecx
    3dae:	49 b9 cd cc cc cc 00 	movabs $0xcccccccd,%r9
    3db5:	00 00 00 
    3db8:	49 0f af c9          	imul   %r9,%rcx
    3dbc:	48 c1 e9 23          	shr    $0x23,%rcx
    3dc0:	41 89 c9             	mov    %ecx,%r9d
    3dc3:	44 89 c9             	mov    %r9d,%ecx
    3dc6:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    3dcc:	8d bf 50 01 00 00    	lea    0x150(%rdi),%edi
    3dd2:	44 01 d7             	add    %r10d,%edi
    3dd5:	8d 7f 08             	lea    0x8(%rdi),%edi
    3dd8:	45 6b c9 0a          	imul   $0xa,%r9d,%r9d
    3ddc:	45 29 c8             	sub    %r9d,%r8d
    3ddf:	41 83 c8 30          	or     $0x30,%r8d
    3de3:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
    3de7:	8d 52 ff             	lea    -0x1(%rdx),%edx
    3dea:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    3df0:	83 f8 09             	cmp    $0x9,%eax
    3df3:	0f 97 c0             	seta   %al
    3df6:	0f b6 c0             	movzbl %al,%eax
    3df9:	89 85 64 ff ff ff    	mov    %eax,-0x9c(%rbp)
    3dff:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    3e02:	85 c0                	test   %eax,%eax
    3e04:	75 88                	jne    0x3d8e
    3e06:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    3e0c:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3e0f:	89 c2                	mov    %eax,%edx
    3e11:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    3e17:	01 d1                	add    %edx,%ecx
    3e19:	8d 49 09             	lea    0x9(%rcx),%ecx
    3e1c:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    3e22:	85 c0                	test   %eax,%eax
    3e24:	75 1d                	jne    0x3e43
    3e26:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3e2a:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    3e30:	8d 49 ff             	lea    -0x1(%rcx),%ecx
    3e33:	89 ca                	mov    %ecx,%edx
    3e35:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    3e3b:	ba 30 00 00 00       	mov    $0x30,%edx
    3e40:	88 14 08             	mov    %dl,(%rax,%rcx,1)
    3e43:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    3e49:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    3e4f:	39 c8                	cmp    %ecx,%eax
    3e51:	74 73                	je     0x3ec6
    3e53:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3e56:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    3e5c:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    3e62:	39 c8                	cmp    %ecx,%eax
    3e64:	0f 86 0b 01 00 00    	jbe    0x3f75
    3e6a:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3e71:	8b 45 ec             	mov    -0x14(%rbp),%eax
    3e74:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    3e7a:	8b 55 cc             	mov    -0x34(%rbp),%edx
    3e7d:	8d b2 50 01 00 00    	lea    0x150(%rdx),%esi
    3e83:	ba 30 00 00 00       	mov    $0x30,%edx
    3e88:	01 c1                	add    %eax,%ecx
    3e8a:	e8 29 23 fe ff       	call   0xfffffffffffe61b8
    3e8f:	89 c1                	mov    %eax,%ecx
    3e91:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3e98:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3e9f:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3ea3:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    3ea6:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    3eac:	8d 40 ff             	lea    -0x1(%rax),%eax
    3eaf:	89 c2                	mov    %eax,%edx
    3eb1:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    3eb7:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    3ebd:	39 c8                	cmp    %ecx,%eax
    3ebf:	77 e2                	ja     0x3ea3
    3ec1:	e9 af 00 00 00       	jmp    0x3f75
    3ec6:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3eca:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3ed0:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    3ed4:	83 e0 20             	and    $0x20,%eax
    3ed7:	85 c0                	test   %eax,%eax
    3ed9:	75 31                	jne    0x3f0c
    3edb:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3ee2:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3ee8:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    3eee:	ba 01 00 00 00       	mov    $0x1,%edx
    3ef3:	e8 da 21 fe ff       	call   0xfffffffffffe60d2
    3ef8:	89 c1                	mov    %eax,%ecx
    3efa:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3f01:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3f08:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3f0c:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
    3f12:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    3f18:	8d 49 01             	lea    0x1(%rcx),%ecx
    3f1b:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    3f21:	85 c0                	test   %eax,%eax
    3f23:	75 0b                	jne    0x3f30
    3f25:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    3f2b:	83 f8 01             	cmp    $0x1,%eax
    3f2e:	7c 45                	jl     0x3f75
    3f30:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3f34:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3f3a:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    3f3e:	83 e0 20             	and    $0x20,%eax
    3f41:	85 c0                	test   %eax,%eax
    3f43:	75 30                	jne    0x3f75
    3f45:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3f4c:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3f52:	be f3 0d 00 00       	mov    $0xdf3,%esi
    3f57:	ba 01 00 00 00       	mov    $0x1,%edx
    3f5c:	e8 71 21 fe ff       	call   0xfffffffffffe60d2
    3f61:	89 c1                	mov    %eax,%ecx
    3f63:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3f6a:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3f71:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3f75:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    3f79:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3f7f:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    3f85:	8b 55 d8             	mov    -0x28(%rbp),%edx
    3f88:	29 f2                	sub    %esi,%edx
    3f8a:	89 55 fc             	mov    %edx,-0x4(%rbp)
    3f8d:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    3f91:	83 e0 20             	and    $0x20,%eax
    3f94:	85 c0                	test   %eax,%eax
    3f96:	75 43                	jne    0x3fdb
    3f98:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    3f9f:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    3fa5:	44 8b 4d fc          	mov    -0x4(%rbp),%r9d
    3fa9:	44 8b 85 7c ff ff ff 	mov    -0x84(%rbp),%r8d
    3fb0:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    3fb6:	44 89 c8             	mov    %r9d,%eax
    3fb9:	44 89 c2             	mov    %r8d,%edx
    3fbc:	45 39 c8             	cmp    %r9d,%r8d
    3fbf:	0f 4f d0             	cmovg  %eax,%edx
    3fc2:	e8 0b 21 fe ff       	call   0xfffffffffffe60d2
    3fc7:	89 c1                	mov    %eax,%ecx
    3fc9:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    3fd0:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    3fd7:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    3fdb:	8b 8d 78 ff ff ff    	mov    -0x88(%rbp),%ecx
    3fe1:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    3fe7:	8b 95 7c ff ff ff    	mov    -0x84(%rbp),%edx
    3fed:	8b 75 fc             	mov    -0x4(%rbp),%esi
    3ff0:	29 f2                	sub    %esi,%edx
    3ff2:	89 95 7c ff ff ff    	mov    %edx,-0x84(%rbp)
    3ff8:	8d 40 04             	lea    0x4(%rax),%eax
    3ffb:	89 c2                	mov    %eax,%edx
    3ffd:	89 95 60 ff ff ff    	mov    %edx,-0xa0(%rbp)
    4003:	39 c8                	cmp    %ecx,%eax
    4005:	73 0f                	jae    0x4016
    4007:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    400d:	83 f8 ff             	cmp    $0xffffffff,%eax
    4010:	0f 8f 4d fd ff ff    	jg     0x3d63
    4016:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    401c:	83 f8 01             	cmp    $0x1,%eax
    401f:	0f 8c 32 01 00 00    	jl     0x4157
    4025:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    402c:	44 8b 85 7c ff ff ff 	mov    -0x84(%rbp),%r8d
    4033:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    4036:	44 89 c0             	mov    %r8d,%eax
    4039:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4040:	0f 92 c2             	setb   %dl
    4043:	0f b6 d2             	movzbl %dl,%edx
    4046:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    404c:	8d 71 40             	lea    0x40(%rcx),%esi
    404f:	ba 30 00 00 00       	mov    $0x30,%edx
    4054:	b9 00 01 00 00       	mov    $0x100,%ecx
    4059:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4060:	0f 42 c8             	cmovb  %eax,%ecx
    4063:	e8 50 21 fe ff       	call   0xfffffffffffe61b8
    4068:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    406f:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    4075:	89 c6                	mov    %eax,%esi
    4077:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    407d:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    4084:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    4088:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    408b:	89 ca                	mov    %ecx,%edx
    408d:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    4093:	83 e1 20             	and    $0x20,%ecx
    4096:	85 c9                	test   %ecx,%ecx
    4098:	0f 94 c1             	sete   %cl
    409b:	0f b6 c9             	movzbl %cl,%ecx
    409e:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    40a1:	85 c0                	test   %eax,%eax
    40a3:	75 79                	jne    0x411e
    40a5:	8b 45 fc             	mov    -0x4(%rbp),%eax
    40a8:	83 e0 01             	and    $0x1,%eax
    40ab:	85 c0                	test   %eax,%eax
    40ad:	74 40                	je     0x40ef
    40af:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    40b5:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    40bc:	8b 45 cc             	mov    -0x34(%rbp),%eax
    40bf:	8d 70 40             	lea    0x40(%rax),%esi
    40c2:	ba 00 01 00 00       	mov    $0x100,%edx
    40c7:	e8 06 20 fe ff       	call   0xfffffffffffe60d2
    40cc:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    40d2:	89 c2                	mov    %eax,%edx
    40d4:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    40db:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    40e2:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    40e6:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    40e9:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    40ef:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    40f5:	8b 8d 58 ff ff ff    	mov    -0xa8(%rbp),%ecx
    40fb:	83 e1 20             	and    $0x20,%ecx
    40fe:	85 c9                	test   %ecx,%ecx
    4100:	0f 94 c1             	sete   %cl
    4103:	0f b6 c9             	movzbl %cl,%ecx
    4106:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4109:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    410f:	89 c1                	mov    %eax,%ecx
    4111:	89 8d 7c ff ff ff    	mov    %ecx,-0x84(%rbp)
    4117:	3d ff 00 00 00       	cmp    $0xff,%eax
    411c:	77 87                	ja     0x40a5
    411e:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4121:	85 c0                	test   %eax,%eax
    4123:	74 32                	je     0x4157
    4125:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    412c:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4132:	8b 95 7c ff ff ff    	mov    -0x84(%rbp),%edx
    4138:	8b 45 cc             	mov    -0x34(%rbp),%eax
    413b:	8d 70 40             	lea    0x40(%rax),%esi
    413e:	e8 8f 1f fe ff       	call   0xfffffffffffe60d2
    4143:	89 c1                	mov    %eax,%ecx
    4145:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    414c:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4153:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4157:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    415b:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4161:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    4165:	83 e0 20             	and    $0x20,%eax
    4168:	85 c0                	test   %eax,%eax
    416a:	75 30                	jne    0x419c
    416c:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4173:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4179:	8b 45 98             	mov    -0x68(%rbp),%eax
    417c:	8b 55 e8             	mov    -0x18(%rbp),%edx
    417f:	89 c6                	mov    %eax,%esi
    4181:	29 c2                	sub    %eax,%edx
    4183:	e8 4a 1f fe ff       	call   0xfffffffffffe60d2
    4188:	89 c1                	mov    %eax,%ecx
    418a:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4191:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4198:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    419c:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    41a2:	3d 00 20 00 00       	cmp    $0x2000,%eax
    41a7:	0f 85 4e 01 00 00    	jne    0x42fb
    41ad:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    41b0:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    41b6:	39 c8                	cmp    %ecx,%eax
    41b8:	0f 8e 3d 01 00 00    	jle    0x42fb
    41be:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    41c5:	8b 55 80             	mov    -0x80(%rbp),%edx
    41c8:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    41ce:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    41d1:	29 d0                	sub    %edx,%eax
    41d3:	41 89 c0             	mov    %eax,%r8d
    41d6:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    41da:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    41e1:	0f 92 c2             	setb   %dl
    41e4:	0f b6 d2             	movzbl %dl,%edx
    41e7:	89 95 54 ff ff ff    	mov    %edx,-0xac(%rbp)
    41ed:	8d 71 40             	lea    0x40(%rcx),%esi
    41f0:	ba 20 00 00 00       	mov    $0x20,%edx
    41f5:	b9 00 01 00 00       	mov    $0x100,%ecx
    41fa:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4201:	0f 42 c8             	cmovb  %eax,%ecx
    4204:	e8 af 1f fe ff       	call   0xfffffffffffe61b8
    4209:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    4210:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    4216:	89 c6                	mov    %eax,%esi
    4218:	8b 85 54 ff ff ff    	mov    -0xac(%rbp),%eax
    421e:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    4225:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    4229:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    422c:	89 ca                	mov    %ecx,%edx
    422e:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    4234:	83 e1 20             	and    $0x20,%ecx
    4237:	85 c9                	test   %ecx,%ecx
    4239:	0f 94 c1             	sete   %cl
    423c:	0f b6 c9             	movzbl %cl,%ecx
    423f:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    4245:	85 c0                	test   %eax,%eax
    4247:	75 79                	jne    0x42c2
    4249:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    424f:	83 e0 01             	and    $0x1,%eax
    4252:	85 c0                	test   %eax,%eax
    4254:	74 40                	je     0x4296
    4256:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    425c:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4263:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4266:	8d 70 40             	lea    0x40(%rax),%esi
    4269:	ba 00 01 00 00       	mov    $0x100,%edx
    426e:	e8 5f 1e fe ff       	call   0xfffffffffffe60d2
    4273:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4279:	89 c2                	mov    %eax,%edx
    427b:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4282:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4289:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    428d:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    4290:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    4296:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4299:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    429f:	83 e1 20             	and    $0x20,%ecx
    42a2:	85 c9                	test   %ecx,%ecx
    42a4:	0f 94 c1             	sete   %cl
    42a7:	0f b6 c9             	movzbl %cl,%ecx
    42aa:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    42b0:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    42b6:	89 c1                	mov    %eax,%ecx
    42b8:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    42bb:	3d ff 00 00 00       	cmp    $0xff,%eax
    42c0:	77 87                	ja     0x4249
    42c2:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    42c8:	85 c0                	test   %eax,%eax
    42ca:	74 2f                	je     0x42fb
    42cc:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    42d3:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    42d9:	8b 55 fc             	mov    -0x4(%rbp),%edx
    42dc:	8b 45 cc             	mov    -0x34(%rbp),%eax
    42df:	8d 70 40             	lea    0x40(%rax),%esi
    42e2:	e8 eb 1d fe ff       	call   0xfffffffffffe60d2
    42e7:	89 c1                	mov    %eax,%ecx
    42e9:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    42f0:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    42f7:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    42fb:	8b 75 80             	mov    -0x80(%rbp),%esi
    42fe:	8b 95 6c ff ff ff    	mov    -0x94(%rbp),%edx
    4304:	89 d1                	mov    %edx,%ecx
    4306:	89 f0                	mov    %esi,%eax
    4308:	39 f2                	cmp    %esi,%edx
    430a:	0f 4f c1             	cmovg  %ecx,%eax
    430d:	89 45 fc             	mov    %eax,-0x4(%rbp)
    4310:	e9 fe 0a 00 00       	jmp    0x4e13
    4315:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    431b:	8b 75 80             	mov    -0x80(%rbp),%esi
    431e:	8b 4d 94             	mov    -0x6c(%rbp),%ecx
    4321:	89 ca                	mov    %ecx,%edx
    4323:	83 e6 20             	and    $0x20,%esi
    4326:	89 f7                	mov    %esi,%edi
    4328:	89 bd 64 ff ff ff    	mov    %edi,-0x9c(%rbp)
    432e:	8d 52 09             	lea    0x9(%rdx),%edx
    4331:	85 f6                	test   %esi,%esi
    4333:	0f 45 ca             	cmovne %edx,%ecx
    4336:	89 8d 7c ff ff ff    	mov    %ecx,-0x84(%rbp)
    433c:	83 f8 0b             	cmp    $0xb,%eax
    433f:	0f 87 e0 00 00 00    	ja     0x4425
    4345:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    434b:	b8 0c 00 00 00       	mov    $0xc,%eax
    4350:	29 c8                	sub    %ecx,%eax
    4352:	85 c0                	test   %eax,%eax
    4354:	0f 84 cb 00 00 00    	je     0x4425
    435a:	f2 0f 10 85 40 ff ff 	movsd  -0xc0(%rbp),%xmm0
    4361:	ff 
    4362:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    4368:	8d 40 f4             	lea    -0xc(%rax),%eax
    436b:	89 45 fc             	mov    %eax,-0x4(%rbp)
    436e:	f2 0f 11 45 b8       	movsd  %xmm0,-0x48(%rbp)
    4373:	8b 55 fc             	mov    -0x4(%rbp),%edx
    4376:	f2 0f 10 45 b8       	movsd  -0x48(%rbp),%xmm0
    437b:	f2 0f 10 8d 40 ff ff 	movsd  -0xc0(%rbp),%xmm1
    4382:	ff 
    4383:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    4387:	f2 0f 11 45 b8       	movsd  %xmm0,-0x48(%rbp)
    438c:	89 d0                	mov    %edx,%eax
    438e:	8d 40 01             	lea    0x1(%rax),%eax
    4391:	89 c1                	mov    %eax,%ecx
    4393:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    4399:	39 d0                	cmp    %edx,%eax
    439b:	0f 93 c0             	setae  %al
    439e:	0f b6 c0             	movzbl %al,%eax
    43a1:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    43a7:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    43aa:	85 c0                	test   %eax,%eax
    43ac:	75 c5                	jne    0x4373
    43ae:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    43b2:	8b 8d 7c ff ff ff    	mov    -0x84(%rbp),%ecx
    43b8:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    43bc:	83 f8 2d             	cmp    $0x2d,%eax
    43bf:	75 4a                	jne    0x440b
    43c1:	f2 0f 10 4d b0       	movsd  -0x50(%rbp),%xmm1
    43c6:	f2 0f 10 55 b8       	movsd  -0x48(%rbp),%xmm2
    43cb:	0f 28 c2             	movaps %xmm2,%xmm0
    43ce:	66 48 0f 7e c8       	movq   %xmm1,%rax
    43d3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    43da:	00 00 80 
    43dd:	48 31 c8             	xor    %rcx,%rax
    43e0:	66 48 0f 6e c8       	movq   %rax,%xmm1
    43e5:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
    43e9:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
    43ed:	66 48 0f 7e c0       	movq   %xmm0,%rax
    43f2:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    43f9:	00 00 80 
    43fc:	48 31 c8             	xor    %rcx,%rax
    43ff:	66 48 0f 6e c0       	movq   %rax,%xmm0
    4404:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    4409:	eb 1a                	jmp    0x4425
    440b:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    4410:	f2 0f 10 4d b8       	movsd  -0x48(%rbp),%xmm1
    4415:	0f 28 d1             	movaps %xmm1,%xmm2
    4418:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
    441c:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
    4420:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    4425:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4429:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    442c:	8b 55 e8             	mov    -0x18(%rbp),%edx
    442f:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    4435:	8b 84 08 6c 01 00 00 	mov    0x16c(%rax,%rcx,1),%eax
    443c:	89 c2                	mov    %eax,%edx
    443e:	89 95 78 ff ff ff    	mov    %edx,-0x88(%rbp)
    4444:	c1 fa 1f             	sar    $0x1f,%edx
    4447:	89 d1                	mov    %edx,%ecx
    4449:	01 d0                	add    %edx,%eax
    444b:	31 c8                	xor    %ecx,%eax
    444d:	89 c1                	mov    %eax,%ecx
    444f:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4452:	85 c0                	test   %eax,%eax
    4454:	0f 84 a0 00 00 00    	je     0x44fa
    445a:	31 c0                	xor    %eax,%eax
    445c:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    4462:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4465:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    446b:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    446f:	8b 7d cc             	mov    -0x34(%rbp),%edi
    4472:	41 89 d2             	mov    %edx,%r10d
    4475:	41 89 c0             	mov    %eax,%r8d
    4478:	89 c1                	mov    %eax,%ecx
    447a:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
    4480:	89 c9                	mov    %ecx,%ecx
    4482:	49 b9 cd cc cc cc 00 	movabs $0xcccccccd,%r9
    4489:	00 00 00 
    448c:	49 0f af c9          	imul   %r9,%rcx
    4490:	48 c1 e9 23          	shr    $0x23,%rcx
    4494:	41 89 c9             	mov    %ecx,%r9d
    4497:	44 89 c9             	mov    %r9d,%ecx
    449a:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    44a0:	8d bf 44 01 00 00    	lea    0x144(%rdi),%edi
    44a6:	44 01 d7             	add    %r10d,%edi
    44a9:	8d 7f 0b             	lea    0xb(%rdi),%edi
    44ac:	45 6b c9 0a          	imul   $0xa,%r9d,%r9d
    44b0:	45 29 c8             	sub    %r9d,%r8d
    44b3:	41 83 c8 30          	or     $0x30,%r8d
    44b7:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
    44bb:	8d 52 ff             	lea    -0x1(%rdx),%edx
    44be:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    44c4:	83 f8 09             	cmp    $0x9,%eax
    44c7:	0f 97 c0             	seta   %al
    44ca:	0f b6 c0             	movzbl %al,%eax
    44cd:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
    44d3:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    44d6:	85 c0                	test   %eax,%eax
    44d8:	75 88                	jne    0x4462
    44da:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    44e0:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    44e3:	89 c2                	mov    %eax,%edx
    44e5:	8d 89 44 01 00 00    	lea    0x144(%rcx),%ecx
    44eb:	01 d1                	add    %edx,%ecx
    44ed:	8d 49 0c             	lea    0xc(%rcx),%ecx
    44f0:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    44f6:	85 c0                	test   %eax,%eax
    44f8:	75 1d                	jne    0x4517
    44fa:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    44fe:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    4504:	8d 49 ff             	lea    -0x1(%rcx),%ecx
    4507:	89 ca                	mov    %ecx,%edx
    4509:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    450f:	ba 30 00 00 00       	mov    $0x30,%edx
    4514:	88 14 08             	mov    %dl,(%rax,%rcx,1)
    4517:	8b 45 cc             	mov    -0x34(%rbp),%eax
    451a:	8b b5 5c ff ff ff    	mov    -0xa4(%rbp),%esi
    4520:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
    4526:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
    452a:	44 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%r9d
    4531:	44 8b 45 80          	mov    -0x80(%rbp),%r8d
    4535:	8b 7d 8c             	mov    -0x74(%rbp),%edi
    4538:	83 cf 02             	or     $0x2,%edi
    453b:	89 bd 74 ff ff ff    	mov    %edi,-0x8c(%rbp)
    4541:	89 f7                	mov    %esi,%edi
    4543:	8d 7f fe             	lea    -0x2(%rdi),%edi
    4546:	41 89 fa             	mov    %edi,%r10d
    4549:	44 89 95 70 ff ff ff 	mov    %r10d,-0x90(%rbp)
    4550:	45 8d 40 0f          	lea    0xf(%r8),%r8d
    4554:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
    4558:	8d 76 ff             	lea    -0x1(%rsi),%esi
    455b:	41 b8 2d 00 00 00    	mov    $0x2d,%r8d
    4561:	bf 2b 00 00 00       	mov    $0x2b,%edi
    4566:	45 85 c9             	test   %r9d,%r9d
    4569:	41 0f 4c f8          	cmovl  %r8d,%edi
    456d:	40 88 3c 32          	mov    %dil,(%rdx,%rsi,1)
    4571:	83 e1 08             	and    $0x8,%ecx
    4574:	89 8d 5c ff ff ff    	mov    %ecx,-0xa4(%rbp)
    457a:	8d 80 50 01 00 00    	lea    0x150(%rax),%eax
    4580:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    4586:	f2 0f 10 85 48 ff ff 	movsd  -0xb8(%rbp),%xmm0
    458d:	ff 
    458e:	f2 0f 10 4d b0       	movsd  -0x50(%rbp),%xmm1
    4593:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    4599:	89 45 fc             	mov    %eax,-0x4(%rbp)
    459c:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
    45a3:	ff ff 7f 
    45a6:	66 48 0f 6e d0       	movq   %rax,%xmm2
    45ab:	66 0f 54 ca          	andpd  %xmm2,%xmm1
    45af:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    45b3:	0f 97 c0             	seta   %al
    45b6:	0f b6 c0             	movzbl %al,%eax
    45b9:	85 c0                	test   %eax,%eax
    45bb:	74 72                	je     0x462f
    45bd:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    45c2:	f2 0f 11 85 70 fe ff 	movsd  %xmm0,-0x190(%rbp)
    45c9:	ff 
    45ca:	f2 0f 2c c0          	cvttsd2si %xmm0,%eax
    45ce:	89 85 7c fe ff ff    	mov    %eax,-0x184(%rbp)
    45d4:	83 f8 01             	cmp    $0x1,%eax
    45d7:	71 48                	jno    0x4621
    45d9:	f2 0f 10 85 70 fe ff 	movsd  -0x190(%rbp),%xmm0
    45e0:	ff 
    45e1:	66 0f 2e c0          	ucomisd %xmm0,%xmm0
    45e5:	0f 8a 85 08 00 00    	jp     0x4e70
    45eb:	f2 0f 10 85 70 fe ff 	movsd  -0x190(%rbp),%xmm0
    45f2:	ff 
    45f3:	48 b8 00 00 20 00 00 	movabs $0xc1e0000000200000,%rax
    45fa:	00 e0 c1 
    45fd:	66 48 0f 6e c8       	movq   %rax,%xmm1
    4602:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    4606:	0f 86 57 08 00 00    	jbe    0x4e63
    460c:	f2 0f 10 85 70 fe ff 	movsd  -0x190(%rbp),%xmm0
    4613:	ff 
    4614:	0f 57 c9             	xorps  %xmm1,%xmm1
    4617:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    461b:	0f 87 42 08 00 00    	ja     0x4e63
    4621:	8b 85 7c fe ff ff    	mov    -0x184(%rbp),%eax
    4627:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    462d:	eb 0b                	jmp    0x463a
    462f:	b8 00 00 00 80       	mov    $0x80000000,%eax
    4634:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    463a:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    463d:	8b 95 58 ff ff ff    	mov    -0xa8(%rbp),%edx
    4643:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4646:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    464b:	f2 0f 10 8d 40 ff ff 	movsd  -0xc0(%rbp),%xmm1
    4652:	ff 
    4653:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
    4657:	44 8b 8d 64 ff ff ff 	mov    -0x9c(%rbp),%r9d
    465e:	89 c7                	mov    %eax,%edi
    4660:	41 89 d0             	mov    %edx,%r8d
    4663:	45 8d 80 c0 0d 00 00 	lea    0xdc0(%r8),%r8d
    466a:	46 0f b6 04 06       	movzbl (%rsi,%r8,1),%r8d
    466f:	45 09 c8             	or     %r9d,%r8d
    4672:	44 88 04 3e          	mov    %r8b,(%rsi,%rdi,1)
    4676:	0f 57 d2             	xorps  %xmm2,%xmm2
    4679:	f2 0f 2a d2          	cvtsi2sd %edx,%xmm2
    467d:	f2 0f 5c c2          	subsd  %xmm2,%xmm0
    4681:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    4685:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
    468a:	8d 40 01             	lea    0x1(%rax),%eax
    468d:	89 c2                	mov    %eax,%edx
    468f:	89 95 58 ff ff ff    	mov    %edx,-0xa8(%rbp)
    4695:	8d 89 50 01 00 00    	lea    0x150(%rcx),%ecx
    469b:	29 c8                	sub    %ecx,%eax
    469d:	83 f8 01             	cmp    $0x1,%eax
    46a0:	75 4b                	jne    0x46ed
    46a2:	8b 85 5c ff ff ff    	mov    -0xa4(%rbp),%eax
    46a8:	85 c0                	test   %eax,%eax
    46aa:	75 25                	jne    0x46d1
    46ac:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    46b2:	85 c0                	test   %eax,%eax
    46b4:	7f 1b                	jg     0x46d1
    46b6:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    46bb:	0f 57 c9             	xorps  %xmm1,%xmm1
    46be:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    46c2:	0f 94 c0             	sete   %al
    46c5:	0f 9b c1             	setnp  %cl
    46c8:	20 c8                	and    %cl,%al
    46ca:	0f b6 c0             	movzbl %al,%eax
    46cd:	85 c0                	test   %eax,%eax
    46cf:	75 1c                	jne    0x46ed
    46d1:	8b 45 fc             	mov    -0x4(%rbp),%eax
    46d4:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
    46d8:	89 c2                	mov    %eax,%edx
    46da:	be 2e 00 00 00       	mov    $0x2e,%esi
    46df:	40 88 74 11 01       	mov    %sil,0x1(%rcx,%rdx,1)
    46e4:	8d 40 02             	lea    0x2(%rax),%eax
    46e7:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
    46ed:	f2 0f 10 45 b0       	movsd  -0x50(%rbp),%xmm0
    46f2:	0f 57 c9             	xorps  %xmm1,%xmm1
    46f5:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
    46f9:	0f 95 c0             	setne  %al
    46fc:	0f 9a c1             	setp   %cl
    46ff:	08 c8                	or     %cl,%al
    4701:	0f b6 c0             	movzbl %al,%eax
    4704:	85 c0                	test   %eax,%eax
    4706:	0f 85 7a fe ff ff    	jne    0x4586
    470c:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
    4712:	8b b5 70 ff ff ff    	mov    -0x90(%rbp),%esi
    4718:	8b 45 e8             	mov    -0x18(%rbp),%eax
    471b:	8b 95 74 ff ff ff    	mov    -0x8c(%rbp),%edx
    4721:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    4726:	89 7d fc             	mov    %edi,-0x4(%rbp)
    4729:	29 f0                	sub    %esi,%eax
    472b:	89 c6                	mov    %eax,%esi
    472d:	89 b5 78 ff ff ff    	mov    %esi,-0x88(%rbp)
    4733:	01 c2                	add    %eax,%edx
    4735:	89 d0                	mov    %edx,%eax
    4737:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    473d:	b8 fd ff ff 7f       	mov    $0x7ffffffd,%eax
    4742:	29 d0                	sub    %edx,%eax
    4744:	39 c8                	cmp    %ecx,%eax
    4746:	0f 8c c7 06 00 00    	jl     0x4e13
    474c:	8b bd 60 ff ff ff    	mov    -0xa0(%rbp),%edi
    4752:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    4758:	44 8b 9d 58 ff ff ff 	mov    -0xa8(%rbp),%r11d
    475f:	44 8b 4d d4          	mov    -0x2c(%rbp),%r9d
    4763:	8b 55 cc             	mov    -0x34(%rbp),%edx
    4766:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    476c:	41 89 f8             	mov    %edi,%r8d
    476f:	44 89 de             	mov    %r11d,%esi
    4772:	8d 92 50 01 00 00    	lea    0x150(%rdx),%edx
    4778:	29 d6                	sub    %edx,%esi
    477a:	89 f2                	mov    %esi,%edx
    477c:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    4782:	41 89 fa             	mov    %edi,%r10d
    4785:	45 8d 40 02          	lea    0x2(%r8),%r8d
    4789:	45 01 d9             	add    %r11d,%r9d
    478c:	45 39 d1             	cmp    %r10d,%r9d
    478f:	41 0f 4c f0          	cmovl  %r8d,%esi
    4793:	85 ff                	test   %edi,%edi
    4795:	0f 45 d6             	cmovne %esi,%edx
    4798:	89 d6                	mov    %edx,%esi
    479a:	89 75 84             	mov    %esi,-0x7c(%rbp)
    479d:	01 d1                	add    %edx,%ecx
    479f:	89 8d 54 ff ff ff    	mov    %ecx,-0xac(%rbp)
    47a5:	25 00 20 01 00       	and    $0x12000,%eax
    47aa:	89 c1                	mov    %eax,%ecx
    47ac:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
    47b2:	85 c0                	test   %eax,%eax
    47b4:	0f 85 54 01 00 00    	jne    0x490e
    47ba:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    47c0:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    47c6:	39 c8                	cmp    %ecx,%eax
    47c8:	0f 8e 40 01 00 00    	jle    0x490e
    47ce:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    47d5:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    47db:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    47e1:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    47e4:	29 d0                	sub    %edx,%eax
    47e6:	41 89 c0             	mov    %eax,%r8d
    47e9:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    47ed:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    47f4:	0f 92 c2             	setb   %dl
    47f7:	0f b6 d2             	movzbl %dl,%edx
    47fa:	89 95 68 ff ff ff    	mov    %edx,-0x98(%rbp)
    4800:	8d 71 40             	lea    0x40(%rcx),%esi
    4803:	ba 20 00 00 00       	mov    $0x20,%edx
    4808:	b9 00 01 00 00       	mov    $0x100,%ecx
    480d:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4814:	0f 42 c8             	cmovb  %eax,%ecx
    4817:	e8 9c 19 fe ff       	call   0xfffffffffffe61b8
    481c:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    4823:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    4829:	89 c6                	mov    %eax,%esi
    482b:	8b 85 68 ff ff ff    	mov    -0x98(%rbp),%eax
    4831:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    4838:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    483c:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    483f:	89 ca                	mov    %ecx,%edx
    4841:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    4847:	83 e1 20             	and    $0x20,%ecx
    484a:	85 c9                	test   %ecx,%ecx
    484c:	0f 94 c1             	sete   %cl
    484f:	0f b6 c9             	movzbl %cl,%ecx
    4852:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    4858:	85 c0                	test   %eax,%eax
    485a:	75 79                	jne    0x48d5
    485c:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    4862:	83 e0 01             	and    $0x1,%eax
    4865:	85 c0                	test   %eax,%eax
    4867:	74 40                	je     0x48a9
    4869:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    486f:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4876:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4879:	8d 70 40             	lea    0x40(%rax),%esi
    487c:	ba 00 01 00 00       	mov    $0x100,%edx
    4881:	e8 4c 18 fe ff       	call   0xfffffffffffe60d2
    4886:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    488c:	89 c2                	mov    %eax,%edx
    488e:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4895:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    489c:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    48a0:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    48a3:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    48a9:	8b 45 fc             	mov    -0x4(%rbp),%eax
    48ac:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    48b2:	83 e1 20             	and    $0x20,%ecx
    48b5:	85 c9                	test   %ecx,%ecx
    48b7:	0f 94 c1             	sete   %cl
    48ba:	0f b6 c9             	movzbl %cl,%ecx
    48bd:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    48c3:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    48c9:	89 c1                	mov    %eax,%ecx
    48cb:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    48ce:	3d ff 00 00 00       	cmp    $0xff,%eax
    48d3:	77 87                	ja     0x485c
    48d5:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    48db:	85 c0                	test   %eax,%eax
    48dd:	74 2f                	je     0x490e
    48df:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    48e6:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    48ec:	8b 55 fc             	mov    -0x4(%rbp),%edx
    48ef:	8b 45 cc             	mov    -0x34(%rbp),%eax
    48f2:	8d 70 40             	lea    0x40(%rax),%esi
    48f5:	e8 d8 17 fe ff       	call   0xfffffffffffe60d2
    48fa:	89 c1                	mov    %eax,%ecx
    48fc:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4903:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    490a:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    490e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4912:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4918:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    491c:	83 e0 20             	and    $0x20,%eax
    491f:	85 c0                	test   %eax,%eax
    4921:	75 32                	jne    0x4955
    4923:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    492a:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4930:	8b 95 74 ff ff ff    	mov    -0x8c(%rbp),%edx
    4936:	8b b5 7c ff ff ff    	mov    -0x84(%rbp),%esi
    493c:	e8 91 17 fe ff       	call   0xfffffffffffe60d2
    4941:	89 c1                	mov    %eax,%ecx
    4943:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    494a:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4951:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4955:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    495b:	3d 00 00 01 00       	cmp    $0x10000,%eax
    4960:	0f 85 54 01 00 00    	jne    0x4aba
    4966:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    496c:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    4972:	39 c8                	cmp    %ecx,%eax
    4974:	0f 8e 40 01 00 00    	jle    0x4aba
    497a:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4981:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    4987:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    498d:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    4990:	29 d0                	sub    %edx,%eax
    4992:	41 89 c0             	mov    %eax,%r8d
    4995:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    4999:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    49a0:	0f 92 c2             	setb   %dl
    49a3:	0f b6 d2             	movzbl %dl,%edx
    49a6:	89 95 74 ff ff ff    	mov    %edx,-0x8c(%rbp)
    49ac:	8d 71 40             	lea    0x40(%rcx),%esi
    49af:	ba 30 00 00 00       	mov    $0x30,%edx
    49b4:	b9 00 01 00 00       	mov    $0x100,%ecx
    49b9:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    49c0:	0f 42 c8             	cmovb  %eax,%ecx
    49c3:	e8 f0 17 fe ff       	call   0xfffffffffffe61b8
    49c8:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    49cf:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    49d5:	89 c6                	mov    %eax,%esi
    49d7:	8b 85 74 ff ff ff    	mov    -0x8c(%rbp),%eax
    49dd:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    49e4:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    49e8:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    49eb:	89 ca                	mov    %ecx,%edx
    49ed:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    49f3:	83 e1 20             	and    $0x20,%ecx
    49f6:	85 c9                	test   %ecx,%ecx
    49f8:	0f 94 c1             	sete   %cl
    49fb:	0f b6 c9             	movzbl %cl,%ecx
    49fe:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    4a04:	85 c0                	test   %eax,%eax
    4a06:	75 79                	jne    0x4a81
    4a08:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    4a0e:	83 e0 01             	and    $0x1,%eax
    4a11:	85 c0                	test   %eax,%eax
    4a13:	74 40                	je     0x4a55
    4a15:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4a1b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4a22:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4a25:	8d 70 40             	lea    0x40(%rax),%esi
    4a28:	ba 00 01 00 00       	mov    $0x100,%edx
    4a2d:	e8 a0 16 fe ff       	call   0xfffffffffffe60d2
    4a32:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4a38:	89 c2                	mov    %eax,%edx
    4a3a:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4a41:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4a48:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4a4c:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    4a4f:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    4a55:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4a58:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    4a5e:	83 e1 20             	and    $0x20,%ecx
    4a61:	85 c9                	test   %ecx,%ecx
    4a63:	0f 94 c1             	sete   %cl
    4a66:	0f b6 c9             	movzbl %cl,%ecx
    4a69:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    4a6f:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    4a75:	89 c1                	mov    %eax,%ecx
    4a77:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4a7a:	3d ff 00 00 00       	cmp    $0xff,%eax
    4a7f:	77 87                	ja     0x4a08
    4a81:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    4a87:	85 c0                	test   %eax,%eax
    4a89:	74 2f                	je     0x4aba
    4a8b:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4a92:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4a98:	8b 55 fc             	mov    -0x4(%rbp),%edx
    4a9b:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4a9e:	8d 70 40             	lea    0x40(%rax),%esi
    4aa1:	e8 2c 16 fe ff       	call   0xfffffffffffe60d2
    4aa6:	89 c1                	mov    %eax,%ecx
    4aa8:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4aaf:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4ab6:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4aba:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4abe:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4ac4:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    4ac8:	83 e0 20             	and    $0x20,%eax
    4acb:	85 c0                	test   %eax,%eax
    4acd:	75 35                	jne    0x4b04
    4acf:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4ad6:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4adc:	8b 95 64 ff ff ff    	mov    -0x9c(%rbp),%edx
    4ae2:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4ae5:	8d b0 50 01 00 00    	lea    0x150(%rax),%esi
    4aeb:	e8 e2 15 fe ff       	call   0xfffffffffffe60d2
    4af0:	89 c1                	mov    %eax,%ecx
    4af2:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4af9:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4b00:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4b04:	8b 8d 64 ff ff ff    	mov    -0x9c(%rbp),%ecx
    4b0a:	8b 45 84             	mov    -0x7c(%rbp),%eax
    4b0d:	29 c8                	sub    %ecx,%eax
    4b0f:	89 c1                	mov    %eax,%ecx
    4b11:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4b14:	83 f8 01             	cmp    $0x1,%eax
    4b17:	0f 8c 32 01 00 00    	jl     0x4c4f
    4b1d:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4b24:	44 8b 45 fc          	mov    -0x4(%rbp),%r8d
    4b28:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    4b2b:	44 89 c0             	mov    %r8d,%eax
    4b2e:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4b35:	0f 92 c2             	setb   %dl
    4b38:	0f b6 d2             	movzbl %dl,%edx
    4b3b:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    4b41:	8d 71 40             	lea    0x40(%rcx),%esi
    4b44:	ba 30 00 00 00       	mov    $0x30,%edx
    4b49:	b9 00 01 00 00       	mov    $0x100,%ecx
    4b4e:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4b55:	0f 42 c8             	cmovb  %eax,%ecx
    4b58:	e8 5b 16 fe ff       	call   0xfffffffffffe61b8
    4b5d:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    4b64:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    4b6a:	89 c6                	mov    %eax,%esi
    4b6c:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    4b72:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    4b79:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    4b7d:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    4b80:	89 ca                	mov    %ecx,%edx
    4b82:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    4b88:	83 e1 20             	and    $0x20,%ecx
    4b8b:	85 c9                	test   %ecx,%ecx
    4b8d:	0f 94 c1             	sete   %cl
    4b90:	0f b6 c9             	movzbl %cl,%ecx
    4b93:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    4b99:	85 c0                	test   %eax,%eax
    4b9b:	75 79                	jne    0x4c16
    4b9d:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    4ba3:	83 e0 01             	and    $0x1,%eax
    4ba6:	85 c0                	test   %eax,%eax
    4ba8:	74 40                	je     0x4bea
    4baa:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4bb0:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4bb7:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4bba:	8d 70 40             	lea    0x40(%rax),%esi
    4bbd:	ba 00 01 00 00       	mov    $0x100,%edx
    4bc2:	e8 0b 15 fe ff       	call   0xfffffffffffe60d2
    4bc7:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4bcd:	89 c2                	mov    %eax,%edx
    4bcf:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4bd6:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4bdd:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4be1:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    4be4:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    4bea:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4bed:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    4bf3:	83 e1 20             	and    $0x20,%ecx
    4bf6:	85 c9                	test   %ecx,%ecx
    4bf8:	0f 94 c1             	sete   %cl
    4bfb:	0f b6 c9             	movzbl %cl,%ecx
    4bfe:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    4c04:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    4c0a:	89 c1                	mov    %eax,%ecx
    4c0c:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4c0f:	3d ff 00 00 00       	cmp    $0xff,%eax
    4c14:	77 87                	ja     0x4b9d
    4c16:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    4c1c:	85 c0                	test   %eax,%eax
    4c1e:	74 2f                	je     0x4c4f
    4c20:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4c27:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4c2d:	8b 55 fc             	mov    -0x4(%rbp),%edx
    4c30:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4c33:	8d 70 40             	lea    0x40(%rax),%esi
    4c36:	e8 97 14 fe ff       	call   0xfffffffffffe60d2
    4c3b:	89 c1                	mov    %eax,%ecx
    4c3d:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4c44:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4c4b:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4c4f:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4c53:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4c59:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
    4c5d:	83 e0 20             	and    $0x20,%eax
    4c60:	85 c0                	test   %eax,%eax
    4c62:	75 32                	jne    0x4c96
    4c64:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4c6b:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4c71:	8b 95 78 ff ff ff    	mov    -0x88(%rbp),%edx
    4c77:	8b b5 70 ff ff ff    	mov    -0x90(%rbp),%esi
    4c7d:	e8 50 14 fe ff       	call   0xfffffffffffe60d2
    4c82:	89 c1                	mov    %eax,%ecx
    4c84:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4c8b:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4c92:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4c96:	8b 85 60 ff ff ff    	mov    -0xa0(%rbp),%eax
    4c9c:	3d 00 20 00 00       	cmp    $0x2000,%eax
    4ca1:	0f 85 54 01 00 00    	jne    0x4dfb
    4ca7:	8b 8d 54 ff ff ff    	mov    -0xac(%rbp),%ecx
    4cad:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    4cb3:	39 c8                	cmp    %ecx,%eax
    4cb5:	0f 8e 40 01 00 00    	jle    0x4dfb
    4cbb:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4cc2:	8b 95 54 ff ff ff    	mov    -0xac(%rbp),%edx
    4cc8:	8b 85 6c ff ff ff    	mov    -0x94(%rbp),%eax
    4cce:	8b 4d cc             	mov    -0x34(%rbp),%ecx
    4cd1:	29 d0                	sub    %edx,%eax
    4cd3:	41 89 c0             	mov    %eax,%r8d
    4cd6:	44 89 45 fc          	mov    %r8d,-0x4(%rbp)
    4cda:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4ce1:	0f 92 c2             	setb   %dl
    4ce4:	0f b6 d2             	movzbl %dl,%edx
    4ce7:	89 95 64 ff ff ff    	mov    %edx,-0x9c(%rbp)
    4ced:	8d 71 40             	lea    0x40(%rcx),%esi
    4cf0:	ba 20 00 00 00       	mov    $0x20,%edx
    4cf5:	b9 00 01 00 00       	mov    $0x100,%ecx
    4cfa:	41 81 f8 00 01 00 00 	cmp    $0x100,%r8d
    4d01:	0f 42 c8             	cmovb  %eax,%ecx
    4d04:	e8 af 14 fe ff       	call   0xfffffffffffe61b8
    4d09:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    4d10:	8b 95 e4 fe ff ff    	mov    -0x11c(%rbp),%edx
    4d16:	89 c6                	mov    %eax,%esi
    4d18:	8b 85 64 ff ff ff    	mov    -0x9c(%rbp),%eax
    4d1e:	48 8b 89 90 12 00 00 	mov    0x1290(%rcx),%rcx
    4d25:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
    4d29:	8b 0c 11             	mov    (%rcx,%rdx,1),%ecx
    4d2c:	89 ca                	mov    %ecx,%edx
    4d2e:	89 95 5c ff ff ff    	mov    %edx,-0xa4(%rbp)
    4d34:	83 e1 20             	and    $0x20,%ecx
    4d37:	85 c9                	test   %ecx,%ecx
    4d39:	0f 94 c1             	sete   %cl
    4d3c:	0f b6 c9             	movzbl %cl,%ecx
    4d3f:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    4d45:	85 c0                	test   %eax,%eax
    4d47:	75 79                	jne    0x4dc2
    4d49:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    4d4f:	83 e0 01             	and    $0x1,%eax
    4d52:	85 c0                	test   %eax,%eax
    4d54:	74 40                	je     0x4d96
    4d56:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4d5c:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4d63:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4d66:	8d 70 40             	lea    0x40(%rax),%esi
    4d69:	ba 00 01 00 00       	mov    $0x100,%edx
    4d6e:	e8 5f 13 fe ff       	call   0xfffffffffffe60d2
    4d73:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4d79:	89 c2                	mov    %eax,%edx
    4d7b:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4d82:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4d89:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4d8d:	8b 04 08             	mov    (%rax,%rcx,1),%eax
    4d90:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%rbp)
    4d96:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4d99:	8b 8d 5c ff ff ff    	mov    -0xa4(%rbp),%ecx
    4d9f:	83 e1 20             	and    $0x20,%ecx
    4da2:	85 c9                	test   %ecx,%ecx
    4da4:	0f 94 c1             	sete   %cl
    4da7:	0f b6 c9             	movzbl %cl,%ecx
    4daa:	89 8d 58 ff ff ff    	mov    %ecx,-0xa8(%rbp)
    4db0:	8d 80 00 ff ff ff    	lea    -0x100(%rax),%eax
    4db6:	89 c1                	mov    %eax,%ecx
    4db8:	89 4d fc             	mov    %ecx,-0x4(%rbp)
    4dbb:	3d ff 00 00 00       	cmp    $0xff,%eax
    4dc0:	77 87                	ja     0x4d49
    4dc2:	8b 85 58 ff ff ff    	mov    -0xa8(%rbp),%eax
    4dc8:	85 c0                	test   %eax,%eax
    4dca:	74 2f                	je     0x4dfb
    4dcc:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4dd3:	8b 8d e4 fe ff ff    	mov    -0x11c(%rbp),%ecx
    4dd9:	8b 55 fc             	mov    -0x4(%rbp),%edx
    4ddc:	8b 45 cc             	mov    -0x34(%rbp),%eax
    4ddf:	8d 70 40             	lea    0x40(%rax),%esi
    4de2:	e8 eb 12 fe ff       	call   0xfffffffffffe60d2
    4de7:	89 c1                	mov    %eax,%ecx
    4de9:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    4df0:	48 8b 80 90 12 00 00 	mov    0x1290(%rax),%rax
    4df7:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
    4dfb:	8b b5 54 ff ff ff    	mov    -0xac(%rbp),%esi
    4e01:	8b 95 6c ff ff ff    	mov    -0x94(%rbp),%edx
    4e07:	89 d1                	mov    %edx,%ecx
    4e09:	89 f0                	mov    %esi,%eax
    4e0b:	39 f2                	cmp    %esi,%edx
    4e0d:	0f 4f c1             	cmovg  %ecx,%eax
    4e10:	89 45 fc             	mov    %eax,-0x4(%rbp)
    4e13:	8b 45 fc             	mov    -0x4(%rbp),%eax
    4e16:	85 c0                	test   %eax,%eax
    4e18:	0f 8d 74 b4 ff ff    	jge    0x292
    4e1e:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
    4e22:	b9 3d 00 00 00       	mov    $0x3d,%ecx
    4e27:	89 88 e0 10 00 00    	mov    %ecx,0x10e0(%rax)
    4e2d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    4e32:	89 45 f8             	mov    %eax,-0x8(%rbp)
    4e35:	8b 45 f8             	mov    -0x8(%rbp),%eax
    4e38:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
    4e3f:	8b 55 cc             	mov    -0x34(%rbp),%edx
    4e42:	8d 92 70 03 00 00    	lea    0x370(%rdx),%edx
    4e48:	89 91 50 12 00 00    	mov    %edx,0x1250(%rcx)
    4e4e:	89 85 6c fe ff ff    	mov    %eax,-0x194(%rbp)
    4e54:	8b 85 6c fe ff ff    	mov    -0x194(%rbp),%eax
    4e5a:	48 81 c4 a0 01 00 00 	add    $0x1a0,%rsp
    4e61:	5d                   	pop    %rbp
    4e62:	c3                   	ret
    4e63:	b8 6a 00 00 00       	mov    $0x6a,%eax
    4e68:	89 85 68 fe ff ff    	mov    %eax,-0x198(%rbp)
    4e6e:	eb 0d                	jmp    0x4e7d
    4e70:	b8 6d 00 00 00       	mov    $0x6d,%eax
    4e75:	89 85 68 fe ff ff    	mov    %eax,-0x198(%rbp)
    4e7b:	eb 00                	jmp    0x4e7d
    4e7d:	8b b5 68 fe ff ff    	mov    -0x198(%rbp),%esi
    4e83:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4e8a:	48 b8 b0 f4 a6 e7 18 	movabs $0x5618e7a6f4b0,%rax
    4e91:	56 00 00 
    4e94:	ff d0                	call   *%rax
    4e96:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
    4e9d:	48 b8 10 f5 a6 e7 18 	movabs $0x5618e7a6f510,%rax
    4ea4:	56 00 00 
    4ea7:	ff d0                	call   *%rax
    4ea9:	31 c0                	xor    %eax,%eax
    4eab:	48 81 c4 a0 01 00 00 	add    $0x1a0,%rsp
    4eb2:	5d                   	pop    %rbp
    4eb3:	c3                   	ret
    4eb4:	bf c0 ff ff ba       	mov    $0xbaffffc0,%edi
    4eb9:	c0 ff ff             	sar    $0xff,%bh
    4ebc:	b5 c0                	mov    $0xc0,%ch
    4ebe:	ff                   	(bad)
    4ebf:	ff                   	(bad)
    4ec0:	ba c0 ff ff bf       	mov    $0xbfffffc0,%edx
    4ec5:	c0 ff ff             	sar    $0xff,%bh
    4ec8:	bf c0 ff ff bf       	mov    $0xbfffffc0,%edi
    4ecd:	c0 ff ff             	sar    $0xff,%bh
    4ed0:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4ed5:	c0 ff ff             	sar    $0xff,%bh
    4ed8:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4edd:	c0 ff ff             	sar    $0xff,%bh
    4ee0:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4ee5:	c0 ff ff             	sar    $0xff,%bh
    4ee8:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4eed:	c0 ff ff             	sar    $0xff,%bh
    4ef0:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4ef5:	c0 ff ff             	sar    $0xff,%bh
    4ef8:	ba c0 ff ff b0       	mov    $0xb0ffffc0,%edx
    4efd:	c0 ff ff             	sar    $0xff,%bh
    4f00:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4f05:	c0 ff ff             	sar    $0xff,%bh
    4f08:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4f0d:	c0 ff ff             	sar    $0xff,%bh
    4f10:	ab                   	stos   %eax,%es:(%rdi)
    4f11:	c0 ff ff             	sar    $0xff,%bh
    4f14:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4f19:	c0 ff ff             	sar    $0xff,%bh
    4f1c:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4f21:	c0 ff ff             	sar    $0xff,%bh
    4f24:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4f29:	c0 ff ff             	sar    $0xff,%bh
    4f2c:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4f31:	c0 ff ff             	sar    $0xff,%bh
    4f34:	bf c0 ff ff ba       	mov    $0xbaffffc0,%edi
    4f39:	c0 ff ff             	sar    $0xff,%bh
    4f3c:	a6                   	cmpsb  %es:(%rdi),%ds:(%rsi)
    4f3d:	c0 ff ff             	sar    $0xff,%bh
    4f40:	a1 c0 ff ff bf c0 ff 	movabs 0xbfffffc0bfffffc0,%eax
    4f47:	ff bf 
    4f49:	c0 ff ff             	sar    $0xff,%bh
    4f4c:	bf c0 ff ff ba       	mov    $0xbaffffc0,%edi
    4f51:	c0 ff ff             	sar    $0xff,%bh
    4f54:	a1 c0 ff ff ba c0 ff 	movabs 0xbaffffc0baffffc0,%eax
    4f5b:	ff ba 
    4f5d:	c0 ff ff             	sar    $0xff,%bh
    4f60:	ba c0 ff ff 9c       	mov    $0x9cffffc0,%edx
    4f65:	c0 ff ff             	sar    $0xff,%bh
    4f68:	9a                   	(bad)
    4f69:	c0 ff ff             	sar    $0xff,%bh
    4f6c:	95                   	xchg   %eax,%ebp
    4f6d:	c0 ff ff             	sar    $0xff,%bh
    4f70:	90                   	nop
    4f71:	c0 ff ff             	sar    $0xff,%bh
    4f74:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4f79:	c0 ff ff             	sar    $0xff,%bh
    4f7c:	8b c0                	mov    %eax,%eax
    4f7e:	ff                   	(bad)
    4f7f:	ff                   	(bad)
    4f80:	ba c0 ff ff 89       	mov    $0x89ffffc0,%edx
    4f85:	c0 ff ff             	sar    $0xff,%bh
    4f88:	ba c0 ff ff ba       	mov    $0xbaffffc0,%edx
    4f8d:	c0 ff ff             	sar    $0xff,%bh
    4f90:	ab                   	stos   %eax,%es:(%rdi)
    4f91:	c0 ff ff             	sar    $0xff,%bh
    4f94:	50                   	push   %rax
    4f95:	c0 ff ff             	sar    $0xff,%bh
    4f98:	4e c0 ff ff          	rex.WRX sar $0xff,%dil
    4f9c:	4c c0 ff ff          	rex.WR sar $0xff,%dil
    4fa0:	4a c0 ff ff          	rex.WX sar $0xff,%dil
    4fa4:	48 c0 ff ff          	rex.W sar $0xff,%dil
    4fa8:	43 c0 ff ff          	rex.XB sar $0xff,%r15b
    4fac:	39 c0                	cmp    %eax,%eax
    4fae:	ff                   	(bad)
    4faf:	ff                   	(bad)
    4fb0:	3e c0 ff ff          	ds sar $0xff,%bh
