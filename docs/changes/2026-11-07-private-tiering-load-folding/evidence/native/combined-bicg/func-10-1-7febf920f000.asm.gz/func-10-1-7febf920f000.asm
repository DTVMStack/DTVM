
/workspace/DTVM/work/combined-optimization/v2/profiles/bicg-repeat30-main/func-10-1-7febf920f000.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	41 57                	push   %r15
   6:	41 56                	push   %r14
   8:	41 55                	push   %r13
   a:	41 54                	push   %r12
   c:	53                   	push   %rbx
   d:	48 83 ec 38          	sub    $0x38,%rsp
  11:	48 89 fb             	mov    %rdi,%rbx
  14:	48 b8 00 00 00 00 00 	movabs $0x409db00000000000,%rax
  1b:	b0 9d 40 
  1e:	66 48 0f 6e c0       	movq   %rax,%xmm0
  23:	f2 0f 11 45 a8       	movsd  %xmm0,-0x58(%rbp)
  28:	48 b8 00 00 00 00 00 	movabs $0x40a0680000000000,%rax
  2f:	68 a0 40 
  32:	66 48 0f 6e c0       	movq   %rax,%xmm0
  37:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
  3c:	31 c0                	xor    %eax,%eax
  3e:	31 c0                	xor    %eax,%eax
  40:	31 c0                	xor    %eax,%eax
  42:	31 c0                	xor    %eax,%eax
  44:	31 c0                	xor    %eax,%eax
  46:	31 c0                	xor    %eax,%eax
  48:	31 c0                	xor    %eax,%eax
  4a:	31 c0                	xor    %eax,%eax
  4c:	31 c0                	xor    %eax,%eax
  4e:	31 c0                	xor    %eax,%eax
  50:	31 c0                	xor    %eax,%eax
  52:	31 c0                	xor    %eax,%eax
  54:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
  5b:	ff 
  5c:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
  63:	be 10 00 00 00       	mov    $0x10,%esi
  68:	48 89 df             	mov    %rbx,%rdi
  6b:	e8 98 11 ff ff       	call   0xffffffffffff1208
  70:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
  77:	8b 83 50 12 00 00    	mov    0x1250(%rbx),%eax
  7d:	44 8d 70 a0          	lea    -0x60(%rax),%r14d
  81:	8d 40 a0             	lea    -0x60(%rax),%eax
  84:	89 83 50 12 00 00    	mov    %eax,0x1250(%rbx)
  8a:	45 31 ed             	xor    %r13d,%r13d
  8d:	be f0 e1 3c 00       	mov    $0x3ce1f0,%esi
  92:	ba 08 00 00 00       	mov    $0x8,%edx
  97:	48 89 df             	mov    %rbx,%rdi
  9a:	e8 7f 0f ff ff       	call   0xffffffffffff101e
  9f:	89 45 cc             	mov    %eax,-0x34(%rbp)
  a2:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
  a9:	be 6c 07 00 00       	mov    $0x76c,%esi
  ae:	ba 08 00 00 00       	mov    $0x8,%edx
  b3:	48 89 df             	mov    %rbx,%rdi
  b6:	e8 63 0f ff ff       	call   0xffffffffffff101e
  bb:	89 45 c8             	mov    %eax,-0x38(%rbp)
  be:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
  c5:	be 34 08 00 00       	mov    $0x834,%esi
  ca:	ba 08 00 00 00       	mov    $0x8,%edx
  cf:	48 89 df             	mov    %rbx,%rdi
  d2:	e8 47 0f ff ff       	call   0xffffffffffff101e
  d7:	89 45 c4             	mov    %eax,-0x3c(%rbp)
  da:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
  e1:	be 6c 07 00 00       	mov    $0x76c,%esi
  e6:	ba 08 00 00 00       	mov    $0x8,%edx
  eb:	48 89 df             	mov    %rbx,%rdi
  ee:	e8 2b 0f ff ff       	call   0xffffffffffff101e
  f3:	41 89 c7             	mov    %eax,%r15d
  f6:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
  fd:	be 34 08 00 00       	mov    $0x834,%esi
 102:	ba 08 00 00 00       	mov    $0x8,%edx
 107:	48 89 df             	mov    %rbx,%rdi
 10a:	e8 0f 0f ff ff       	call   0xffffffffffff101e
 10f:	89 45 bc             	mov    %eax,-0x44(%rbp)
 112:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 119:	44 89 f8             	mov    %r15d,%eax
 11c:	89 45 c0             	mov    %eax,-0x40(%rbp)
 11f:	be 18 00 00 00       	mov    $0x18,%esi
 124:	48 89 df             	mov    %rbx,%rdi
 127:	e8 dc 10 ff ff       	call   0xffffffffffff1208
 12c:	f2 0f 10 4d a8       	movsd  -0x58(%rbp),%xmm1
 131:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 138:	44 89 e9             	mov    %r13d,%ecx
 13b:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
 141:	89 ca                	mov    %ecx,%edx
 143:	48 69 d2 35 3a fc 44 	imul   $0x44fc3a35,%rdx,%rdx
 14a:	48 c1 ea 29          	shr    $0x29,%rdx
 14e:	89 d2                	mov    %edx,%edx
 150:	69 d2 6c 07 00 00    	imul   $0x76c,%edx,%edx
 156:	29 d1                	sub    %edx,%ecx
 158:	0f 57 c0             	xorps  %xmm0,%xmm0
 15b:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
 160:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 164:	f2 42 0f 11 04 38    	movsd  %xmm0,(%rax,%r15,1)
 16a:	45 8d 7f 08          	lea    0x8(%r15),%r15d
 16e:	45 8d 6d 01          	lea    0x1(%r13),%r13d
 172:	41 81 fd 6c 07 00 00 	cmp    $0x76c,%r13d
 179:	75 bd                	jne    0x138
 17b:	4c 89 75 d0          	mov    %r14,-0x30(%rbp)
 17f:	45 31 ff             	xor    %r15d,%r15d
 182:	8b 45 cc             	mov    -0x34(%rbp),%eax
 185:	41 89 c6             	mov    %eax,%r14d
 188:	be 20 00 00 00       	mov    $0x20,%esi
 18d:	48 89 df             	mov    %rbx,%rdi
 190:	e8 73 10 ff ff       	call   0xffffffffffff1208
 195:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 19c:	f2 0f 10 4d b0       	movsd  -0x50(%rbp),%xmm1
 1a1:	44 89 f9             	mov    %r15d,%ecx
 1a4:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
 1aa:	89 ca                	mov    %ecx,%edx
 1ac:	48 be 2d 34 a9 f9 00 	movabs $0xf9a9342d,%rsi
 1b3:	00 00 00 
 1b6:	48 0f af d6          	imul   %rsi,%rdx
 1ba:	48 c1 ea 2b          	shr    $0x2b,%rdx
 1be:	89 d2                	mov    %edx,%edx
 1c0:	69 d2 34 08 00 00    	imul   $0x834,%edx,%edx
 1c6:	29 d1                	sub    %edx,%ecx
 1c8:	44 89 fa             	mov    %r15d,%edx
 1cb:	c1 e2 03             	shl    $0x3,%edx
 1ce:	8b 75 bc             	mov    -0x44(%rbp),%esi
 1d1:	01 d6                	add    %edx,%esi
 1d3:	0f 57 c0             	xorps  %xmm0,%xmm0
 1d6:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
 1db:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 1df:	f2 0f 11 04 30       	movsd  %xmm0,(%rax,%rsi,1)
 1e4:	45 89 fd             	mov    %r15d,%r13d
 1e7:	45 31 e4             	xor    %r12d,%r12d
 1ea:	44 89 e9             	mov    %r13d,%ecx
 1ed:	48 ba 2d 34 a9 f9 00 	movabs $0xf9a9342d,%rdx
 1f4:	00 00 00 
 1f7:	48 0f af ca          	imul   %rdx,%rcx
 1fb:	48 c1 e9 2b          	shr    $0x2b,%rcx
 1ff:	89 c9                	mov    %ecx,%ecx
 201:	44 89 f2             	mov    %r14d,%edx
 204:	44 01 e2             	add    %r12d,%edx
 207:	69 c9 34 08 00 00    	imul   $0x834,%ecx,%ecx
 20d:	44 89 ee             	mov    %r13d,%esi
 210:	29 ce                	sub    %ecx,%esi
 212:	0f 57 c0             	xorps  %xmm0,%xmm0
 215:	f2 0f 2a c6          	cvtsi2sd %esi,%xmm0
 219:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 21d:	f2 0f 11 04 10       	movsd  %xmm0,(%rax,%rdx,1)
 222:	45 01 fd             	add    %r15d,%r13d
 225:	45 8d 64 24 08       	lea    0x8(%r12),%r12d
 22a:	41 81 fc 60 3b 00 00 	cmp    $0x3b60,%r12d
 231:	75 b7                	jne    0x1ea
 233:	45 8d b6 60 3b 00 00 	lea    0x3b60(%r14),%r14d
 23a:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 23e:	41 81 ff 34 08 00 00 	cmp    $0x834,%r15d
 245:	0f 85 56 ff ff ff    	jne    0x1a1
 24b:	be 28 00 00 00       	mov    $0x28,%esi
 250:	48 89 df             	mov    %rbx,%rdi
 253:	e8 b0 0f ff ff       	call   0xffffffffffff1208
 258:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 25f:	49 89 de             	mov    %rbx,%r14
 262:	31 db                	xor    %ebx,%ebx
 264:	31 d2                	xor    %edx,%edx
 266:	b9 60 3b 00 00       	mov    $0x3b60,%ecx
 26b:	4c 89 f7             	mov    %r14,%rdi
 26e:	8b 75 c8             	mov    -0x38(%rbp),%esi
 271:	e8 42 0f ff ff       	call   0xffffffffffff11b8
 276:	4d 89 f0             	mov    %r14,%r8
 279:	49 8b b6 90 12 00 00 	mov    0x1290(%r14),%rsi
 280:	8b 4d cc             	mov    -0x34(%rbp),%ecx
 283:	41 89 cc             	mov    %ecx,%r12d
 286:	8b 7d c0             	mov    -0x40(%rbp),%edi
 289:	41 89 dd             	mov    %ebx,%r13d
 28c:	41 c1 e5 03          	shl    $0x3,%r13d
 290:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
 293:	41 89 cf             	mov    %ecx,%r15d
 296:	45 01 ef             	add    %r13d,%r15d
 299:	31 c9                	xor    %ecx,%ecx
 29b:	4a 89 0c 3e          	mov    %rcx,(%rsi,%r15,1)
 29f:	8b 4d bc             	mov    -0x44(%rbp),%ecx
 2a2:	44 01 e9             	add    %r13d,%ecx
 2a5:	45 31 ed             	xor    %r13d,%r13d
 2a8:	89 c2                	mov    %eax,%edx
 2aa:	44 01 ea             	add    %r13d,%edx
 2ad:	41 89 d6             	mov    %edx,%r14d
 2b0:	f2 42 0f 10 04 36    	movsd  (%rsi,%r14,1),%xmm0
 2b6:	f2 0f 10 0c 0e       	movsd  (%rsi,%rcx,1),%xmm1
 2bb:	45 89 e6             	mov    %r12d,%r14d
 2be:	45 01 ee             	add    %r13d,%r14d
 2c1:	f2 42 0f 59 0c 36    	mulsd  (%rsi,%r14,1),%xmm1
 2c7:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 2cb:	f2 0f 11 04 16       	movsd  %xmm0,(%rsi,%rdx,1)
 2d0:	f2 42 0f 10 04 3e    	movsd  (%rsi,%r15,1),%xmm0
 2d6:	f2 42 0f 10 0c 36    	movsd  (%rsi,%r14,1),%xmm1
 2dc:	89 fa                	mov    %edi,%edx
 2de:	44 01 ea             	add    %r13d,%edx
 2e1:	f2 0f 59 0c 16       	mulsd  (%rsi,%rdx,1),%xmm1
 2e6:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 2ea:	f2 42 0f 11 04 3e    	movsd  %xmm0,(%rsi,%r15,1)
 2f0:	45 8d 6d 08          	lea    0x8(%r13),%r13d
 2f4:	41 81 fd 60 3b 00 00 	cmp    $0x3b60,%r13d
 2fb:	75 ab                	jne    0x2a8
 2fd:	45 8d a4 24 60 3b 00 	lea    0x3b60(%r12),%r12d
 304:	00 
 305:	8d 5b 01             	lea    0x1(%rbx),%ebx
 308:	81 fb 34 08 00 00    	cmp    $0x834,%ebx
 30e:	0f 85 75 ff ff ff    	jne    0x289
 314:	89 45 c8             	mov    %eax,-0x38(%rbp)
 317:	45 31 ff             	xor    %r15d,%r15d
 31a:	be 30 00 00 00       	mov    $0x30,%esi
 31f:	4c 89 c3             	mov    %r8,%rbx
 322:	48 89 df             	mov    %rbx,%rdi
 325:	e8 de 0e ff ff       	call   0xffffffffffff1208
 32a:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 331:	44 8b a8 90 04 00 00 	mov    0x490(%rax),%r13d
 338:	be 00 04 00 00       	mov    $0x400,%esi
 33d:	ba 16 00 00 00       	mov    $0x16,%edx
 342:	b9 01 00 00 00       	mov    $0x1,%ecx
 347:	48 89 df             	mov    %rbx,%rdi
 34a:	45 89 e8             	mov    %r13d,%r8d
 34d:	e8 8a 0d ff ff       	call   0xffffffffffff10dc
 352:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 359:	b9 26 04 00 00       	mov    $0x426,%ecx
 35e:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 362:	42 89 4c 30 50       	mov    %ecx,0x50(%rax,%r14,1)
 367:	ba 17 04 00 00       	mov    $0x417,%edx
 36c:	41 8d 4e 50          	lea    0x50(%r14),%ecx
 370:	48 89 df             	mov    %rbx,%rdi
 373:	44 89 ee             	mov    %r13d,%esi
 376:	e8 f7 0d ff ff       	call   0xffffffffffff1172
 37b:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 382:	8b 4d c8             	mov    -0x38(%rbp),%ecx
 385:	41 89 cc             	mov    %ecx,%r12d
 388:	44 89 f9             	mov    %r15d,%ecx
 38b:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
 391:	89 ca                	mov    %ecx,%edx
 393:	48 be cd cc cc cc 00 	movabs $0xcccccccd,%rsi
 39a:	00 00 00 
 39d:	48 0f af d6          	imul   %rsi,%rdx
 3a1:	48 c1 ea 24          	shr    $0x24,%rdx
 3a5:	89 d2                	mov    %edx,%edx
 3a7:	6b d2 14             	imul   $0x14,%edx,%edx
 3aa:	29 d1                	sub    %edx,%ecx
 3ac:	85 c9                	test   %ecx,%ecx
 3ae:	75 17                	jne    0x3c7
 3b0:	be 0a 00 00 00       	mov    $0xa,%esi
 3b5:	48 89 df             	mov    %rbx,%rdi
 3b8:	44 89 ea             	mov    %r13d,%edx
 3bb:	e8 6c 0d ff ff       	call   0xffffffffffff112c
 3c0:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 3c7:	f2 42 0f 10 04 20    	movsd  (%rax,%r12,1),%xmm0
 3cd:	f2 42 0f 11 44 30 40 	movsd  %xmm0,0x40(%rax,%r14,1)
 3d4:	ba 28 04 00 00       	mov    $0x428,%edx
 3d9:	41 8d 4e 40          	lea    0x40(%r14),%ecx
 3dd:	48 89 df             	mov    %rbx,%rdi
 3e0:	44 89 ee             	mov    %r13d,%esi
 3e3:	e8 8a 0d ff ff       	call   0xffffffffffff1172
 3e8:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 3ef:	45 8d 64 24 08       	lea    0x8(%r12),%r12d
 3f4:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 3f8:	41 81 ff 6c 07 00 00 	cmp    $0x76c,%r15d
 3ff:	75 87                	jne    0x388
 401:	b9 26 04 00 00       	mov    $0x426,%ecx
 406:	42 89 4c 30 30       	mov    %ecx,0x30(%rax,%r14,1)
 40b:	ba 30 04 00 00       	mov    $0x430,%edx
 410:	41 8d 4e 30          	lea    0x30(%r14),%ecx
 414:	48 89 df             	mov    %rbx,%rdi
 417:	44 89 ee             	mov    %r13d,%esi
 41a:	e8 53 0d ff ff       	call   0xffffffffffff1172
 41f:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 426:	b9 41 04 00 00       	mov    $0x441,%ecx
 42b:	42 89 4c 30 20       	mov    %ecx,0x20(%rax,%r14,1)
 430:	ba 17 04 00 00       	mov    $0x417,%edx
 435:	41 8d 4e 20          	lea    0x20(%r14),%ecx
 439:	48 89 df             	mov    %rbx,%rdi
 43c:	44 89 ee             	mov    %r13d,%esi
 43f:	e8 2e 0d ff ff       	call   0xffffffffffff1172
 444:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 44b:	45 31 ff             	xor    %r15d,%r15d
 44e:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
 451:	41 89 cc             	mov    %ecx,%r12d
 454:	44 89 f9             	mov    %r15d,%ecx
 457:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
 45d:	89 ca                	mov    %ecx,%edx
 45f:	48 be cd cc cc cc 00 	movabs $0xcccccccd,%rsi
 466:	00 00 00 
 469:	48 0f af d6          	imul   %rsi,%rdx
 46d:	48 c1 ea 24          	shr    $0x24,%rdx
 471:	89 d2                	mov    %edx,%edx
 473:	6b d2 14             	imul   $0x14,%edx,%edx
 476:	29 d1                	sub    %edx,%ecx
 478:	85 c9                	test   %ecx,%ecx
 47a:	75 17                	jne    0x493
 47c:	be 0a 00 00 00       	mov    $0xa,%esi
 481:	48 89 df             	mov    %rbx,%rdi
 484:	44 89 ea             	mov    %r13d,%edx
 487:	e8 a0 0c ff ff       	call   0xffffffffffff112c
 48c:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 493:	f2 42 0f 10 04 20    	movsd  (%rax,%r12,1),%xmm0
 499:	f2 42 0f 11 44 30 10 	movsd  %xmm0,0x10(%rax,%r14,1)
 4a0:	ba 28 04 00 00       	mov    $0x428,%edx
 4a5:	41 8d 4e 10          	lea    0x10(%r14),%ecx
 4a9:	48 89 df             	mov    %rbx,%rdi
 4ac:	44 89 ee             	mov    %r13d,%esi
 4af:	e8 be 0c ff ff       	call   0xffffffffffff1172
 4b4:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 4bb:	45 8d 64 24 08       	lea    0x8(%r12),%r12d
 4c0:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 4c4:	41 81 ff 34 08 00 00 	cmp    $0x834,%r15d
 4cb:	75 87                	jne    0x454
 4cd:	b9 41 04 00 00       	mov    $0x441,%ecx
 4d2:	42 89 0c 30          	mov    %ecx,(%rax,%r14,1)
 4d6:	ba 30 04 00 00       	mov    $0x430,%edx
 4db:	48 89 df             	mov    %rbx,%rdi
 4de:	44 89 ee             	mov    %r13d,%esi
 4e1:	44 89 f1             	mov    %r14d,%ecx
 4e4:	e8 89 0c ff ff       	call   0xffffffffffff1172
 4e9:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 4f0:	be 43 04 00 00       	mov    $0x443,%esi
 4f5:	ba 16 00 00 00       	mov    $0x16,%edx
 4fa:	b9 01 00 00 00       	mov    $0x1,%ecx
 4ff:	48 89 df             	mov    %rbx,%rdi
 502:	45 89 e8             	mov    %r13d,%r8d
 505:	e8 d2 0b ff ff       	call   0xffffffffffff10dc
 50a:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 511:	48 89 df             	mov    %rbx,%rdi
 514:	8b 75 cc             	mov    -0x34(%rbp),%esi
 517:	e8 20 0b ff ff       	call   0xffffffffffff103c
 51c:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 523:	48 89 df             	mov    %rbx,%rdi
 526:	8b 75 c8             	mov    -0x38(%rbp),%esi
 529:	e8 0e 0b ff ff       	call   0xffffffffffff103c
 52e:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 535:	48 89 df             	mov    %rbx,%rdi
 538:	8b 75 c4             	mov    -0x3c(%rbp),%esi
 53b:	e8 fc 0a ff ff       	call   0xffffffffffff103c
 540:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 547:	48 89 df             	mov    %rbx,%rdi
 54a:	8b 75 c0             	mov    -0x40(%rbp),%esi
 54d:	e8 ea 0a ff ff       	call   0xffffffffffff103c
 552:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 559:	48 89 df             	mov    %rbx,%rdi
 55c:	8b 75 bc             	mov    -0x44(%rbp),%esi
 55f:	e8 d8 0a ff ff       	call   0xffffffffffff103c
 564:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 56b:	41 8d 46 60          	lea    0x60(%r14),%eax
 56f:	89 83 50 12 00 00    	mov    %eax,0x1250(%rbx)
 575:	48 89 df             	mov    %rbx,%rdi
 578:	e8 95 0c ff ff       	call   0xffffffffffff1212
 57d:	48 8b 83 90 12 00 00 	mov    0x1290(%rbx),%rax
 584:	31 c0                	xor    %eax,%eax
 586:	48 83 c4 38          	add    $0x38,%rsp
 58a:	5b                   	pop    %rbx
 58b:	41 5c                	pop    %r12
 58d:	41 5d                	pop    %r13
 58f:	41 5e                	pop    %r14
 591:	41 5f                	pop    %r15
 593:	5d                   	pop    %rbp
 594:	c3                   	ret
