
/workspace/DTVM/work/pr643-research/native-atax-canonical-off/func-2-greedy.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	41 57                	push   %r15
   6:	41 56                	push   %r14
   8:	41 55                	push   %r13
   a:	41 54                	push   %r12
   c:	53                   	push   %rbx
   d:	48 83 ec 48          	sub    $0x48,%rsp
  11:	48 89 fb             	mov    %rdi,%rbx
  14:	48 b8 00 00 00 00 00 	movabs $0x40a0680000000000,%rax
  1b:	68 a0 40 
  1e:	66 48 0f 6e c0       	movq   %rax,%xmm0
  23:	f2 0f 11 45 a0       	movsd  %xmm0,-0x60(%rbp)
  28:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
  2f:	00 f0 3f 
  32:	66 48 0f 6e c0       	movq   %rax,%xmm0
  37:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
  3c:	48 b8 00 00 00 00 00 	movabs $0x40c28e0000000000,%rax
  43:	8e c2 40 
  46:	66 48 0f 6e c0       	movq   %rax,%xmm0
  4b:	f2 0f 11 45 a8       	movsd  %xmm0,-0x58(%rbp)
  50:	31 c0                	xor    %eax,%eax
  52:	31 c0                	xor    %eax,%eax
  54:	31 c0                	xor    %eax,%eax
  56:	31 c0                	xor    %eax,%eax
  58:	31 c0                	xor    %eax,%eax
  5a:	31 c0                	xor    %eax,%eax
  5c:	31 c0                	xor    %eax,%eax
  5e:	31 c0                	xor    %eax,%eax
  60:	31 c0                	xor    %eax,%eax
  62:	31 c0                	xor    %eax,%eax
  64:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
  6b:	ff 
  6c:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  73:	8b 83 78 11 00 00    	mov    0x1178(%rbx),%eax
  79:	8d 48 d0             	lea    -0x30(%rax),%ecx
  7c:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
  80:	8d 40 d0             	lea    -0x30(%rax),%eax
  83:	89 83 78 11 00 00    	mov    %eax,0x1178(%rbx)
  89:	45 31 ff             	xor    %r15d,%r15d
  8c:	be f0 e1 3c 00       	mov    $0x3ce1f0,%esi
  91:	ba 08 00 00 00       	mov    $0x8,%edx
  96:	48 89 df             	mov    %rbx,%rdi
  99:	e8 80 1f ff ff       	call   0xffffffffffff201e
  9e:	89 45 c4             	mov    %eax,-0x3c(%rbp)
  a1:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  a8:	be 34 08 00 00       	mov    $0x834,%esi
  ad:	ba 08 00 00 00       	mov    $0x8,%edx
  b2:	48 89 df             	mov    %rbx,%rdi
  b5:	e8 64 1f ff ff       	call   0xffffffffffff201e
  ba:	41 89 c6             	mov    %eax,%r14d
  bd:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  c4:	be 34 08 00 00       	mov    $0x834,%esi
  c9:	ba 08 00 00 00       	mov    $0x8,%edx
  ce:	48 89 df             	mov    %rbx,%rdi
  d1:	e8 48 1f ff ff       	call   0xffffffffffff201e
  d6:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
  da:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  e1:	be 6c 07 00 00       	mov    $0x76c,%esi
  e6:	ba 08 00 00 00       	mov    $0x8,%edx
  eb:	48 89 df             	mov    %rbx,%rdi
  ee:	e8 2b 1f ff ff       	call   0xffffffffffff201e
  f3:	f2 0f 10 5d 98       	movsd  -0x68(%rbp),%xmm3
  f8:	f2 0f 10 55 a0       	movsd  -0x60(%rbp),%xmm2
  fd:	0f 57 c9             	xorps  %xmm1,%xmm1
 100:	89 45 bc             	mov    %eax,-0x44(%rbp)
 103:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 10a:	44 89 f1             	mov    %r14d,%ecx
 10d:	44 01 f9             	add    %r15d,%ecx
 110:	0f 28 c1             	movaps %xmm1,%xmm0
 113:	f2 0f 5e c2          	divsd  %xmm2,%xmm0
 117:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
 11b:	f2 0f 11 04 08       	movsd  %xmm0,(%rax,%rcx,1)
 120:	f2 0f 58 cb          	addsd  %xmm3,%xmm1
 124:	45 8d 7f 08          	lea    0x8(%r15),%r15d
 128:	41 81 ff a0 41 00 00 	cmp    $0x41a0,%r15d
 12f:	75 d9                	jne    0x10a
 131:	44 89 75 c0          	mov    %r14d,-0x40(%rbp)
 135:	45 31 ed             	xor    %r13d,%r13d
 138:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
 13b:	41 89 cc             	mov    %ecx,%r12d
 13e:	f2 0f 10 4d a8       	movsd  -0x58(%rbp),%xmm1
 143:	45 31 f6             	xor    %r14d,%r14d
 146:	45 89 ef             	mov    %r13d,%r15d
 149:	44 89 f9             	mov    %r15d,%ecx
 14c:	48 ba 2d 34 a9 f9 00 	movabs $0xf9a9342d,%rdx
 153:	00 00 00 
 156:	48 0f af ca          	imul   %rdx,%rcx
 15a:	48 c1 e9 2b          	shr    $0x2b,%rcx
 15e:	89 c9                	mov    %ecx,%ecx
 160:	44 89 e2             	mov    %r12d,%edx
 163:	44 01 f2             	add    %r14d,%edx
 166:	69 c9 34 08 00 00    	imul   $0x834,%ecx,%ecx
 16c:	44 89 fe             	mov    %r15d,%esi
 16f:	29 ce                	sub    %ecx,%esi
 171:	0f 57 c0             	xorps  %xmm0,%xmm0
 174:	f2 0f 2a c6          	cvtsi2sd %esi,%xmm0
 178:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 17c:	f2 0f 11 04 10       	movsd  %xmm0,(%rax,%rdx,1)
 181:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 185:	45 8d 76 08          	lea    0x8(%r14),%r14d
 189:	41 81 fe a0 41 00 00 	cmp    $0x41a0,%r14d
 190:	75 b7                	jne    0x149
 192:	45 8d a4 24 a0 41 00 	lea    0x41a0(%r12),%r12d
 199:	00 
 19a:	45 8d 6d 01          	lea    0x1(%r13),%r13d
 19e:	41 81 fd 6c 07 00 00 	cmp    $0x76c,%r13d
 1a5:	75 9c                	jne    0x143
 1a7:	48 89 5d d0          	mov    %rbx,-0x30(%rbp)
 1ab:	31 db                	xor    %ebx,%ebx
 1ad:	31 d2                	xor    %edx,%edx
 1af:	b9 a0 41 00 00       	mov    $0x41a0,%ecx
 1b4:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 1b8:	4c 89 f7             	mov    %r14,%rdi
 1bb:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
 1bf:	e8 f4 1f ff ff       	call   0xffffffffffff21b8
 1c4:	41 89 c4             	mov    %eax,%r12d
 1c7:	49 8b 86 b8 11 00 00 	mov    0x11b8(%r14),%rax
 1ce:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
 1d1:	41 89 ce             	mov    %ecx,%r14d
 1d4:	8b 75 c0             	mov    -0x40(%rbp),%esi
 1d7:	89 d9                	mov    %ebx,%ecx
 1d9:	c1 e1 03             	shl    $0x3,%ecx
 1dc:	8b 55 bc             	mov    -0x44(%rbp),%edx
 1df:	41 89 d5             	mov    %edx,%r13d
 1e2:	41 01 cd             	add    %ecx,%r13d
 1e5:	31 c9                	xor    %ecx,%ecx
 1e7:	4a 89 0c 28          	mov    %rcx,(%rax,%r13,1)
 1eb:	69 cb a0 41 00 00    	imul   $0x41a0,%ebx,%ecx
 1f1:	8b 55 c4             	mov    -0x3c(%rbp),%edx
 1f4:	01 ca                	add    %ecx,%edx
 1f6:	0f 57 d2             	xorps  %xmm2,%xmm2
 1f9:	45 31 ff             	xor    %r15d,%r15d
 1fc:	44 89 f1             	mov    %r14d,%ecx
 1ff:	44 01 f9             	add    %r15d,%ecx
 202:	f2 0f 10 04 08       	movsd  (%rax,%rcx,1),%xmm0
 207:	89 f1                	mov    %esi,%ecx
 209:	44 01 f9             	add    %r15d,%ecx
 20c:	f2 0f 10 0c 08       	movsd  (%rax,%rcx,1),%xmm1
 211:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
 215:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
 219:	f2 42 0f 11 14 28    	movsd  %xmm2,(%rax,%r13,1)
 21f:	45 8d 7f 08          	lea    0x8(%r15),%r15d
 223:	41 81 ff a0 41 00 00 	cmp    $0x41a0,%r15d
 22a:	75 d0                	jne    0x1fc
 22c:	f2 42 0f 10 04 20    	movsd  (%rax,%r12,1),%xmm0
 232:	f2 0f 10 0c 10       	movsd  (%rax,%rdx,1),%xmm1
 237:	f2 0f 59 d1          	mulsd  %xmm1,%xmm2
 23b:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
 23f:	f2 42 0f 11 04 20    	movsd  %xmm0,(%rax,%r12,1)
 245:	41 bf 08 00 00 00    	mov    $0x8,%r15d
 24b:	44 89 e2             	mov    %r12d,%edx
 24e:	44 01 fa             	add    %r15d,%edx
 251:	f2 0f 10 04 10       	movsd  (%rax,%rdx,1),%xmm0
 256:	f2 42 0f 10 0c 28    	movsd  (%rax,%r13,1),%xmm1
 25c:	44 89 f1             	mov    %r14d,%ecx
 25f:	44 01 f9             	add    %r15d,%ecx
 262:	f2 0f 10 14 08       	movsd  (%rax,%rcx,1),%xmm2
 267:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
 26b:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 26f:	f2 0f 11 04 10       	movsd  %xmm0,(%rax,%rdx,1)
 274:	45 8d 7f 08          	lea    0x8(%r15),%r15d
 278:	41 81 ff a0 41 00 00 	cmp    $0x41a0,%r15d
 27f:	75 ca                	jne    0x24b
 281:	45 8d b6 a0 41 00 00 	lea    0x41a0(%r14),%r14d
 288:	8d 5b 01             	lea    0x1(%rbx),%ebx
 28b:	81 fb 6c 07 00 00    	cmp    $0x76c,%ebx
 291:	0f 85 40 ff ff ff    	jne    0x1d7
 297:	45 31 ff             	xor    %r15d,%r15d
 29a:	44 8b b0 8c 04 00 00 	mov    0x48c(%rax),%r14d
 2a1:	be 00 04 00 00       	mov    $0x400,%esi
 2a6:	ba 16 00 00 00       	mov    $0x16,%edx
 2ab:	b9 01 00 00 00       	mov    $0x1,%ecx
 2b0:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 2b4:	48 89 df             	mov    %rbx,%rdi
 2b7:	45 89 f0             	mov    %r14d,%r8d
 2ba:	e8 1d 1e ff ff       	call   0xffffffffffff20dc
 2bf:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 2c6:	b9 26 04 00 00       	mov    $0x426,%ecx
 2cb:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 2cf:	48 89 d6             	mov    %rdx,%rsi
 2d2:	89 4c 30 20          	mov    %ecx,0x20(%rax,%rsi,1)
 2d6:	ba 17 04 00 00       	mov    $0x417,%edx
 2db:	8d 4e 20             	lea    0x20(%rsi),%ecx
 2de:	48 89 df             	mov    %rbx,%rdi
 2e1:	44 89 f6             	mov    %r14d,%esi
 2e4:	e8 89 1e ff ff       	call   0xffffffffffff2172
 2e9:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 2f0:	45 89 e5             	mov    %r12d,%r13d
 2f3:	44 89 f8             	mov    %r15d,%eax
 2f6:	25 ff ff 00 00       	and    $0xffff,%eax
 2fb:	be 14 00 00 00       	mov    $0x14,%esi
 300:	31 d2                	xor    %edx,%edx
 302:	f7 f6                	div    %esi
 304:	85 d2                	test   %edx,%edx
 306:	75 17                	jne    0x31f
 308:	be 0a 00 00 00       	mov    $0xa,%esi
 30d:	48 89 df             	mov    %rbx,%rdi
 310:	44 89 f2             	mov    %r14d,%edx
 313:	e8 14 1e ff ff       	call   0xffffffffffff212c
 318:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 31f:	f2 42 0f 10 04 29    	movsd  (%rcx,%r13,1),%xmm0
 325:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 329:	f2 0f 11 44 01 10    	movsd  %xmm0,0x10(%rcx,%rax,1)
 32f:	ba 28 04 00 00       	mov    $0x428,%edx
 334:	8d 48 10             	lea    0x10(%rax),%ecx
 337:	48 89 df             	mov    %rbx,%rdi
 33a:	44 89 f6             	mov    %r14d,%esi
 33d:	e8 30 1e ff ff       	call   0xffffffffffff2172
 342:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 349:	45 8d 6d 08          	lea    0x8(%r13),%r13d
 34d:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 351:	41 81 ff 34 08 00 00 	cmp    $0x834,%r15d
 358:	75 99                	jne    0x2f3
 35a:	b8 26 04 00 00       	mov    $0x426,%eax
 35f:	4c 8b 7d c8          	mov    -0x38(%rbp),%r15
 363:	42 89 04 39          	mov    %eax,(%rcx,%r15,1)
 367:	ba 30 04 00 00       	mov    $0x430,%edx
 36c:	48 89 df             	mov    %rbx,%rdi
 36f:	44 89 f6             	mov    %r14d,%esi
 372:	44 89 f9             	mov    %r15d,%ecx
 375:	e8 f8 1d ff ff       	call   0xffffffffffff2172
 37a:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 381:	be 41 04 00 00       	mov    $0x441,%esi
 386:	ba 16 00 00 00       	mov    $0x16,%edx
 38b:	b9 01 00 00 00       	mov    $0x1,%ecx
 390:	48 89 df             	mov    %rbx,%rdi
 393:	45 89 f0             	mov    %r14d,%r8d
 396:	e8 41 1d ff ff       	call   0xffffffffffff20dc
 39b:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 3a2:	48 89 df             	mov    %rbx,%rdi
 3a5:	8b 75 c4             	mov    -0x3c(%rbp),%esi
 3a8:	e8 8f 1c ff ff       	call   0xffffffffffff203c
 3ad:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 3b4:	48 89 df             	mov    %rbx,%rdi
 3b7:	8b 75 c0             	mov    -0x40(%rbp),%esi
 3ba:	e8 7d 1c ff ff       	call   0xffffffffffff203c
 3bf:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 3c6:	48 89 df             	mov    %rbx,%rdi
 3c9:	44 89 e6             	mov    %r12d,%esi
 3cc:	e8 6b 1c ff ff       	call   0xffffffffffff203c
 3d1:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 3d8:	48 89 df             	mov    %rbx,%rdi
 3db:	8b 75 bc             	mov    -0x44(%rbp),%esi
 3de:	e8 59 1c ff ff       	call   0xffffffffffff203c
 3e3:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 3ea:	41 8d 47 30          	lea    0x30(%r15),%eax
 3ee:	89 83 78 11 00 00    	mov    %eax,0x1178(%rbx)
 3f4:	31 c0                	xor    %eax,%eax
 3f6:	48 83 c4 48          	add    $0x48,%rsp
 3fa:	5b                   	pop    %rbx
 3fb:	41 5c                	pop    %r12
 3fd:	41 5d                	pop    %r13
 3ff:	41 5e                	pop    %r14
 401:	41 5f                	pop    %r15
 403:	5d                   	pop    %rbp
 404:	c3                   	ret
