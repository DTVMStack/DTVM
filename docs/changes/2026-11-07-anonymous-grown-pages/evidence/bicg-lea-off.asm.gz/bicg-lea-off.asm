
/workspace/DTVM/work/pr643-research/native-bicg-canonical-off/func-2-greedy.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	41 57                	push   %r15
   6:	41 56                	push   %r14
   8:	41 55                	push   %r13
   a:	41 54                	push   %r12
   c:	53                   	push   %rbx
   d:	48 83 ec 38          	sub    $0x38,%rsp
  11:	48 89 fb             	mov    %rdi,%rbx
  14:	48 b8 00 00 00 00 00 	movabs $0x409db00000000000,%rax
  1b:	b0 9d 40 
  1e:	66 48 0f 6e c0       	movq   %rax,%xmm0
  23:	f2 0f 11 45 a8       	movsd  %xmm0,-0x58(%rbp)
  28:	48 b8 00 00 00 00 00 	movabs $0x40a0680000000000,%rax
  2f:	68 a0 40 
  32:	66 48 0f 6e c0       	movq   %rax,%xmm0
  37:	f2 0f 11 45 b0       	movsd  %xmm0,-0x50(%rbp)
  3c:	31 c0                	xor    %eax,%eax
  3e:	31 c0                	xor    %eax,%eax
  40:	31 c0                	xor    %eax,%eax
  42:	31 c0                	xor    %eax,%eax
  44:	31 c0                	xor    %eax,%eax
  46:	31 c0                	xor    %eax,%eax
  48:	31 c0                	xor    %eax,%eax
  4a:	31 c0                	xor    %eax,%eax
  4c:	31 c0                	xor    %eax,%eax
  4e:	31 c0                	xor    %eax,%eax
  50:	31 c0                	xor    %eax,%eax
  52:	31 c0                	xor    %eax,%eax
  54:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
  5b:	ff 
  5c:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  63:	8b 83 78 11 00 00    	mov    0x1178(%rbx),%eax
  69:	44 8d 60 a0          	lea    -0x60(%rax),%r12d
  6d:	8d 40 a0             	lea    -0x60(%rax),%eax
  70:	89 83 78 11 00 00    	mov    %eax,0x1178(%rbx)
  76:	45 31 ff             	xor    %r15d,%r15d
  79:	be f0 e1 3c 00       	mov    $0x3ce1f0,%esi
  7e:	ba 08 00 00 00       	mov    $0x8,%edx
  83:	48 89 df             	mov    %rbx,%rdi
  86:	e8 93 1f ff ff       	call   0xffffffffffff201e
  8b:	89 45 cc             	mov    %eax,-0x34(%rbp)
  8e:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  95:	be 6c 07 00 00       	mov    $0x76c,%esi
  9a:	ba 08 00 00 00       	mov    $0x8,%edx
  9f:	48 89 df             	mov    %rbx,%rdi
  a2:	e8 77 1f ff ff       	call   0xffffffffffff201e
  a7:	89 45 c8             	mov    %eax,-0x38(%rbp)
  aa:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  b1:	be 34 08 00 00       	mov    $0x834,%esi
  b6:	ba 08 00 00 00       	mov    $0x8,%edx
  bb:	48 89 df             	mov    %rbx,%rdi
  be:	e8 5b 1f ff ff       	call   0xffffffffffff201e
  c3:	89 45 c4             	mov    %eax,-0x3c(%rbp)
  c6:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  cd:	be 6c 07 00 00       	mov    $0x76c,%esi
  d2:	ba 08 00 00 00       	mov    $0x8,%edx
  d7:	48 89 df             	mov    %rbx,%rdi
  da:	e8 3f 1f ff ff       	call   0xffffffffffff201e
  df:	41 89 c6             	mov    %eax,%r14d
  e2:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  e9:	be 34 08 00 00       	mov    $0x834,%esi
  ee:	ba 08 00 00 00       	mov    $0x8,%edx
  f3:	48 89 df             	mov    %rbx,%rdi
  f6:	e8 23 1f ff ff       	call   0xffffffffffff201e
  fb:	f2 0f 10 4d a8       	movsd  -0x58(%rbp),%xmm1
 100:	45 89 f0             	mov    %r14d,%r8d
 103:	41 89 c1             	mov    %eax,%r9d
 106:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 10d:	45 89 c5             	mov    %r8d,%r13d
 110:	44 89 f8             	mov    %r15d,%eax
 113:	25 ff ff 00 00       	and    $0xffff,%eax
 118:	be 6c 07 00 00       	mov    $0x76c,%esi
 11d:	31 d2                	xor    %edx,%edx
 11f:	f7 f6                	div    %esi
 121:	0f 57 c0             	xorps  %xmm0,%xmm0
 124:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
 129:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 12d:	f2 42 0f 11 04 29    	movsd  %xmm0,(%rcx,%r13,1)
 133:	45 8d 6d 08          	lea    0x8(%r13),%r13d
 137:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 13b:	41 81 ff 6c 07 00 00 	cmp    $0x76c,%r15d
 142:	75 cc                	jne    0x110
 144:	45 31 ed             	xor    %r13d,%r13d
 147:	8b 45 cc             	mov    -0x34(%rbp),%eax
 14a:	89 c6                	mov    %eax,%esi
 14c:	f2 0f 10 4d b0       	movsd  -0x50(%rbp),%xmm1
 151:	44 89 e8             	mov    %r13d,%eax
 154:	25 ff ff 00 00       	and    $0xffff,%eax
 159:	bf 34 08 00 00       	mov    $0x834,%edi
 15e:	31 d2                	xor    %edx,%edx
 160:	f7 f7                	div    %edi
 162:	44 89 e8             	mov    %r13d,%eax
 165:	c1 e0 03             	shl    $0x3,%eax
 168:	44 89 cf             	mov    %r9d,%edi
 16b:	01 c7                	add    %eax,%edi
 16d:	0f 57 c0             	xorps  %xmm0,%xmm0
 170:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
 175:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 179:	f2 0f 11 04 39       	movsd  %xmm0,(%rcx,%rdi,1)
 17e:	45 89 ef             	mov    %r13d,%r15d
 181:	45 31 f6             	xor    %r14d,%r14d
 184:	44 89 f8             	mov    %r15d,%eax
 187:	48 ba 2d 34 a9 f9 00 	movabs $0xf9a9342d,%rdx
 18e:	00 00 00 
 191:	48 0f af c2          	imul   %rdx,%rax
 195:	48 c1 e8 2b          	shr    $0x2b,%rax
 199:	89 c0                	mov    %eax,%eax
 19b:	89 f2                	mov    %esi,%edx
 19d:	44 01 f2             	add    %r14d,%edx
 1a0:	69 c0 34 08 00 00    	imul   $0x834,%eax,%eax
 1a6:	44 89 ff             	mov    %r15d,%edi
 1a9:	29 c7                	sub    %eax,%edi
 1ab:	0f 57 c0             	xorps  %xmm0,%xmm0
 1ae:	f2 0f 2a c7          	cvtsi2sd %edi,%xmm0
 1b2:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 1b6:	f2 0f 11 04 11       	movsd  %xmm0,(%rcx,%rdx,1)
 1bb:	45 01 ef             	add    %r13d,%r15d
 1be:	45 8d 76 08          	lea    0x8(%r14),%r14d
 1c2:	41 81 fe 60 3b 00 00 	cmp    $0x3b60,%r14d
 1c9:	75 b9                	jne    0x184
 1cb:	8d b6 60 3b 00 00    	lea    0x3b60(%rsi),%esi
 1d1:	45 8d 6d 01          	lea    0x1(%r13),%r13d
 1d5:	41 81 fd 34 08 00 00 	cmp    $0x834,%r13d
 1dc:	0f 85 6f ff ff ff    	jne    0x151
 1e2:	44 89 4d bc          	mov    %r9d,-0x44(%rbp)
 1e6:	44 89 45 c0          	mov    %r8d,-0x40(%rbp)
 1ea:	4c 89 65 d0          	mov    %r12,-0x30(%rbp)
 1ee:	45 31 e4             	xor    %r12d,%r12d
 1f1:	31 d2                	xor    %edx,%edx
 1f3:	b9 60 3b 00 00       	mov    $0x3b60,%ecx
 1f8:	48 89 df             	mov    %rbx,%rdi
 1fb:	8b 75 c8             	mov    -0x38(%rbp),%esi
 1fe:	e8 b5 1f ff ff       	call   0xffffffffffff21b8
 203:	48 8b bb b8 11 00 00 	mov    0x11b8(%rbx),%rdi
 20a:	8b 4d cc             	mov    -0x34(%rbp),%ecx
 20d:	41 89 ce             	mov    %ecx,%r14d
 210:	44 8b 45 c0          	mov    -0x40(%rbp),%r8d
 214:	44 8b 4d bc          	mov    -0x44(%rbp),%r9d
 218:	45 89 e7             	mov    %r12d,%r15d
 21b:	41 c1 e7 03          	shl    $0x3,%r15d
 21f:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
 222:	41 89 cd             	mov    %ecx,%r13d
 225:	45 01 fd             	add    %r15d,%r13d
 228:	31 c9                	xor    %ecx,%ecx
 22a:	4a 89 0c 2f          	mov    %rcx,(%rdi,%r13,1)
 22e:	44 89 c9             	mov    %r9d,%ecx
 231:	44 01 f9             	add    %r15d,%ecx
 234:	45 31 ff             	xor    %r15d,%r15d
 237:	89 c2                	mov    %eax,%edx
 239:	44 01 fa             	add    %r15d,%edx
 23c:	89 d6                	mov    %edx,%esi
 23e:	f2 0f 10 04 37       	movsd  (%rdi,%rsi,1),%xmm0
 243:	f2 0f 10 0c 0f       	movsd  (%rdi,%rcx,1),%xmm1
 248:	44 89 f6             	mov    %r14d,%esi
 24b:	44 01 fe             	add    %r15d,%esi
 24e:	f2 0f 10 14 37       	movsd  (%rdi,%rsi,1),%xmm2
 253:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
 257:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 25b:	f2 0f 11 04 17       	movsd  %xmm0,(%rdi,%rdx,1)
 260:	f2 42 0f 10 04 2f    	movsd  (%rdi,%r13,1),%xmm0
 266:	f2 0f 10 0c 37       	movsd  (%rdi,%rsi,1),%xmm1
 26b:	44 89 c2             	mov    %r8d,%edx
 26e:	44 01 fa             	add    %r15d,%edx
 271:	f2 0f 10 14 17       	movsd  (%rdi,%rdx,1),%xmm2
 276:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
 27a:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 27e:	f2 42 0f 11 04 2f    	movsd  %xmm0,(%rdi,%r13,1)
 284:	45 8d 7f 08          	lea    0x8(%r15),%r15d
 288:	41 81 ff 60 3b 00 00 	cmp    $0x3b60,%r15d
 28f:	75 a6                	jne    0x237
 291:	45 8d b6 60 3b 00 00 	lea    0x3b60(%r14),%r14d
 298:	45 8d 64 24 01       	lea    0x1(%r12),%r12d
 29d:	41 81 fc 34 08 00 00 	cmp    $0x834,%r12d
 2a4:	0f 85 6e ff ff ff    	jne    0x218
 2aa:	89 45 c8             	mov    %eax,-0x38(%rbp)
 2ad:	45 31 ed             	xor    %r13d,%r13d
 2b0:	44 8b bf 90 04 00 00 	mov    0x490(%rdi),%r15d
 2b7:	be 00 04 00 00       	mov    $0x400,%esi
 2bc:	ba 16 00 00 00       	mov    $0x16,%edx
 2c1:	b9 01 00 00 00       	mov    $0x1,%ecx
 2c6:	48 89 df             	mov    %rbx,%rdi
 2c9:	45 89 f8             	mov    %r15d,%r8d
 2cc:	e8 0b 1e ff ff       	call   0xffffffffffff20dc
 2d1:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 2d8:	b9 26 04 00 00       	mov    $0x426,%ecx
 2dd:	4c 8b 65 d0          	mov    -0x30(%rbp),%r12
 2e1:	42 89 4c 20 50       	mov    %ecx,0x50(%rax,%r12,1)
 2e6:	ba 17 04 00 00       	mov    $0x417,%edx
 2eb:	41 8d 4c 24 50       	lea    0x50(%r12),%ecx
 2f0:	48 89 df             	mov    %rbx,%rdi
 2f3:	44 89 fe             	mov    %r15d,%esi
 2f6:	e8 77 1e ff ff       	call   0xffffffffffff2172
 2fb:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 302:	8b 45 c8             	mov    -0x38(%rbp),%eax
 305:	41 89 c6             	mov    %eax,%r14d
 308:	44 89 e8             	mov    %r13d,%eax
 30b:	25 ff ff 00 00       	and    $0xffff,%eax
 310:	be 14 00 00 00       	mov    $0x14,%esi
 315:	31 d2                	xor    %edx,%edx
 317:	f7 f6                	div    %esi
 319:	85 d2                	test   %edx,%edx
 31b:	75 17                	jne    0x334
 31d:	be 0a 00 00 00       	mov    $0xa,%esi
 322:	48 89 df             	mov    %rbx,%rdi
 325:	44 89 fa             	mov    %r15d,%edx
 328:	e8 ff 1d ff ff       	call   0xffffffffffff212c
 32d:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 334:	f2 42 0f 10 04 31    	movsd  (%rcx,%r14,1),%xmm0
 33a:	f2 42 0f 11 44 21 40 	movsd  %xmm0,0x40(%rcx,%r12,1)
 341:	ba 28 04 00 00       	mov    $0x428,%edx
 346:	41 8d 4c 24 40       	lea    0x40(%r12),%ecx
 34b:	48 89 df             	mov    %rbx,%rdi
 34e:	44 89 fe             	mov    %r15d,%esi
 351:	e8 1c 1e ff ff       	call   0xffffffffffff2172
 356:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 35d:	45 8d 76 08          	lea    0x8(%r14),%r14d
 361:	45 8d 6d 01          	lea    0x1(%r13),%r13d
 365:	41 81 fd 6c 07 00 00 	cmp    $0x76c,%r13d
 36c:	75 9a                	jne    0x308
 36e:	b8 26 04 00 00       	mov    $0x426,%eax
 373:	42 89 44 21 30       	mov    %eax,0x30(%rcx,%r12,1)
 378:	ba 30 04 00 00       	mov    $0x430,%edx
 37d:	41 8d 4c 24 30       	lea    0x30(%r12),%ecx
 382:	48 89 df             	mov    %rbx,%rdi
 385:	44 89 fe             	mov    %r15d,%esi
 388:	e8 e5 1d ff ff       	call   0xffffffffffff2172
 38d:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 394:	b9 41 04 00 00       	mov    $0x441,%ecx
 399:	42 89 4c 20 20       	mov    %ecx,0x20(%rax,%r12,1)
 39e:	ba 17 04 00 00       	mov    $0x417,%edx
 3a3:	41 8d 4c 24 20       	lea    0x20(%r12),%ecx
 3a8:	48 89 df             	mov    %rbx,%rdi
 3ab:	44 89 fe             	mov    %r15d,%esi
 3ae:	e8 bf 1d ff ff       	call   0xffffffffffff2172
 3b3:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 3ba:	45 31 ed             	xor    %r13d,%r13d
 3bd:	8b 45 c4             	mov    -0x3c(%rbp),%eax
 3c0:	41 89 c6             	mov    %eax,%r14d
 3c3:	44 89 e8             	mov    %r13d,%eax
 3c6:	25 ff ff 00 00       	and    $0xffff,%eax
 3cb:	be 14 00 00 00       	mov    $0x14,%esi
 3d0:	31 d2                	xor    %edx,%edx
 3d2:	f7 f6                	div    %esi
 3d4:	85 d2                	test   %edx,%edx
 3d6:	75 17                	jne    0x3ef
 3d8:	be 0a 00 00 00       	mov    $0xa,%esi
 3dd:	48 89 df             	mov    %rbx,%rdi
 3e0:	44 89 fa             	mov    %r15d,%edx
 3e3:	e8 44 1d ff ff       	call   0xffffffffffff212c
 3e8:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 3ef:	f2 42 0f 10 04 31    	movsd  (%rcx,%r14,1),%xmm0
 3f5:	f2 42 0f 11 44 21 10 	movsd  %xmm0,0x10(%rcx,%r12,1)
 3fc:	ba 28 04 00 00       	mov    $0x428,%edx
 401:	41 8d 4c 24 10       	lea    0x10(%r12),%ecx
 406:	48 89 df             	mov    %rbx,%rdi
 409:	44 89 fe             	mov    %r15d,%esi
 40c:	e8 61 1d ff ff       	call   0xffffffffffff2172
 411:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 418:	45 8d 76 08          	lea    0x8(%r14),%r14d
 41c:	45 8d 6d 01          	lea    0x1(%r13),%r13d
 420:	41 81 fd 34 08 00 00 	cmp    $0x834,%r13d
 427:	75 9a                	jne    0x3c3
 429:	b8 41 04 00 00       	mov    $0x441,%eax
 42e:	42 89 04 21          	mov    %eax,(%rcx,%r12,1)
 432:	ba 30 04 00 00       	mov    $0x430,%edx
 437:	48 89 df             	mov    %rbx,%rdi
 43a:	44 89 fe             	mov    %r15d,%esi
 43d:	44 89 e1             	mov    %r12d,%ecx
 440:	e8 2d 1d ff ff       	call   0xffffffffffff2172
 445:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 44c:	be 43 04 00 00       	mov    $0x443,%esi
 451:	ba 16 00 00 00       	mov    $0x16,%edx
 456:	b9 01 00 00 00       	mov    $0x1,%ecx
 45b:	48 89 df             	mov    %rbx,%rdi
 45e:	45 89 f8             	mov    %r15d,%r8d
 461:	e8 76 1c ff ff       	call   0xffffffffffff20dc
 466:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 46d:	48 89 df             	mov    %rbx,%rdi
 470:	8b 75 cc             	mov    -0x34(%rbp),%esi
 473:	e8 c4 1b ff ff       	call   0xffffffffffff203c
 478:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 47f:	48 89 df             	mov    %rbx,%rdi
 482:	8b 75 c8             	mov    -0x38(%rbp),%esi
 485:	e8 b2 1b ff ff       	call   0xffffffffffff203c
 48a:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 491:	48 89 df             	mov    %rbx,%rdi
 494:	8b 75 c4             	mov    -0x3c(%rbp),%esi
 497:	e8 a0 1b ff ff       	call   0xffffffffffff203c
 49c:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 4a3:	48 89 df             	mov    %rbx,%rdi
 4a6:	8b 75 c0             	mov    -0x40(%rbp),%esi
 4a9:	e8 8e 1b ff ff       	call   0xffffffffffff203c
 4ae:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 4b5:	48 89 df             	mov    %rbx,%rdi
 4b8:	8b 75 bc             	mov    -0x44(%rbp),%esi
 4bb:	e8 7c 1b ff ff       	call   0xffffffffffff203c
 4c0:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 4c7:	41 8d 44 24 60       	lea    0x60(%r12),%eax
 4cc:	89 83 78 11 00 00    	mov    %eax,0x1178(%rbx)
 4d2:	31 c0                	xor    %eax,%eax
 4d4:	48 83 c4 38          	add    $0x38,%rsp
 4d8:	5b                   	pop    %rbx
 4d9:	41 5c                	pop    %r12
 4db:	41 5d                	pop    %r13
 4dd:	41 5e                	pop    %r14
 4df:	41 5f                	pop    %r15
 4e1:	5d                   	pop    %rbp
 4e2:	c3                   	ret
