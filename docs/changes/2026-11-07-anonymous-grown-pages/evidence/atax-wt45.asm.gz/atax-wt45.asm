
work/pr643-research/wt-live-atax/code-2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
   8:	4d 8b 52 18          	mov    0x18(%r10),%r10
   c:	49 81 c2 80 00 00 00 	add    $0x80,%r10
  13:	4c 3b d4             	cmp    %rsp,%r10
  16:	0f 87 31 04 00 00    	ja     0x44d
  1c:	48 83 ec 70          	sub    $0x70,%rsp
  20:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
  25:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  2a:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
  2f:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
  34:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
  39:	8b 8f 40 01 00 00    	mov    0x140(%rdi),%ecx
  3f:	48 89 c8             	mov    %rcx,%rax
  42:	83 e8 30             	sub    $0x30,%eax
  45:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  4a:	89 87 40 01 00 00    	mov    %eax,0x140(%rdi)
  50:	48 89 3c 24          	mov    %rdi,(%rsp)
  54:	ba f0 e1 3c 00       	mov    $0x3ce1f0,%edx
  59:	41 bd 08 00 00 00    	mov    $0x8,%r13d
  5f:	4c 89 e9             	mov    %r13,%rcx
  62:	48 8b 34 24          	mov    (%rsp),%rsi
  66:	e8 55 04 00 00       	call   0x4c0
  6b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  70:	bb 34 08 00 00       	mov    $0x834,%ebx
  75:	4c 89 e9             	mov    %r13,%rcx
  78:	48 89 da             	mov    %rbx,%rdx
  7b:	48 8b 34 24          	mov    (%rsp),%rsi
  7f:	48 8b 3c 24          	mov    (%rsp),%rdi
  83:	e8 38 04 00 00       	call   0x4c0
  88:	48 89 da             	mov    %rbx,%rdx
  8b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  90:	4c 89 e9             	mov    %r13,%rcx
  93:	48 8b 34 24          	mov    (%rsp),%rsi
  97:	48 8b 3c 24          	mov    (%rsp),%rdi
  9b:	e8 20 04 00 00       	call   0x4c0
  a0:	49 89 c4             	mov    %rax,%r12
  a3:	ba 6c 07 00 00       	mov    $0x76c,%edx
  a8:	4c 89 e9             	mov    %r13,%rcx
  ab:	48 8b 34 24          	mov    (%rsp),%rsi
  af:	48 8b 3c 24          	mov    (%rsp),%rdi
  b3:	e8 08 04 00 00       	call   0x4c0
  b8:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  bd:	33 c0                	xor    %eax,%eax
  bf:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  c3:	48 8b 3c 24          	mov    (%rsp),%rdi
  c7:	4c 8b 6f 38          	mov    0x38(%rdi),%r13
  cb:	c5 fb 5e 0d 7d 03 00 	vdivsd 0x37d(%rip),%xmm0,%xmm1        # 0x450
  d2:	00 
  d3:	c5 f3 58 0d 85 03 00 	vaddsd 0x385(%rip),%xmm1,%xmm1        # 0x460
  da:	00 
  db:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  e0:	03 c8                	add    %eax,%ecx
  e2:	c4 c1 7b 11 4c 0d 00 	vmovsd %xmm1,0x0(%r13,%rcx,1)
  e9:	8d 48 08             	lea    0x8(%rax),%ecx
  ec:	c5 fb 58 05 7c 03 00 	vaddsd 0x37c(%rip),%xmm0,%xmm0        # 0x470
  f3:	00 
  f4:	3d 98 41 00 00       	cmp    $0x4198,%eax
  f9:	0f 84 08 00 00 00    	je     0x107
  ff:	48 89 c8             	mov    %rcx,%rax
 102:	e9 c4 ff ff ff       	jmp    0xcb
 107:	33 c9                	xor    %ecx,%ecx
 109:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
 10e:	33 f6                	xor    %esi,%esi
 110:	48 89 ca             	mov    %rcx,%rdx
 113:	c4 e2 43 f6 3d 64 03 	mulx   0x364(%rip),%edi,%edi        # 0x480
 11a:	00 00 
 11c:	c1 ef 0b             	shr    $0xb,%edi
 11f:	44 69 c7 34 08 00 00 	imul   $0x834,%edi,%r8d
 126:	48 89 d7             	mov    %rdx,%rdi
 129:	41 2b f8             	sub    %r8d,%edi
 12c:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 130:	c5 fb 2a d7          	vcvtsi2sd %edi,%xmm0,%xmm2
 134:	c5 eb 5e 05 54 03 00 	vdivsd 0x354(%rip),%xmm2,%xmm0        # 0x490
 13b:	00 
 13c:	8d 3c 30             	lea    (%rax,%rsi,1),%edi
 13f:	c4 c1 7b 11 44 3d 00 	vmovsd %xmm0,0x0(%r13,%rdi,1)
 146:	8d 7e 08             	lea    0x8(%rsi),%edi
 149:	81 c2 01 00 00 00    	add    $0x1,%edx
 14f:	81 fe 98 41 00 00    	cmp    $0x4198,%esi
 155:	0f 84 08 00 00 00    	je     0x163
 15b:	48 89 fe             	mov    %rdi,%rsi
 15e:	e9 b0 ff ff ff       	jmp    0x113
 163:	8d 71 01             	lea    0x1(%rcx),%esi
 166:	81 c0 a0 41 00 00    	add    $0x41a0,%eax
 16c:	81 f9 6b 07 00 00    	cmp    $0x76b,%ecx
 172:	0f 84 08 00 00 00    	je     0x180
 178:	48 89 f1             	mov    %rsi,%rcx
 17b:	e9 8e ff ff ff       	jmp    0x10e
 180:	45 33 f6             	xor    %r14d,%r14d
 183:	41 b8 a0 41 00 00    	mov    $0x41a0,%r8d
 189:	4c 89 e2             	mov    %r12,%rdx
 18c:	4c 89 f1             	mov    %r14,%rcx
 18f:	48 8b 34 24          	mov    (%rsp),%rsi
 193:	48 8b 3c 24          	mov    (%rsp),%rdi
 197:	e8 c4 b4 00 00       	call   0xb660
 19c:	44 8b c8             	mov    %eax,%r9d
 19f:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
 1a4:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 1a9:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
 1ae:	46 8d 14 f6          	lea    (%rsi,%r14,8),%r10d
 1b2:	4b c7 44 15 00 00 00 	movq   $0x0,0x0(%r13,%r10,1)
 1b9:	00 00 
 1bb:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 1bf:	33 c9                	xor    %ecx,%ecx
 1c1:	8d 14 0f             	lea    (%rdi,%rcx,1),%edx
 1c4:	c4 c1 7b 10 4c 15 00 	vmovsd 0x0(%r13,%rdx,1),%xmm1
 1cb:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 1d0:	03 d1                	add    %ecx,%edx
 1d2:	c4 c1 7b 10 54 15 00 	vmovsd 0x0(%r13,%rdx,1),%xmm2
 1d9:	c5 f3 59 ca          	vmulsd %xmm2,%xmm1,%xmm1
 1dd:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 1e1:	c4 81 7b 11 44 15 00 	vmovsd %xmm0,0x0(%r13,%r10,1)
 1e8:	8d 51 08             	lea    0x8(%rcx),%edx
 1eb:	81 f9 98 41 00 00    	cmp    $0x4198,%ecx
 1f1:	0f 84 08 00 00 00    	je     0x1ff
 1f7:	48 89 d1             	mov    %rdx,%rcx
 1fa:	e9 c2 ff ff ff       	jmp    0x1c1
 1ff:	c4 81 7b 10 4c 0d 00 	vmovsd 0x0(%r13,%r9,1),%xmm1
 206:	41 69 ce a0 41 00 00 	imul   $0x41a0,%r14d,%ecx
 20d:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 212:	03 ca                	add    %edx,%ecx
 214:	c4 c1 7b 59 44 0d 00 	vmulsd 0x0(%r13,%rcx,1),%xmm0,%xmm0
 21b:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
 21f:	c4 81 7b 11 44 0d 00 	vmovsd %xmm0,0x0(%r13,%r9,1)
 226:	b9 08 00 00 00       	mov    $0x8,%ecx
 22b:	8d 14 08             	lea    (%rax,%rcx,1),%edx
 22e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
 233:	c4 c1 7b 10 44 15 00 	vmovsd 0x0(%r13,%rdx,1),%xmm0
 23a:	c4 81 7b 10 4c 15 00 	vmovsd 0x0(%r13,%r10,1),%xmm1
 241:	8d 04 0f             	lea    (%rdi,%rcx,1),%eax
 244:	c4 c1 73 59 4c 05 00 	vmulsd 0x0(%r13,%rax,1),%xmm1,%xmm1
 24b:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 24f:	c4 c1 7b 11 44 15 00 	vmovsd %xmm0,0x0(%r13,%rdx,1)
 256:	8d 41 08             	lea    0x8(%rcx),%eax
 259:	81 f9 98 41 00 00    	cmp    $0x4198,%ecx
 25f:	0f 84 0d 00 00 00    	je     0x272
 265:	48 89 c1             	mov    %rax,%rcx
 268:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 26d:	e9 b9 ff ff ff       	jmp    0x22b
 272:	41 8d 46 01          	lea    0x1(%r14),%eax
 276:	81 c7 a0 41 00 00    	add    $0x41a0,%edi
 27c:	41 81 fe 6b 07 00 00 	cmp    $0x76b,%r14d
 283:	0f 84 12 00 00 00    	je     0x29b
 289:	49 89 c6             	mov    %rax,%r14
 28c:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
 291:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 296:	e9 0e ff ff ff       	jmp    0x1a9
 29b:	41 8b 9d 8c 04 00 00 	mov    0x48c(%r13),%ebx
 2a2:	ba 00 04 00 00       	mov    $0x400,%edx
 2a7:	b9 16 00 00 00       	mov    $0x16,%ecx
 2ac:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 2b2:	48 8b 34 24          	mov    (%rsp),%rsi
 2b6:	48 8b 3c 24          	mov    (%rsp),%rdi
 2ba:	49 89 d9             	mov    %rbx,%r9
 2bd:	e8 de 3c 00 00       	call   0x3fa0
 2c2:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 2c7:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
 2cc:	48 89 d0             	mov    %rdx,%rax
 2cf:	83 e8 30             	sub    $0x30,%eax
 2d2:	41 c7 44 05 20 26 04 	movl   $0x426,0x20(%r13,%rax,1)
 2d9:	00 00 
 2db:	49 89 c4             	mov    %rax,%r12
 2de:	b9 17 04 00 00       	mov    $0x417,%ecx
 2e3:	44 8d 42 f0          	lea    -0x10(%rdx),%r8d
 2e7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 2ec:	48 8b 34 24          	mov    (%rsp),%rsi
 2f0:	48 8b 3c 24          	mov    (%rsp),%rdi
 2f4:	e8 87 a9 00 00       	call   0xac80
 2f9:	33 db                	xor    %ebx,%ebx
 2fb:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
 300:	48 89 da             	mov    %rbx,%rdx
 303:	81 e2 ff ff 00 00    	and    $0xffff,%edx
 309:	c4 e2 7b f6 05 8e 01 	mulx   0x18e(%rip),%eax,%eax        # 0x4a0
 310:	00 00 
 312:	c1 e8 04             	shr    $0x4,%eax
 315:	6b c0 14             	imul   $0x14,%eax,%eax
 318:	2b d0                	sub    %eax,%edx
 31a:	85 d2                	test   %edx,%edx
 31c:	0f 85 17 00 00 00    	jne    0x339
 322:	ba 0a 00 00 00       	mov    $0xa,%edx
 327:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
 32c:	48 8b 34 24          	mov    (%rsp),%rsi
 330:	48 8b 3c 24          	mov    (%rsp),%rdi
 334:	e8 c7 4a 00 00       	call   0x4e00
 339:	41 8b c7             	mov    %r15d,%eax
 33c:	c4 c1 7b 10 44 05 00 	vmovsd 0x0(%r13,%rax,1),%xmm0
 343:	c4 81 7b 11 44 25 10 	vmovsd %xmm0,0x10(%r13,%r12,1)
 34a:	b9 28 04 00 00       	mov    $0x428,%ecx
 34f:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
 354:	45 8d 46 e0          	lea    -0x20(%r14),%r8d
 358:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 35d:	48 8b 34 24          	mov    (%rsp),%rsi
 361:	48 8b 3c 24          	mov    (%rsp),%rdi
 365:	e8 16 a9 00 00       	call   0xac80
 36a:	8d 4b 01             	lea    0x1(%rbx),%ecx
 36d:	41 81 c7 08 00 00 00 	add    $0x8,%r15d
 374:	81 fb 33 08 00 00    	cmp    $0x833,%ebx
 37a:	0f 84 0d 00 00 00    	je     0x38d
 380:	48 89 cb             	mov    %rcx,%rbx
 383:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
 388:	e9 73 ff ff ff       	jmp    0x300
 38d:	43 c7 44 25 00 26 04 	movl   $0x426,0x0(%r13,%r12,1)
 394:	00 00 
 396:	b9 30 04 00 00       	mov    $0x430,%ecx
 39b:	4d 89 f0             	mov    %r14,%r8
 39e:	41 83 e8 30          	sub    $0x30,%r8d
 3a2:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 3a7:	48 8b 34 24          	mov    (%rsp),%rsi
 3ab:	48 8b 3c 24          	mov    (%rsp),%rdi
 3af:	e8 cc a8 00 00       	call   0xac80
 3b4:	ba 41 04 00 00       	mov    $0x441,%edx
 3b9:	b9 16 00 00 00       	mov    $0x16,%ecx
 3be:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 3c4:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
 3c9:	48 8b 34 24          	mov    (%rsp),%rsi
 3cd:	48 8b 3c 24          	mov    (%rsp),%rdi
 3d1:	e8 ca 3b 00 00       	call   0x3fa0
 3d6:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 3db:	48 8b 34 24          	mov    (%rsp),%rsi
 3df:	48 8b 3c 24          	mov    (%rsp),%rdi
 3e3:	e8 f8 1f 00 00       	call   0x23e0
 3e8:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 3ed:	48 8b 34 24          	mov    (%rsp),%rsi
 3f1:	48 8b 3c 24          	mov    (%rsp),%rdi
 3f5:	e8 e6 1f 00 00       	call   0x23e0
 3fa:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 3ff:	48 8b 34 24          	mov    (%rsp),%rsi
 403:	48 8b 3c 24          	mov    (%rsp),%rdi
 407:	e8 d4 1f 00 00       	call   0x23e0
 40c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 411:	48 8b 34 24          	mov    (%rsp),%rsi
 415:	48 8b 3c 24          	mov    (%rsp),%rdi
 419:	e8 c2 1f 00 00       	call   0x23e0
 41e:	48 8b 3c 24          	mov    (%rsp),%rdi
 422:	44 89 b7 40 01 00 00 	mov    %r14d,0x140(%rdi)
 429:	33 c0                	xor    %eax,%eax
 42b:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
 430:	4c 8b 64 24 48       	mov    0x48(%rsp),%r12
 435:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
 43a:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
 43f:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
 444:	48 83 c4 70          	add    $0x70,%rsp
 448:	48 89 ec             	mov    %rbp,%rsp
 44b:	5d                   	pop    %rbp
 44c:	c3                   	ret
 44d:	0f 0b                	ud2
 44f:	00 00                	add    %al,(%rax)
 451:	00 00                	add    %al,(%rax)
 453:	00 00                	add    %al,(%rax)
 455:	68 a0 40 00 00       	push   $0x40a0
	...
 466:	f0 3f                	lock (bad)
	...
 474:	00 00                	add    %al,(%rax)
 476:	f0 3f                	lock (bad)
	...
 480:	2d 34 a9 f9 00       	sub    $0xf9a934,%eax
	...
 495:	8e c2                	mov    %edx,%es
 497:	40 00 00             	rex add %al,(%rax)
 49a:	00 00                	add    %al,(%rax)
 49c:	00 00                	add    %al,(%rax)
 49e:	00 00                	add    %al,(%rax)
 4a0:	cd cc                	int    $0xcc
 4a2:	cc                   	int3
 4a3:	cc                   	int3
 4a4:	00 00                	add    %al,(%rax)
	...
