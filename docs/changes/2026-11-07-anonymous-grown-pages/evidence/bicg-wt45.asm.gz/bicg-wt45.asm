
work/pr643-research/wt-live-bicg/code-2.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
   8:	4d 8b 52 18          	mov    0x18(%r10),%r10
   c:	49 81 c2 80 00 00 00 	add    $0x80,%r10
  13:	4c 3b d4             	cmp    %rsp,%r10
  16:	0f 87 1e 05 00 00    	ja     0x53a
  1c:	48 83 ec 70          	sub    $0x70,%rsp
  20:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
  25:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  2a:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
  2f:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
  34:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
  39:	8b 8f 40 01 00 00    	mov    0x140(%rdi),%ecx
  3f:	48 89 c8             	mov    %rcx,%rax
  42:	83 e8 60             	sub    $0x60,%eax
  45:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  4a:	89 87 40 01 00 00    	mov    %eax,0x140(%rdi)
  50:	ba f0 e1 3c 00       	mov    $0x3ce1f0,%edx
  55:	41 be 08 00 00 00    	mov    $0x8,%r14d
  5b:	49 89 fc             	mov    %rdi,%r12
  5e:	4c 89 f1             	mov    %r14,%rcx
  61:	4c 89 e6             	mov    %r12,%rsi
  64:	e8 37 05 00 00       	call   0x5a0
  69:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6e:	bb 6c 07 00 00       	mov    $0x76c,%ebx
  73:	4c 89 f1             	mov    %r14,%rcx
  76:	48 89 da             	mov    %rbx,%rdx
  79:	4c 89 e6             	mov    %r12,%rsi
  7c:	4c 89 e7             	mov    %r12,%rdi
  7f:	e8 1c 05 00 00       	call   0x5a0
  84:	49 89 c7             	mov    %rax,%r15
  87:	41 bd 34 08 00 00    	mov    $0x834,%r13d
  8d:	4c 89 f1             	mov    %r14,%rcx
  90:	4c 89 ea             	mov    %r13,%rdx
  93:	4c 89 e6             	mov    %r12,%rsi
  96:	4c 89 e7             	mov    %r12,%rdi
  99:	e8 02 05 00 00       	call   0x5a0
  9e:	48 89 da             	mov    %rbx,%rdx
  a1:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  a6:	4c 89 f1             	mov    %r14,%rcx
  a9:	4c 89 e6             	mov    %r12,%rsi
  ac:	4c 89 e7             	mov    %r12,%rdi
  af:	e8 ec 04 00 00       	call   0x5a0
  b4:	4c 89 f1             	mov    %r14,%rcx
  b7:	4c 89 ea             	mov    %r13,%rdx
  ba:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  bf:	4c 89 e6             	mov    %r12,%rsi
  c2:	4c 89 e7             	mov    %r12,%rdi
  c5:	e8 d6 04 00 00       	call   0x5a0
  ca:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  cf:	33 c9                	xor    %ecx,%ecx
  d1:	4d 8b 6c 24 38       	mov    0x38(%r12),%r13
  d6:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  db:	48 89 ca             	mov    %rcx,%rdx
  de:	81 e2 ff ff 00 00    	and    $0xffff,%edx
  e4:	c4 e2 4b f6 35 53 04 	mulx   0x453(%rip),%esi,%esi        # 0x540
  eb:	00 00 
  ed:	c1 ee 09             	shr    $0x9,%esi
  f0:	69 f6 6c 07 00 00    	imul   $0x76c,%esi,%esi
  f6:	2b d6                	sub    %esi,%edx
  f8:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  fc:	c4 e1 fb 2a c2       	vcvtsi2sd %rdx,%xmm0,%xmm0
 101:	c5 fb 5e 05 47 04 00 	vdivsd 0x447(%rip),%xmm0,%xmm0        # 0x550
 108:	00 
 109:	8b d0                	mov    %eax,%edx
 10b:	c4 c1 7b 11 44 15 00 	vmovsd %xmm0,0x0(%r13,%rdx,1)
 112:	81 c0 08 00 00 00    	add    $0x8,%eax
 118:	8d 51 01             	lea    0x1(%rcx),%edx
 11b:	81 f9 6b 07 00 00    	cmp    $0x76b,%ecx
 121:	0f 84 08 00 00 00    	je     0x12f
 127:	48 89 d1             	mov    %rdx,%rcx
 12a:	e9 ac ff ff ff       	jmp    0xdb
 12f:	33 f6                	xor    %esi,%esi
 131:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 136:	48 89 f2             	mov    %rsi,%rdx
 139:	81 e2 ff ff 00 00    	and    $0xffff,%edx
 13f:	c4 e2 7b f6 05 18 04 	mulx   0x418(%rip),%eax,%eax        # 0x560
 146:	00 00 
 148:	c1 e8 0b             	shr    $0xb,%eax
 14b:	69 c0 34 08 00 00    	imul   $0x834,%eax,%eax
 151:	2b d0                	sub    %eax,%edx
 153:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 157:	c4 e1 fb 2a c2       	vcvtsi2sd %rdx,%xmm0,%xmm0
 15c:	c5 fb 5e 05 0c 04 00 	vdivsd 0x40c(%rip),%xmm0,%xmm0        # 0x570
 163:	00 
 164:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 169:	8d 04 f0             	lea    (%rax,%rsi,8),%eax
 16c:	c4 c1 7b 11 44 05 00 	vmovsd %xmm0,0x0(%r13,%rax,1)
 173:	33 ff                	xor    %edi,%edi
 175:	48 89 f2             	mov    %rsi,%rdx
 178:	c4 e2 7b f6 05 df 03 	mulx   0x3df(%rip),%eax,%eax        # 0x560
 17f:	00 00 
 181:	c1 e8 0b             	shr    $0xb,%eax
 184:	44 69 c0 34 08 00 00 	imul   $0x834,%eax,%r8d
 18b:	48 89 d0             	mov    %rdx,%rax
 18e:	41 2b c0             	sub    %r8d,%eax
 191:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
 195:	c5 fb 2a c0          	vcvtsi2sd %eax,%xmm0,%xmm0
 199:	c5 fb 5e 05 df 03 00 	vdivsd 0x3df(%rip),%xmm0,%xmm0        # 0x580
 1a0:	00 
 1a1:	8d 04 39             	lea    (%rcx,%rdi,1),%eax
 1a4:	c4 c1 7b 11 44 05 00 	vmovsd %xmm0,0x0(%r13,%rax,1)
 1ab:	8d 47 08             	lea    0x8(%rdi),%eax
 1ae:	03 d6                	add    %esi,%edx
 1b0:	81 ff 58 3b 00 00    	cmp    $0x3b58,%edi
 1b6:	0f 84 08 00 00 00    	je     0x1c4
 1bc:	48 89 c7             	mov    %rax,%rdi
 1bf:	e9 b4 ff ff ff       	jmp    0x178
 1c4:	8d 46 01             	lea    0x1(%rsi),%eax
 1c7:	81 c1 60 3b 00 00    	add    $0x3b60,%ecx
 1cd:	81 fe 33 08 00 00    	cmp    $0x833,%esi
 1d3:	0f 84 08 00 00 00    	je     0x1e1
 1d9:	48 89 c6             	mov    %rax,%rsi
 1dc:	e9 55 ff ff ff       	jmp    0x136
 1e1:	45 33 f6             	xor    %r14d,%r14d
 1e4:	41 b8 60 3b 00 00    	mov    $0x3b60,%r8d
 1ea:	4c 89 fa             	mov    %r15,%rdx
 1ed:	4c 89 f1             	mov    %r14,%rcx
 1f0:	4c 89 e6             	mov    %r12,%rsi
 1f3:	4c 89 e7             	mov    %r12,%rdi
 1f6:	e8 45 b5 00 00       	call   0xb740
 1fb:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 200:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 205:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 20a:	42 8d 14 f2          	lea    (%rdx,%r14,8),%edx
 20e:	49 c7 44 15 00 00 00 	movq   $0x0,0x0(%r13,%rdx,1)
 215:	00 00 
 217:	33 ff                	xor    %edi,%edi
 219:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
 21e:	42 8d 34 f6          	lea    (%rsi,%r14,8),%esi
 222:	44 8d 04 38          	lea    (%rax,%rdi,1),%r8d
 226:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
 22b:	c4 81 7b 10 44 05 00 	vmovsd 0x0(%r13,%r8,1),%xmm0
 232:	c4 c1 7b 10 4c 35 00 	vmovsd 0x0(%r13,%rsi,1),%xmm1
 239:	8d 04 39             	lea    (%rcx,%rdi,1),%eax
 23c:	c4 c1 73 59 4c 05 00 	vmulsd 0x0(%r13,%rax,1),%xmm1,%xmm1
 243:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 247:	c4 81 7b 11 44 05 00 	vmovsd %xmm0,0x0(%r13,%r8,1)
 24e:	c4 c1 7b 10 44 15 00 	vmovsd 0x0(%r13,%rdx,1),%xmm0
 255:	c4 c1 7b 10 4c 05 00 	vmovsd 0x0(%r13,%rax,1),%xmm1
 25c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
 261:	03 c7                	add    %edi,%eax
 263:	c4 c1 73 59 4c 05 00 	vmulsd 0x0(%r13,%rax,1),%xmm1,%xmm1
 26a:	c5 fb 58 c1          	vaddsd %xmm1,%xmm0,%xmm0
 26e:	c4 c1 7b 11 44 15 00 	vmovsd %xmm0,0x0(%r13,%rdx,1)
 275:	8d 47 08             	lea    0x8(%rdi),%eax
 278:	81 ff 58 3b 00 00    	cmp    $0x3b58,%edi
 27e:	0f 84 0d 00 00 00    	je     0x291
 284:	48 89 c7             	mov    %rax,%rdi
 287:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 28c:	e9 91 ff ff ff       	jmp    0x222
 291:	41 8d 46 01          	lea    0x1(%r14),%eax
 295:	81 c1 60 3b 00 00    	add    $0x3b60,%ecx
 29b:	41 81 fe 33 08 00 00 	cmp    $0x833,%r14d
 2a2:	0f 84 12 00 00 00    	je     0x2ba
 2a8:	49 89 c6             	mov    %rax,%r14
 2ab:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 2b0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 2b5:	e9 4b ff ff ff       	jmp    0x205
 2ba:	41 8b b5 90 04 00 00 	mov    0x490(%r13),%esi
 2c1:	48 89 34 24          	mov    %rsi,(%rsp)
 2c5:	ba 00 04 00 00       	mov    $0x400,%edx
 2ca:	b9 16 00 00 00       	mov    $0x16,%ecx
 2cf:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 2d5:	4c 89 e6             	mov    %r12,%rsi
 2d8:	4c 89 e7             	mov    %r12,%rdi
 2db:	4c 8b 0c 24          	mov    (%rsp),%r9
 2df:	e8 9c 3d 00 00       	call   0x4080
 2e4:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
 2e9:	48 89 f2             	mov    %rsi,%rdx
 2ec:	83 ea 60             	sub    $0x60,%edx
 2ef:	41 c7 44 15 50 26 04 	movl   $0x426,0x50(%r13,%rdx,1)
 2f6:	00 00 
 2f8:	49 89 d6             	mov    %rdx,%r14
 2fb:	b9 17 04 00 00       	mov    $0x417,%ecx
 300:	44 8d 46 f0          	lea    -0x10(%rsi),%r8d
 304:	48 8b 14 24          	mov    (%rsp),%rdx
 308:	4c 89 e6             	mov    %r12,%rsi
 30b:	4c 89 e7             	mov    %r12,%rdi
 30e:	e8 4d aa 00 00       	call   0xad60
 313:	33 db                	xor    %ebx,%ebx
 315:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
 31a:	48 89 da             	mov    %rbx,%rdx
 31d:	81 e2 ff ff 00 00    	and    $0xffff,%edx
 323:	c4 e2 73 f6 0d 64 02 	mulx   0x264(%rip),%ecx,%ecx        # 0x590
 32a:	00 00 
 32c:	c1 e9 04             	shr    $0x4,%ecx
 32f:	6b c9 14             	imul   $0x14,%ecx,%ecx
 332:	2b d1                	sub    %ecx,%edx
 334:	85 d2                	test   %edx,%edx
 336:	0f 85 14 00 00 00    	jne    0x350
 33c:	ba 0a 00 00 00       	mov    $0xa,%edx
 341:	48 8b 0c 24          	mov    (%rsp),%rcx
 345:	4c 89 e6             	mov    %r12,%rsi
 348:	4c 89 e7             	mov    %r12,%rdi
 34b:	e8 90 4b 00 00       	call   0x4ee0
 350:	41 8b c7             	mov    %r15d,%eax
 353:	c4 c1 7b 10 44 05 00 	vmovsd 0x0(%r13,%rax,1),%xmm0
 35a:	c4 81 7b 11 44 35 40 	vmovsd %xmm0,0x40(%r13,%r14,1)
 361:	b9 28 04 00 00       	mov    $0x428,%ecx
 366:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 36b:	44 8d 40 e0          	lea    -0x20(%rax),%r8d
 36f:	48 8b 14 24          	mov    (%rsp),%rdx
 373:	4c 89 e6             	mov    %r12,%rsi
 376:	4c 89 e7             	mov    %r12,%rdi
 379:	e8 e2 a9 00 00       	call   0xad60
 37e:	8d 4b 01             	lea    0x1(%rbx),%ecx
 381:	41 81 c7 08 00 00 00 	add    $0x8,%r15d
 388:	81 fb 6b 07 00 00    	cmp    $0x76b,%ebx
 38e:	0f 84 08 00 00 00    	je     0x39c
 394:	48 89 cb             	mov    %rcx,%rbx
 397:	e9 7e ff ff ff       	jmp    0x31a
 39c:	43 c7 44 35 30 26 04 	movl   $0x426,0x30(%r13,%r14,1)
 3a3:	00 00 
 3a5:	b9 30 04 00 00       	mov    $0x430,%ecx
 3aa:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 3af:	44 8d 40 d0          	lea    -0x30(%rax),%r8d
 3b3:	48 8b 14 24          	mov    (%rsp),%rdx
 3b7:	4c 89 e6             	mov    %r12,%rsi
 3ba:	4c 89 e7             	mov    %r12,%rdi
 3bd:	e8 9e a9 00 00       	call   0xad60
 3c2:	43 c7 44 35 20 41 04 	movl   $0x441,0x20(%r13,%r14,1)
 3c9:	00 00 
 3cb:	b9 17 04 00 00       	mov    $0x417,%ecx
 3d0:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 3d5:	44 8d 40 c0          	lea    -0x40(%rax),%r8d
 3d9:	48 8b 14 24          	mov    (%rsp),%rdx
 3dd:	4c 89 e6             	mov    %r12,%rsi
 3e0:	4c 89 e7             	mov    %r12,%rdi
 3e3:	e8 78 a9 00 00       	call   0xad60
 3e8:	33 db                	xor    %ebx,%ebx
 3ea:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
 3ef:	48 89 da             	mov    %rbx,%rdx
 3f2:	81 e2 ff ff 00 00    	and    $0xffff,%edx
 3f8:	c4 e2 73 f6 0d 8f 01 	mulx   0x18f(%rip),%ecx,%ecx        # 0x590
 3ff:	00 00 
 401:	c1 e9 04             	shr    $0x4,%ecx
 404:	6b f1 14             	imul   $0x14,%ecx,%esi
 407:	2b d6                	sub    %esi,%edx
 409:	85 d2                	test   %edx,%edx
 40b:	0f 85 14 00 00 00    	jne    0x425
 411:	ba 0a 00 00 00       	mov    $0xa,%edx
 416:	48 8b 0c 24          	mov    (%rsp),%rcx
 41a:	4c 89 e6             	mov    %r12,%rsi
 41d:	4c 89 e7             	mov    %r12,%rdi
 420:	e8 bb 4a 00 00       	call   0x4ee0
 425:	41 8b f7             	mov    %r15d,%esi
 428:	c4 c1 7b 10 74 35 00 	vmovsd 0x0(%r13,%rsi,1),%xmm6
 42f:	c4 81 7b 11 74 35 10 	vmovsd %xmm6,0x10(%r13,%r14,1)
 436:	b9 28 04 00 00       	mov    $0x428,%ecx
 43b:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 440:	44 8d 40 b0          	lea    -0x50(%rax),%r8d
 444:	48 8b 14 24          	mov    (%rsp),%rdx
 448:	4c 89 e6             	mov    %r12,%rsi
 44b:	4c 89 e7             	mov    %r12,%rdi
 44e:	e8 0d a9 00 00       	call   0xad60
 453:	8d 7b 01             	lea    0x1(%rbx),%edi
 456:	41 81 c7 08 00 00 00 	add    $0x8,%r15d
 45d:	81 fb 33 08 00 00    	cmp    $0x833,%ebx
 463:	0f 84 08 00 00 00    	je     0x471
 469:	48 89 fb             	mov    %rdi,%rbx
 46c:	e9 7e ff ff ff       	jmp    0x3ef
 471:	43 c7 44 35 00 41 04 	movl   $0x441,0x0(%r13,%r14,1)
 478:	00 00 
 47a:	b9 30 04 00 00       	mov    $0x430,%ecx
 47f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 484:	49 89 c0             	mov    %rax,%r8
 487:	41 83 e8 60          	sub    $0x60,%r8d
 48b:	48 8b 14 24          	mov    (%rsp),%rdx
 48f:	4c 89 e6             	mov    %r12,%rsi
 492:	4c 89 e7             	mov    %r12,%rdi
 495:	e8 c6 a8 00 00       	call   0xad60
 49a:	ba 43 04 00 00       	mov    $0x443,%edx
 49f:	b9 16 00 00 00       	mov    $0x16,%ecx
 4a4:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 4aa:	4c 8b 0c 24          	mov    (%rsp),%r9
 4ae:	4c 89 e6             	mov    %r12,%rsi
 4b1:	4c 89 e7             	mov    %r12,%rdi
 4b4:	e8 c7 3b 00 00       	call   0x4080
 4b9:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 4be:	4c 89 e6             	mov    %r12,%rsi
 4c1:	4c 89 e7             	mov    %r12,%rdi
 4c4:	e8 f7 1f 00 00       	call   0x24c0
 4c9:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 4ce:	4c 89 e6             	mov    %r12,%rsi
 4d1:	4c 89 e7             	mov    %r12,%rdi
 4d4:	e8 e7 1f 00 00       	call   0x24c0
 4d9:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 4de:	4c 89 e6             	mov    %r12,%rsi
 4e1:	4c 89 e7             	mov    %r12,%rdi
 4e4:	e8 d7 1f 00 00       	call   0x24c0
 4e9:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 4ee:	4c 89 e6             	mov    %r12,%rsi
 4f1:	4c 89 e7             	mov    %r12,%rdi
 4f4:	e8 c7 1f 00 00       	call   0x24c0
 4f9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 4fe:	4c 89 e6             	mov    %r12,%rsi
 501:	4c 89 e7             	mov    %r12,%rdi
 504:	e8 b7 1f 00 00       	call   0x24c0
 509:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
 50e:	41 89 84 24 40 01 00 	mov    %eax,0x140(%r12)
 515:	00 
 516:	33 c0                	xor    %eax,%eax
 518:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
 51d:	4c 8b 64 24 48       	mov    0x48(%rsp),%r12
 522:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
 527:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
 52c:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
 531:	48 83 c4 70          	add    $0x70,%rsp
 535:	48 89 ec             	mov    %rbp,%rsp
 538:	5d                   	pop    %rbp
 539:	c3                   	ret
 53a:	0f 0b                	ud2
 53c:	00 00                	add    %al,(%rax)
 53e:	00 00                	add    %al,(%rax)
 540:	35 3a fc 44 00       	xor    $0x44fc3a,%eax
	...
 555:	b0 9d                	mov    $0x9d,%al
 557:	40 00 00             	rex add %al,(%rax)
 55a:	00 00                	add    %al,(%rax)
 55c:	00 00                	add    %al,(%rax)
 55e:	00 00                	add    %al,(%rax)
 560:	2d 34 a9 f9 00       	sub    $0xf9a934,%eax
	...
 575:	68 a0 40 00 00       	push   $0x40a0
	...
 582:	00 00                	add    %al,(%rax)
 584:	00 68 a0             	add    %ch,-0x60(%rax)
 587:	40 00 00             	rex add %al,(%rax)
 58a:	00 00                	add    %al,(%rax)
 58c:	00 00                	add    %al,(%rax)
 58e:	00 00                	add    %al,(%rax)
 590:	cd cc                	int    $0xcc
 592:	cc                   	int3
 593:	cc                   	int3
 594:	00 00                	add    %al,(%rax)
	...
