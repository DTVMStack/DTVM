
/workspace/DTVM/work/pr643-research/native-atax-canonical-on/func-2-greedy.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	41 57                	push   %r15
   6:	41 56                	push   %r14
   8:	41 55                	push   %r13
   a:	41 54                	push   %r12
   c:	53                   	push   %rbx
   d:	48 83 ec 48          	sub    $0x48,%rsp
  11:	48 89 fb             	mov    %rdi,%rbx
  14:	48 b8 00 00 00 00 00 	movabs $0x40a0680000000000,%rax
  1b:	68 a0 40 
  1e:	66 48 0f 6e c0       	movq   %rax,%xmm0
  23:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
  28:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
  2f:	00 f0 3f 
  32:	66 48 0f 6e c0       	movq   %rax,%xmm0
  37:	f2 0f 11 45 90       	movsd  %xmm0,-0x70(%rbp)
  3c:	48 b8 00 00 00 00 00 	movabs $0x40c28e0000000000,%rax
  43:	8e c2 40 
  46:	66 48 0f 6e c0       	movq   %rax,%xmm0
  4b:	f2 0f 11 45 a0       	movsd  %xmm0,-0x60(%rbp)
  50:	31 c0                	xor    %eax,%eax
  52:	31 c0                	xor    %eax,%eax
  54:	31 c0                	xor    %eax,%eax
  56:	31 c0                	xor    %eax,%eax
  58:	31 c0                	xor    %eax,%eax
  5a:	31 c0                	xor    %eax,%eax
  5c:	31 c0                	xor    %eax,%eax
  5e:	31 c0                	xor    %eax,%eax
  60:	31 c0                	xor    %eax,%eax
  62:	31 c0                	xor    %eax,%eax
  64:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
  6b:	ff 
  6c:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  73:	8b 83 78 11 00 00    	mov    0x1178(%rbx),%eax
  79:	8d 48 d0             	lea    -0x30(%rax),%ecx
  7c:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
  80:	8d 40 d0             	lea    -0x30(%rax),%eax
  83:	89 83 78 11 00 00    	mov    %eax,0x1178(%rbx)
  89:	45 31 e4             	xor    %r12d,%r12d
  8c:	be f0 e1 3c 00       	mov    $0x3ce1f0,%esi
  91:	ba 08 00 00 00       	mov    $0x8,%edx
  96:	48 89 df             	mov    %rbx,%rdi
  99:	e8 80 1f ff ff       	call   0xffffffffffff201e
  9e:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
  a2:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  a9:	be 34 08 00 00       	mov    $0x834,%esi
  ae:	ba 08 00 00 00       	mov    $0x8,%edx
  b3:	48 89 df             	mov    %rbx,%rdi
  b6:	e8 63 1f ff ff       	call   0xffffffffffff201e
  bb:	41 89 c6             	mov    %eax,%r14d
  be:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  c5:	be 34 08 00 00       	mov    $0x834,%esi
  ca:	ba 08 00 00 00       	mov    $0x8,%edx
  cf:	48 89 df             	mov    %rbx,%rdi
  d2:	e8 47 1f ff ff       	call   0xffffffffffff201e
  d7:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
  db:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  e2:	be 6c 07 00 00       	mov    $0x76c,%esi
  e7:	ba 08 00 00 00       	mov    $0x8,%edx
  ec:	48 89 df             	mov    %rbx,%rdi
  ef:	e8 2a 1f ff ff       	call   0xffffffffffff201e
  f4:	f2 0f 10 5d 90       	movsd  -0x70(%rbp),%xmm3
  f9:	f2 0f 10 55 98       	movsd  -0x68(%rbp),%xmm2
  fe:	0f 57 c9             	xorps  %xmm1,%xmm1
 101:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 105:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 10c:	43 8d 0c 26          	lea    (%r14,%r12,1),%ecx
 110:	0f 28 c1             	movaps %xmm1,%xmm0
 113:	f2 0f 5e c2          	divsd  %xmm2,%xmm0
 117:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
 11b:	f2 0f 11 04 08       	movsd  %xmm0,(%rax,%rcx,1)
 120:	f2 0f 58 cb          	addsd  %xmm3,%xmm1
 124:	45 8d 64 24 08       	lea    0x8(%r12),%r12d
 129:	41 81 fc a0 41 00 00 	cmp    $0x41a0,%r12d
 130:	75 da                	jne    0x10c
 132:	4c 89 75 b8          	mov    %r14,-0x48(%rbp)
 136:	45 31 ff             	xor    %r15d,%r15d
 139:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 13d:	f2 0f 10 4d a0       	movsd  -0x60(%rbp),%xmm1
 142:	45 31 ed             	xor    %r13d,%r13d
 145:	45 89 fc             	mov    %r15d,%r12d
 148:	44 89 e1             	mov    %r12d,%ecx
 14b:	48 ba 2d 34 a9 f9 00 	movabs $0xf9a9342d,%rdx
 152:	00 00 00 
 155:	48 0f af ca          	imul   %rdx,%rcx
 159:	48 c1 e9 2b          	shr    $0x2b,%rcx
 15d:	89 c9                	mov    %ecx,%ecx
 15f:	43 8d 14 2e          	lea    (%r14,%r13,1),%edx
 163:	69 c9 34 08 00 00    	imul   $0x834,%ecx,%ecx
 169:	44 89 e6             	mov    %r12d,%esi
 16c:	29 ce                	sub    %ecx,%esi
 16e:	0f 57 c0             	xorps  %xmm0,%xmm0
 171:	f2 0f 2a c6          	cvtsi2sd %esi,%xmm0
 175:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 179:	f2 0f 11 04 10       	movsd  %xmm0,(%rax,%rdx,1)
 17e:	45 8d 64 24 01       	lea    0x1(%r12),%r12d
 183:	45 8d 6d 08          	lea    0x8(%r13),%r13d
 187:	41 81 fd a0 41 00 00 	cmp    $0x41a0,%r13d
 18e:	75 b8                	jne    0x148
 190:	45 8d b6 a0 41 00 00 	lea    0x41a0(%r14),%r14d
 197:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 19b:	41 81 ff 6c 07 00 00 	cmp    $0x76c,%r15d
 1a2:	75 9e                	jne    0x142
 1a4:	48 89 5d d0          	mov    %rbx,-0x30(%rbp)
 1a8:	31 db                	xor    %ebx,%ebx
 1aa:	31 d2                	xor    %edx,%edx
 1ac:	b9 a0 41 00 00       	mov    $0x41a0,%ecx
 1b1:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1b5:	4c 89 ff             	mov    %r15,%rdi
 1b8:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1bc:	e8 f7 1f ff ff       	call   0xffffffffffff21b8
 1c1:	41 89 c6             	mov    %eax,%r14d
 1c4:	49 8b 87 b8 11 00 00 	mov    0x11b8(%r15),%rax
 1cb:	4c 8b 6d c0          	mov    -0x40(%rbp),%r13
 1cf:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
 1d3:	89 d9                	mov    %ebx,%ecx
 1d5:	c1 e1 03             	shl    $0x3,%ecx
 1d8:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 1dc:	44 8d 3c 0a          	lea    (%rdx,%rcx,1),%r15d
 1e0:	31 c9                	xor    %ecx,%ecx
 1e2:	4a 89 0c 38          	mov    %rcx,(%rax,%r15,1)
 1e6:	69 cb a0 41 00 00    	imul   $0x41a0,%ebx,%ecx
 1ec:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 1f0:	8d 14 0a             	lea    (%rdx,%rcx,1),%edx
 1f3:	0f 57 d2             	xorps  %xmm2,%xmm2
 1f6:	45 31 e4             	xor    %r12d,%r12d
 1f9:	43 8d 4c 25 00       	lea    0x0(%r13,%r12,1),%ecx
 1fe:	f2 0f 10 04 08       	movsd  (%rax,%rcx,1),%xmm0
 203:	42 8d 0c 26          	lea    (%rsi,%r12,1),%ecx
 207:	f2 0f 10 0c 08       	movsd  (%rax,%rcx,1),%xmm1
 20c:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
 210:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
 214:	f2 42 0f 11 14 38    	movsd  %xmm2,(%rax,%r15,1)
 21a:	45 8d 64 24 08       	lea    0x8(%r12),%r12d
 21f:	41 81 fc a0 41 00 00 	cmp    $0x41a0,%r12d
 226:	75 d1                	jne    0x1f9
 228:	f2 42 0f 10 04 30    	movsd  (%rax,%r14,1),%xmm0
 22e:	f2 0f 10 0c 10       	movsd  (%rax,%rdx,1),%xmm1
 233:	f2 0f 59 d1          	mulsd  %xmm1,%xmm2
 237:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
 23b:	f2 42 0f 11 04 30    	movsd  %xmm0,(%rax,%r14,1)
 241:	41 bc 08 00 00 00    	mov    $0x8,%r12d
 247:	43 8d 14 26          	lea    (%r14,%r12,1),%edx
 24b:	f2 0f 10 04 10       	movsd  (%rax,%rdx,1),%xmm0
 250:	f2 42 0f 10 0c 38    	movsd  (%rax,%r15,1),%xmm1
 256:	43 8d 4c 25 00       	lea    0x0(%r13,%r12,1),%ecx
 25b:	f2 0f 10 14 08       	movsd  (%rax,%rcx,1),%xmm2
 260:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
 264:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 268:	f2 0f 11 04 10       	movsd  %xmm0,(%rax,%rdx,1)
 26d:	45 8d 64 24 08       	lea    0x8(%r12),%r12d
 272:	41 81 fc a0 41 00 00 	cmp    $0x41a0,%r12d
 279:	75 cc                	jne    0x247
 27b:	45 8d ad a0 41 00 00 	lea    0x41a0(%r13),%r13d
 282:	8d 5b 01             	lea    0x1(%rbx),%ebx
 285:	81 fb 6c 07 00 00    	cmp    $0x76c,%ebx
 28b:	0f 85 42 ff ff ff    	jne    0x1d3
 291:	45 31 e4             	xor    %r12d,%r12d
 294:	44 8b a8 8c 04 00 00 	mov    0x48c(%rax),%r13d
 29b:	be 00 04 00 00       	mov    $0x400,%esi
 2a0:	ba 16 00 00 00       	mov    $0x16,%edx
 2a5:	b9 01 00 00 00       	mov    $0x1,%ecx
 2aa:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 2ae:	48 89 df             	mov    %rbx,%rdi
 2b1:	45 89 e8             	mov    %r13d,%r8d
 2b4:	e8 23 1e ff ff       	call   0xffffffffffff20dc
 2b9:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 2c0:	b9 26 04 00 00       	mov    $0x426,%ecx
 2c5:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
 2c9:	48 89 d6             	mov    %rdx,%rsi
 2cc:	89 4c 30 20          	mov    %ecx,0x20(%rax,%rsi,1)
 2d0:	ba 17 04 00 00       	mov    $0x417,%edx
 2d5:	8d 4e 20             	lea    0x20(%rsi),%ecx
 2d8:	48 89 df             	mov    %rbx,%rdi
 2db:	44 89 ee             	mov    %r13d,%esi
 2de:	e8 8f 1e ff ff       	call   0xffffffffffff2172
 2e3:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 2ea:	45 89 f7             	mov    %r14d,%r15d
 2ed:	44 89 e0             	mov    %r12d,%eax
 2f0:	25 ff ff 00 00       	and    $0xffff,%eax
 2f5:	be 14 00 00 00       	mov    $0x14,%esi
 2fa:	31 d2                	xor    %edx,%edx
 2fc:	f7 f6                	div    %esi
 2fe:	85 d2                	test   %edx,%edx
 300:	75 17                	jne    0x319
 302:	be 0a 00 00 00       	mov    $0xa,%esi
 307:	48 89 df             	mov    %rbx,%rdi
 30a:	44 89 ea             	mov    %r13d,%edx
 30d:	e8 1a 1e ff ff       	call   0xffffffffffff212c
 312:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 319:	f2 42 0f 10 04 39    	movsd  (%rcx,%r15,1),%xmm0
 31f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 323:	f2 0f 11 44 01 10    	movsd  %xmm0,0x10(%rcx,%rax,1)
 329:	ba 28 04 00 00       	mov    $0x428,%edx
 32e:	8d 48 10             	lea    0x10(%rax),%ecx
 331:	48 89 df             	mov    %rbx,%rdi
 334:	44 89 ee             	mov    %r13d,%esi
 337:	e8 36 1e ff ff       	call   0xffffffffffff2172
 33c:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 343:	45 8d 7f 08          	lea    0x8(%r15),%r15d
 347:	45 8d 64 24 01       	lea    0x1(%r12),%r12d
 34c:	41 81 fc 34 08 00 00 	cmp    $0x834,%r12d
 353:	75 98                	jne    0x2ed
 355:	b8 26 04 00 00       	mov    $0x426,%eax
 35a:	4c 8b 7d c8          	mov    -0x38(%rbp),%r15
 35e:	42 89 04 39          	mov    %eax,(%rcx,%r15,1)
 362:	ba 30 04 00 00       	mov    $0x430,%edx
 367:	48 89 df             	mov    %rbx,%rdi
 36a:	44 89 ee             	mov    %r13d,%esi
 36d:	44 89 f9             	mov    %r15d,%ecx
 370:	e8 fd 1d ff ff       	call   0xffffffffffff2172
 375:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 37c:	be 41 04 00 00       	mov    $0x441,%esi
 381:	ba 16 00 00 00       	mov    $0x16,%edx
 386:	b9 01 00 00 00       	mov    $0x1,%ecx
 38b:	48 89 df             	mov    %rbx,%rdi
 38e:	45 89 e8             	mov    %r13d,%r8d
 391:	e8 46 1d ff ff       	call   0xffffffffffff20dc
 396:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 39d:	48 89 df             	mov    %rbx,%rdi
 3a0:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 3a4:	e8 93 1c ff ff       	call   0xffffffffffff203c
 3a9:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 3b0:	48 89 df             	mov    %rbx,%rdi
 3b3:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
 3b7:	e8 80 1c ff ff       	call   0xffffffffffff203c
 3bc:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 3c3:	48 89 df             	mov    %rbx,%rdi
 3c6:	44 89 f6             	mov    %r14d,%esi
 3c9:	e8 6e 1c ff ff       	call   0xffffffffffff203c
 3ce:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 3d5:	48 89 df             	mov    %rbx,%rdi
 3d8:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
 3dc:	e8 5b 1c ff ff       	call   0xffffffffffff203c
 3e1:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 3e8:	41 8d 47 30          	lea    0x30(%r15),%eax
 3ec:	89 83 78 11 00 00    	mov    %eax,0x1178(%rbx)
 3f2:	31 c0                	xor    %eax,%eax
 3f4:	48 83 c4 48          	add    $0x48,%rsp
 3f8:	5b                   	pop    %rbx
 3f9:	41 5c                	pop    %r12
 3fb:	41 5d                	pop    %r13
 3fd:	41 5e                	pop    %r14
 3ff:	41 5f                	pop    %r15
 401:	5d                   	pop    %rbp
 402:	c3                   	ret
