
/workspace/DTVM/work/pr643-research/native-bicg-canonical-on/func-2-greedy.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	55                   	push   %rbp
   1:	48 89 e5             	mov    %rsp,%rbp
   4:	41 57                	push   %r15
   6:	41 56                	push   %r14
   8:	41 55                	push   %r13
   a:	41 54                	push   %r12
   c:	53                   	push   %rbx
   d:	48 83 ec 48          	sub    $0x48,%rsp
  11:	48 89 fb             	mov    %rdi,%rbx
  14:	48 b8 00 00 00 00 00 	movabs $0x409db00000000000,%rax
  1b:	b0 9d 40 
  1e:	66 48 0f 6e c0       	movq   %rax,%xmm0
  23:	f2 0f 11 45 98       	movsd  %xmm0,-0x68(%rbp)
  28:	48 b8 00 00 00 00 00 	movabs $0x40a0680000000000,%rax
  2f:	68 a0 40 
  32:	66 48 0f 6e c0       	movq   %rax,%xmm0
  37:	f2 0f 11 45 a0       	movsd  %xmm0,-0x60(%rbp)
  3c:	31 c0                	xor    %eax,%eax
  3e:	31 c0                	xor    %eax,%eax
  40:	31 c0                	xor    %eax,%eax
  42:	31 c0                	xor    %eax,%eax
  44:	31 c0                	xor    %eax,%eax
  46:	31 c0                	xor    %eax,%eax
  48:	31 c0                	xor    %eax,%eax
  4a:	31 c0                	xor    %eax,%eax
  4c:	31 c0                	xor    %eax,%eax
  4e:	31 c0                	xor    %eax,%eax
  50:	31 c0                	xor    %eax,%eax
  52:	31 c0                	xor    %eax,%eax
  54:	48 8b 84 e4 00 c0 ff 	mov    -0x4000(%rsp,%riz,8),%rax
  5b:	ff 
  5c:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  63:	8b 83 78 11 00 00    	mov    0x1178(%rbx),%eax
  69:	44 8d 70 a0          	lea    -0x60(%rax),%r14d
  6d:	8d 40 a0             	lea    -0x60(%rax),%eax
  70:	89 83 78 11 00 00    	mov    %eax,0x1178(%rbx)
  76:	45 31 ed             	xor    %r13d,%r13d
  79:	be f0 e1 3c 00       	mov    $0x3ce1f0,%esi
  7e:	ba 08 00 00 00       	mov    $0x8,%edx
  83:	48 89 df             	mov    %rbx,%rdi
  86:	e8 93 1f ff ff       	call   0xffffffffffff201e
  8b:	89 45 cc             	mov    %eax,-0x34(%rbp)
  8e:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  95:	be 6c 07 00 00       	mov    $0x76c,%esi
  9a:	ba 08 00 00 00       	mov    $0x8,%edx
  9f:	48 89 df             	mov    %rbx,%rdi
  a2:	e8 77 1f ff ff       	call   0xffffffffffff201e
  a7:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
  ab:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  b2:	be 34 08 00 00       	mov    $0x834,%esi
  b7:	ba 08 00 00 00       	mov    $0x8,%edx
  bc:	48 89 df             	mov    %rbx,%rdi
  bf:	e8 5a 1f ff ff       	call   0xffffffffffff201e
  c4:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
  c8:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  cf:	be 6c 07 00 00       	mov    $0x76c,%esi
  d4:	ba 08 00 00 00       	mov    $0x8,%edx
  d9:	48 89 df             	mov    %rbx,%rdi
  dc:	e8 3d 1f ff ff       	call   0xffffffffffff201e
  e1:	41 89 c7             	mov    %eax,%r15d
  e4:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
  eb:	be 34 08 00 00       	mov    $0x834,%esi
  f0:	ba 08 00 00 00       	mov    $0x8,%edx
  f5:	48 89 df             	mov    %rbx,%rdi
  f8:	e8 21 1f ff ff       	call   0xffffffffffff201e
  fd:	f2 0f 10 4d 98       	movsd  -0x68(%rbp),%xmm1
 102:	4d 89 f8             	mov    %r15,%r8
 105:	41 89 c1             	mov    %eax,%r9d
 108:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 10f:	45 89 c7             	mov    %r8d,%r15d
 112:	44 89 e8             	mov    %r13d,%eax
 115:	25 ff ff 00 00       	and    $0xffff,%eax
 11a:	be 6c 07 00 00       	mov    $0x76c,%esi
 11f:	31 d2                	xor    %edx,%edx
 121:	f7 f6                	div    %esi
 123:	0f 57 c0             	xorps  %xmm0,%xmm0
 126:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
 12b:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 12f:	f2 42 0f 11 04 39    	movsd  %xmm0,(%rcx,%r15,1)
 135:	45 8d 7f 08          	lea    0x8(%r15),%r15d
 139:	45 8d 6d 01          	lea    0x1(%r13),%r13d
 13d:	41 81 fd 6c 07 00 00 	cmp    $0x76c,%r13d
 144:	75 cc                	jne    0x112
 146:	45 31 ff             	xor    %r15d,%r15d
 149:	8b 45 cc             	mov    -0x34(%rbp),%eax
 14c:	89 c6                	mov    %eax,%esi
 14e:	f2 0f 10 4d a0       	movsd  -0x60(%rbp),%xmm1
 153:	44 89 f8             	mov    %r15d,%eax
 156:	25 ff ff 00 00       	and    $0xffff,%eax
 15b:	bf 34 08 00 00       	mov    $0x834,%edi
 160:	31 d2                	xor    %edx,%edx
 162:	f7 f7                	div    %edi
 164:	44 89 f8             	mov    %r15d,%eax
 167:	c1 e0 03             	shl    $0x3,%eax
 16a:	41 8d 04 01          	lea    (%r9,%rax,1),%eax
 16e:	0f 57 c0             	xorps  %xmm0,%xmm0
 171:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
 176:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 17a:	f2 0f 11 04 01       	movsd  %xmm0,(%rcx,%rax,1)
 17f:	45 89 fd             	mov    %r15d,%r13d
 182:	45 31 e4             	xor    %r12d,%r12d
 185:	44 89 e8             	mov    %r13d,%eax
 188:	48 ba 2d 34 a9 f9 00 	movabs $0xf9a9342d,%rdx
 18f:	00 00 00 
 192:	48 0f af c2          	imul   %rdx,%rax
 196:	48 c1 e8 2b          	shr    $0x2b,%rax
 19a:	89 c0                	mov    %eax,%eax
 19c:	42 8d 14 26          	lea    (%rsi,%r12,1),%edx
 1a0:	69 c0 34 08 00 00    	imul   $0x834,%eax,%eax
 1a6:	44 89 ef             	mov    %r13d,%edi
 1a9:	29 c7                	sub    %eax,%edi
 1ab:	0f 57 c0             	xorps  %xmm0,%xmm0
 1ae:	f2 0f 2a c7          	cvtsi2sd %edi,%xmm0
 1b2:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
 1b6:	f2 0f 11 04 11       	movsd  %xmm0,(%rcx,%rdx,1)
 1bb:	47 8d 6c 3d 00       	lea    0x0(%r13,%r15,1),%r13d
 1c0:	45 8d 64 24 08       	lea    0x8(%r12),%r12d
 1c5:	41 81 fc 60 3b 00 00 	cmp    $0x3b60,%r12d
 1cc:	75 b7                	jne    0x185
 1ce:	8d b6 60 3b 00 00    	lea    0x3b60(%rsi),%esi
 1d4:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 1d8:	41 81 ff 34 08 00 00 	cmp    $0x834,%r15d
 1df:	0f 85 6e ff ff ff    	jne    0x153
 1e5:	4c 89 4d a8          	mov    %r9,-0x58(%rbp)
 1e9:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 1ed:	4c 89 75 d0          	mov    %r14,-0x30(%rbp)
 1f1:	45 31 f6             	xor    %r14d,%r14d
 1f4:	31 d2                	xor    %edx,%edx
 1f6:	b9 60 3b 00 00       	mov    $0x3b60,%ecx
 1fb:	48 89 df             	mov    %rbx,%rdi
 1fe:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 202:	e8 b1 1f ff ff       	call   0xffffffffffff21b8
 207:	48 8b bb b8 11 00 00 	mov    0x11b8(%rbx),%rdi
 20e:	8b 4d cc             	mov    -0x34(%rbp),%ecx
 211:	41 89 cc             	mov    %ecx,%r12d
 214:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 218:	4c 8b 4d a8          	mov    -0x58(%rbp),%r9
 21c:	45 89 f5             	mov    %r14d,%r13d
 21f:	41 c1 e5 03          	shl    $0x3,%r13d
 223:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 227:	46 8d 3c 29          	lea    (%rcx,%r13,1),%r15d
 22b:	31 c9                	xor    %ecx,%ecx
 22d:	4a 89 0c 3f          	mov    %rcx,(%rdi,%r15,1)
 231:	43 8d 0c 29          	lea    (%r9,%r13,1),%ecx
 235:	45 31 ed             	xor    %r13d,%r13d
 238:	42 8d 14 28          	lea    (%rax,%r13,1),%edx
 23c:	89 d6                	mov    %edx,%esi
 23e:	f2 0f 10 04 37       	movsd  (%rdi,%rsi,1),%xmm0
 243:	f2 0f 10 0c 0f       	movsd  (%rdi,%rcx,1),%xmm1
 248:	43 8d 34 2c          	lea    (%r12,%r13,1),%esi
 24c:	f2 0f 10 14 37       	movsd  (%rdi,%rsi,1),%xmm2
 251:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
 255:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 259:	f2 0f 11 04 17       	movsd  %xmm0,(%rdi,%rdx,1)
 25e:	f2 42 0f 10 04 3f    	movsd  (%rdi,%r15,1),%xmm0
 264:	f2 0f 10 0c 37       	movsd  (%rdi,%rsi,1),%xmm1
 269:	43 8d 14 28          	lea    (%r8,%r13,1),%edx
 26d:	f2 0f 10 14 17       	movsd  (%rdi,%rdx,1),%xmm2
 272:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
 276:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
 27a:	f2 42 0f 11 04 3f    	movsd  %xmm0,(%rdi,%r15,1)
 280:	45 8d 6d 08          	lea    0x8(%r13),%r13d
 284:	41 81 fd 60 3b 00 00 	cmp    $0x3b60,%r13d
 28b:	75 ab                	jne    0x238
 28d:	45 8d a4 24 60 3b 00 	lea    0x3b60(%r12),%r12d
 294:	00 
 295:	45 8d 76 01          	lea    0x1(%r14),%r14d
 299:	41 81 fe 34 08 00 00 	cmp    $0x834,%r14d
 2a0:	0f 85 76 ff ff ff    	jne    0x21c
 2a6:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 2aa:	45 31 ff             	xor    %r15d,%r15d
 2ad:	44 8b af 90 04 00 00 	mov    0x490(%rdi),%r13d
 2b4:	be 00 04 00 00       	mov    $0x400,%esi
 2b9:	ba 16 00 00 00       	mov    $0x16,%edx
 2be:	b9 01 00 00 00       	mov    $0x1,%ecx
 2c3:	48 89 df             	mov    %rbx,%rdi
 2c6:	45 89 e8             	mov    %r13d,%r8d
 2c9:	e8 0e 1e ff ff       	call   0xffffffffffff20dc
 2ce:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 2d5:	b9 26 04 00 00       	mov    $0x426,%ecx
 2da:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 2de:	42 89 4c 30 50       	mov    %ecx,0x50(%rax,%r14,1)
 2e3:	ba 17 04 00 00       	mov    $0x417,%edx
 2e8:	41 8d 4e 50          	lea    0x50(%r14),%ecx
 2ec:	48 89 df             	mov    %rbx,%rdi
 2ef:	44 89 ee             	mov    %r13d,%esi
 2f2:	e8 7b 1e ff ff       	call   0xffffffffffff2172
 2f7:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 2fe:	4c 8b 65 c0          	mov    -0x40(%rbp),%r12
 302:	44 89 f8             	mov    %r15d,%eax
 305:	25 ff ff 00 00       	and    $0xffff,%eax
 30a:	be 14 00 00 00       	mov    $0x14,%esi
 30f:	31 d2                	xor    %edx,%edx
 311:	f7 f6                	div    %esi
 313:	85 d2                	test   %edx,%edx
 315:	75 17                	jne    0x32e
 317:	be 0a 00 00 00       	mov    $0xa,%esi
 31c:	48 89 df             	mov    %rbx,%rdi
 31f:	44 89 ea             	mov    %r13d,%edx
 322:	e8 05 1e ff ff       	call   0xffffffffffff212c
 327:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 32e:	f2 42 0f 10 04 21    	movsd  (%rcx,%r12,1),%xmm0
 334:	f2 42 0f 11 44 31 40 	movsd  %xmm0,0x40(%rcx,%r14,1)
 33b:	ba 28 04 00 00       	mov    $0x428,%edx
 340:	41 8d 4e 40          	lea    0x40(%r14),%ecx
 344:	48 89 df             	mov    %rbx,%rdi
 347:	44 89 ee             	mov    %r13d,%esi
 34a:	e8 23 1e ff ff       	call   0xffffffffffff2172
 34f:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 356:	45 8d 64 24 08       	lea    0x8(%r12),%r12d
 35b:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 35f:	41 81 ff 6c 07 00 00 	cmp    $0x76c,%r15d
 366:	75 9a                	jne    0x302
 368:	b8 26 04 00 00       	mov    $0x426,%eax
 36d:	42 89 44 31 30       	mov    %eax,0x30(%rcx,%r14,1)
 372:	ba 30 04 00 00       	mov    $0x430,%edx
 377:	41 8d 4e 30          	lea    0x30(%r14),%ecx
 37b:	48 89 df             	mov    %rbx,%rdi
 37e:	44 89 ee             	mov    %r13d,%esi
 381:	e8 ec 1d ff ff       	call   0xffffffffffff2172
 386:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 38d:	b9 41 04 00 00       	mov    $0x441,%ecx
 392:	42 89 4c 30 20       	mov    %ecx,0x20(%rax,%r14,1)
 397:	ba 17 04 00 00       	mov    $0x417,%edx
 39c:	41 8d 4e 20          	lea    0x20(%r14),%ecx
 3a0:	48 89 df             	mov    %rbx,%rdi
 3a3:	44 89 ee             	mov    %r13d,%esi
 3a6:	e8 c7 1d ff ff       	call   0xffffffffffff2172
 3ab:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 3b2:	45 31 ff             	xor    %r15d,%r15d
 3b5:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 3b9:	44 89 f8             	mov    %r15d,%eax
 3bc:	25 ff ff 00 00       	and    $0xffff,%eax
 3c1:	be 14 00 00 00       	mov    $0x14,%esi
 3c6:	31 d2                	xor    %edx,%edx
 3c8:	f7 f6                	div    %esi
 3ca:	85 d2                	test   %edx,%edx
 3cc:	75 17                	jne    0x3e5
 3ce:	be 0a 00 00 00       	mov    $0xa,%esi
 3d3:	48 89 df             	mov    %rbx,%rdi
 3d6:	44 89 ea             	mov    %r13d,%edx
 3d9:	e8 4e 1d ff ff       	call   0xffffffffffff212c
 3de:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 3e5:	f2 42 0f 10 04 21    	movsd  (%rcx,%r12,1),%xmm0
 3eb:	f2 42 0f 11 44 31 10 	movsd  %xmm0,0x10(%rcx,%r14,1)
 3f2:	ba 28 04 00 00       	mov    $0x428,%edx
 3f7:	41 8d 4e 10          	lea    0x10(%r14),%ecx
 3fb:	48 89 df             	mov    %rbx,%rdi
 3fe:	44 89 ee             	mov    %r13d,%esi
 401:	e8 6c 1d ff ff       	call   0xffffffffffff2172
 406:	48 8b 8b b8 11 00 00 	mov    0x11b8(%rbx),%rcx
 40d:	45 8d 64 24 08       	lea    0x8(%r12),%r12d
 412:	45 8d 7f 01          	lea    0x1(%r15),%r15d
 416:	41 81 ff 34 08 00 00 	cmp    $0x834,%r15d
 41d:	75 9a                	jne    0x3b9
 41f:	b8 41 04 00 00       	mov    $0x441,%eax
 424:	42 89 04 31          	mov    %eax,(%rcx,%r14,1)
 428:	ba 30 04 00 00       	mov    $0x430,%edx
 42d:	48 89 df             	mov    %rbx,%rdi
 430:	44 89 ee             	mov    %r13d,%esi
 433:	44 89 f1             	mov    %r14d,%ecx
 436:	e8 37 1d ff ff       	call   0xffffffffffff2172
 43b:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 442:	be 43 04 00 00       	mov    $0x443,%esi
 447:	ba 16 00 00 00       	mov    $0x16,%edx
 44c:	b9 01 00 00 00       	mov    $0x1,%ecx
 451:	48 89 df             	mov    %rbx,%rdi
 454:	45 89 e8             	mov    %r13d,%r8d
 457:	e8 80 1c ff ff       	call   0xffffffffffff20dc
 45c:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 463:	48 89 df             	mov    %rbx,%rdi
 466:	8b 75 cc             	mov    -0x34(%rbp),%esi
 469:	e8 ce 1b ff ff       	call   0xffffffffffff203c
 46e:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 475:	48 89 df             	mov    %rbx,%rdi
 478:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 47c:	e8 bb 1b ff ff       	call   0xffffffffffff203c
 481:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 488:	48 89 df             	mov    %rbx,%rdi
 48b:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
 48f:	e8 a8 1b ff ff       	call   0xffffffffffff203c
 494:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 49b:	48 89 df             	mov    %rbx,%rdi
 49e:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
 4a2:	e8 95 1b ff ff       	call   0xffffffffffff203c
 4a7:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 4ae:	48 89 df             	mov    %rbx,%rdi
 4b1:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 4b5:	e8 82 1b ff ff       	call   0xffffffffffff203c
 4ba:	48 8b 83 b8 11 00 00 	mov    0x11b8(%rbx),%rax
 4c1:	41 8d 46 60          	lea    0x60(%r14),%eax
 4c5:	89 83 78 11 00 00    	mov    %eax,0x1178(%rbx)
 4cb:	31 c0                	xor    %eax,%eax
 4cd:	48 83 c4 48          	add    $0x48,%rsp
 4d1:	5b                   	pop    %rbx
 4d2:	41 5c                	pop    %r12
 4d4:	41 5d                	pop    %r13
 4d6:	41 5e                	pop    %r14
 4d8:	41 5f                	pop    %r15
 4da:	5d                   	pop    %rbp
 4db:	c3                   	ret
